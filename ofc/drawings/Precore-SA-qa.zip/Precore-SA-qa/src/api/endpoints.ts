const Endpoint = {
  login: "/auth/signin",
  tender: "/tender",

  //Configuration Endpoints
  unit: "/unit",
  category: "/item-category",
  item: "/item",

  supplier: "/supplier",
  itemType: "/item-type",
};

export default Endpoint;
