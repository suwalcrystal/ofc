import { BuildingIcon } from "@/assets/sidebar/BuildingIcon";
import { CartIcon } from "@/assets/sidebar/CartIcon";
import { DashboardIcon } from "@/assets/sidebar/HomeIcon";
import { ItemManagement } from "@/assets/sidebar/ItemManagement";
import { ProjectIcon } from "@/assets/sidebar/ProjectIcon";
import { ReportsIcon } from "@/assets/sidebar/ReportsIcon";
import { SupplierIcon } from "@/assets/sidebar/SupplierIcon";
import { TenderIcon } from "@/assets/sidebar/TenderIcon";
import { AccountingIcon } from "@/components/sidebar/AccountingIcon";
import { PATH } from "@/constants/paths";
import { SidebarItem } from "@/interface/sidebar.interface";

export const SIDE_BAR_ITEMS: SidebarItem[][] = [
  [
    {
      title: "Dashboard",
      icon: <DashboardIcon />,
      link: PATH.dashboard,
    },
    {
      title: "Tender",
      icon: <TenderIcon />,
      link: PATH.tender.tender,
    },
    {
      title: "Projects",
      icon: <ProjectIcon />,
      link: PATH.projects.projects,
    },
  ],
  [
    {
      title: "Budgets & Cost Control",
      icon: <BuildingIcon />,
      link: PATH.budgetsControl,
    },
    {
      title: "Procurement",
      icon: <CartIcon />,
      link: PATH.procurement.procurement,
      children: [
        {
          title: "Purchase Requests",
          icon: <SupplierIcon />,
          link: `${PATH.procurement.purchaseRequests}`,
        },
        {
          title: "Request for Quote",
          icon: <SupplierIcon />,
          link: `${PATH.procurement.requestForQuote}`,
        },
        {
          title: "Purchase Orders",
          icon: <SupplierIcon />,
          link: `${PATH.procurement.purchaseOrder}`,
        },
        {
          title: "Invoices",
          icon: <SupplierIcon />,
          link: `${PATH.procurement}/invoices`,
        },
        {
          title: "Warehouse",
          icon: <SupplierIcon />,
          link: `${PATH.procurement}/warehouse`,
        },
        {
          title: "Delivery Tracker",
          icon: <SupplierIcon />,
          link: `${PATH.procurement}/delivery-tracker`,
        },
        {
          title: "Approval History",
          icon: <SupplierIcon />,
          link: `${PATH.procurement}/approval-history`,
        },
      ],
    },
    {
      title: "Subcontractors",
      icon: <ReportsIcon />,
      link: PATH.subcontractors,
    },
    {
      title: "Payments & Finance",
      icon: <SupplierIcon />,
      link: PATH.paymentsFinance,
      children: [
        {
          title: "Invoices",
          icon: <SupplierIcon />,
          link: `${PATH.paymentsFinance}/invoices`,
        },
        {
          title: "Bank Reconciliation",
          icon: <SupplierIcon />,
          link: `${PATH.paymentsFinance}/reconciliation`,
        },
        {
          title: "Cash Flow",
          icon: <SupplierIcon />,
          link: `${PATH.paymentsFinance}/cashflow`,
        },
      ],
    },
    {
      title: "Accounting",
      icon: <AccountingIcon />,
      link: PATH.accounting,
    },
    {
      title: "HR & Labor Cost",
      icon: <ItemManagement />,
      link: PATH.hRLaborCost,
    },
    {
      title: "Reports",
      icon: <ItemManagement />,
      link: PATH.reports,
    },
    {
      title: "Items Management",
      icon: <ItemManagement />,
      link: PATH.itemsManagement.itemsManagement,
    },
  ],
];
