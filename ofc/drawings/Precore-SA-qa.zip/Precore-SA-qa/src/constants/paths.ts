export const PATH = {
  home: "/",
  dashboard: "/dashboard",

  auth: {
    login: "/login",
    forgotPassword: "/forget-password",
    resetPassword: "/reset-password",
  },

  tender: {
    tender: "/tender",
    createTender: "/tender/create",
    tenderDetail: "/tender/tender-detail",
  },
  projects: {
    projects: "/projects",
    projectDetail: "/projects/project-detail",
  },

  documentDetail: "/document-detail",
  budgetsControl: "/budgets-control",

  procurement: {
    procurement: "/procurement",
    purchaseRequests: "/procurement/purchase-requests",
    createPR: "/procurement/purchase-requests/create-pr",
    addItemsPr: "/procurement/purchase-requests/add-items-pr",
    procurementDetail: "/procurement/purchase-requests/detail",

    requestForQuote: "/procurement/request-for-quote",
    createRFQ: "/procurement/create-request-for-quote",
    addSellerToRFQ: "/procurement/add-seller-to-rfq",
    rfqDetail: "/procurement/request-for-quote/detail",

    purchaseOrder: "/procurement/purchase-order",
    poDetail: "/procurement/purchase-order/detail",
  },

  subcontractors: "/subcontractors",
  paymentsFinance: "/payments-finance",
  invoice: "/payments-finance/invoices",
  accounting: "/accounting",
  hRLaborCost: "/hRLaborCost",
  reports: "/reports",

  //configuration
  itemsManagement: {
    itemsManagement: "/items-management",
    items: "/items/manage",
    category: "/category/manage",
    unit: "/unit/manage",
  },
};
