import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import QueryClientProviders from "./query-client-provider/provider";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryClientProviders>
      <App />
    </QueryClientProviders>
  </StrictMode>
);
