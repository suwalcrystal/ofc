import { PATH } from "@/constants/paths";
import Layout from "@/layout/Layout";
import PrivateRouteWrapper from "@/layout/PrivateRouteWrapper";
import PublicRouteWrapper from "@/layout/PublicRouteWrapper";
import ForgetPasswordForm from "@/pages/auth/forget-password/ForgetPasswordForm";
import LoginPage from "@/pages/auth/login";
import ResetPassword from "@/pages/auth/reset-password/ResetPassword";
import UnitManagement from "@/pages/items-management/modules/unit-management";
import PoDetail from "@/pages/procurement/po/po-detail/PoDetail";
import PurchaseOrder from "@/pages/procurement/po/PurchaseOrder";
import AddItemsToPr from "@/pages/procurement/pr/partials/AddItemsToPr";
import CreatePR from "@/pages/procurement/pr/partials/CreatePR";
import Tender from "@/pages/tender";
import CreateTender from "@/pages/tender/partials/create-tender";
import PrDetail from "@/pages/procurement/pr/pr-detail/PrDetail";
import AddSupplierToRFQ from "@/pages/procurement/rfq/partials/AddSupplierToRFQ";
import CreateRFQ from "@/pages/procurement/rfq/partials/CreateRFQ";
import RfqDetail from "@/pages/procurement/rfq/rfq-detail/RfqDetail";
import { lazy } from "react";
import CategoryManagement from "@/pages/items-management/modules/category-management";
import ItemManagement from "@/pages/items-management/modules/item-management";
import ItemsManagement from "@/pages/items-management";

// Lazy imports
const Home = lazy(() => import("@/pages/home/Home"));
const DashboardPage = lazy(() => import("@/pages/dashboard/DashboardPage"));
const Projects = lazy(() => import("@/pages/projects/Projects"));
const ProductDetail = lazy(() => import("@/pages/poduct-detail/page"));

const DocumentDetailPage = lazy(
  () => import("@/pages/poduct-detail/tabs/documents/document-detail/page")
);
const BudgetsControl = lazy(
  () => import("@/pages/budgetsControl/BudgetsControl")
);
const PurchaseRequestPage = lazy(
  () => import("@/pages/procurement/pr/PurchaseRequestPage")
);
const RequestForQuotePage = lazy(
  () => import("@/pages/procurement/rfq/RequestForQuotePage")
);

const Subcontractors = lazy(
  () => import("@/pages/subcontractors/Subcontractors")
);
const PaymentsFinance = lazy(
  () => import("@/pages/paymentsFinance/PaymentsFinance")
);
const Accounting = lazy(() => import("@/pages/accounting/Accounting"));
const HRLaborCost = lazy(() => import("@/pages/hRLaborCost/HRLaborCost"));
const Reports = lazy(() => import("@/pages/reports/Reports"));

const MainRoutes = [
  {
    path: "/",
    element: (
      <PrivateRouteWrapper>
        <Layout />
      </PrivateRouteWrapper>
    ),
    children: [
      { path: PATH.home, element: <Home /> },
      { path: PATH.dashboard, element: <DashboardPage /> },

      { path: PATH.tender.tender, element: <Tender /> },
      { path: PATH.tender.createTender, element: <CreateTender /> },
      // Projects routes
      { path: PATH.projects.projects, element: <Projects /> },
      { path: PATH.projects.projectDetail, element: <ProductDetail /> },
      { path: PATH.documentDetail, element: <DocumentDetailPage /> },

      // Budgets control route
      { path: PATH.budgetsControl, element: <BudgetsControl /> },

      // Procurement routes
      // purchase request flow
      {
        path: PATH.procurement.purchaseRequests,
        element: <PurchaseRequestPage />,
      },
      {
        path: PATH.procurement.createPR,
        element: <CreatePR />,
      },
      {
        path: PATH.procurement.addItemsPr,
        element: <AddItemsToPr />,
      },

      // request for quote flow
      {
        path: PATH.procurement.requestForQuote,
        element: <RequestForQuotePage />,
      },
      {
        path: PATH.procurement.createRFQ,
        element: <CreateRFQ />,
      },
      {
        path: PATH.procurement.addSellerToRFQ,
        element: <AddSupplierToRFQ />,
      },
      {
        path: PATH.procurement.procurementDetail,
        element: <PrDetail />,
      },
      {
        path: PATH.procurement.rfqDetail,
        element: <RfqDetail />,
      },

      // purchase order flow
      {
        path: PATH.procurement.purchaseOrder,
        element: <PurchaseOrder />,
      },
      {
        path: PATH.procurement.poDetail,
        element: <PoDetail />,
      },

      { path: PATH.subcontractors, element: <Subcontractors /> },
      { path: PATH.paymentsFinance, element: <PaymentsFinance /> },
      { path: PATH.invoice, element: <PaymentsFinance /> },
      { path: PATH.accounting, element: <Accounting /> },
      { path: PATH.hRLaborCost, element: <HRLaborCost /> },
      { path: PATH.reports, element: <Reports /> },

      // configuration routes
      {
        path: PATH.itemsManagement.itemsManagement,
        element: <ItemsManagement />,
      },
      {
        path: PATH.itemsManagement.unit,
        element: <UnitManagement />,
      },
      {
        path: PATH.itemsManagement.category,
        element: <CategoryManagement />,
      },
      {
        path: PATH.itemsManagement.items,
        element: <ItemManagement />,
      },
    ],
  },
  // auth routes
  {
    element: <PublicRouteWrapper />,
    children: [
      { path: PATH.auth.login, element: <LoginPage /> },
      { path: PATH.auth.forgotPassword, element: <ForgetPasswordForm /> },
      { path: PATH.auth.resetPassword, element: <ResetPassword /> },
    ],
  },
];

export default MainRoutes;
