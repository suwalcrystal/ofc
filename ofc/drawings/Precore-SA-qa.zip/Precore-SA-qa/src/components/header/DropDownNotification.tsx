import { FC, useRef, useState } from "react";
import notificationIcon from "@/assets/icons/notification.svg";
import useClickOutside from "@/hooks/useClickOutside";

interface DropdownNotificationsProps {
  align?: "left" | "right";
}

const Notifications: FC<DropdownNotificationsProps> = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const trigger = useRef<HTMLButtonElement>(null);
  const dropdown = useRef<HTMLDivElement>(null);

  useClickOutside(dropdown, () => setDropdownOpen(false), [trigger]);

  const handleDropdownOpen = () => {
    setDropdownOpen(!dropdownOpen);
    if (!dropdownOpen) {
      setUnreadCount(0);
    }
  };

  // const markAllAsRead = () => {
  //   setNotifications([]);
  //   setUnreadCount(0);
  // };

  return (
    <div className="inline-flex relative">
      <button
        ref={trigger}
        className={`w-8 h-8 flex items-center bg-[#E3F2FD] justify-center bg-secondary-50/90 rounded-lg p-2 ${
          dropdownOpen && "bg-red-200"
        }`}
        aria-haspopup="true"
        onClick={handleDropdownOpen}
        aria-expanded={dropdownOpen}
      >
        <img src={notificationIcon} className="h-[1.25rem] w-[1.25rem]" />
        {unreadCount > 0 && (
          <div className="top-0 right-0 absolute border-2 border-red-500 d bg-rose-500 rounded-full w-4 h-4 flex items-center justify-center text-xs text-red-50border-red-500">
            {unreadCount}
          </div>
        )}
      </button>
      {/* 
      <div
        ref={dropdown}
        onFocus={() => setDropdownOpen(true)}
        onBlur={() => setDropdownOpen(false)}
      >
        <div className="flex justify-between items-center px-4 pt-1.5 pb-2 text-red-400 text-xs dark:text-red-500">
          <p className="font-semibold">
            Notifications{" "}
            <select className="!border-0 !ring-0 w-min h-min focus:outline-none text-sm appearance-none outline-none">
              <option>All</option>
            </select>{" "}
          </p>
          <button
            className="w-max h-min text-secondary hover:underline"
            onClick={markAllAsRead}
          >
            Mark All as Read
          </button>
        </div>
        <ul>
          {notifications.map((notification, index) => (
            <li
              key={index}
              className="border-red-200 dark:border-red-700 last:border-0 border-b"
            >
              <Link
                className="flex gap-2 hover:bg-red-50 dark:hover:bg-red-700/20 px-4 py-2"
                to="#0"
                onClick={() => setDropdownOpen(!dropdownOpen)}
              >
                <img
                  src={Logo}
                  alt="Notification"
                  className="block border-secondary border rounded-full w-10 h-10 aspect-square object-contain"
                />
                <div className="space-y-2">
                  <p className="pl-2 border-l-3 text-left text-xs">
                    {notification}
                  </p>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </div> */}
    </div>
  );
};

export default Notifications;
