import { AiOutlineMenu } from "react-icons/ai";
import Notifications from "./DropDownNotification";
import UserMenu from "./DropDownProfile";
import { CiMenuFries } from "react-icons/ci";
import ChatIcon from "./ChatIcon";

interface HeaderProps {
  sidebarOpen: boolean;
  setSidebarOpen: (val: boolean) => void;
  sidebarExpanded: boolean;
  setSidebarExpanded: (val: boolean) => void;
}

const Header: React.FC<HeaderProps> = ({
  sidebarExpanded,
  setSidebarExpanded,
}) => {
  return (
    <header className="bg-background-200">
      <div className="flex justify-between items-center py-[0.625rem] px-[1.38rem]">
        <button
          onClick={() => setSidebarExpanded(!sidebarExpanded)}
          className=" text-[#202224] cursor-pointer"
        >
          {sidebarExpanded ? <AiOutlineMenu /> : <CiMenuFries />}
        </button>

        <div className="flex items-center space-x-3 w-full justify-end">
          <div className="flex items-center gap-5">
            <button className="flex justify-center items-center p-1 rounded-full w-10 h-10">
              <ChatIcon align="right" />
            </button>

            <button className="flex justify-center items-center p-1 rounded-full w-10 h-10">
              <Notifications align="right" />
            </button>
            <UserMenu align="right" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
