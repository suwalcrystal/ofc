import { FC, useEffect, useRef, useState } from "react";

import AvatarImage from "@/assets/icons/user.png";
import Gear from "@/assets/icons/Gear.svg";

interface DropdownProfileProps {
  align?: "left" | "right";
}

const UserMenu: FC<DropdownProfileProps> = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const trigger = useRef<HTMLButtonElement>(null);
  const dropdown = useRef<HTMLDivElement>(null);

  // const handleSignOut = () => {
  //   clearAllCookies();
  // };

  useEffect(() => {
    const clickHandler = ({ target }: MouseEvent) => {
      if (!dropdown.current) return;
      if (
        !dropdownOpen ||
        (dropdown.current && dropdown.current.contains(target as Node)) ||
        (trigger.current && trigger.current.contains(target as Node))
      )
        return;
      setDropdownOpen(false);
    };
    document.addEventListener("click", clickHandler);
    return () => document.removeEventListener("click", clickHandler);
  }, [dropdownOpen]);

  // close if the esc key is pressed
  useEffect(() => {
    const keyHandler = ({ keyCode }: KeyboardEvent) => {
      if (!dropdownOpen || keyCode !== 27) return;
      setDropdownOpen(false);
    };
    document.addEventListener("keydown", keyHandler);
    return () => document.removeEventListener("keydown", keyHandler);
  }, [dropdownOpen]);

  return (
    <div className="inline-flex gap-4 relative bg-green-50 rounded-[1.6875rem] px-4 py-2">
      <button
        ref={trigger}
        className="inline-flex justify-center items-center gap-3 group"
        aria-haspopup="true"
        onClick={() => setDropdownOpen(!dropdownOpen)}
        aria-expanded={dropdownOpen}
      >
        <img
          className="border-[0.49px] border-[#1E88E5] bg-amber-400 max-w-full h-8 object-contain rounded-full"
          src={AvatarImage}
          width="32"
          height="32"
          alt="User"
        />
      </button>
      <button>
        <img
          className=" max-w-full h-[1.5rem] object-contain rounded-full"
          src={Gear}
          width="32"
          height="32"
          alt="Gear"
        />
      </button>
    </div>
  );
};

export default UserMenu;
