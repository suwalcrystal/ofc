import { FC, useRef, useState } from "react";
import chatIcon from "@/assets/icons/chat.svg";
import useClickOutside from "@/hooks/useClickOutside";

interface DropdownNotificationsProps {
  align?: "left" | "right";
}

const ChatIcon: FC<DropdownNotificationsProps> = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  const trigger = useRef<HTMLButtonElement>(null);
  const dropdown = useRef<HTMLDivElement>(null);

  useClickOutside(dropdown, () => setDropdownOpen(false), [trigger]);

  const handleDropdownOpen = () => {
    setDropdownOpen(!dropdownOpen);
    if (!dropdownOpen) {
      setUnreadCount(0);
    }
  };

  return (
    <div className="inline-flex relative">
      <button
        ref={trigger}
        className={`w-8 h-8 flex items-center bg-[#FFF8E1] justify-center bg-secondary-50/90 rounded-lg p-2 ${
          dropdownOpen && "bg-red-200"
        }`}
        aria-haspopup="true"
        onClick={handleDropdownOpen}
        aria-expanded={dropdownOpen}
      >
        <img src={chatIcon} className="h-[1.25rem] w-[1.25rem]" />
        {unreadCount > 0 && (
          <div className="top-0 right-0 absolute border-2 border-red-500 d bg-rose-500 rounded-full w-4 h-4 flex items-center justify-center text-xs text-red-50border-red-500">
            {unreadCount}
          </div>
        )}
      </button>
    </div>
  );
};

export default ChatIcon;
