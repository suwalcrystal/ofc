import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { IBaseTableProps } from "@/interface/baseTable.interface";
import { ChevronDown, ChevronUp } from "lucide-react";

const BaseTable = <T,>({
  data,
  columns,
  renderRow,
  tableHeight,
  selectAllCheckbox,
}: IBaseTableProps<T>) => {
  const [sorting, setSorting] = React.useState<{
    key: keyof T | null;
    direction: "asc" | "desc" | null;
  }>({ key: null, direction: null });

  const sortedData = React.useMemo(() => {
    if (!sorting.key || !sorting.direction) return data;

    const { key, direction } = sorting;

    return [...data].sort((a, b) => {
      const aVal = a[key];
      const bVal = b[key];

      if (aVal === bVal) return 0;
      if (aVal == null) return 1;
      if (bVal == null) return -1;

      if (typeof aVal === "string" && typeof bVal === "string") {
        return direction === "asc"
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }

      return direction === "asc"
        ? aVal > bVal
          ? 1
          : -1
        : aVal < bVal
          ? 1
          : -1;
    });
  }, [data, sorting]);

  return (
    <div style={{ maxHeight: tableHeight }} className="overflow-auto">
      <Table className="w-full table-auto">
        <TableHeader className="sticky top-0 z-10 bg-[#E1E3E4]">
          <TableRow>
            {columns.map(({ key, label, sortable }, index) => {
              const isSorted = sorting.key === key;
              const direction = sorting.direction;

              return (
                <TableHead
                  key={String(key)}
                  className="typography-paragraph-small font-medium text-text-500"
                >
                  {sortable ? (
                    <button
                      onClick={() => {
                        if (isSorted) {
                          setSorting({
                            key,
                            direction: direction === "asc" ? "desc" : "asc",
                          });
                        } else {
                          setSorting({ key, direction: "asc" });
                        }
                      }}
                      className="inline-flex items-center space-x-1 select-none group"
                      aria-sort={
                        isSorted
                          ? direction === "asc"
                            ? "ascending"
                            : "descending"
                          : "none"
                      }
                      aria-label={`Sort by ${label}`}
                      type="button"
                    >
                      <span>
                        {index === 0 && selectAllCheckbox
                          ? selectAllCheckbox
                          : label}
                      </span>
                      <span>
                        {isSorted ? (
                          direction === "asc" ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )
                        ) : (
                          <ChevronUp className="h-4 w-4 opacity-0 group-hover:opacity-100" />
                        )}
                      </span>
                    </button>
                  ) : index === 0 && selectAllCheckbox ? (
                    selectAllCheckbox
                  ) : (
                    label
                  )}
                </TableHead>
              );
            })}
          </TableRow>
        </TableHeader>

        <TableBody>
          {sortedData.length > 0 ? (
            sortedData.map((item, index) => (
              <TableRow
                key={index}
                className="typography-paragraph-small text-text-500 bg-background-100 "
              >
                {renderRow(item, index, columns)}
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell
                colSpan={columns.length}
                className="py-4 text-center text-gray-500"
              >
                No records found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default BaseTable;
