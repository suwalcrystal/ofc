import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const SelectField = ({
  label,
  value,
  onChange,
  options,
  placeholder,
  error,
  touched,
  isRequired = true,
}: {
  label?: string;
  name: string;
  value?: string;
  onChange: (value: string) => void;
  options: { label: string; value: string }[];
  placeholder: string;
  error?: string;
  touched?: boolean;
  isRequired?: boolean;
}) => {
  return (
    <div className="flex flex-col space-y-2">
      {label && (
        <label className="typography-paragraph-small font-medium text-text-500">
          {label} {isRequired && <span className="text-error">*</span>}
        </label>
      )}
      <Select
        value={value || ""}
        onValueChange={(val) => {
          if (val) {
            onChange(val);
          }
        }}
      >
        <SelectTrigger className="h-12 bg-white w-full p-5 ">
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {options.map((opt) => (
            <SelectItem
              key={opt.value}
              value={opt.value}
              className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem] "
            >
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {touched && error && <div className="text-sm text-error">{error}</div>}
    </div>
  );
};

export default SelectField;
