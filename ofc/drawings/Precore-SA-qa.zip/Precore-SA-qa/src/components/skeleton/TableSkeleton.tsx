import { Skeleton } from "../ui/skeleton";
import { Table, TableBody, TableCell, TableRow } from "../ui/table";

const TableSkeleton = ({
  rowLength,
  colLength,
}: {
  rowLength: number;
  colLength: number;
}) => {
  return (
    <div>
      <div className="overflow-x-auto">
        <Table>
          <TableBody>
            {Array.from({ length: colLength }).map((_, rowIndex) => (
              <TableRow key={`row-skeleton-${rowIndex}`}>
                {Array.from({ length: rowLength }).map((_, colIndex) => (
                  <TableCell key={`cell-skeleton-${rowIndex}-${colIndex}`}>
                    <Skeleton className="h-10 w-full rounded " />
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default TableSkeleton;
