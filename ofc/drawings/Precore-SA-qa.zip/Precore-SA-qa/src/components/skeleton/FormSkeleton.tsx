import { Skeleton } from "../ui/skeleton";

const FormSkeleton = () => {
  const buttonWidth = "w-[200px]";

  return (
    <div className="h-fit ">
      {Array.from({ length: 3 }).map((_, index) => (
        <div
          key={index}
          className="flex items-center justify-between space-x-8"
        >
          <Skeleton className="h-11 w-full mb-6" />
          <Skeleton className="h-11 w-full mb-6" />
        </div>
      ))}
      <div className="w-full flex justify-start space-x-8">
        <Skeleton className={`h-11 ${buttonWidth} mb-6`} />
        <Skeleton className={`h-11 ${buttonWidth} mb-6`} />
      </div>
    </div>
  );
};

export default FormSkeleton;
