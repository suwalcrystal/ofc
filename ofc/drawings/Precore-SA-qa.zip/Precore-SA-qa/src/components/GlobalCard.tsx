import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface GlobalCardProps {
  title: string;
  value: string;
  icon: ReactNode;
  bgColor?: string;
}

const GlobalCard = ({
  title,
  value,
  icon,
  bgColor = "bg-gray-50",
}: GlobalCardProps) => {
  const isOnTrack = value === "On Track";
  const valueTextColor = isOnTrack ? "text-green-500" : "text-text-500";

  const match = value.match(/^([\d.,\s\w]+?)\s+(AED)$/i);
  const mainValue = match?.[1];
  const currency = match?.[2];

  return (
    <div className="bg-white border border-boarder-300 rounded-[0.75rem] shadow-card p-4 flex items-start gap-[0.62rem]">
      <div className={cn("p-[0.59rem] rounded-full", bgColor)}>{icon}</div>
      <div>
        <h3 className="text-text-400 typography-paragraph-small font-medium pb-2">
          {title}
        </h3>
        <p
          className={cn(
            valueTextColor,
            "typography-paragraph-large font-semibold  flex items-baseline gap-1"
          )}
        >
          {mainValue ? (
            <>
              <span>{mainValue}</span>
              <span className="typography-paragraph-caption font-normal">
                {currency}
              </span>
            </>
          ) : (
            value
          )}
        </p>
      </div>
    </div>
  );
};

export default GlobalCard;
