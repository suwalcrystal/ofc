import useSearch from "@/hooks/useSearch";
import { useState } from "react";
import { FiSearch } from "react-icons/fi";

const Search = () => {
  const { handleSearch, search } = useSearch();
  const [inputValue, setInputValue] = useState(search ?? "");

  const handleInputChange = (e: { target: { value: string } }) => {
    const value = e.target.value;
    setInputValue(value);
    if (value.length === 0) {
      handleSearch("");
    } else if (value.length >= (length !== undefined ? length : 3)) {
      handleSearch(value);
    }
  };

  return (
    <>
      <div className="relative">
        <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-text-200" />
        <input
          type="text"
          placeholder="Search"
          value={inputValue}
          onChange={handleInputChange}
          className="w-full pl-9 pr-3 py-[0.62rem] border border-boarder-300 bg-background-300 rounded-[1.375rem] focus:outline-none typography-paragraph-regular text-text-500 "
        />
      </div>
    </>
  );
};

export default Search;
