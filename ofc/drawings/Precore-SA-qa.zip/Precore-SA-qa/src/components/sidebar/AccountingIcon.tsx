export const AccountingIcon = () => {
  return (
    <svg
      width="14"
      height="16"
      viewBox="0 0 14 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="stroke-current"
    >
      <path
        d="M9.25 1H2.5C2.10218 1 1.72064 1.1475 1.43934 1.41005C1.15804 1.6726 1 2.0287 1 2.4V13.6C1 13.9713 1.15804 14.3274 1.43934 14.5899C1.72064 14.8525 2.10218 15 2.5 15H11.5C11.8978 15 12.2794 14.8525 12.5607 14.5899C12.842 14.3274 13 13.9713 13 13.6V4.5L9.25 1Z"
        stroke="currentColor"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M8.5 1V3.8C8.5 4.1713 8.65804 4.5274 8.93934 4.78995C9.22064 5.0525 9.60217 5.2 10 5.2H13M4 8.7H5.5M8.5 8.7H10M4 11.5H5.5M8.5 11.5H10"
        stroke="currentColor"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
