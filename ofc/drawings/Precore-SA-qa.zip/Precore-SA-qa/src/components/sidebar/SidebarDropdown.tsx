import SidebarLinkGroup from "./SidebarLinkGroup";
import { NavLink } from "react-router-dom";
import { FaAngleUp, FaAngleDown } from "react-icons/fa6";
import plus from "@/assets/icons/plus.svg";
import type { SidebarItem } from "@/interface/sidebar.interface";

interface SidebarDropdownProps {
  item: SidebarItem;
  isActive: boolean;
  sidebarExpanded: boolean;
}

const SidebarDropdown: React.FC<SidebarDropdownProps> = ({
  item,
  isActive,
  sidebarExpanded,
}) => {
  const children = item.children ?? [];

  return (
    <SidebarLinkGroup activeCondition={isActive}>
      {(handleClick, open) => (
        <div className="overflow-hidden sidebar-expanded:mb-2 last:mb-1 ">
          {/* Top-level toggle item */}
          <a
            href="#0"
            onClick={(e) => {
              e.preventDefault();
              handleClick();
            }}
            className={`flex items-center rounded-none  group transition gap-2 ${
              isActive ? "text-green-500" : "hover:text-green-500"
            }`}
          >
            {/* Left border */}
            <div
              className={`w-[0.45rem] bg-green-500 opacity-0 h-[3rem] rounded-r-[0.5rem] transition-all duration-300 ${
                isActive
                  ? "opacity-100 rounded-none"
                  : "group-hover:opacity-100"
              }`}
            />

            {/* Main content block */}
            <div
              className={`flex w-full justify-between p-4 rounded-[0.5rem] items-center
    ${isActive ? "text-white bg-green-500" : ""}
    ${sidebarExpanded ? "mr-0" : "mr-2"}
  `}
            >
              <div
                className={`flex items-center gap-x-[0.75rem] ${
                  !sidebarExpanded ? "lg:flex-col" : "lg:flex-row"
                }`}
              >
                <div
                  className={`shrink-0 text-text-400 font-medium ${
                    isActive ? "text-white" : "group-hover:text-green-500"
                  }`}
                >
                  {item.icon}
                </div>

                {sidebarExpanded && (
                  <span className="text-[0.875rem] font-medium tracking-tighter leading-[120%] lg:sidebar-expanded:text-sm line-clamp-1 rounded-none">
                    {item.title}
                  </span>
                )}
              </div>

              {/* Chevron */}
              {sidebarExpanded && (
                <div className="ml-2 text-sm text-white/70">
                  {open ? <FaAngleUp /> : <FaAngleDown />}
                </div>
              )}
            </div>

            {/* Plus icon */}
            {sidebarExpanded && (
              <div
                className={`shrink-0 ${
                  isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                }`}
              >
                <img src={plus} alt="plus" className="w-[2rem] h-[2rem]" />
              </div>
            )}
          </a>

          {/* Sub-menu */}
          <ul
            className={`px-[1.5rem] mt-1 transition-all ${!open && "hidden"}`}
          >
            {children.map((child) => (
              <li className="mb-1 last:mb-0" key={child.link}>
                {child.link && (
                  <NavLink
                    end
                    to={child.link}
                    className={({ isActive }) =>
                      `flex items-center gap-2 p-3 rounded-[0.5rem] text-xs font-medium transition group ${
                        isActive
                          ? "bg-green-500 text-white"
                          : "hover:text-green-500 hover:bg-primary/10"
                      }`
                    }
                  >
                    <div className="text-base">{child.icon}</div>
                    <span className="truncate">{child.title}</span>
                  </NavLink>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </SidebarLinkGroup>
  );
};

export default SidebarDropdown;
