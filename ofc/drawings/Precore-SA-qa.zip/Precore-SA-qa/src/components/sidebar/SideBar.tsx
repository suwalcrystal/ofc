import React from "react";
import { useLocation } from "react-router-dom";
import { SIDE_BAR_ITEMS } from "@/constants/sidebarItems";
import SidebarHeader from "./SidebarHeader";
import SidebarItem from "./SidebarItems";
import SidebarFooter from "./SidebarFooter";
import SidebarWrapper from "./SidebarWrapper";
import SidebarDropdown from "./SidebarDropdown";

interface SideBarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (val: boolean) => void;
  sidebarExpanded: boolean;
  setSidebarExpanded: (val: boolean) => void;
}

const SideBar: React.FC<SideBarProps> = ({
  sidebarOpen,
  setSidebarOpen,
  sidebarExpanded,
}) => {
  const { pathname } = useLocation();

  return (
    <SidebarWrapper
      sidebarOpen={sidebarOpen}
      setSidebarOpen={setSidebarOpen}
      sidebarExpanded={sidebarExpanded}
    >
      <SidebarHeader sidebarExpanded={sidebarExpanded} />

      <ul className="flex flex-col mt-[1.88rem]">
        {SIDE_BAR_ITEMS.map((group, groupIndex) => (
          <React.Fragment key={groupIndex}>
            {group.map((data, index) => {
              const hasChildren = (data?.children || []).length > 0;
              const isActive = data?.children?.some(
                (child) => child.link === pathname
              );

              return hasChildren ? (
                <SidebarDropdown
                  key={index}
                  item={data}
                  isActive={isActive ?? false}
                  sidebarExpanded={sidebarExpanded}
                />
              ) : (
                <SidebarItem
                  key={index}
                  item={data}
                  pathname={pathname}
                  sidebarExpanded={sidebarExpanded}
                />
              );
            })}
            {/* Add divider after each group except last */}
            {groupIndex < SIDE_BAR_ITEMS.length - 1 && (
              <hr className="my-3 border-[0.025rem] border-section-bg-700 mx-[1rem]" />
            )}
          </React.Fragment>
        ))}
      </ul>

      <SidebarFooter sidebarExpanded={sidebarExpanded} />
    </SidebarWrapper>
  );
};

export default SideBar;
