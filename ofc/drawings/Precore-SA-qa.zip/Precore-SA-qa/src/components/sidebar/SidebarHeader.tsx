import { Link } from "react-router-dom";
import logo from "/logo.jpg";
import logoCollapsed from "/logCollapse.png";
import { PATH } from "@/constants/paths";

interface SidebarItemProps {
  sidebarExpanded: boolean;
}

const SidebarHeader: React.FC<SidebarItemProps> = ({ sidebarExpanded }) => (
  <div className="h-[3rem] sticky top-0 bg-background-200 w-full">
    <Link to={PATH.dashboard} aria-label="Navigate to Dashboard">
      <img
        src={sidebarExpanded ? logo : logoCollapsed}
        alt="Precore Dashboard Logo"
        className="w-full h-full object-contain"
      />
    </Link>
  </div>
);

export default SidebarHeader;
