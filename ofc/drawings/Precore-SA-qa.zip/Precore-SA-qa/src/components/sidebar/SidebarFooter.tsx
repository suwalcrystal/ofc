import { PATH } from "@/constants/paths";
import { clearAllCookies } from "@/utils/cookie";
import { FiLogOut } from "react-icons/fi";
import { useNavigate } from "react-router-dom";

interface SidebarItemProps {
  sidebarExpanded: boolean;
}

const SidebarFooter = ({ sidebarExpanded }: SidebarItemProps) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    clearAllCookies();
    localStorage.clear();
    navigate(PATH.auth.login);
  };

  return (
    <div className="px-[1rem] pb-[1rem]">
      <hr className="my-3 border-[0.025rem] border-section-bg-700 mx-[1rem]" />

      <button
        onClick={handleLogout}
        className="w-full px-4 py-2 hover:bg-primary/5 hover:text-red-500 text-text-400"
      >
        <div
          className={`flex items-center ${
            sidebarExpanded ? "gap-x-2 justify-start" : "justify-center"
          }`}
        >
          <FiLogOut className="text-lg" />

          {/* Show "Logout" only if sidebar is expanded */}
          {sidebarExpanded && (
            <span className="text-[0.875rem] text-nowrap font-medium tracking-tighter leading-[120%] lg:sidebar-expanded:text-sm">
              Logout
            </span>
          )}
        </div>
      </button>
    </div>
  );
};

export default SidebarFooter;
