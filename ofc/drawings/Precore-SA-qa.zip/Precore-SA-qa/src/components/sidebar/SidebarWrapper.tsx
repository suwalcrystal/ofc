import React, { useEffect, useRef } from "react";

interface SidebarWrapperProps {
  children: React.ReactNode;
  sidebarOpen: boolean;
  setSidebarOpen: (val: boolean) => void;
  sidebarExpanded: boolean; // still used for width
}

const SidebarWrapper: React.FC<SidebarWrapperProps> = ({
  children,
  sidebarOpen,
  setSidebarOpen,
  sidebarExpanded,
}) => {
  const sidebarRef = useRef<HTMLDivElement | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);

  // Close sidebar on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        !sidebarOpen ||
        sidebarRef.current?.contains(event.target as Node) ||
        triggerRef.current?.contains(event.target as Node)
      ) {
        return;
      }
      setSidebarOpen(false);
    };
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, [sidebarOpen]);

  // Close on ESC key
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === "Escape" && sidebarOpen) {
        setSidebarOpen(false);
      }
    };
    document.addEventListener("keydown", handleEsc);
    return () => document.removeEventListener("keydown", handleEsc);
  }, [sidebarOpen]);

  return (
    <div
      ref={sidebarRef}
      className={`flex flex-col absolute z-50 left-0 top-0 py-[1.5rem] lg:static h-screen overflow-y-scroll lg:overflow-y-auto no-scrollbar shrink-0  transition-all ease-in-out bg-background-200 ${
        sidebarExpanded ? "w-[15rem]" : "w-[4.75rem]"
      } ${sidebarOpen ? "translate-x-0" : "-translate-x-64"} lg:translate-x-0`}
    >
      {children}
    </div>
  );
};

export default SidebarWrapper;
