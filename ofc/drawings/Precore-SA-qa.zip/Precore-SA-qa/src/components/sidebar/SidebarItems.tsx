import type { SidebarItem } from "@/interface/sidebar.interface";
import { NavLink } from "react-router-dom";
import plus from "@/assets/icons/plus.svg";

interface SidebarItemProps {
  item: SidebarItem;
  pathname: string;
  sidebarExpanded: boolean;
}

const SidebarItem = ({ item, pathname, sidebarExpanded }: SidebarItemProps) => {
  if (!item.link) return null;

  const isActive = pathname.includes(item.link);

  return (
    <li className="overflow-hidden sidebar-expanded:mb-2 last:mb-1">
      <NavLink
        end
        to={item.link}
        className={`flex  items-center group transition gap-2 ${
          isActive ? "text-green-500" : "hover:text-green-500"
        }`}
      >
        {/* line */}
        <div
          className={`w-[0.45rem] bg-green-500 opacity-0 h-[3rem] rounded-r-[0.5rem] transition-all duration-300 ${
            isActive ? "opacity-100" : " group-hover:opacity-100"
          }`}
        />

        {/* text and icon */}
        <div
          className={`flex w-full justify-between p-4 rounded-[0.5rem] items-center
    ${isActive ? "text-white bg-green-500" : ""}
    ${sidebarExpanded ? "mr-0" : "mr-2"}
  `}
        >
          <div
            className={`flex items-center gap-x-[0.75rem] ${
              !sidebarExpanded ? "lg:flex-col" : "lg:flex-row"
            }`}
          >
            <div
              className={`shrink-0 text-text-400 font-medium ${
                isActive ? "text-white" : "group-hover:text-green-500"
              }`}
            >
              {item.icon}
            </div>

            {/* Show title only when sidebar is expanded */}
            <div title={item?.title} className=" ">
              {sidebarExpanded && (
                <span className="text-[0.875rem] font-medium tracking-tighter leading-[120%] lg:sidebar-expanded:text-sm line-clamp-1 ">
                  {item.title}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* plus icon - only show when sidebar is expanded */}
        {sidebarExpanded && (
          <div
            className={`shrink-0 ${
              isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100 "
            }`}
          >
            <img src={plus} alt="plus" className="w-[2rem] h-[2rem]" />
          </div>
        )}
      </NavLink>
    </li>
  );
};

export default SidebarItem;
