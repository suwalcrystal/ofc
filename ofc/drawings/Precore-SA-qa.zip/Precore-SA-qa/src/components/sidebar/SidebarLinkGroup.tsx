import { ReactNode, useState } from "react";

interface Props {
  children: (func: () => unknown, open: boolean) => ReactNode;
  activeCondition: boolean;
}

const SidebarLinkGroup: React.FC<Props> = ({
  children,
  activeCondition,
}: Props) => {
  const [open, setOpen] = useState(activeCondition);

  const handleClick = () => {
    setOpen(!open);
  };

  return (
    <li
      className={` rounded-[1.25rem] sidebar-expanded:mb-2 last:mb-1${
        activeCondition ? "" : "bg-transparent"
      }`}
    >
      {children(handleClick, open)}
    </li>
  );
};

export default SidebarLinkGroup;
