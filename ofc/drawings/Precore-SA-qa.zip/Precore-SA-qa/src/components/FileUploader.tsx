import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "./ui/button";
import Upload from "/src/assets/icons/upload.svg";

type FileUploaderProps = {
  name: string;
  value: File[] | string | null;
  setFieldValue: (
    field: string,
    value: File[] | string | null,
    shouldValidate?: boolean
  ) => void;
};

const FileUploader: React.FC<FileUploaderProps> = ({
  name,
  value = null,
  setFieldValue,
}) => {
  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      const validFiles = acceptedFiles.filter((file: File) =>
        [
          "image/jpeg",
          "image/png",
          "image/jpg",
          "application/pdf",
          "application/msword",
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ].includes(file.type)
      );

      if (validFiles.length) {
        setFieldValue(name, [validFiles[0]]);
      } else {
        alert("Only image, PDF, or DOC/DOCX files are allowed.");
      }
    },
    [name, setFieldValue]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: false,
    accept: {
      "image/*": [".png", ".jpg", ".jpeg"],
      "application/pdf": [".pdf"],
      "application/msword": [".doc"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        [".docx"],
    },
  });

  const renderPreview = () => {
    if (Array.isArray(value) && value.length > 0) {
      return (
        <ul className="mt-8 flex items-center justify-center h-full text-sm text-green-600 text-left">
          {value.map((file, index) => (
            <li key={index}>{file.name}</li>
          ))}
        </ul>
      );
    }

    if (typeof value === "string" && value !== "") {
      return <div className="mt-8 text-sm text-green-600">{value}</div>;
    }

    return isDragActive ? (
      <p>Drop your files here…</p>
    ) : (
      <div className="flex flex-col items-center gap-y-1">
        <img src={Upload} alt="Upload Icon" />
        <span className="text-sm text-text-400 font-normal">
          Drag files here or click to upload
        </span>
        <span className="text-xs text-[#888888]">
          .JPG, .PNG files supported
        </span>
        <Button
          type="button"
          variant="outline"
          className="max-h-6 text-xs rounded-full typography-paragraph-small font-medium cursor-pointer w-fit px-4 bg-transparent border border-gray-300 mt-2 text-black"
        >
          Browse
        </Button>
      </div>
    );
  };

  return (
    <div
      {...getRootProps()}
      className="border-1 border-gray-200 p-4 h-auto min-h-[120px] text-center rounded-md cursor-pointer"
    >
      <input {...getInputProps()} />
      {renderPreview()}
    </div>
  );
};

export default FileUploader;
