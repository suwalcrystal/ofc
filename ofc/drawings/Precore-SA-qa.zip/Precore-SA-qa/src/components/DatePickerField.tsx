import { format } from "date-fns";
import calendarIcon from "@/assets/icons/calendar.svg";
import { cn } from "@/lib/utils";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";

const DatePickerField = ({
  label,
  value,
  onChange,
  error,
  touched,
}: {
  label: string;
  value: Date | undefined;
  onChange: (date: Date | undefined) => void;
  error?: string;
  touched?: boolean;
}) => (
  <div className="flex flex-col space-y-2">
    <label className="typography-paragraph-small font-medium text-text-500">
      {label} <span className="text-error">*</span>
    </label>
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "w-full flex justify-between items-center text-left font-normal bg-white p-5",
            !value && "text-muted-foreground"
          )}
        >
          <span>{value ? format(value, "dd MMM, yyyy") : "Select date"}</span>
          <div className="size-4">
            <img
              src={calendarIcon}
              alt="calendar-icon"
              className="size-full object-cover"
            />
          </div>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <CalendarComponent
          mode="single"
          selected={value}
          onSelect={onChange}
          initialFocus
        />
      </PopoverContent>
    </Popover>
    {touched && error && <div className="text-sm text-error">{error}</div>}
  </div>
);

export default DatePickerField;
