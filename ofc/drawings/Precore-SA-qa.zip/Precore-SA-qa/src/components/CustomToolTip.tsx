import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface CustomToolTipProps {
  label: string;
  value: string;
}

const CustomToolTip: React.FC<CustomToolTipProps> = ({ label, value }) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger>{label}</TooltipTrigger>
        <TooltipContent className="bg-white border border-boarder-300 shadow-[0px_4px_4px_0px rgba(0,0,0,0.04)] rounded-[0.625rem] p-[0.62rem] typography-paragraph-small font-medium text-text-400 my-2">
          {value}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default CustomToolTip;
