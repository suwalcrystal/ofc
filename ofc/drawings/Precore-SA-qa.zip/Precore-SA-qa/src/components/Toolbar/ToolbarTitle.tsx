import React, { ReactNode } from "react";

interface IProps {
  title?: ReactNode;
  search?: ReactNode;
  toggler?: ReactNode;
  filter?: ReactNode;
  addButton?: ReactNode;
}

const ToolBar: React.FC<IProps> = ({
  title,
  search,
  toggler,
  filter,
  addButton,
}) => {
  return (
    <div className="top-0 z-40 sticky pt-[0.88rem] pb-[0.88rem] flex items-center justify-between border-b-2 border-white bg-section-bg-400">
      {/* Left side */}
      <div className="flex items-center gap-[1.25rem]">
        <h3 className="text-text-500 typography-h3 font-semibold">{title}</h3>
        {search}
        {toggler}
        {filter}
      </div>

      {/* Right side */}
      <div>{addButton}</div>
    </div>
  );
};

export default ToolBar;
