interface ToolbarTitleProps {
  title: string;
}

const ToolbarTitle = ({ title }: ToolbarTitleProps) => {
  return (
    <div>
      <h3 className="text-text-500 typography-h3 font-semibold">{title}</h3>
    </div>
  );
};

export default ToolbarTitle;
