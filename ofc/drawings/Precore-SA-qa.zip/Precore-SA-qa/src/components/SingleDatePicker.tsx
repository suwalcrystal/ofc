import * as React from "react";
import { format } from "date-fns";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";

import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

import calendarIcon from "@/assets/icons/calendar.svg";

interface SingleDatePickerProps {
  placeholder?: string;
  value?: Date | string;
  onChange?: (date: Date | undefined) => void;
  onBlur?: (e: React.FocusEvent) => void;
  name?: string;
  id?: string;
  className?: string;
}

export function SingleDatePicker({
  className,
  placeholder,
  value,
  onChange,
  onBlur,
  name,
  id,
}: SingleDatePickerProps) {
  const [open, setOpen] = React.useState(false);
  return (
    <div className={cn("flex gap-2.5", className)}>
      {/* From Date */}
      <Popover modal open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant={"outline"}
            className={cn(
              " flex justify-between file:text-foreground  selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
              "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]",
              "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
              className
            )}
            onBlur={onBlur}
            id={id}
            name={name}
          >
            {value
              ? format(value, "LLL dd, y")
              : (placeholder ?? "Select Date")}
            <div className="size-4">
              <img
                src={calendarIcon}
                alt="calendar-icon"
                className="size-full object-cover"
              />
            </div>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={typeof value === "string" ? undefined : value}
            onSelect={(date) => {
              if (onChange) {
                onChange(date ?? undefined);
              }
              setOpen(false);
            }}
            defaultMonth={typeof value === "string" ? undefined : value}
            initialFocus
            disabled={(date) =>
              date < new Date(new Date().setHours(0, 0, 0, 0))
            }
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
