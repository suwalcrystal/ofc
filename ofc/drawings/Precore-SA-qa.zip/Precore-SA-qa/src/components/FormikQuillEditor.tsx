// components/FormikQuillEditor.tsx
import { useEffect } from "react";
import ReactQuill from "react-quill-new";
import "react-quill-new/dist/quill.snow.css";
import { useField } from "formik";

interface FormikQuillEditorProps {
  name: string;
  label?: string;
  placeholder?: string;
  toolbar?: boolean;
}

const FormikQuillEditor = ({
  name,
  label,
  placeholder,
  toolbar = true,
}: FormikQuillEditorProps) => {
  const [{ value }, { touched, error }, { setValue, setTouched }] =
    useField(name);

  const modules = {
    toolbar: toolbar
      ? [
          [{ header: [1, 2, 3, false] }],
          ["bold", "italic", "underline", "strike"],
          [{ list: "ordered" }, { list: "bullet" }],
          ["link", "image"],
          ["clean"],
        ]
      : false,
    clipboard: {
      matchVisual: false,
    },
  };

  const formats = [
    "header",
    "bold",
    "italic",
    "underline",
    "strike",
    "list",
    "bullet",
    "link",
    "image",
  ];

  useEffect(() => {
    if (value === undefined || value === null) {
      setValue("");
    }
  }, [value, setValue]);

  return (
    <div>
      {label && (
        <label
          htmlFor={name}
          className="block mb-2 typography-paragraph-small font-medium text-text-500 "
        >
          {label}
        </label>
      )}

      <ReactQuill
        theme="snow"
        value={value || ""}
        onChange={(content) => {
          setValue(content);
          setTouched(true);
        }}
        onBlur={() => setTouched(true)}
        placeholder={placeholder}
        modules={modules}
        formats={formats}
        className="no-border-quill bg-background-100 border border-boarder-300 rounded-[0.5rem] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 h-38"
      />
      {touched && error && (
        <div className="text-red-500 typography-paragraph-small pl-2 mt-1">
          {error}
        </div>
      )}
    </div>
  );
};

export default FormikQuillEditor;
