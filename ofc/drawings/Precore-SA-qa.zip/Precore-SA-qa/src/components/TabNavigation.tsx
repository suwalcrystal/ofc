import { cn } from "@/lib/utils";

interface Tab {
  name: string;
  current: boolean;
}

interface TabNavigationProps {
  tabs: Tab[];
  onTabChange: (tabName: string) => void;
}

const TabNavigation = ({ tabs, onTabChange }: TabNavigationProps) => {
  return (
    <div className="top-14 z-40 sticky  bg-section-bg-400 ">
      <div className=" border-text-200 pb-5">
        <nav className="-mb-px flex space-x-8 overflow-x-auto ">
          {tabs.map((tab) => (
            <button
              key={tab.name}
              onClick={() => onTabChange(tab.name)}
              className={cn(
                tab.current
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-text-400 hover:border-text-200 hover:text-text-600",
                "cursor-pointer whitespace-nowrap border-b py-4 px-1 typography-paragraph-regular font-medium transition-colors"
              )}
              aria-current={tab.current ? "page" : undefined}
            >
              {tab.name}
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default TabNavigation;
