import { cn } from "../lib/utils";
import ExtendedButton from "./ExtendedButton";
import { Button } from "./ui/button";
import { Dialog, DialogContent } from "./ui/dialog";

interface DeleteModalProps {
  title?: string;
  open: boolean;
  onClose: () => void;
  loading?: boolean;
  onDelete?: () => void;
  className?: string;
  text?: string;
}

const DeleteModal = ({
  open,
  title,
  onClose,
  loading,
  onDelete,
  className,
  text,
}: DeleteModalProps) => {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className={cn("p-0 min-w-[524px]", className)}>
        <div className="p-6">
          <p className="text-2xl font-semibold">
            Confirm Delete
            <span className="text-destructive">{`${text}`}</span> ?
          </p>
          <p className="mt-2 text-base text-[#6A6A6A] font-normal">
            Are you sure you want to delete<span> {`${title}`}</span>? After
            deletion this cannot be restored.
          </p>
          <div className="flex gap-5 mt-8 w-full">
            <Button
              className="text-base flex-1 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium cursor-pointer w-[110px]"
              variant={"outline"}
              onClick={onClose}
            >
              Cancel
            </Button>
            <ExtendedButton
              variant="destructive"
              onClick={onDelete}
              className="text-base flex-1 w-[110px] p-[1.25rem] border border-red-500 bg-red-500 hover:bg-red-500 hover:opacity-90  "
              text={"Delete"}
              isLoading={loading}
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DeleteModal;
