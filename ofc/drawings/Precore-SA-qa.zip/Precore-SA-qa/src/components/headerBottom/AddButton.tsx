import { Button } from "../ui/button";

interface AddButtonProps {
  title: string;
  onClick?: () => void;
}

const AddButton = ({ title, onClick }: AddButtonProps) => {
  return (
    <div>
      <Button
        className="bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer"
        onClick={onClick}
      >
        + {title}
      </Button>
    </div>
  );
};

export default AddButton;
