import { useState } from "react";
import { IoMdArrowDropdown } from "react-icons/io";
import { MdFilterList } from "react-icons/md";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function FilterComponent() {
  const [status, setStatus] = useState<string>("");
  const [phase, setPhase] = useState<string>("");
  const [location, setLocation] = useState<string>("");

  return (
    <div className="flex flex-wrap gap-2">
      <Button
        variant="default"
        className="bg-green-600 hover:bg-green-700 rounded-full text-white flex items-center gap-1 py-[0.23rem] px-[0.75rem]"
      >
        <MdFilterList className="h-4 w-4" />
        <span className="typography-paragraph-small">Filter</span>
      </Button>

      {/* status  */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="bg-white border-[0.625px] border-gray-300 typography-paragraph-small text-text-400 font-medium flex items-center gap-1 py-[0.23rem] px-[0.75rem] rounded-full"
          >
            Status
            <IoMdArrowDropdown className="h-4 w-4 ml-auto" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56">
          <DropdownMenuRadioGroup value={status} onValueChange={setStatus}>
            <DropdownMenuRadioItem value="active">Active</DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="inactive">
              Inactive
            </DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="pending">
              Pending
            </DropdownMenuRadioItem>
          </DropdownMenuRadioGroup>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* phase  */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="bg-white border-[0.625px] border-gray-300 typography-paragraph-small text-text-400 font-medium flex items-center gap-1 py-[0.23rem] px-[0.75rem] rounded-full"
          >
            Phase
            <IoMdArrowDropdown className="h-4 w-4 ml-auto" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56">
          <DropdownMenuRadioGroup value={phase} onValueChange={setPhase}>
            <DropdownMenuRadioItem value="planning">
              Planning
            </DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="development">
              Development
            </DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="testing">
              Testing
            </DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="production">
              Production
            </DropdownMenuRadioItem>
          </DropdownMenuRadioGroup>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* location  */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="bg-white border-[0.625px] border-gray-300 typography-paragraph-small text-text-400 font-medium flex items-center gap-1 py-[0.23rem] px-[0.75rem] rounded-full"
          >
            Location
            <IoMdArrowDropdown className="h-4 w-4 ml-auto" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56">
          <DropdownMenuRadioGroup value={location} onValueChange={setLocation}>
            <DropdownMenuRadioItem value="north">North</DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="south">South</DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="east">East</DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="west">West</DropdownMenuRadioItem>
          </DropdownMenuRadioGroup>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
