import { useState } from "react";
import { cn } from "@/lib/utils";

interface ToggleSwitchProps {
  options: string[];
  defaultSelected?: string;
  onChange?: (selected: string) => void;
}

export default function ToggleSwitch({
  options = ["Card", "Table"],
  defaultSelected = "Table",
  onChange,
}: ToggleSwitchProps) {
  const [selected, setSelected] = useState(defaultSelected);

  const handleSelect = (option: string) => {
    setSelected(option);
    onChange?.(option);
  };

  return (
    <div
      className={cn(
        "flex items-center p-[0.38rem] border border-boarder-300 rounded-full w-fit bg-white"
      )}
    >
      {options.map((option) => (
        <button
          key={option}
          onClick={() => handleSelect(option)}
          className={cn(
            "px-[0.75rem] py-[0.3rem] typography-paragraph-small font-medium rounded-full transition-all mx-[2px] cursor-pointer",
            selected === option
              ? "bg-green-50 text-green-500"
              : "bg-transparent text-gray-600 hover:bg-gray-200"
          )}
        >
          {option}
        </button>
      ))}
    </div>
  );
}
