import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";

import { Button } from "./ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

const Pagination = ({
  totalPages = 20,
  totalCount,
  currentPage,
}: {
  totalPages: number;
  totalCount?: number;
  currentPage?: string;
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const initialPage = parseInt(searchParams.get("page") || "1", 10);
  const itemsPerPage = parseInt(searchParams.get("perPage") || "10", 10);
  const [page, setPage] = useState(initialPage);

  useEffect(() => {
    setPage(initialPage);
  }, [initialPage]);

  const goToPage = (targetPage: number) => {
    const newParams = new URLSearchParams(searchParams);
    newParams.set("page", targetPage.toString());
    navigate(`${location.pathname}?${newParams.toString()}`, { replace: true });
  };

  const getPagesToShow = () => {
    const pages = [];

    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (page <= 3) {
        pages.push(1, 2, 3, 4, -1, totalPages);
      } else if (page >= totalPages - 2) {
        pages.push(
          1,
          -1,
          totalPages - 3,
          totalPages - 2,
          totalPages - 1,
          totalPages
        );
      } else {
        pages.push(1, -1, page - 1, page, page + 1, -1, totalPages);
      }
    }

    return pages;
  };

  return (
    <div className="flex items-center justify-between  mt-4">
      <div className="flex items-center space-x-2">
        <span className="text-sm text-text-400 typography-paragraph-caption">
          On Page
        </span>
        <Select
          value={itemsPerPage.toString()}
          onValueChange={(value) => {
            const newParams = new URLSearchParams(searchParams);
            newParams.set("page", "1");
            newParams.set("perPage", value);
            navigate(`${location.pathname}?${newParams.toString()}`, {
              replace: true,
            });
          }}
        >
          <SelectTrigger className="rounded-full py-[0.38rem] px-[0.75rem] bg-background-300 border border-boarder-300 cursor-pointer">
            <SelectValue placeholder={itemsPerPage.toString()} />
          </SelectTrigger>

          <SelectContent>
            <SelectItem value="5">5</SelectItem>
            <SelectItem value="10">10</SelectItem>
            <SelectItem value="20">20</SelectItem>
            <SelectItem value="50">50</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center justify-between  flex-wrap gap-2">
        <div className="text-sm">
          Shown {Number(currentPage) * itemsPerPage - itemsPerPage + 1}-
          {Math.min(Number(currentPage) * itemsPerPage, Number(totalCount))} of{" "}
          {totalCount}
        </div>

        <Button
          variant="ghost"
          size="icon"
          onClick={() => page > 1 && goToPage(page - 1)}
          disabled={page <= 1}
          className="h-8 w-8 cursor-pointer"
        >
          <ChevronLeft className="h-10 w-10" />
        </Button>

        {/* Pages */}
        {getPagesToShow().map((p, index) =>
          p < 0 ? (
            <span key={`ellipsis-${index}`} className="px-1">
              ...
            </span>
          ) : (
            <Button
              key={`page-${p}`}
              variant="ghost"
              size="icon"
              className={`rounded-full h-8 w-8 cursor-pointer ${
                page === p
                  ? "bg-gray-500 text-white hover:bg-gray-500 hover:text-white"
                  : "bg-white"
              }`}
              onClick={() => goToPage(p)}
            >
              {p}
            </Button>
          )
        )}

        <Button
          variant="ghost"
          size="icon"
          onClick={() => page < totalPages && goToPage(page + 1)}
          disabled={page >= totalPages}
          className="h-10 w-10 cursor-pointer"
        >
          <ChevronRight className="h-10 w-10" />
        </Button>
      </div>
    </div>
  );
};

export default Pagination;
