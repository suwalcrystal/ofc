// type FieldError = {
//   path: string;
//   msg: string;
// };

// type ErrorResponse = {
//   data?: {
//     errors?: FieldError[];
//     message?: string;
//   };
// };

// type ApiResponse = {
//   error?: ErrorResponse;
//   data?: {
//     status: string;
//     message: string;
//   };
// };

// type SetErrorCallback = (errors: Record<string, string>) => void;

// const handleErrors = (
//   response: ApiResponse,
//   setErrorCallback: SetErrorCallback
// ): void => {
//   if (response.error?.data) {
//     if (Array.isArray(response.error.data.errors)) {
//       const errorObject: Record<string, string> = {};
//       response.error.data.errors.forEach(({ path, msg }) => {
//         errorObject[path] = msg;
//       });
//       setErrorCallback(errorObject);
//     } else if (response.error.data.message) {
//       setErrorCallback({ general: response.error.data.message });
//     }
//   }
// };

// export default handleErrors;

import { AxiosError } from "axios";

type FieldError = {
  path: string;
  msg: string;
};

type SetErrorCallback = (errors: Record<string, string>) => void;

const handleErrors = (
  error: AxiosError<{ message: string; errors?: FieldError[] }>,
  setErrorCallback: SetErrorCallback
): void => {
  const errorData = error.response?.data;

  if (errorData?.errors && Array.isArray(errorData.errors)) {
    const formErrors: Record<string, string> = {};
    errorData.errors.forEach(({ path, msg }) => {
      formErrors[path] = msg;
    });
    setErrorCallback(formErrors);
  } else if (errorData?.message) {
    setErrorCallback({ general: errorData.message });
  }
};

export default handleErrors;
