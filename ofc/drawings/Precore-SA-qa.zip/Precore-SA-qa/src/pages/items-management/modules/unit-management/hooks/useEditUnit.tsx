import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { IUnitType } from "./useGetUnit";
import { UnitFormSchema, UnitFormSchemaType } from "../schema";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import { useFormik } from "formik";
import axiosInstance from "@/utils/axios-instance";
import useGetUnitDetail from "./useGetUnitDetail";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import Endpoint from "@/api/endpoints";
import handleErrors from "@/service/api.error";

type UnitEditType = UnitFormSchemaType & {
  id: string | number;
};

const editUnit = async (data: UnitEditType) => {
  const payload = {
    name: data.name,
    symbol: data.symbol,
    status: data.status ? "active" : "inactive",
  };
  const response = await axiosInstance.patch(
    `${Endpoint.unit}/${data.id}`,
    payload
  );
  return response.data;
};

const useEditUnit = (onClose: () => void) => {
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const id = searchParams.get("id") ?? "";

  const { data, isLoading } = useGetUnitDetail(id);

  const queryClient = useQueryClient();

  const { mutate, isPending, error } = useMutation<
    ApiResponseType<IUnitType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    UnitEditType
  >({
    mutationFn: editUnit,
    onSuccess: (res) => {
      onClose();
      queryClient.invalidateQueries({
        queryKey: [KEYS.unit],
      });
      searchParams.delete("id");
      navigate(`${location.pathname}?${searchParams.toString()}`);
      showSuccessMessage(res?.message || "Unit updated Successfully");
    },
    onError: (err) => {
      if (err?.response?.status === 422) {
        handleErrors(err, formik.setErrors);
      } else {
        showErrorMessage(err?.response?.data?.message || "An error occurred");
      }
    },
  });

  const formik = useFormik({
    initialValues: {
      name: data?.data?.name ?? "",
      symbol: data?.data?.symbol ?? "",
      status: data?.data?.status === "active" ? true : false,
    },
    enableReinitialize: true,
    validationSchema: UnitFormSchema,
    onSubmit: (values: UnitFormSchemaType) => {
      mutate({ id, ...values });
    },
  });

  return {
    formik,
    error,
    isPending,
    isLoading,
  };
};

export default useEditUnit;
