import * as Yup from "yup";

export const CategoryFormSchema = Yup.object({
  name: Yup.string().required("Name is required."),
  status: Yup.boolean().notRequired(),
});
export type CategoryFormSchemaType = Yup.InferType<typeof CategoryFormSchema>;
