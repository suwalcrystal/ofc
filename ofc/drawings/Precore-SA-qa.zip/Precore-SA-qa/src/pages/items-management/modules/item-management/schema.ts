import * as Yup from "yup";

// const SUPPORTED_TYPES = [
//   "image/jpeg",
//   "image/png",
//   "image/jpg",
//   "application/pdf",
//   "application/msword",
//   "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
// ];

// const imageSchema = Yup.mixed<(File | string)[]>()
//   .nullable()
//   .notRequired()
//   .test(
//     "validType",
//     "Only Image, PDF, and Word documents are allowed",
//     (value) => {
//       if (!value || value.length === 0) return true;

//       return value.every((item) => {
//         if (typeof item === "string") return true;
//         return SUPPORTED_TYPES.includes(item.type);
//       });
//     }
//   )
//   .test("fileSize", "Each file must be less than 5MB", (value) => {
//     if (!value || value.length === 0) return true;

//     return value.every((item) => {
//       if (typeof item === "string") return true;
//       return item.size <= 5 * 1024 * 1024;
//     });
//   });

export const ItemFormSchema = Yup.object({
  status: Yup.mixed(),
  image: Yup.mixed(), // this type needs to be changes
  sku: Yup.string().required("SKU is required."),
  name: Yup.string().required("Item Name is required."),
  description: Yup.string().notRequired(),
  pricePerUnit: Yup.number().required("Price is required."),
  currency: Yup.string().required("Currency is required."),
  itemCategoryId: Yup.string().notRequired(),
  supplierId: Yup.string().notRequired(),
  unitId: Yup.string().notRequired(),
  itemTypeId: Yup.string().required("Item Type is required."),
  // freeOfCharge: Yup.boolean().notRequired(),
  xeroChartOfAccounts: Yup.string().required(
    "Xero Chart of Accounts is required."
  ),
});

export type ItemFormSchemaType = Yup.InferType<typeof ItemFormSchema>;
