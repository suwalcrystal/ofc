import type { ColumnDef } from "@tanstack/react-table";
import { IItemType } from "../hooks/useGetItem";
import ItemCellActions from "./cell-actions";

import Avatar from "/src/assets/icons/avatar.svg";

export const ItemColumns: ColumnDef<IItemType>[] = [
  {
    accessorKey: "image",
    header: "Image",
    cell: ({ row }) => (
      <>
        {row.getValue("image") != null ? (
          <img
            src={row.getValue("image")}
            alt="Item Image"
            className="w-[83px] h-[54px] rounded-md"
          />
        ) : (
          <div className="flex items-center justify-center w-[83px] h-[54px] border-1 rounded-md border-[#C0C0C0] border-dashed">
            <img src={Avatar} alt="" />
          </div>
        )}
      </>
    ),
  },
  {
    header: "SKU / Item Name / Description",
    cell: ({ row }) => {
      return (
        <div className="space-y-[5px] font-medium text-base text-black">
          <p className="text-xs text-[#1E1E1E]">{row.original.sku ?? "-"}</p>
          <p>{row.original.name ?? "-"}</p>
          <p>{row.original.description ?? "-"}</p>
        </div>
      );
    },
  },

  {
    accessorKey: "pricePerUnit",
    header: "Price/Unit",
    cell: ({ row }) => <div>{row.getValue("pricePerUnit") ?? "-"}</div>,
  },
  {
    accessorKey: "itemCategory",
    header: "Category",
    cell: ({ row }) => <div>{row.original.itemCategory?.name ?? "-"}</div>,
  },
  {
    accessorKey: "supplier",
    header: "Supplier",
    cell: ({ row }) => <div>{row.original?.supplier?.name ?? "-"}</div>,
  },
  {
    accessorKey: "xeroChartOfAccounts",
    header: "Xero Chart Accounts",
    cell: ({ row }) => <div>{row.getValue("xeroChartOfAccounts") ?? "-"}</div>,
  },
  {
    accessorKey: "itemType",
    header: "Item Type",
    cell: ({ row }) => <div>{row.original.itemType?.name ?? "-"}</div>,
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => (
      <div>
        {row.getValue("status") === "active" ? (
          <li className="text-green-600 font-medium">Active</li>
        ) : (
          <li className="text-[#8E8E8E]">Inactive </li>
        )}
      </div>
    ),
  },

  {
    accessorKey: "actions",
    header: "Action",
    cell: ({ row }) => <ItemCellActions data={row.original} />,
  },
];
