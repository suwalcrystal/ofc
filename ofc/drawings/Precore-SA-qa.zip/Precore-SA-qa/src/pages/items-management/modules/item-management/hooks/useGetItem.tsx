import { useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useSearchParams } from "react-router-dom";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import axiosInstance from "@/utils/axios-instance";
import Endpoint from "@/api/endpoints";

export interface IItemType {
  id: string;
  name: string;
  status: "active" | "inactive";
  image: string | null;
  description: string;
  link: string;
  pricePerUnit: number;
  currency: string;
  unitId: string;
  itemCategoryId: string;
  itemTypeId: string;
  supplierId: string;
  createdAt: string;
  updatedAt: string;
  sku: string;
  supplier: {
    id: string;
    name: string;
  };
  itemCategory: {
    id: string;
    name: string;
  };
  itemType: {
    id: string;
    name: string;
  };
  xeroChartOfAccounts: string;
}

const useGetItem = () => {
  const [searchParams] = useSearchParams();
  const page = searchParams.get("page") ?? "1";
  const search = searchParams.get("search") ?? "";

  return useQuery<
    ApiResponseType<IItemType[]>,
    AxiosError<{ message: string; error: Record<string, unknown> }>
  >({
    queryKey: [KEYS.item, page, search],
    queryFn: async () => {
      const response = await axiosInstance.get(Endpoint.item, {
        params: {
          page: page,
          search: search,
        },
      });
      return response?.data;
    },
  });
};

export default useGetItem;
