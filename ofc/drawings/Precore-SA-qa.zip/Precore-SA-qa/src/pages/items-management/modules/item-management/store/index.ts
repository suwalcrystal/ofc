import { create as createZustand } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

interface Store {
  isFilterOpen: boolean;
  setIsFilterOpen: (isFilterOpen: boolean) => void;
}

export const useItemStore = createZustand<Store>()(
  persist(
    (set) => ({
      isFilterOpen: false,
      setIsFilterOpen: (isFilterOpen) => set({ isFilterOpen }),
    }),
    {
      name: "filter-open",
      storage: createJSONStorage(() => sessionStorage),
    }
  )
);
