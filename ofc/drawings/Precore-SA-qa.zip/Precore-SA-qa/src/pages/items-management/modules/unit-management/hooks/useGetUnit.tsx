import { useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useSearchParams } from "react-router-dom";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import axiosInstance from "@/utils/axios-instance";
import Endpoint from "@/api/endpoints";

export interface IUnitType {
  id: string;
  name: string;
  symbol: string;
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
}

const useGetUnit = () => {
  const [searchParams] = useSearchParams();
  const page = searchParams.get("page") ?? "1";
  const perPage = searchParams.get("perPage") ?? "10";

  return useQuery<
    ApiResponseType<IUnitType[]>,
    AxiosError<{ message: string; error: Record<string, unknown> }>
  >({
    queryKey: [KEYS.unit, page, perPage],
    queryFn: async () => {
      const response = await axiosInstance.get(Endpoint.unit, {
        params: {
          page: page,
          perPage: perPage,
        },
      });
      return response?.data;
    },
  });
};

export default useGetUnit;
