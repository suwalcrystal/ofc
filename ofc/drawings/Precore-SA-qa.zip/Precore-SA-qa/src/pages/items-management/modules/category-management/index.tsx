import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useState } from "react";
import useGetCategory from "./hooks/useGetCategory";
import { DataTable } from "@/components/DataTable";
import { CategoryColumns } from "./partials/columns";
import AddCategory from "./partials/add-category";
import Pagination from "@/components/Pagination";

const CategoryManagement = () => {
  const { data: category, isLoading } = useGetCategory();

  const [open, setOpen] = useState(false);
  function handleAddCategoryModal() {
    setOpen((prev) => !prev);
  }

  return (
    <div>
      <div className="border-b-2 border-white py-4 mb-6 flex items-center justify-between mb-6">
        <h3 className="text-text-500 typography-h3 font-semibold">
          Category Management
        </h3>

        <Button
          className="bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer"
          onClick={handleAddCategoryModal}
        >
          Add Category
        </Button>
      </div>

      {/* Category Table */}

      <DataTable
        message="No Category Found"
        data={category?.data || []}
        isLoading={isLoading}
        columns={CategoryColumns}
      />

      {category?.pagination?.totalRecords &&
      category?.pagination?.totalRecords > 10 ? (
        <Pagination
          currentPage={category?.pagination?.currentPage}
          totalCount={category?.pagination?.totalRecords}
          totalPages={category?.pagination?.totalPages}
        />
      ) : (
        ""
      )}
      <Dialog open={open} onOpenChange={handleAddCategoryModal}>
        <DialogContent className={cn("p-6 min-w-[630px] ")}>
          <DialogTitle>Add Category</DialogTitle>
          <DialogDescription>
            <AddCategory onClose={handleAddCategoryModal} />
          </DialogDescription>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CategoryManagement;
