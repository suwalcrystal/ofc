import { useLocation, useNavigate, useSearchParams } from "react-router-dom";

const FILTER_KEYS = [
  "name",
  "supplier",
  "category",
  "currency",
  "freeOfCharge",
  "xeroChartOfAccounts",
  "active",
  "itemType",
  "onPage",
] as const;

type FilterKey = (typeof FILTER_KEYS)[number];
type FilterParams = Partial<Record<FilterKey, string>>;

const useFilterItem = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();

  const filterValues = FILTER_KEYS.reduce(
    (acc, key) => {
      acc[key] = searchParams.get(key) ?? "";
      return acc;
    },
    {} as Record<FilterKey, string>
  );

  const updateSearchParams = (params: FilterParams) => {
    const updatedSearchParams = new URLSearchParams(searchParams);

    Object.entries(params).forEach(([key, value]) => {
      if (value === "") {
        updatedSearchParams.delete(key);
      } else {
        updatedSearchParams.set(key, value);
      }
    });

    navigate(`${location.pathname}?${updatedSearchParams.toString()}`, {
      replace: true,
    });
  };

  const handleResetFilter = () => {
    navigate(location.pathname, { replace: true });
  };

  return {
    ...filterValues,
    updateSearchParams,
    handleResetFilter,
  };
};

export default useFilterItem;
