import { useState } from "react";
import Edit from "/src/assets/icons/edit.svg";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "../../../../../components/ui/dialog";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { cn } from "../../../../../lib/utils";
import { IItemType } from "../hooks/useGetItem";
import Delete from "/src/assets/icons/delete.svg";
import DeleteModal from "@/components/DeleteModal";
import useDeleteItems from "../hooks/useDeleteItem";
import EditItem from "./edit-item";

const ItemCellActions = ({ data }: { data: IItemType }) => {
  const [open, setOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState<boolean>(false);
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();

  function handleEditItemModal() {
    searchParams.set("id", data?.id);
    navigate(`${location.pathname}?${searchParams.toString()}`);
    setIsEditOpen((prev) => !prev);
  }

  const { deleteItems, isPending } = useDeleteItems({
    handleDeleteModalToggle,
  });

  function handleDeleteModalToggle() {
    setOpen((prev) => !prev);
  }

  function handleDeleteItem() {
    deleteItems({ id: data?.id });
  }

  return (
    <>
      <div className="flex items-end gap-4 ml-2">
        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <img
            onClick={handleEditItemModal}
            src={Edit}
            alt="Edit"
            className="h-4"
          />
          <DialogContent
            className={cn(
              "p-6  min-w-[630px] max-h-[750px] cursor-pointer overflow-y-auto"
            )}
          >
            <DialogTitle>Edit Item</DialogTitle>
            <DialogDescription>
              <EditItem onClose={handleEditItemModal} />
            </DialogDescription>
          </DialogContent>
        </Dialog>

        <img
          className="h-4"
          src={Delete}
          alt="Delete"
          onClick={handleDeleteModalToggle}
        />
      </div>

      <DeleteModal
        text={``}
        title="Item"
        onClose={handleDeleteModalToggle}
        open={open}
        onDelete={handleDeleteItem}
        loading={isPending}
      />
    </>
  );
};

export default ItemCellActions;
