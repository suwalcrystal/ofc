import type { ColumnDef } from "@tanstack/react-table";
import { IUnitType } from "../hooks/useGetUnit";
import UnitCellActions from "./cell-actions";

export const UnitColumns: ColumnDef<IUnitType>[] = [
  {
    accessorKey: "name",
    header: "Name",
    cell: ({ row }) => <div>{row.getValue("name") ?? "-"}</div>,
  },
  {
    accessorKey: "symbol",
    header: "Symbol",
    cell: ({ row }) => <div>{row.getValue("symbol") ?? "-"}</div>,
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => (
      <div>
        {row.getValue("status") === "active" ? (
          <li className="text-green-600 font-medium">Active</li>
        ) : (
          <li className="text-[#8E8E8E]">Inactive </li>
        )}
      </div>
    ),
  },

  {
    accessorKey: "actions",
    header: "Action",
    cell: ({ row }) => <UnitCellActions data={row.original} />,
  },
];
