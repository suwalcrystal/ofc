import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";

import { useFormik } from "formik";
import { CategoryFormSchema, CategoryFormSchemaType } from "../schema";
import { KEYS } from "@/lib/keys";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import { ApiResponseType } from "@/lib/type";
import axiosInstance from "@/utils/axios-instance";
import Endpoint from "@/api/endpoints";
import handleErrors from "@/service/api.error";

interface ICategoryType {
  id: string;
  name: string;
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
  message?: string;
}

const addCategory = async (data: CategoryFormSchemaType) => {
  const payload = {
    ...data,
    status: data.status ? "active" : "inactive",
  };
  const response = await axiosInstance.post(Endpoint.category, payload);
  return response.data;
};

const useAddCategory = (onClose: () => void) => {
  const queryClient = useQueryClient();

  const { mutate, isPending, error } = useMutation<
    ApiResponseType<ICategoryType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    CategoryFormSchemaType
  >({
    mutationFn: addCategory,
    onSuccess: (res) => {
      onClose();
      queryClient.invalidateQueries({
        queryKey: [KEYS.category],
      });
      showSuccessMessage(res?.message || "Category Created Successfully");
    },
    onError: (err) => {
      if (err?.response?.status === 422) {
        handleErrors(err, formik.setErrors);
      } else {
        showErrorMessage(
          err?.response?.data?.message ||
            "An error occurred while adding the category"
        );
      }
    },
  });

  const formik = useFormik({
    initialValues: {
      name: "",
      status: false,
    },
    validationSchema: CategoryFormSchema,
    onSubmit: (values) => {
      mutate(values);
    },
  });

  return {
    formik,
    error,
    isPending,
  };
};

export default useAddCategory;
