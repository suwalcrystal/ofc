import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import axiosInstance from "@/utils/axios-instance";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import Endpoint from "@/api/endpoints";
import { ICategoryType } from "./useGetCategory";

interface DeleteCategoryProps {
  id?: number | string;
}

const deleteCategory = async (data: DeleteCategoryProps) => {
  const response = await axiosInstance.delete(
    `${Endpoint.category}/${data.id}`
  );
  return response.data;
};

const useDeleteCategory = ({
  handleDeleteModalToggle,
}: {
  handleDeleteModalToggle: () => void;
}) => {
  const queryClient = useQueryClient();

  const { mutate, isPending } = useMutation<
    ApiResponseType<ICategoryType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    DeleteCategoryProps
  >({
    mutationFn: deleteCategory,
    onSuccess: (res) => {
      handleDeleteModalToggle();
      queryClient.invalidateQueries({
        queryKey: [KEYS.category],
      });
      showSuccessMessage(res?.message || "Category deleted Successfully");
    },
    onError: (error) => {
      showErrorMessage(
        error?.response?.data.message ||
          "Failed to delete Category. Please try again."
      );
    },
  });

  const deleteCategoryies = (data: DeleteCategoryProps) => {
    mutate(data);
  };

  return {
    isPending,
    deleteCategoryies,
  };
};

export default useDeleteCategory;
