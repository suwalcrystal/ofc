export const ACTIVE = [
  {
    label: "Active",
    value: "active",
  },
  {
    label: "Inactive",
    value: "inactive",
  },
];

export const CURRENCY = [
  { label: "AED", value: "AED" },
  { label: "EUR", value: "EUR" },
  { label: "USD", value: "USD" },
];

export const FREE_OF_CHARGE = [
  {
    label: "Yes",
    value: "yes",
  },
  {
    label: "No",
    value: "no",
  },
];

export const XERO_CHART_OF_ACCOUNTS = [
  {
    label: "Cost of Goods Sold",
    value: "COST_OF_GOODS_SOLD",
  },
  { label: "Office Expenses", value: "OFFICE_EXPENSES" },
  {
    label: "Equipment Rental",
    value: "EQUIPMENT_RENTALS",
  },
  {
    label: "Sub Contractor",
    value: "SUB_CONTRACTOR",
  },
];

export const ITEM_TYPE = [
  {
    label: "Consumable",
    value: "consumable",
  },
];

export const ON_PAGE = [
  {
    label: "10",
    value: "10",
  },
  {
    label: "20",
    value: "20",
  },
  {
    label: "50",
    value: "50",
  },
  {
    label: "100",
    value: "100",
  },
  {
    label: "100",
    value: "100",
  },
];

export const UNIT = [
  {
    label: "Meter",
    value: "meter",
  },
  {
    label: "Piece",
    value: "piece",
  },
  {
    label: "Pack",
    value: "pack",
  },
  {
    label: "Kilogram",
    value: "kilogram",
  },
  {
    label: "litre",
    value: "litre",
  },
  {
    label: "Box",
    value: "box",
  },
];
