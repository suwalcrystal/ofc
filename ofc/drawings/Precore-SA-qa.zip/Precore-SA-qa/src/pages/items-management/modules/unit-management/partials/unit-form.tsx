import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useFormikContext } from "formik";

interface UnitFormValues {
  name: string;
  symbol?: string;
  status?: string;
}

export const UnitForm = () => {
  const formik = useFormikContext<UnitFormValues>();
  return (
    <div className=" flex space-y-4 flex-col my-6">
      <div className="space-y-2">
        <Label
          htmlFor="name"
          className="typography-paragraph-small font-medium text-text-500"
        >
          Name <span className="text-error">*</span>
        </Label>
        <Input
          id="name"
          name="name"
          type="text"
          placeholder="Name"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.name}
          className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
        />
        {formik.touched.name && formik.errors.name && (
          <p className="text-red-500 typography-paragraph-small ">
            {formik.errors.name}
          </p>
        )}
      </div>
      <div className="space-y-2">
        <Label
          htmlFor="symbol"
          className="typography-paragraph-small font-medium text-text-500"
        >
          Symbol <span className="text-error">*</span>
        </Label>
        <Input
          id="symbol"
          name="symbol"
          type="text"
          placeholder="Symbol"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.symbol}
          className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
        />

        {formik.touched.symbol && formik.errors.symbol && (
          <p className="text-red-500 typography-paragraph-small ">
            {formik.errors.symbol}
          </p>
        )}
      </div>
      <div className="space-y-2">
        <Label
          htmlFor="status"
          className="typography-paragraph-small font-medium text-text-500"
        >
          Status
        </Label>
        <div className="flex items-center space-x-4 mt-3">
          <Switch
            name="status"
            onBlur={formik.handleBlur}
            checked={String(formik.values.status) === "true"}
            onCheckedChange={(checked: boolean) =>
              formik.setFieldValue("status", checked)
            }
            id="status"
          />

          <Label
            htmlFor="status"
            className="typography-paragraph-small font-medium text-text-500 -ml-2"
          >
            Active
          </Label>
        </div>
        {formik.touched.status && formik.errors.status && (
          <p className="text-red-500 typography-paragraph-small ">
            {formik.errors.status}
          </p>
        )}
      </div>
    </div>
  );
};
