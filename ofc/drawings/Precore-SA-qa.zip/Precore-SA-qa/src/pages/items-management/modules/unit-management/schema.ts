import * as Yup from "yup";

export const UnitFormSchema = Yup.object({
  name: Yup.string().required("Name is required."),
  symbol: Yup.string().required("Symbol is required."),
  status: Yup.boolean().notRequired(),
});
export type UnitFormSchemaType = Yup.InferType<typeof UnitFormSchema>;
