import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { useFormik } from "formik";

import { IItemType } from "./useGetItem";
import useGetItemDetail from "./useGetItemDetail";
import axiosInstance from "@/utils/axios-instance";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import Endpoint from "@/api/endpoints";
import { ItemFormSchema, ItemFormSchemaType } from "../schema";
import handleErrors from "@/service/api.error";

type ItemEditType = ItemFormSchemaType & { id: string | number };

const editItem = async (data: ItemEditType) => {
  const { id, ...rest } = data;
  const formData = new FormData();
  if (typeof rest.image === "string") {
    formData.append("image", rest.image);
  } else if (Array.isArray(rest.image) && rest.image.length > 0) {
    rest.image
      .filter((file): file is File => file instanceof File)
      .forEach((file: File) => {
        formData.append("image", file);
      });
  }
  formData.append("status", rest.status ? "active" : "inactive");
  formData.append("sku", rest.sku);
  formData.append("name", rest.name);
  formData.append("description", rest.description || "");
  formData.append("pricePerUnit", rest.pricePerUnit.toString());
  formData.append("currency", rest.currency);
  formData.append("unitId", rest.unitId || "");
  formData.append("itemCategoryId", rest.itemCategoryId || "");
  formData.append("supplierId", rest.supplierId || "");
  formData.append("itemTypeId", rest.itemTypeId || "");
  formData.append("xeroChartOfAccounts", rest.xeroChartOfAccounts || "");

  //   formData.forEach((value, key) => {
  //     console.log(`Key: ${key}, Value: ${value}`);
  //   });

  const response = await axiosInstance.patch(
    `${Endpoint.item}/${id}`,
    formData
  );

  return response.data;
};

const useEditItem = (onClose: () => void) => {
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const id = searchParams.get("id") ?? "";
  const { data, isLoading } = useGetItemDetail(id);

  const { mutate, isPending, error } = useMutation<
    ApiResponseType<IItemType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    ItemEditType
  >({
    mutationFn: editItem,
    onSuccess: (res) => {
      onClose();
      queryClient.invalidateQueries({ queryKey: [KEYS.item] });

      searchParams.delete("id");
      navigate(`${location.pathname}?${searchParams.toString()}`);

      showSuccessMessage(res?.message || "Item updated successfully");
    },
    onError: (err) => {
      if (err?.response?.status === 422) {
        handleErrors(err, formik.setErrors);
      } else {
        showErrorMessage(
          err?.response?.data?.message ||
            "An error occurred while updating the item"
        );
      }
    },
  });

  const formik = useFormik({
    initialValues: {
      status: data?.data?.status === "active",
      image: data?.data?.image || [],
      sku: data?.data?.sku || "",
      name: data?.data?.name || "",
      description: data?.data?.description || "",
      pricePerUnit: data?.data?.pricePerUnit || 0,
      currency: data?.data?.currency || "",
      unitId: data?.data?.unitId || "",
      itemCategoryId: String(data?.data?.itemCategoryId || ""),
      supplierId: data?.data?.supplierId || "",
      itemTypeId: data?.data?.itemTypeId || "",
      xeroChartOfAccounts: data?.data?.xeroChartOfAccounts || "",
    },
    enableReinitialize: true,
    validationSchema: ItemFormSchema,
    onSubmit: (values: ItemFormSchemaType) => {
      mutate({ id, ...values });
    },
  });

  return {
    formik,
    error,
    isPending,
    isLoading,
  };
};

export default useEditItem;
