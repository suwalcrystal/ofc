import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import axiosInstance from "@/utils/axios-instance";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import Endpoint from "@/api/endpoints";
import { IItemType } from "./useGetItem";

interface DeleteItemProps {
  id?: number | string;
}

const deleteItem = async (data: DeleteItemProps) => {
  const response = await axiosInstance.delete(`${Endpoint.item}/${data.id}`);
  return response.data;
};

const useDeleteItems = ({
  handleDeleteModalToggle,
}: {
  handleDeleteModalToggle: () => void;
}) => {
  const queryClient = useQueryClient();

  const { mutate, isPending } = useMutation<
    ApiResponseType<IItemType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    DeleteItemProps
  >({
    mutationFn: deleteItem,
    onSuccess: (res) => {
      handleDeleteModalToggle();
      queryClient.invalidateQueries({
        queryKey: [KEYS.item],
      });
      showSuccessMessage(res?.message || "Item deleted Successfully");
    },
    onError: (error) => {
      showErrorMessage(
        error?.response?.data.message ||
          "Failed to delete item . Please try again."
      );
    },
  });

  const deleteItems = (data: DeleteItemProps) => {
    mutate(data);
  };

  return {
    isPending,
    deleteItems,
  };
};

export default useDeleteItems;
