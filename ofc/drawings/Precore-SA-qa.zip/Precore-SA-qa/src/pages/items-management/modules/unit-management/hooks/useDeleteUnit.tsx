import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import axiosInstance from "@/utils/axios-instance";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import Endpoint from "@/api/endpoints";
import { IUnitType } from "./useGetUnit";

interface DeleteUnitProps {
  id?: number | string;
}

const deleteUnit = async (data: DeleteUnitProps) => {
  const response = await axiosInstance.delete(`${Endpoint.unit}/${data.id}`);
  return response.data;
};

const useDeleteUnits = ({
  handleDeleteModalToggle,
}: {
  handleDeleteModalToggle: () => void;
}) => {
  const queryClient = useQueryClient();

  const { mutate, isPending } = useMutation<
    ApiResponseType<IUnitType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    DeleteUnitProps
  >({
    mutationFn: deleteUnit,
    onSuccess: (res) => {
      handleDeleteModalToggle();
      queryClient.invalidateQueries({
        queryKey: [KEYS.unit],
      });
      showSuccessMessage(res?.message || "Unit deleted Successfully");
    },
    onError: (error) => {
      showErrorMessage(
        error?.response?.data.message ||
          "Failed to delete unit unit. Please try again."
      );
    },
  });

  const deleteUnits = (data: DeleteUnitProps) => {
    mutate(data);
  };

  return {
    isPending,
    deleteUnits,
  };
};

export default useDeleteUnits;
