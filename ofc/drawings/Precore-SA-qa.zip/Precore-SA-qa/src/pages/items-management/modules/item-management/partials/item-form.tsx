import SelectField from "@/components/SelectField";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useFormikContext } from "formik";
import { CURRENCY, XERO_CHART_OF_ACCOUNTS } from "../data";
import useGetSuppliers from "../hooks/useGetSuppliers";
import useGetCategory from "../../category-management/hooks/useGetCategory";
import FileUploader from "@/components/FileUploader";
import useGetUnit from "../../unit-management/hooks/useGetUnit";
import useGetItemType from "../hooks/useGetItemType";

interface ItemFormValues {
  status?: string;
  image?: File[] | null;
  sku: string;
  charge?: string | number | null;
  name: string;
  description?: string;
  pricePerUnit: number;
  currency: string;
  unitId?: string;
  itemCategoryId?: string;
  supplierId?: string;
  itemTypeId?: string;
  xeroChartOfAccounts?: string;
}

export const ItemForm = () => {
  const formik = useFormikContext<ItemFormValues>();

  const { data: suppliers } = useGetSuppliers();
  const { data: categories } = useGetCategory();
  const { data: unit } = useGetUnit();
  const { data: itemType } = useGetItemType();

  const suppliersOptions = suppliers?.data?.map(
    (supplier: { id: string; name: string }) => {
      return { label: supplier.name, value: supplier.id };
    }
  );

  const categoriesOptions = categories?.data?.map(
    (category: { id: string; name: string }) => {
      return { label: category.name, value: category.id };
    }
  );

  const unitOptions = unit?.data?.map((unit: { id: string; name: string }) => {
    return { label: unit.name, value: unit.id };
  });
  const itemTypeOptions = itemType?.data?.map(
    (item: { id: string; name: string }) => {
      return { label: item.name, value: item.id };
    }
  );

  return (
    <div className=" flex space-y-4 flex-col my-6 ">
      <div className="space-y-2">
        <Label
          htmlFor="status"
          className="typography-paragraph-small font-medium text-text-500"
        >
          Status
        </Label>
        <div className="flex items-center space-x-4 mt-3">
          <Switch
            name="status"
            onBlur={formik.handleBlur}
            checked={String(formik.values.status) === "true"}
            onCheckedChange={(checked: boolean) =>
              formik.setFieldValue("status", checked)
            }
            id="status"
          />

          <Label
            htmlFor="status"
            className="typography-paragraph-small font-medium text-text-500 -ml-2"
          >
            Active
          </Label>
        </div>
        {formik.touched.status && formik.errors.status && (
          <p className="text-red-500 typography-paragraph-small ">
            {formik.errors.status}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <FileUploader
          name="image"
          value={formik.values.image || []}
          setFieldValue={(field: string, value: File[] | string | null) =>
            formik.setFieldValue(field, value)
          }
        />
      </div>
      <div className="space-y-2">
        <Label
          htmlFor="sku"
          className="typography-paragraph-small font-medium text-text-500"
        >
          SKU <span className="text-error">*</span>
        </Label>
        <Input
          id="sku"
          name="sku"
          type="text"
          placeholder="SKU"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.sku}
          className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
        />

        {formik.touched.sku && formik.errors.sku && (
          <p className="text-red-500 typography-paragraph-small ">
            {formik.errors.sku}
          </p>
        )}
      </div>
      <div className="space-y-2">
        <Label
          htmlFor="name"
          className="typography-paragraph-small font-medium text-text-500"
        >
          Item Name <span className="text-error">*</span>
        </Label>
        <Input
          id="name"
          name="name"
          type="text"
          placeholder="Item Name"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.name}
          className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
        />
        {formik.touched.name && formik.errors.name && (
          <p className="text-red-500 typography-paragraph-small ">
            {formik.errors.name}
          </p>
        )}
      </div>
      <div className="space-y-2">
        <Label
          htmlFor="description"
          className="typography-paragraph-small font-medium text-text-500"
        >
          Description
        </Label>
        <Textarea
          name="description"
          value={formik.values.description}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          placeholder="Description"
          className="h-[7rem] border-boarder-300 bg-background-100 rounded-[8px] focus-visible:border-green-500 focus-visible:ring-0"
        />
        {formik.touched.description && formik.errors.description && (
          <p className="text-red-500 typography-paragraph-small ">
            {formik.errors.description}
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-y-3">
          <div className="space-y-2">
            <Label
              htmlFor="pricePerUnit"
              className="typography-paragraph-small font-medium text-text-500"
            >
              Price <span className="text-error">*</span>
            </Label>
            <Input
              id="pricePerUnit"
              name="pricePerUnit"
              type="number"
              placeholder="Price"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.pricePerUnit}
              className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
            />

            {formik.touched.pricePerUnit && formik.errors.pricePerUnit && (
              <p className="text-red-500 typography-paragraph-small ">
                {formik.errors.pricePerUnit}
              </p>
            )}
          </div>

          {/* <div className="flex gap-x-2">
            <Checkbox
              id="charge"
              name="charge"
              aria-label="Free of Charge"
              checked={formik.values.charge === 0}
              onCheckedChange={(checked) => {
                formik.setFieldValue("charge", checked ? 0 : null);
              }}
            />

            <Label
              htmlFor="charge"
              className="typography-paragraph-small font-normal text-text-500 cursor-pointer"
            >
              Free of Charge
            </Label>
          </div> */}
        </div>
        <div className="space-y-4">
          <SelectField
            label="Currency"
            name="currency"
            value={formik.values.currency}
            onChange={(val) => formik.setFieldValue("currency", val)}
            options={CURRENCY}
            placeholder="Select"
            touched={formik.touched.currency}
            error={formik.errors.currency}
          />
        </div>
      </div>

      <div className="space-y-2">
        <SelectField
          isRequired={false}
          label="Unit"
          name="unitId"
          value={formik.values.unitId}
          onChange={(val) => formik.setFieldValue("unitId", val)}
          options={unitOptions || []}
          placeholder="Select"
          touched={formik.touched.unitId}
          error={formik.errors.unitId}
        />
      </div>

      <div className="space-y-2">
        <SelectField
          isRequired={false}
          label="Category"
          name="itemCategoryId"
          value={formik.values.itemCategoryId || ""}
          onChange={(val) => {
            formik.setFieldValue("itemCategoryId", val);
          }}
          options={categoriesOptions || []}
          placeholder="Select"
          touched={formik.touched.itemCategoryId}
          error={formik.errors.itemCategoryId}
        />
      </div>

      <div className="space-y-2">
        <SelectField
          isRequired={false}
          label="Supplier"
          name="supplierId"
          value={formik.values.supplierId || ""}
          onChange={(val) => formik.setFieldValue("supplierId", val)}
          options={suppliersOptions || []}
          placeholder="Select"
          touched={formik.touched.supplierId}
          error={formik.errors.supplierId}
        />
      </div>

      <div className="space-y-2">
        <SelectField
          label="Item Type"
          name="itemTypeId"
          value={formik.values.itemTypeId || ""}
          onChange={(val) => formik.setFieldValue("itemTypeId", val)}
          options={itemTypeOptions || []}
          placeholder="Select"
          touched={formik.touched.itemTypeId}
          error={formik.errors.itemTypeId}
        />
      </div>
      <div className="space-y-2">
        <SelectField
          label="Xero Chart of Accounts"
          name="xeroChartOfAccounts"
          value={formik.values.xeroChartOfAccounts}
          onChange={(val) => formik.setFieldValue("xeroChartOfAccounts", val)}
          options={XERO_CHART_OF_ACCOUNTS}
          placeholder="Select"
          touched={formik.touched.xeroChartOfAccounts}
          error={formik.errors.xeroChartOfAccounts}
        />
      </div>
    </div>
  );
};
