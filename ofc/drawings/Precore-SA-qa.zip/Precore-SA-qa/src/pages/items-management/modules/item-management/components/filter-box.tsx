import { FormikProvider, useFormik } from "formik";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import SelectField from "@/components/SelectField";
import ExtendedButton from "@/components/ExtendedButton";

import useFilterItem from "../hooks/useFIlterItem";
import useGetSuppliers from "../hooks/useGetSuppliers";
import useGetCategory from "../../category-management/hooks/useGetCategory";
import {
  ACTIVE,
  CURRENCY,
  FREE_OF_CHARGE,
  ITEM_TYPE,
  ON_PAGE,
  XERO_CHART_OF_ACCOUNTS,
} from "../data";
import { useItemStore } from "../store";
import { X } from "lucide-react";

const FilterBox = () => {
  const { setIsFilterOpen } = useItemStore();
  const { data: suppliers } = useGetSuppliers();
  const { data: categories } = useGetCategory();

  const {
    name,
    supplier,
    category,
    currency,
    freeOfCharge,
    xeroChartOfAccounts,
    active,
    itemType,
    onPage,
    updateSearchParams,
    handleResetFilter,
  } = useFilterItem();

  const initialValues = {
    name,
    supplier,
    category,
    currency,
    freeOfCharge,
    xeroChartOfAccounts,
    active,
    itemType,
    onPage,
  };

  const formik = useFormik({
    initialValues,
    enableReinitialize: true,
    onSubmit: (values) => {
      updateSearchParams(values);
    },
  });

  const handleReset = () => {
    handleResetFilter();
    formik.resetForm({
      values: Object.fromEntries(
        Object.keys(initialValues).map((key) => [key, ""])
      ) as typeof initialValues,
    });
  };

  const suppliersOptions = suppliers?.data?.map(
    (supplier: { id: string; name: string }) => {
      return { label: supplier.name, value: supplier.id };
    }
  );

  const categoriesOptions = categories?.data?.map(
    (category: { id: string; name: string }) => {
      return { label: category.name, value: category.id };
    }
  );

  const selectFields = [
    {
      name: "supplier",
      label: "Supplier",
      options: suppliersOptions ?? [],
    },
    {
      name: "category",
      label: "Category",
      options: categoriesOptions ?? [],
    },
    { name: "currency", label: "Currency", options: CURRENCY },
    {
      name: "freeOfCharge",
      label: "Free of Charge",
      options: FREE_OF_CHARGE,
    },
    {
      name: "xeroChartOfAccounts",
      label: "Xero Chart of Accounts",
      options: XERO_CHART_OF_ACCOUNTS,
    },
    { name: "active", label: "Active", options: ACTIVE },
    { name: "itemType", label: "Item Type", options: ITEM_TYPE },
    { name: "page", label: "On Page", options: ON_PAGE },
  ] as {
    name: keyof typeof initialValues;
    label: string;
    options: [];
  }[];

  return (
    <div className="bg-white p-6 mb-4">
      <div className="flex items-center justify-between ">
        <p className="font-semibold text-2xl">Filter</p>
        <X className="cursor-pointer" onClick={() => setIsFilterOpen(false)} />
      </div>
      <FormikProvider value={formik}>
        <form
          onSubmit={formik.handleSubmit}
          className="space-y-6 bg-background-200 my-4 rounded-[0.5rem] shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]"
        >
          <div className="grid grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label
                htmlFor="name"
                className="typography-paragraph-small font-medium text-text-500"
              >
                Item Name
              </Label>
              <Input
                id="name"
                name="name"
                type="text"
                placeholder="Name"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.name}
                className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
              />
            </div>
            {selectFields?.map(({ name, label, options }) => (
              <SelectField
                key={name}
                label={label}
                name={name}
                value={formik.values[name]}
                onChange={(val) => formik.setFieldValue(name, val)}
                options={options}
                placeholder="Select"
              />
            ))}
          </div>

          <div className="flex gap-5 justify-between mt-10 w-full">
            <ExtendedButton
              type="submit"
              className="w-[130px] p-[1.25rem] border border-green-500 px-4"
              text="Filter Results"
            />
            <Button
              type="button"
              onClick={handleReset}
              className="p-[1.25rem] rounded-full typography-paragraph-small font-medium cursor-pointer w-[110px] bg-white border border-red-400 text-red-400 hover:bg-red-400 hover:text-white"
            >
              Reset All
            </Button>
          </div>
        </form>
      </FormikProvider>
    </div>
  );
};

export default FilterBox;
