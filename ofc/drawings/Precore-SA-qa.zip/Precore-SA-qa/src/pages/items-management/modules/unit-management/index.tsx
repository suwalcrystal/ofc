import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useState } from "react";
import AddUnit from "./partials/add-unit";
import useGetUnit from "./hooks/useGetUnit";
import { UnitColumns } from "./partials/columns";
import { DataTable } from "@/components/DataTable";
import Pagination from "@/components/Pagination";

const UnitManagement = () => {
  const { data: unit, isLoading } = useGetUnit();

  const [open, setOpen] = useState(false);
  function handleAddUnitModal() {
    setOpen((prev) => !prev);
  }

  return (
    <div>
      <div className="border-b-2 border-white py-4 mb-6 flex items-center justify-between mb-6">
        <h3 className="text-text-500 typography-h3 font-semibold">
          Unit Management
        </h3>

        <Button
          className="bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer"
          onClick={handleAddUnitModal}
        >
          Add Unit
        </Button>
      </div>

      {/* Unit Table */}
      <DataTable
        message="No Units Found"
        data={unit?.data || []}
        isLoading={isLoading}
        columns={UnitColumns}
      />

      {unit?.pagination?.totalRecords && unit?.pagination?.totalRecords > 10 ? (
        <Pagination
          currentPage={unit?.pagination?.currentPage}
          totalCount={unit?.pagination?.totalRecords}
          totalPages={unit?.pagination?.totalPages}
        />
      ) : (
        ""
      )}

      <Dialog open={open} onOpenChange={handleAddUnitModal}>
        <DialogContent className={cn("p-6 min-w-[630px] ")}>
          <DialogTitle>Add Unit</DialogTitle>
          <DialogDescription>
            <AddUnit onClose={handleAddUnitModal} />
          </DialogDescription>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UnitManagement;
