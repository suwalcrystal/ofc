//this location needs to be changed
import { useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useSearchParams } from "react-router-dom";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import axiosInstance from "@/utils/axios-instance";
import Endpoint from "@/api/endpoints";

export interface IItemTypeType {
  id: string;
  name: string;
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
}

const useGetItemType = () => {
  const [searchParams] = useSearchParams();
  const page = searchParams.get("page") ?? "1";
  const search = searchParams.get("search") ?? "";

  return useQuery<
    ApiResponseType<IItemTypeType[]>,
    AxiosError<{ message: string; error: Record<string, unknown> }>
  >({
    queryKey: [KEYS.itemType, page, search],
    queryFn: async () => {
      const response = await axiosInstance.get(Endpoint.itemType, {
        params: {
          page: page,
          search: search,
        },
      });
      return response?.data;
    },
  });
};

export default useGetItemType;
