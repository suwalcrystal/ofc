import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { FormikProvider } from "formik";
import { UnitForm } from "./unit-form";
import FormSkeleton from "@/components/skeleton/FormSkeleton";
import { Button } from "@/components/ui/button";
import ExtendedButton from "@/components/ExtendedButton";
import useEditUnit from "../hooks/useEditUnit";

interface EditUnitProps {
  onClose: () => void;
}

export default function EditUnit({ onClose }: EditUnitProps) {
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { isPending, formik, isLoading } = useEditUnit(onClose);
  if (isLoading) {
    return <FormSkeleton />;
  }

  return (
    <>
      <FormikProvider value={formik}>
        <form
          onSubmit={formik.handleSubmit}
          className="space-y-6 bg-background-200 rounded-[0.5rem] shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]"
        >
          <UnitForm />
          <div className="flex gap-5  mt-10 w-full">
            <Button
              type="button"
              className=" p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium cursor-pointer w-[110px]"
              variant="outline"
              onClick={() => {
                onClose();
                formik.setErrors({});
                searchParams.delete("id");
                navigate(`${location.pathname}?${searchParams.toString()}`);
              }}
            >
              Cancel
            </Button>
            <ExtendedButton
              type="submit"
              className="w-[110px] p-[1.25rem] border border-green-500  "
              text={"Save"}
              isLoading={isPending}
            />
          </div>
        </form>
      </FormikProvider>
    </>
  );
}
