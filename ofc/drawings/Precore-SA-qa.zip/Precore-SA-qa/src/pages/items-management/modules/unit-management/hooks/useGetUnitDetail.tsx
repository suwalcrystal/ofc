import { useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { IUnitType } from "./useGetUnit";
import axiosInstance from "@/utils/axios-instance";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import Endpoint from "@/api/endpoints";

const useGetUnitDetail = (id: string | number) => {
  return useQuery<
    ApiResponseType<IUnitType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>
  >({
    queryKey: [KEYS.unit, id],
    queryFn: async () => {
      const response = await axiosInstance.get(`${Endpoint.unit}/${id}`);
      return response?.data;
    },
  });
};

export default useGetUnitDetail;
