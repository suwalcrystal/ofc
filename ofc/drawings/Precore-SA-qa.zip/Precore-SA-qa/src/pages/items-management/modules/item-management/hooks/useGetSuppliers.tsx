//this location needs to be changed
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useSearchParams } from "react-router-dom";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import axiosInstance from "@/utils/axios-instance";
import Endpoint from "@/api/endpoints";

export interface ISupplierType {
  id: string;
  name: string;
  description: string;
  link: string | null;
  createdAt: string;
  updatedAt: string;
  image: string | null;
  paymentDetailsId: string;
  paymentDetails: {
    id: string;
    createdAt: string;
    updatedAt: string;
    bankAccountNumber: string;
    bankName: string;
  };
}

const useGetSuppliers = () => {
  const [searchParams] = useSearchParams();
  const page = searchParams.get("page") ?? "1";
  const search = searchParams.get("search") ?? "";

  return useQuery<
    ApiResponseType<ISupplierType[]>,
    AxiosError<{ message: string; error: Record<string, unknown> }>
  >({
    queryKey: [KEYS.supplier, page, search],
    queryFn: async () => {
      const response = await axiosInstance.get(Endpoint.supplier, {
        params: {
          page: page,
          search: search,
        },
      });
      return response?.data;
    },
    placeholderData: keepPreviousData,
    staleTime: 5 * 60 * 1000,
  });
};

export default useGetSuppliers;
