import ExtendedButton from "@/components/ExtendedButton";
import { Button } from "@/components/ui/button";
import { FormikProvider } from "formik";
import useAddCategory from "../hooks/useAddCategory";
import { CategoryForm } from "./category-form";

interface CategoryProps {
  onClose: () => void;
}

export default function AddCategory({ onClose }: CategoryProps) {
  const { formik, isPending } = useAddCategory(onClose);

  return (
    <>
      <FormikProvider value={formik}>
        <form
          onSubmit={formik.handleSubmit}
          className="space-y-6 bg-background-200 rounded-[0.5rem] shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]"
        >
          <CategoryForm />
          <div className="flex gap-5  mt-10 w-full">
            <Button
              type="button"
              className=" p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium cursor-pointer w-[110px]"
              variant="outline"
              onClick={() => {
                onClose();
                formik.setErrors({});
              }}
            >
              Cancel
            </Button>
            <ExtendedButton
              type="submit"
              className="w-[110px] p-[1.25rem] border border-green-500  "
              text={"Add"}
              isLoading={isPending}
            />
          </div>
        </form>
      </FormikProvider>
    </>
  );
}
