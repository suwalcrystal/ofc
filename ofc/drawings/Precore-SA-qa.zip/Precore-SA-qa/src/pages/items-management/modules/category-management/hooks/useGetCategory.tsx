import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useSearchParams } from "react-router-dom";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import axiosInstance from "@/utils/axios-instance";
import Endpoint from "@/api/endpoints";

export interface ICategoryType {
  id: string;
  name: string;
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
}

const useGetCategory = () => {
  const [searchParams] = useSearchParams();
  const page = searchParams.get("page") ?? "1";

  return useQuery<
    ApiResponseType<ICategoryType[]>,
    AxiosError<{ message: string; error: Record<string, unknown> }>
  >({
    queryKey: [KEYS.category, page],
    queryFn: async () => {
      const response = await axiosInstance.get(Endpoint.category, {
        params: {
          page: page,
        },
      });
      return response?.data;
    },
    placeholderData: keepPreviousData,
    staleTime: 5 * 60 * 1000,
  });
};

export default useGetCategory;
