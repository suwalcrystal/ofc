import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";

import { useFormik } from "formik";
import { UnitFormSchema, UnitFormSchemaType } from "../schema";
import { KEYS } from "@/lib/keys";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import { ApiResponseType } from "@/lib/type";
import axiosInstance from "@/utils/axios-instance";
import Endpoint from "@/api/endpoints";
import handleErrors from "@/service/api.error";

interface IUnitType {
  id: string;
  name: string;
  symbol: string;
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
  message?: string;
}

const addUnit = async (data: UnitFormSchemaType) => {
  const payload = {
    ...data,
    status: data.status ? "active" : "inactive",
  };
  const response = await axiosInstance.post(Endpoint.unit, payload);
  return response.data;
};

const useAddUnit = (onClose: () => void) => {
  const queryClient = useQueryClient();

  const { mutate, isPending, error } = useMutation<
    ApiResponseType<IUnitType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    UnitFormSchemaType
  >({
    mutationFn: addUnit,
    onSuccess: (res) => {
      onClose();
      queryClient.invalidateQueries({
        queryKey: [KEYS.unit],
      });
      showSuccessMessage(res?.message || "Unit Created Successfully");
    },
    onError: (err) => {
      if (err?.response?.status === 422) {
        handleErrors(err, formik.setErrors);
      } else {
        showErrorMessage(err?.response?.data?.message || "An error occurred");
      }
    },
  });

  const formik = useFormik({
    initialValues: {
      name: "",
      symbol: "",
      status: false,
    },
    validationSchema: UnitFormSchema,
    onSubmit: (values) => {
      mutate(values);
    },
  });

  return {
    formik,
    error,
    isPending,
  };
};

export default useAddUnit;
