import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { ItemColumns } from "./partials/columns";
import { DataTable } from "@/components/DataTable";
import useGetItem from "./hooks/useGetItem";
import AddItem from "./partials/add-item";
import Search from "@/components/Search";
import FilterBox from "./components/filter-box";
import Pagination from "@/components/Pagination";
import { useItemStore } from "./store";
import FilterItem from "./components/filter-item";

const ItemManagement = () => {
  const { data: item, isLoading } = useGetItem();

  const { isFilterOpen } = useItemStore();
  const [open, setOpen] = useState(false);

  function handleAddItemModal() {
    setOpen((prev) => !prev);
  }

  return (
    <>
      <div className="border-b-2 border-white py-4 mb-6 flex items-center justify-between mb-6">
        <div className="flex items-center gap-[1.25rem]">
          <h3 className="text-text-500 typography-h3 font-semibold">
            Item Management
          </h3>

          <div className="w-[280px]">
            <Search />
          </div>
          <FilterItem />
        </div>

        <Button
          className="bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer"
          onClick={handleAddItemModal}
        >
          Add Item
        </Button>
      </div>

      {isFilterOpen && <FilterBox />}

      {/* Item Table */}
      <DataTable
        message="No Items Found"
        data={item?.data || []}
        isLoading={isLoading}
        columns={ItemColumns}
      />

      {item?.pagination?.totalRecords && item?.pagination?.totalRecords > 10 ? (
        <Pagination
          currentPage={item?.pagination?.currentPage}
          totalCount={item?.pagination?.totalRecords}
          totalPages={item?.pagination?.totalPages}
        />
      ) : (
        ""
      )}

      <Dialog open={open} onOpenChange={handleAddItemModal}>
        <DialogContent
          className={cn(
            "p-6 min-w-[630px]  max-h-[750px] cursor-pointer overflow-y-auto"
          )}
        >
          <DialogTitle>Add Item</DialogTitle>
          <DialogDescription>
            <AddItem onClose={handleAddItemModal} />
          </DialogDescription>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ItemManagement;
