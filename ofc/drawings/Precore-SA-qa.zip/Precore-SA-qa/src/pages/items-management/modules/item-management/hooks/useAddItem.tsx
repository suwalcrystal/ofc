import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";

import { useFormik } from "formik";
import { ItemFormSchema, ItemFormSchemaType } from "../schema";
import { KEYS } from "@/lib/keys";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import { ApiResponseType } from "@/lib/type";
import axiosInstance from "@/utils/axios-instance";
import Endpoint from "@/api/endpoints";
import handleErrors from "@/service/api.error";

interface IItemType {
  id: string;
  name: string;
  symbol: string;
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
  message?: string;
}

const addItem = async (data: ItemFormSchemaType) => {
  const formData = new FormData();
  if (data.image) {
    data.image
      .filter((file: unknown): file is File => file instanceof File)
      .forEach((file: File) => {
        formData.append("image", file);
      });
  }
  formData.append("status", data.status ? "active" : "inactive");
  formData.append("sku", data.sku);
  formData.append("name", data.name);
  formData.append("description", data.description || "");
  formData.append("pricePerUnit", data.pricePerUnit.toString());
  formData.append("currency", data.currency);
  formData.append("unitId", data.unitId || "");
  formData.append("itemCategoryId", data.itemCategoryId || "");
  formData.append("supplierId", data.supplierId || "");
  formData.append("itemTypeId", data.itemTypeId || "");
  formData.append("xeroChartOfAccounts", data.xeroChartOfAccounts || "");

  const response = await axiosInstance.post(Endpoint.item, formData);
  return response.data;
};

const useAddItem = (onClose: () => void) => {
  const queryClient = useQueryClient();

  const { mutate, isPending, error } = useMutation<
    ApiResponseType<IItemType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    ItemFormSchemaType
  >({
    mutationFn: addItem,
    onSuccess: (res) => {
      onClose();
      queryClient.invalidateQueries({
        queryKey: [KEYS.item],
      });
      showSuccessMessage(res?.message || "Item Created Successfully");
    },
    onError: (err) => {
      if (err?.response?.status === 422) {
        handleErrors(err, formik.setErrors);
      } else {
        showErrorMessage(err?.response?.data?.message || "Error occurred");
      }
    },
  });

  const formik = useFormik({
    initialValues: {
      status: "active",
      image: undefined,
      sku: "",
      name: "",
      description: "",
      pricePerUnit: 0,
      currency: "",
      unitId: "",
      itemCategoryId: "",
      supplierId: "",
      itemTypeId: "",
      xeroChartOfAccounts: "",
    },
    validationSchema: ItemFormSchema,
    onSubmit: (values: ItemFormSchemaType) => {
      mutate(values);
    },
  });

  return {
    formik,
    error,
    isPending,
  };
};

export default useAddItem;
