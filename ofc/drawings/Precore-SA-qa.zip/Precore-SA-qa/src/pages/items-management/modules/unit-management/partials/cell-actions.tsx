import { useState } from "react";
import Edit from "/src/assets/icons/edit.svg";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "../../../../../components/ui/dialog";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { cn } from "../../../../../lib/utils";
import { IUnitType } from "../hooks/useGetUnit";
import EditUnit from "./edit-unit";
import Delete from "/src/assets/icons/delete.svg";
import useDeleteUnits from "../hooks/useDeleteUnit";
import DeleteModal from "@/components/DeleteModal";

const UnitCellActions = ({ data }: { data: IUnitType }) => {
  const [open, setOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState<boolean>(false);
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();

  function handleEditUnitModal() {
    searchParams.set("id", data?.id);
    navigate(`${location.pathname}?${searchParams.toString()}`);
    setIsEditOpen((prev) => !prev);
  }

  const { deleteUnits, isPending } = useDeleteUnits({
    handleDeleteModalToggle,
  });
  function handleDeleteModalToggle() {
    setOpen((prev) => !prev);
  }

  function handleDeleteUnit() {
    deleteUnits({ id: data?.id });
  }

  return (
    <>
      <div className="flex items-end gap-4 ml-2">
        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <img
            onClick={handleEditUnitModal}
            src={Edit}
            alt="Edit"
            className="h-4"
          />
          <DialogContent className={cn("p-6  min-w-[630px]")}>
            <DialogTitle>Edit Unit</DialogTitle>
            <DialogDescription>
              <EditUnit onClose={handleEditUnitModal} />
            </DialogDescription>
          </DialogContent>
        </Dialog>

        <img
          className="h-4"
          src={Delete}
          alt="Delete"
          onClick={handleDeleteModalToggle}
        />
      </div>

      <DeleteModal
        text={``}
        title="unit"
        onClose={handleDeleteModalToggle}
        open={open}
        onDelete={handleDeleteUnit}
        loading={isPending}
      />
    </>
  );
};

export default UnitCellActions;
