import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { ICategoryType } from "./useGetCategory";
import { CategoryFormSchema, CategoryFormSchemaType } from "../schema";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import { useFormik } from "formik";
import axiosInstance from "@/utils/axios-instance";
import useGetCategoryDetail from "./useGetCategoryDetail";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import Endpoint from "@/api/endpoints";
import handleErrors from "@/service/api.error";

type CategoryEditType = CategoryFormSchemaType & {
  id: string | number;
};

const editCategory = async (data: CategoryEditType) => {
  const payload = {
    name: data.name,
    status: data.status ? "active" : "inactive",
  };
  const response = await axiosInstance.patch(
    `${Endpoint.category}/${data.id}`,
    payload
  );
  return response.data;
};

const useEditCategory = (onClose: () => void) => {
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const id = searchParams.get("id") ?? "";

  const { data, isLoading } = useGetCategoryDetail(id);

  const queryClient = useQueryClient();

  const { mutate, isPending, error } = useMutation<
    ApiResponseType<ICategoryType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    CategoryEditType
  >({
    mutationFn: editCategory,
    onSuccess: (res) => {
      onClose();
      queryClient.invalidateQueries({
        queryKey: [KEYS.category],
      });
      searchParams.delete("id");
      navigate(`${location.pathname}?${searchParams.toString()}`);
      showSuccessMessage(res?.message || "Category updated Successfully");
    },
    onError: (err) => {
      if (err?.response?.status === 422) {
        handleErrors(err, formik.setErrors);
      } else {
        showErrorMessage(
          err?.response?.data?.message || "Error updating category"
        );
      }
    },
  });

  const formik = useFormik({
    initialValues: {
      name: data?.data?.name ?? "",
      status: data?.data?.status === "active" ? true : false,
    },
    enableReinitialize: true,
    validationSchema: CategoryFormSchema,
    onSubmit: (values: CategoryFormSchemaType) => {
      mutate({ id, ...values });
    },
  });

  return {
    formik,
    error,
    isPending,
    isLoading,
  };
};

export default useEditCategory;
