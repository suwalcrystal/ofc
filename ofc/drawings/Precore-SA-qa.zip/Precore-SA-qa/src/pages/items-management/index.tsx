import { PATH } from "@/constants/paths";
import { ChevronRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const configRoutes = [
  { label: "Item Management", path: PATH.itemsManagement.items },
  {
    label: "Category Management",
    path: PATH.itemsManagement.category,
  },
  { label: "Unit Management", path: PATH.itemsManagement.unit },
];

const ItemsManagement = () => {
  const navigate = useNavigate();

  return (
    <div>
      <div className="border-b-2 border-white py-4 mb-6">
        <h3 className="text-text-500 typography-h3 font-semibold">
          Configuration Management
        </h3>
      </div>

      <div className="flex flex-col gap-y-2">
        {configRoutes.map((config) => (
          <ConfigCard
            key={config.path}
            label={config.label}
            path={config.path}
            onNavigate={navigate}
          />
        ))}
      </div>
    </div>
  );
};

export default ItemsManagement;

const ConfigCard = ({
  label,
  path,
  onNavigate,
}: {
  label: string;
  path: string;
  onNavigate: (path: string) => void;
}) => (
  <div
    onClick={() => onNavigate(path)}
    className="bg-white flex items-center justify-between w-[606px] py-5 px-6 rounded-xl cursor-pointer hover:bg-gray-50 transition"
  >
    <p className="text-base font-medium">{label}</p>
    <ChevronRight className="text-[#6E6E6E]" />
  </div>
);
