import HeaderProductDetail from "./partials/HeaderProductDetail";
import ProjectContent from "./partials/ProjectContent";

const ProductDetail = () => {
  return (
    <div>
      <HeaderProductDetail />
      <ProjectContent />
    </div>
  );
};

export default ProductDetail;
