import { TableCell } from "@/components/ui/table";
import BaseTable from "@/components/BaseTable";
import { IPurchaseOrder } from "../interface/procrument.interface";
import { IColumn } from "@/interface/baseTable.interface";

interface PurchaseOrdersTableProps {
  data: IPurchaseOrder[];
}

const columns: IColumn<IPurchaseOrder>[] = [
  { key: "id", label: "PO No.", sortable: true },
  { key: "status", label: "Status", sortable: true },
  { key: "type", label: "Type", sortable: true },
  { key: "linkedRFP", label: "Linked RFP", sortable: true },
  { key: "supplier", label: "Supplier", sortable: true },
  { key: "value", label: "PO Value", sortable: true },
  { key: "linkedInvoice", label: "Linked Invoice", sortable: true },
];

const renderedRow = (item: IPurchaseOrder): React.JSX.Element[] => [
  <TableCell key="id" className="font-medium text-text-500 text-center">
    {item.id}
  </TableCell>,

  <TableCell key="status" className="font-medium text-text-500 text-center">
    <span
      className={`rounded-full px-2 py-1 text-xs font-medium ${
        item.status === "Approved"
          ? "bg-green-50 text-green-500"
          : "bg-yellow-100 text-yellow-800"
      }`}
    >
      {item.status}
    </span>
  </TableCell>,

  <TableCell key="type" className="font-medium text-text-500 text-center">
    {item.type}
  </TableCell>,

  <TableCell key="linkedRFP" className="text-center">
    <a href="#" className="text-blue hover:underline font-medium">
      {item.linkedRFP}
    </a>
  </TableCell>,

  <TableCell key="supplier" className="font-medium text-text-500 text-center">
    {item.supplier}
  </TableCell>,

  <TableCell key="value" className="text-center">
    <div className="font-medium text-text-500">
      {item.value.toLocaleString()}
    </div>
    <div className="text-text-400 text-xs mt-[0.31rem]">{item.currency}</div>
  </TableCell>,

  <TableCell
    key="linkedInvoice"
    className="font-medium text-text-500 text-center"
  >
    {item.linkedInvoice}
  </TableCell>,
];

const PurchaseOrdersTable: React.FC<PurchaseOrdersTableProps> = ({ data }) => (
  <BaseTable<IPurchaseOrder>
    data={data}
    columns={columns}
    renderRow={renderedRow}
  />
);

export default PurchaseOrdersTable;
