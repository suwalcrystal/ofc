import phone from "@/assets/icons/call.svg";
import mail from "@/assets/icons/mail-16.svg";
import whatsapp from "@/assets/icons/whatsapp-icon.svg";
import BaseTable from "@/components/BaseTable";
import CustomPagination from "@/components/CustomPagination";
import AddButton from "@/components/headerBottom/AddButton";
import { Button } from "@/components/ui/button";
import { getStatusBadge } from "@/utils/getStatusBadge";
import { Trash2 } from "lucide-react";
import { FiEdit3 } from "react-icons/fi";
import { Link } from "react-router-dom";
import { initialData } from "../data";
import { useTeamTableLogic } from "../hook/teamTable.hook";
import { Employee } from "../interface/employee.interface";
import SearchBar from "./SearchBar";
import { TableCell } from "@/components/ui/table";
import { IColumn } from "@/interface/baseTable.interface";

const TeamTable: React.FC = () => {
  const {
    currentItems,
    filterValue,
    setFilterValue,
    currentPage,
    setCurrentPage,
    itemsPerPage,
    setItemsPerPage,
    totalItems,
    handleDelete,
  } = useTeamTableLogic(initialData);

  const columns: IColumn<Employee>[] = [
    { key: "name", label: "Employee", sortable: true },
    { key: "role", label: "Role", sortable: true },
    { key: "department", label: "Department", sortable: true },
    { key: "contact" as keyof Employee, label: "Contact", sortable: false },
    { key: "reportingTo", label: "Reporting To", sortable: true },
    { key: "startDate", label: "Start Date", sortable: true },
    { key: "status", label: "Status", sortable: true },
    { key: "action" as keyof Employee, label: "Actions", sortable: true },
  ];

  const renderRow = (employee: Employee): React.JSX.Element[] => [
    <TableCell key="avatar" className="text-left">
      <div className="flex items-center gap-3">
        <div className="h-12 w-12 overflow-hidden rounded-[0.5rem]">
          <img
            src={employee.avatar}
            alt={employee.name}
            width={48}
            height={48}
            className="h-full w-full object-cover"
          />
        </div>
        <div>
          <div className="font-semibold pb-[0.31rem]">{employee.name}</div>
          <div className="text-text-300 text-xs">{employee.position}</div>
        </div>
      </div>
    </TableCell>,

    <TableCell key="role" className="font-medium text-text-500">
      {employee.role}
    </TableCell>,

    <TableCell key="department" className="font-medium text-text-500">
      {employee.department}
    </TableCell>,

    <TableCell key="contact" className="text-center">
      <div className="flex space-x-2 justify-center">
        <button className="size-[1.5rem] p-[0.19rem] rounded-full bg-text-50 hover:bg-text-100">
          <img src={phone} alt="phone-icon" className="size-full" />
        </button>
        <button className="size-[1.5rem] p-[0.19rem] rounded-full bg-text-50 hover:bg-text-100">
          <img src={whatsapp} alt="whatsapp-icon" className="size-full" />
        </button>
        <button className="size-[1.5rem] p-[0.19rem] rounded-full bg-text-50 hover:bg-text-100">
          <img src={mail} alt="mail-icon" className="size-full" />
        </button>
      </div>
    </TableCell>,

    <TableCell key="reportingTo" className="text-blue hover:underline">
      <Link to="#">{employee.reportingTo}</Link>
    </TableCell>,

    <TableCell key="startDate" className="font-medium text-text-500">
      {employee.startDate}
    </TableCell>,

    <TableCell key="status">{getStatusBadge(employee.status)}</TableCell>,

    <TableCell key="actions">
      <div className="flex space-x-1 justify-center">
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <FiEdit3 className="h-4 w-4" />
          <span className="sr-only">Edit</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => handleDelete(employee.id)}
        >
          <Trash2 className="h-4 w-4" />
          <span className="sr-only">Delete</span>
        </Button>
      </div>
    </TableCell>,
  ];

  return (
    <div>
      <div className="flex items-center justify-between pb-[0.87rem]">
        <SearchBar filterValue={filterValue} setFilterValue={setFilterValue} />
        <AddButton title="Add Team Member" />
      </div>

      <BaseTable<Employee>
        columns={columns}
        data={currentItems}
        renderRow={renderRow}
      />
      <CustomPagination
        currentPage={currentPage}
        itemsPerPage={itemsPerPage}
        totalItems={totalItems}
        setCurrentPage={setCurrentPage}
        setItemsPerPage={setItemsPerPage}
      />
    </div>
  );
};

export default TeamTable;
