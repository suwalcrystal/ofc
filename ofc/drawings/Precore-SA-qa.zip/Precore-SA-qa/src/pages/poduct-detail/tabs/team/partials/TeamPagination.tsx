import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ChevronLeft, ChevronRight } from "lucide-react";

// Pagination Component
interface PaginationProps {
  currentPage: number;
  itemsPerPage: number;
  totalItems: number;
  setCurrentPage: (page: number) => void;
  setItemsPerPage: (items: number) => void;
}

const TeamPagination: React.FC<PaginationProps> = ({
  currentPage,
  itemsPerPage,
  totalItems,
  setCurrentPage,
  setItemsPerPage,
}) => {
  const getPageNumbers = () => {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    if (totalPages <= 7) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }

    const firstPage = 1;
    const lastPage = totalPages;
    let startPage = Math.max(2, currentPage - 1);
    let endPage = Math.min(lastPage - 1, currentPage + 1);

    if (currentPage <= 3) {
      startPage = 2;
      endPage = 5;
    }
    if (currentPage >= totalPages - 2) {
      startPage = totalPages - 4;
      endPage = totalPages - 1;
    }

    const pages = [firstPage];
    if (startPage > 2) pages.push(-1);
    for (let i = startPage; i <= endPage; i++) pages.push(i);
    if (endPage < lastPage - 1) pages.push(-2);
    if (lastPage !== firstPage) pages.push(lastPage);

    return pages;
  };

  return (
    <div className="flex items-center justify-between p-4">
      <div className="flex items-center space-x-2">
        <span>On Page</span>
        <Select
          value={itemsPerPage.toString()}
          onValueChange={(value) => setItemsPerPage(Number(value))}
        >
          <SelectTrigger className="w-[70px]">
            <SelectValue placeholder={itemsPerPage.toString()} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="5">5</SelectItem>
            <SelectItem value="10">10</SelectItem>
            <SelectItem value="20">20</SelectItem>
            <SelectItem value="50">50</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex items-center space-x-4">
        <div className="text-sm">
          Shown {currentPage * itemsPerPage - itemsPerPage + 1}-
          {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems}
        </div>
        <div className="flex items-center">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCurrentPage(Math.max(currentPage - 1, 1))}
            disabled={currentPage === 1}
            className="h-8 w-8"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center space-x-1 mx-1">
            {getPageNumbers().map((pageNum, i) =>
              pageNum < 0 ? (
                <span key={`ellipsis-${i}`} className="px-1">
                  ...
                </span>
              ) : (
                <Button
                  key={`page-${pageNum}`}
                  variant="ghost"
                  size="icon"
                  className={`rounded-full h-8 w-8 ${
                    currentPage === pageNum
                      ? "bg-gray-500 text-white hover:bg-gray-500 hover:text-white"
                      : "bg-white"
                  }`}
                  onClick={() => setCurrentPage(pageNum)}
                >
                  {pageNum}
                </Button>
              )
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() =>
              setCurrentPage(
                Math.min(currentPage + 1, Math.ceil(totalItems / itemsPerPage))
              )
            }
            disabled={currentPage >= Math.ceil(totalItems / itemsPerPage)}
            className="h-8 w-8"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};
export default TeamPagination;
