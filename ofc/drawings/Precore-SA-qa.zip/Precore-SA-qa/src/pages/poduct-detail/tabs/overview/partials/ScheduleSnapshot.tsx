import GhanttChart from "./GhanttChart";
import ProgressOverview from "./ProgressOverview";
import UpcomingMilestones from "./UpcomingMilestones";

const ScheduleSnapshot = () => {
  return (
    <div>
      <div className="rounded-[0.5rem] border border-boarder-300 bg-white shadow-card p-5 w-full lg:w-[53.875rem]">
        <h2 className="text-text-500 typography-paragraph-regular font-semibold pb-[0.87rem]">
          Schedule Snapshot
        </h2>

        <div className="flex gap-5">
          <ProgressOverview />
          <UpcomingMilestones />
        </div>
        <GhanttChart />
      </div>
    </div>
  );
};

export default ScheduleSnapshot;
