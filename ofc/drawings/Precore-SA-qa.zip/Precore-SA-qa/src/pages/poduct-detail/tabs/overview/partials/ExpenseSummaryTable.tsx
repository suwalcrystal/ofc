import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { IoMdArrowDropdown, IoMdArrowDropup } from "react-icons/io";
import { ExpenseSummaryCategory } from "../interface/expenseAccordiion";

const ExpenseSummaryTable = ({
  category,
  isOpen,
  onToggle,
}: {
  category: ExpenseSummaryCategory;
  isOpen: boolean;
  onToggle: () => void;
}) => {
  return (
    <div className="border rounded-md overflow-hidden">
      {/* Header Toggle */}
      <div className="flex items-center p-4 cursor-pointer" onClick={onToggle}>
        <div className="mr-2">
          {isOpen ? (
            <IoMdArrowDropup className="h-5 w-5 text-gray-500" />
          ) : (
            <IoMdArrowDropdown className="h-5 w-5 text-gray-500" />
          )}
        </div>
        <div className="font-semibold text-text-500">{category.name}</div>
        <div className="ml-auto text-text-400 font-medium typography-paragraph-caption">
          <span>Amount Spent: </span>
          {category.amountSpent.toLocaleString()} AED
        </div>
      </div>

      {/* Sub-packages Table */}
      {isOpen && category.subPackages.length > 0 && (
        <div className="px-4 pb-4">
          <div className="bg-[#F3F3F3] rounded-sm overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="typography-paragraph-small text-text-500 font-medium">
                    Category
                  </TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-medium">
                    Amount Spent (AED)
                  </TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-medium">
                    % of Package Budget
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {category.subPackages.map((subPackage, index) => {
                  return (
                    <TableRow
                      key={index}
                      className="bg-white hover:bg-white  border-b"
                    >
                      <TableCell className="typography-paragraph-small font-semibold text-text-500 py-4">
                        {subPackage.name}
                      </TableCell>
                      <TableCell className=" typography-paragraph-small font-semibold text-text-500 py-4">
                        {subPackage.amountSpent.toLocaleString()}
                        <span className="text-text-300 typography-paragraph-caption font-medium px-1">
                          AED
                        </span>
                      </TableCell>
                      <TableCell className=" typography-paragraph-small font-semibold text-text-500 py-4">
                        {subPackage.packageBudget}
                        <span className="text-text-300 typography-paragraph-caption font-medium px-1">
                          %
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpenseSummaryTable;
