import folderImage from "@/assets/icons/floderImage.svg";
import FolderCard from "./partials/FolderCard";

const folderData = [
  { title: "Drawings", size: "10 GB", date: "28.04.2025", image: folderImage },
  {
    title: "Permits & Approvals",
    size: "5 GB",
    date: "10.03.2025",
    image: folderImage,
  },
  { title: "Submitals", size: "20 GB", date: "15.05.2025", image: folderImage },
  { title: "Reports", size: "20 GB", date: "15.05.2025", image: folderImage },
  {
    title: "Transmittals",
    size: "20 GB",
    date: "15.05.2025",
    image: folderImage,
  },
  {
    title: "General",
    size: "20 GB",
    date: "15.05.2025",
    image: folderImage,
  },
];

const DocumentsContent = () => {
  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
        {folderData.map((folder, index) => (
          <FolderCard
            key={index}
            title={folder.title}
            size={folder.size}
            date={folder.date}
            image={folder.image}
          />
        ))}
      </div>
    </div>
  );
};

export default DocumentsContent;
