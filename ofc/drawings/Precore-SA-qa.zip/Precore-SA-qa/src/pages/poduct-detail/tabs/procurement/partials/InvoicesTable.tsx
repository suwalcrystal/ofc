import BaseTable from "@/components/BaseTable";
import { IInvoice } from "../interface/procrument.interface";
import { TableCell } from "@/components/ui/table";
import { IColumn } from "@/interface/baseTable.interface";

interface InvoicesTableProps {
  data: IInvoice[];
}

const columns: IColumn<IInvoice>[] = [
  { key: "id", label: "Invoice No.", sortable: true },
  { key: "status", label: "Status", sortable: true },
  { key: "type", label: "Type", sortable: true },
  { key: "linkedPO", label: "PO Reference", sortable: true },
  { key: "supplier", label: "Supplier", sortable: true },
  { key: "amount", label: "Amount", sortable: true },
  { key: "dueDate", label: "Due Date", sortable: true },
  { key: "attachment", label: "Attachment", sortable: false },
];

const renderedRow = (item: IInvoice): React.JSX.Element[] => [
  <TableCell key="id" className="font-medium text-text-500 text-center">
    {item.id}
  </TableCell>,

  <TableCell key="status" className="text-center">
    <span
      className={`rounded-full px-3 py-1 text-xs font-medium ${
        item.status === "Paid"
          ? "bg-blue-bg text-blue"
          : item.status === "Pending"
            ? "bg-yellow-50 text-yellow-700"
            : "bg-gray-50 text-gray-500"
      }`}
    >
      {item.status}
    </span>
  </TableCell>,

  <TableCell key="type" className="font-medium text-text-500 text-center">
    {item.type}
  </TableCell>,

  <TableCell key="linkedPO" className="text-center">
    <a
      href={`/po/${item.linkedPO}`}
      className="text-blue font-medium hover:underline"
    >
      {item.linkedPO}
    </a>
  </TableCell>,

  <TableCell key="supplier" className="font-medium text-text-500 text-center">
    {item.supplier}
  </TableCell>,

  <TableCell key="amount" className="text-center">
    <div className="font-medium text-text-500">
      {item.amount.toLocaleString()}
    </div>
    <div className="text-text-300 text-xs mt-1">{item.currency}</div>
  </TableCell>,

  <TableCell key="dueDate" className="font-medium text-text-500 text-center">
    {item.dueDate}
  </TableCell>,

  <TableCell key="attachment" className="text-center">
    <button
      className="text-text-300 hover:text-text-700"
      aria-label="View attachment"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="lucide lucide-paperclip"
      >
        <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
      </svg>
    </button>
  </TableCell>,
];

const InvoicesTable: React.FC<InvoicesTableProps> = ({ data }) => (
  <BaseTable<IInvoice> data={data} columns={columns} renderRow={renderedRow} />
);

export default InvoicesTable;
