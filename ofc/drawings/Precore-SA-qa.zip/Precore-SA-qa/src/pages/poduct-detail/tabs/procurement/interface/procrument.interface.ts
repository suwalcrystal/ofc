export interface IPurchaseRequest {
  id: string;
  status: string;
  type?: string;
  requestedBy: string;
  category?: string;
  area?: string;
  description?: string;
  linkedPO?: string;
}

export interface IRequestForQuote {
  id: string;
  status: string;
  type: string;
  linkedPR: string;
  vendors: string;
  quotesReceived: string;
  awardedVendor: string;
}

export interface IPurchaseOrder {
  id: string;
  status: string;
  type: string;
  linkedRFP: string;
  supplier: string;
  value: number;
  currency: string;
  linkedInvoice: string;
}

export interface IInvoice {
  id: string;
  status: string;
  type: string;
  linkedPO: string;
  supplier: string;
  amount: number;
  currency: string;
  dueDate: string;
  attachment?: string;
}

export interface IDelivery {
  id: string;
  status: string;
  type: string;
  linkedPO: string;
  deliveredBy: string;
  receivedBy: string;
  remarks: string;
}
