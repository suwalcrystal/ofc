import TeamTable from "./partials/TeamTable";

const TeamContent = () => {
  return (
    <div>
      <TeamTable />
    </div>
  );
};

export default TeamContent;
