import { useState } from "react";
import { format, parseISO } from "date-fns";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ghanttData } from "../data";

type Task = {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
};

type Month = {
  name: string;
  days: number;
  startDay: number;
};

export default function GhanttChart() {
  const [tasks] = useState<Task[]>(ghanttData);

  const months: Month[] = [
    { name: "Jan", days: 31, startDay: 0 },
    { name: "Feb", days: 28, startDay: 31 },
    { name: "Mar", days: 31, startDay: 59 },
    { name: "Apr", days: 30, startDay: 90 },
    { name: "May", days: 31, startDay: 120 },
    { name: "Jun", days: 30, startDay: 151 },
  ];

  const totalDays = months.reduce((acc, month) => acc + month.days, 0);

  const formatDateRange = (startDate: string, endDate: string) => {
    const start = parseISO(startDate);
    const end = parseISO(endDate);

    return `${format(start, "MMM d")} - ${format(end, "MMM d")}`;
  };

  const calculateTaskPosition = (task: Task) => {
    const startDate = parseISO(task.startDate);
    const endDate = parseISO(task.endDate);

    const startDay = new Date(2025, 0, 1);
    const dayOfYear = (date: Date) => {
      const start = new Date(date.getFullYear(), 0, 0);
      const diff = date.getTime() - start.getTime();
      return Math.floor(diff / (1000 * 60 * 60 * 24));
    };

    const taskStartDay = dayOfYear(startDate) - dayOfYear(startDay);
    const taskEndDay = dayOfYear(endDate) - dayOfYear(startDay);

    const startPercentage = (taskStartDay / totalDays) * 100;
    const width = ((taskEndDay - taskStartDay + 1) / totalDays) * 100;

    return {
      left: `${startPercentage}%`,
      width: `${width}%`,
    };
  };

  return (
    <Card className="w-full shadow-card border-[0.2px] border-boarder-300 rounded-[0.5rem] bg-section-bg-200 gap-2 py-5 mt-4">
      <CardHeader className="px-5">
        <h2 className="typography-paragraph-small text-text-500 font-semibold">
          Gantt Chart
        </h2>
      </CardHeader>

      <CardContent className="px-5 max-w-full">
        {/* Header with months */}
        <div className="flex pb-3">
          <div className="w-1/4 font-medium text-gray-700"></div>
          <div className="w-3/4 flex">
            {months.map((month) => (
              <div
                key={month.name}
                className="flex-1 text-center typography-paragraph-small text-text-200 font-medium"
              >
                {month.name}
              </div>
            ))}
          </div>
        </div>

        {/* Tasks and timeline */}
        <div className="relative">
          {/* Month dividers */}
          <div className="absolute inset-0 w-3/4 right-0 flex pointer-events-none">
            {months.map((month) => (
              <div
                key={month.name}
                className="flex-1 border-l border-dashed border-gray-300 h-full"
              />
            ))}
          </div>

          {/* Tasks */}
          {tasks.map((task) => (
            <div key={task.id} className="flex items-center relative mb-3">
              <div className="w-1/4 pr-4 typography-paragraph-small text-text-400 font-medium">
                {task.name}
              </div>
              <div className="w-3/4 relative">
                <div
                  className="absolute flex items-center justify-center px-14 h-6 bg-green-400 rounded-full text-white font-medium typography-paragraph-caption whitespace-nowrap"
                  style={calculateTaskPosition(task)}
                >
                  {formatDateRange(task.startDate, task.endDate)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
