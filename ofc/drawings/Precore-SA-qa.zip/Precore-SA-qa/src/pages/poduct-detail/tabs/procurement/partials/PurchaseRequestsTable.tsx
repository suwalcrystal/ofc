import { useState } from "react";
import { Eye, Check, X, ChevronDown } from "lucide-react";
import { IPurchaseRequest } from "../interface/procrument.interface";

interface PurchaseRequestsTableProps {
  data: IPurchaseRequest[];
  filterType: string;
}

const PurchaseRequestsTable: React.FC<PurchaseRequestsTableProps> = ({
  data,
  filterType,
}) => {
  const [selectedItems, setSelectedItems] = useState<string[]>([]);

  // Use filterType from props instead of local state
  const filteredData =
    filterType === "pending"
      ? data.filter((item) => item.status === "Pending")
      : data;

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedItems(filteredData.map((item) => item.id));
    } else {
      setSelectedItems([]);
    }
  };

  const handleSelectItem = (id: string) => {
    setSelectedItems((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleApprove = () => {
    console.warn("Approving items:", selectedItems);
    // Implement approval logic here
  };

  const handleReject = () => {
    console.warn("Rejecting items:", selectedItems);
    // Implement rejection logic here
  };

  const columns =
    filterType === "pending"
      ? [
          "",
          "PR No.",
          "Status",
          "Type",
          "Requested By",
          "Category",
          "Area",
          "Description",
          "Linked PO",
          "Action",
        ]
      : [
          "PR No.",
          "Status",
          "Type",
          "Requested By",
          "Category",
          "Area",
          "Description",
          "Linked PO",
          "Action",
        ];

  const renderHeader = () => (
    <div
      className={`grid ${
        filterType === "pending" ? "grid-cols-10" : "grid-cols-9"
      }  bg-[#E1E3E4] p-4 text-sm font-medium text-text-500 typography-paragraph-small rounded-t-[1rem] `}
    >
      {columns.map((column, index) => (
        <div key={index} className="flex items-center truncate">
          {column === "" ? (
            <input
              type="checkbox"
              className="h-4 w-4 rounded border-gray-300"
              onChange={handleSelectAll}
              checked={
                selectedItems.length === filteredData.length &&
                filteredData.length > 0
              }
              aria-label="Select all purchase requests"
            />
          ) : (
            <>
              {column}
              {(column === "Requested By" ||
                column === "Category" ||
                column === "Area") && <ChevronDown className="ml-1 h-4 w-4" />}
            </>
          )}
        </div>
      ))}
    </div>
  );

  const renderRow = (item: IPurchaseRequest) => (
    <div
      key={item.id}
      className={`grid ${
        filterType === "pending" ? "grid-cols-10" : "grid-cols-9"
      }  p-4 text-sm items-center`}
    >
      {filterType === "pending" && (
        <div>
          <input
            type="checkbox"
            className="h-4 w-4 rounded border-gray-300"
            checked={selectedItems.includes(item.id)}
            onChange={() => handleSelectItem(item.id)}
            aria-label={`Select purchase request ${item.id}`}
          />
        </div>
      )}
      <div className="text-text-500 typography-paragraph-small font-medium  truncate">
        {item.id}
      </div>
      <div>
        <span
          className={`rounded-full px-3 py-1 text-xs font-medium ${
            item.status === "Approved"
              ? "bg-green-50 text-green-500"
              : item.status === "Pending"
                ? "bg-yellow-50 text-yellow-700"
                : "bg-gray-50 text-gray-500"
          }`}
        >
          {item.status}
        </span>
      </div>
      <div className="text-text-500 typography-paragraph-small font-medium truncate">
        {item.type || "Equipment"}
      </div>
      <div className="text-blue typography-paragraph-small font-medium  truncate">
        {item.requestedBy}
      </div>
      <div className="text-text-500 typography-paragraph-small font-medium truncate">
        {item.category || "Electrical"}
      </div>
      <div className="text-text-500 typography-paragraph-small font-medium truncate">
        {item.area || "Zone A"}
      </div>
      <div className="text-text-500 typography-paragraph-small font-medium truncate">
        {item.description || "Panel Boards"}
      </div>
      <div className="text-blue typography-paragraph-small font-medium  truncate">
        {item.linkedPO || "PO-008"}
      </div>
      <div className="flex space-x-2">
        <button
          className="text-gray-500 hover:text-gray-700"
          aria-label="View purchase request"
        >
          <Eye className="h-4.5 w-4.5" />
        </button>
        <button
          className="text-text-300 hover:text-text-700"
          aria-label="Approve purchase request"
        >
          <Check className="h-4.5 w-4.5" />
        </button>
        <button
          className="text-text-300 hover:text-text-700"
          aria-label="Reject purchase request"
        >
          <X className="h-4.5 w-4.5" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="overflow-x-auto">
      {filterType === "pending" && filteredData.length > 0 && (
        <div className="flex space-x-4 mb-4">
          <button
            onClick={handleApprove}
            className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-6 rounded-full"
            disabled={selectedItems.length === 0}
            aria-label="Approve selected purchase requests"
          >
            Approve
          </button>
          <button
            onClick={handleReject}
            className="bg-red-500 hover:bg-red-600 text-white font-medium py-2 px-6 rounded-full"
            disabled={selectedItems.length === 0}
            aria-label="Reject selected purchase requests"
          >
            Reject
          </button>
        </div>
      )}
      <div className="min-w-full  rounded-t-[1rem] overflow-hidden">
        {renderHeader()}
        {filteredData.length > 0 ? (
          filteredData.map((item) => renderRow(item))
        ) : (
          <div className="p-4 text-center text-gray-500">
            No purchase requests found
          </div>
        )}
      </div>
    </div>
  );
};

export default PurchaseRequestsTable;
