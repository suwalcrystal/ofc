import mail from "@/assets/icons/mail-16.svg";
import phone from "@/assets/icons/call.svg";
import whatsapp from "@/assets/icons/whatsapp-icon.svg";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TableBody, TableCell, TableRow } from "@/components/ui/table";
import { Trash2 } from "lucide-react";
import { FiEdit3 } from "react-icons/fi";
import { Link } from "react-router-dom";
import { Employee } from "../interface/employee.interface";

// Table Body Component
interface TableBodyProps {
  currentItems: Employee[];
  handleDelete: (id: string) => void;
}

const TeamTableBody: React.FC<TableBodyProps> = ({
  currentItems,
  handleDelete,
}) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Active":
        return (
          <Badge className="bg-green-50 text-green-500 hover:bg-green-100 px-3 py-1 font-medium rounded-full">
            {status}
          </Badge>
        );
      case "Inactive":
        return (
          <Badge className="bg-[#FFF8EB] text-warning hover:bg-warning/40 px-3 py-1 font-medium rounded-full">
            {status}
          </Badge>
        );
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <TableBody>
      {currentItems.map((employee) => (
        <TableRow key={employee.id} className="border-b">
          <TableCell className="typography-paragraph-small font-medium text-text-500 bg-white p-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 overflow-hidden rounded-[0.5rem]">
                <img
                  src={employee.avatar}
                  alt={employee.name}
                  width={48}
                  height={48}
                  className="h-full w-full object-cover"
                />
              </div>
              <div>
                <div className="font-semibold pb-[0.31rem]">
                  {employee.name}
                </div>
                <div className="typography-paragraph-caption text-text-300">
                  {employee.position}
                </div>
              </div>
            </div>
          </TableCell>
          <TableCell className="typography-paragraph-small font-medium text-text-500 bg-white p-4">
            {employee.role}
          </TableCell>
          <TableCell className="typography-paragraph-small font-medium text-text-500 bg-white p-4">
            {employee.department}
          </TableCell>
          <TableCell className="typography-paragraph-small font-medium text-text-500 bg-white p-4">
            <div className="flex space-x-2">
              <button className="size-[1.5rem] p-[0.19rem] rounded-full bg-text-50 hover:bg-text-100">
                <img src={phone} alt="phone-icon" className="size-full" />
              </button>
              <button className="size-[1.5rem] p-[0.19rem] rounded-full bg-text-50 hover:bg-text-100">
                <img src={whatsapp} alt="whatsapp-icon" className="size-full" />
              </button>
              <button className="size-[1.5rem] p-[0.19rem] rounded-full bg-text-50 hover:bg-text-100">
                <img src={mail} alt="mail-icon" className="size-full" />
              </button>
            </div>
          </TableCell>
          <TableCell className="typography-paragraph-small font-medium text-text-500 bg-white p-4">
            <Link to="#" className="text-blue hover:underline">
              {employee.reportingTo}
            </Link>
          </TableCell>
          <TableCell className="typography-paragraph-small font-medium text-text-500 bg-white p-4">
            {employee.startDate}
          </TableCell>
          <TableCell className="typography-paragraph-small font-medium text-text-500 bg-white p-4">
            {getStatusBadge(employee.status)}
          </TableCell>
          <TableCell className="typography-paragraph-small font-medium text-text-500 bg-white p-4">
            <div className="flex space-x-1">
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <FiEdit3 className="h-4 w-4" />
                <span className="sr-only">Edit</span>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => handleDelete(employee.id)}
              >
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Delete</span>
              </Button>
            </div>
          </TableCell>
        </TableRow>
      ))}
    </TableBody>
  );
};

export default TeamTableBody;
