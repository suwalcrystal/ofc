import { Bar, BarChart, CartesianGrid, Cell, XAxis, YAxis } from "recharts";

import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

type DataItem = {
  category: keyof typeof chartConfig;
  amount: number;
};

const data: DataItem[] = [
  {
    category: "Contract Value",
    amount: 12902788,
  },
  {
    category: "Total Budget Spent",
    amount: 30123788,
  },
  {
    category: "Payment Received",
    amount: 63732788,
  },
];

const chartConfig = {
  "Contract Value": {
    label: "Contract Value",
    color: "hsl(45, 80%, 75%)",
    valueFormatter: (value: number) => `AED ${value.toLocaleString()}`,
  },
  "Total Budget Spent": {
    label: "Total Budget Spent",
    color: "hsl(170, 40%, 60%)",
    valueFormatter: (value: number) => `AED ${value.toLocaleString()}`,
  },
  "Payment Received": {
    label: "Payment Received",
    color: "hsl(210, 70%, 70%)",
    valueFormatter: (value: number) => `AED ${value.toLocaleString()}`,
  },
};

const ChartFinancialHealth = () => {
  return (
    <div className="w-full lg:w-[400px] shadow-card border-[0.2px] border-boarder-300 rounded-[0.5rem] bg-section-bg-200 flex gap-2 p-5 ">
      <ChartContainer config={chartConfig} className="w-[60%]  ">
        <BarChart
          data={data}
          margin={{ top: 0, right: 0, left: 0, bottom: 0 }}
          barGap={20}
          className="h-full"
        >
          <CartesianGrid
            strokeDasharray="4 4"
            horizontal={true}
            vertical={true}
          />
          <XAxis
            dataKey="category"
            axisLine={false}
            tickLine={false}
            tick={true}
            height={0}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            tickFormatter={(value) => `${value / 1000000} M`}
            domain={[0, "auto"]}
            width={40}
            height={100}
            startOffset={-10}
            includeHidden
            interval={"preserveStartEnd"}
          />

          <ChartTooltip
            content={
              <ChartTooltipContent
                formatter={(value, name) => (
                  <div className="flex items-center justify-between gap-2">
                    <span>{name}</span>
                    <span className="font-medium">
                      AED {Number(value).toLocaleString()}
                    </span>
                  </div>
                )}
              />
            }
          />

          <Bar
            dataKey="amount"
            radius={[4, 4, 0, 0]}
            maxBarSize={40}
            isAnimationActive={false}
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={chartConfig[entry.category].color}
              />
            ))}
          </Bar>
        </BarChart>
      </ChartContainer>

      <div className="flex flex-col gap-3 w-full justify-center">
        {data.map((item) => (
          <div key={item.category} className="flex gap-2.5 ">
            <div
              className="w-4 h-4 rounded "
              style={{ backgroundColor: chartConfig[item.category].color }}
            />
            <div className="flex flex-col gap-1">
              <span className="text-text-400 typography-paragraph-small font-medium w-max pb-[0.2rem] ">
                {chartConfig[item.category].label}
              </span>

              <span className="text-text-500 typography-paragraph-small font-semibold">
                AED {item.amount.toLocaleString()}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ChartFinancialHealth;
