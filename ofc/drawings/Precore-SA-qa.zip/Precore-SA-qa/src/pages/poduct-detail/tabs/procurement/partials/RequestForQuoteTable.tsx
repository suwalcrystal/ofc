import BaseTable from "@/components/BaseTable";
import { IRequestForQuote } from "../interface/procrument.interface";
import { TableCell } from "@/components/ui/table";
import { IColumn } from "@/interface/baseTable.interface";

interface RequestForQuoteTableProps {
  data: IRequestForQuote[];
}

const columns: IColumn<IRequestForQuote>[] = [
  { key: "id", label: "RFQ No.", sortable: true },
  { key: "status", label: "Status", sortable: true },
  { key: "type", label: "Type", sortable: true },
  { key: "linkedPR", label: "Linked PR", sortable: true },
  { key: "vendors", label: "Sent To", sortable: true },
  { key: "quotesReceived", label: "Quotes Received", sortable: true },
  { key: "awardedVendor", label: "Awarded Vendor", sortable: true },
];

const renderedRow = (item: IRequestForQuote): React.JSX.Element[] => [
  <TableCell key="id" className="font-medium text-text-500 text-center">
    {item.id}
  </TableCell>,

  <TableCell key="status" className="text-center">
    <span
      className={`rounded-full px-2.5 py-1 text-xs font-medium ${
        item.status === "Completed"
          ? "bg-green-50 text-green-500"
          : item.status === "In Progress"
            ? "bg-blue-bg text-blue"
            : "bg-brown-bg text-brown"
      }`}
    >
      {item.status === "In Progress" ? "Quoted" : item.status}
    </span>
  </TableCell>,

  <TableCell key="type" className="font-medium text-text-500 text-center">
    {item.type}
  </TableCell>,

  <TableCell key="linkedPR" className="text-center">
    <a href="#" className="text-blue hover:underline font-medium">
      {item.linkedPR}
    </a>
  </TableCell>,

  <TableCell key="vendors" className="font-medium text-text-500 text-center">
    {item.vendors}
  </TableCell>,

  <TableCell
    key="quotesReceived"
    className="font-medium text-text-500 text-center"
  >
    {item.quotesReceived}
  </TableCell>,

  <TableCell
    key="awardedVendor"
    className="font-medium text-text-500 text-center"
  >
    {item.awardedVendor}
  </TableCell>,
];

const RequestForQuoteTable: React.FC<RequestForQuoteTableProps> = ({
  data,
}) => (
  <BaseTable<IRequestForQuote>
    data={data}
    columns={columns}
    renderRow={renderedRow}
  />
);

export default RequestForQuoteTable;
