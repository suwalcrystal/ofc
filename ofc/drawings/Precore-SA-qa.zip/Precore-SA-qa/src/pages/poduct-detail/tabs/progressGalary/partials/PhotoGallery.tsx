import { useState } from "react";
import { progressGalleryData } from "@/data/progressGalleryData";
import { formatDate } from "@/utils/formatDate";
import ImageModal from "./ImageModal";

type Gallery = {
  id: number;
  image: string;
  label: string;
  user: string;
  timestamp: Date;
  desc: string;
};

const PhotoGallery = () => {
  const currentDate = new Date("2025-04-24");

  const [selectedGallery, setSelectedGallery] = useState<Gallery | null>(null);

  return (
    <div>
      <h1 className="typography-paragraph-small font-semibold text-text-400 mb-3">
        {formatDate(currentDate, "d MMM, yyyy")}
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-9 gap-1">
        {progressGalleryData.map((gallery) => (
          <div key={gallery.id} className="bg-white">
            <div className="h-[8.25rem]">
              <img
                src={gallery.image}
                alt={`gallery ${gallery.id}`}
                className="w-full h-full object-cover cursor-pointer"
                onClick={() => setSelectedGallery(gallery)}
              />
            </div>
            <div className="p-0.5">
              <h2 className="typography-paragraph-caption font-semibold text-text-400">
                {gallery.label}
              </h2>
              <p className="text-text-300 typography-paragraph-caption py-[0.12rem]">
                {gallery.user}
              </p>
              <p className="text-text-300 typography-paragraph-caption">
                {formatDate(gallery.timestamp, "d.M.yyyy HH:mm")}
              </p>
            </div>
          </div>
        ))}
      </div>

      <ImageModal
        gallery={selectedGallery}
        onClose={() => setSelectedGallery(null)}
      />
    </div>
  );
};

export default PhotoGallery;
