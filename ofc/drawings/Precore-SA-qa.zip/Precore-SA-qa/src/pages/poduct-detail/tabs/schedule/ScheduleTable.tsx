import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import React, { useState } from "react";
import { IoMdArrowDropright, IoMdArrowDropup } from "react-icons/io";

const columns = [
  { label: "ID" },
  { label: "Activity Name" },
  { label: "Planned Start" },
  { label: "Planned End" },
  { label: "Actual Start" },
  { label: "Actual End" },
  { label: "Progress %" },
  { label: "Status" },
  { label: "Delay" },
  { label: "Assigned To" },
  { label: "Comments" },
];

const projectData = [
  {
    section: "Structure",
    tasks: [
      {
        id: "A101",
        name: "Site Preparation",
        plannedStart: "24.04.2025",
        plannedEnd: "24.06.2025",
        actualStart: "26.04.2025",
        actualEnd: "30.06.2025",
        progress: 100,
        status: "Completed",
        delay: "6 Days",
        assignedTo: "Emma Wilsan",
        comments: "4 comments",
      },
      {
        id: "A102",
        name: "Foundation",
        plannedStart: "24.04.2025",
        plannedEnd: "24.06.2025",
        actualStart: "26.04.2025",
        actualEnd: "30.06.2025",
        progress: 90,
        status: "In Progress",
        delay: "-",
        assignedTo: "Alice Brown",
        comments: "-",
      },
      {
        id: "A103",
        name: "Steel Framing",
        plannedStart: "24.04.2025",
        plannedEnd: "24.06.2025",
        actualStart: "26.04.2025",
        actualEnd: "30.06.2025",
        progress: 90,
        status: "In Progress",
        delay: "-",
        assignedTo: "John Doe",
        comments: "-",
      },
    ],
  },
  {
    section: "MEP",
    tasks: [
      {
        id: "A104",
        name: "Delectrical",
        plannedStart: "24.04.2025",
        plannedEnd: "24.06.2025",
        actualStart: "26.04.2025",
        actualEnd: "30.06.2025",
        progress: 100,
        status: "Completed",
        delay: "6 Days",
        assignedTo: "Emma Wilsan",
        comments: "4 comments",
      },
      {
        id: "A105",
        name: "Plumbing",
        plannedStart: "24.04.2025",
        plannedEnd: "24.06.2025",
        actualStart: "26.04.2025",
        actualEnd: "30.06.2025",
        progress: 100,
        status: "Completed",
        delay: "6 Days",
        assignedTo: "Emma Wilsan",
        comments: "4 comments",
      },
    ],
  },
  {
    section: "Finishing",
    tasks: [
      {
        id: "A106",
        name: "Site Preparation",
        plannedStart: "24.04.2025",
        plannedEnd: "24.06.2025",
        actualStart: "26.04.2025",
        actualEnd: "30.06.2025",
        progress: 100,
        status: "Completed",
        delay: "6 Days",
        assignedTo: "Emma Wilsan",
        comments: "4 comments",
      },
      {
        id: "A107",
        name: "Foundation",
        plannedStart: "24.04.2025",
        plannedEnd: "24.06.2025",
        actualStart: "26.04.2025",
        actualEnd: "30.06.2025",
        progress: 90,
        status: "In Progress",
        delay: "-",
        assignedTo: "Alice Brown",
        comments: "-",
      },
    ],
  },
];

export default function ScheduleTable() {
  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const initialExpandedState = projectData.reduce(
    (acc, section) => {
      acc[section.section] = true;
      return acc;
    },
    {} as Record<string, boolean>
  );

  const [expandedSections, setExpandedSections] =
    useState(initialExpandedState);

  return (
    <div>
      <Table className="border-collapse rounded-[1rem] overflow-hidden">
        <TableHeader className="bg-background-600">
          <TableRow>
            {columns.map((col, index) => (
              <TableHead
                key={index}
                className="typography-paragraph-body-sm p-4"
              >
                {col.label}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {projectData.map((section) => (
            <React.Fragment key={section.section}>
              <TableRow
                key={section.section}
                className="hover:bg-gray-100 cursor-pointer border-0"
                onClick={() => toggleSection(section.section)}
              >
                <TableCell
                  colSpan={11}
                  className="typography-paragraph-small font-semibold text-text-500 table-body p-4 "
                >
                  <div className="flex items-center">
                    {expandedSections[section.section] ? (
                      <IoMdArrowDropup className="h-4 w-4 mr-1" />
                    ) : (
                      <IoMdArrowDropright className="h-4 w-4 mr-1" />
                    )}
                    {section.section}
                  </div>
                </TableCell>
              </TableRow>
              {expandedSections[section.section] &&
                section.tasks.map((task) => (
                  <TableRow key={task.id} className="hover:bg-gray-50">
                    <TableCell className="typography-paragraph-small font-medium text-text-500 table-body p-4">
                      {task.id}
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-semibold text-text-500 table-body p-4">
                      {task.name}
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-medium text-text-500 table-body p-4">
                      {task.plannedStart}
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-medium text-text-500 table-body p-4">
                      {task.plannedEnd}
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-medium text-text-500 table-body p-4">
                      {task.actualStart}
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-medium text-text-500 table-body p-4">
                      {task.actualEnd}
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-medium text-text-500 table-body p-4">
                      {task.progress}%
                    </TableCell>
                    <TableCell className="table-body p-4">
                      <Badge
                        variant="outline"
                        className={`typography-paragraph-caption font-medium px-2.5 py-1.5  border-0 rounded-full ${
                          task.status === "Completed"
                            ? "bg-[#E1ECFF] text-blue hover:bg-blue/30"
                            : "bg-green-50 text-green-500 hover:bg-green-100"
                        }`}
                      >
                        {task.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-medium text-text-500 table-body p-4">
                      {task.delay}
                    </TableCell>
                    <TableCell className="text-blue typography-paragraph-small font-medium table-body p-4">
                      <a href="#"> {task.assignedTo}</a>
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-medium text-text-500 table-body p-4">
                      {task.comments}
                    </TableCell>
                  </TableRow>
                ))}
            </React.Fragment>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
