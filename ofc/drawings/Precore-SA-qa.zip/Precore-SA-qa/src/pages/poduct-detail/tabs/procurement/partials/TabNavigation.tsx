import type React from "react";

import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import addIcon from "@/assets/icons/add_procurement_data.svg";

interface TabNavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const TabNavigation: React.FC<TabNavigationProps> = ({
  activeTab,
  setActiveTab,
}) => (
  <div className="flex items-center">
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="flex h-auto p-0 bg-transparent w-full">
        <TabsTrigger
          value="purchase-requests"
          className="flex-1 py-2 px-6 rounded-none border border-r-0 rounded-t-[0.5rem] border-boarder-300 data-[state=active]:text-emerald-600 data-[state=active]:shadow-none  text-gray-700 bg-white"
        >
          Purchase Requests
        </TabsTrigger>
        <TabsTrigger
          value="request-for-quote"
          className="flex-1 py-2 px-6 rounded-none border border-r-0 rounded-t-[0.5rem] border-boarder-300 data-[state=active]:text-emerald-600 data-[state=active]:shadow-none  text-gray-700 bg-white"
        >
          Request for Quote
        </TabsTrigger>
        <TabsTrigger
          value="purchase-order"
          className="flex-1 py-2 px-6 rounded-none border border-r-0 rounded-t-[0.5rem] border-boarder-300 data-[state=active]:text-emerald-600 data-[state=active]:shadow-none  text-gray-700 bg-white"
        >
          Purchase Order
        </TabsTrigger>
        <TabsTrigger
          value="invoices"
          className="flex-1 py-2 px-6 rounded-none border border-r-0 rounded-t-[0.5rem] border-boarder-300 data-[state=active]:text-emerald-600 data-[state=active]:shadow-none  text-gray-700 bg-white"
        >
          Invoices
        </TabsTrigger>
        <TabsTrigger
          value="deliveries"
          className="flex-1 py-2 px-6 rounded-none border border-r-0 rounded-t-[0.5rem] border-boarder-300 data-[state=active]:text-emerald-600 data-[state=active]:shadow-none  text-gray-700 bg-white"
        >
          Deliveries
        </TabsTrigger>
      </TabsList>
    </Tabs>
    <Button variant="ghost" className="p-0 mx-2 cursor-pointer">
      <img src={addIcon} alt="add-icon" />
    </Button>
  </div>
);

export default TabNavigation;
