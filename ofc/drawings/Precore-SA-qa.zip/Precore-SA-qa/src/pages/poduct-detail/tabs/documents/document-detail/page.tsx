import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Download, Trash2 } from "lucide-react";
import { IoMdArrowDropdown } from "react-icons/io";
import FileIcon from "./partials/FileIcon";
import AddButton from "@/components/headerBottom/AddButton";
import { documents } from "@/data/documentData";

const fileTypes = ["All Files", "PDF", "Word", "Excel", "PowerPoint"];
const dateOptions = [
  "Newest First",
  "Oldest First",
  "Last 7 Days",
  "Last 30 Days",
];

const DocumentDetailPage = () => {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2">
          <h1 className="typography-paragraph-regular font-medium text-text-500">
            Permits & Approvals
          </h1>

          <div className="flex gap-2 items-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium">
                  File Type <IoMdArrowDropdown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0">
                {fileTypes.map((type, index) => (
                  <DropdownMenuItem
                    key={index}
                    onClick={() => console.warn(type)}
                    className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                  >
                    {type}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium">
                  Date <IoMdArrowDropdown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0">
                {dateOptions.map((option, index) => (
                  <DropdownMenuItem
                    key={index}
                    onClick={() => console.warn(option)}
                    className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                  >
                    {option}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div>
          <AddButton title="Upload Document" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {documents?.map((doc) => (
          <div
            key={doc.id}
            className="bg-white rounded-[0.75rem] shadow-[0px_2px_14px_0px_rgba(0,0,0,0.02)] border border-boarder-300 p-4 flex flex-col hover:shadow-[0px_5px_14.7px_2px_rgba(0,0,0,0.08)] transition-all duration-200"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <FileIcon fileType={doc.type} />
                <div>
                  <h3 className="font-semibold text-text-500 typography-paragraph-regular pb-[0.37rem]">
                    {doc.name}
                  </h3>
                  <p className="typography-paragraph-small font-medium text-text-300 ">
                    {doc.uploader}
                  </p>
                  <p className="typography-paragraph-small font-medium py-[0.25rem] text-text-300 ">
                    {doc.date}
                  </p>
                  <p className="typography-paragraph-small font-medium text-text-300 ">
                    {doc.size}
                  </p>
                </div>
              </div>
              <div className="flex flex-col items-end space-y-2">
                <button
                  className="bg-section-bg-300 rounded-full p-2 hover:bg-section-bg-400"
                  aria-label="Download"
                  title="Download"
                >
                  <Download
                    size={18}
                    className="text-text-400 hover:text-text-600"
                  />
                </button>
                <button
                  className="text-red-400 hover:text-red-600 p-2 rounded-full hover:bg-red-50"
                  aria-label="Delete"
                  title="Delete"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DocumentDetailPage;
