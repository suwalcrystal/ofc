import ScheduleTable from "./ScheduleTable";

const ScheduleContent = () => {
  return (
    <div>
      <ScheduleTable />
    </div>
  );
};

export default ScheduleContent;
