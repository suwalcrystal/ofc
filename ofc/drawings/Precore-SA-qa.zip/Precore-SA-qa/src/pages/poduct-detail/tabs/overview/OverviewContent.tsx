import GlobalCard from "@components/GlobalCard";
import { statusCards } from "../../data";
import AccordionExpensesSummary from "./partials/AccordionExpensesSummary";
import ClientBillingSnapshot from "./partials/ClientBillingSnapshot";
import FinancialHealth from "./partials/FinancialHealth";
import ScheduleSnapshot from "./partials/ScheduleSnapshot";
import TeamSnapshot from "./partials/TeamSnapshot";

const OverviewContent = () => (
  <>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5 mb-5">
      {statusCards?.map((card, index) => (
        <GlobalCard
          key={index}
          title={card.title}
          value={card.value}
          icon={card.icon}
          bgColor={card.bgColor}
        />
      ))}
    </div>
    <div className="flex gap-5 ">
      <div className="flex flex-col gap-5">
        <FinancialHealth />
        <ScheduleSnapshot />
      </div>

      <div className="flex flex-col gap-5 w-full">
        <ClientBillingSnapshot />
        <TeamSnapshot />
      </div>
    </div>

    <AccordionExpensesSummary />
  </>
);

export default OverviewContent;
