import BaseTable from "@/components/BaseTable";
import { IDelivery } from "../interface/procrument.interface";
import { TableCell } from "@/components/ui/table";
import { IColumn } from "@/interface/baseTable.interface";

interface DeliveriesTableProps {
  data: IDelivery[];
}

const columns: IColumn<IDelivery>[] = [
  { key: "id", label: "Delivery ID", sortable: true },
  { key: "status", label: "Status", sortable: true },
  { key: "type", label: "Type", sortable: true },
  { key: "linkedPO", label: "Linked PO", sortable: true },
  { key: "deliveredBy", label: "Delivered By", sortable: true },
  { key: "receivedBy", label: "Received By", sortable: true },
  { key: "remarks", label: "Remarks", sortable: false },
];

const renderedRow = (item: IDelivery): React.JSX.Element[] => [
  <TableCell
    key="id"
    className="font-medium text-text-500 truncate text-center"
  >
    {item.id}
  </TableCell>,

  <TableCell key="status" className="text-center">
    <span
      className={`rounded-full px-3 py-1 text-xs font-medium ${
        item.status === "Received"
          ? "bg-blue-bg text-blue"
          : item.status === "Pending"
            ? "bg-yellow-50 text-yellow-700"
            : item.status === "In Transit"
              ? "bg-green-50 text-green-500"
              : "bg-gray-50 text-gray-500"
      }`}
    >
      {item.status}
    </span>
  </TableCell>,

  <TableCell
    key="type"
    className="font-medium text-text-500 truncate text-center"
  >
    {item.type}
  </TableCell>,

  <TableCell key="linkedPO" className="text-center">
    <a
      href={`/po/${item.linkedPO}`}
      className="text-blue font-medium hover:underline truncate"
    >
      {item.linkedPO}
    </a>
  </TableCell>,

  <TableCell
    key="deliveredBy"
    className="font-medium text-text-500 truncate text-center"
  >
    {item.deliveredBy}
  </TableCell>,

  <TableCell
    key="receivedBy"
    className="font-medium text-text-500 truncate text-center"
  >
    {item.receivedBy}
  </TableCell>,

  <TableCell
    key="remarks"
    className="font-medium text-text-500 truncate text-center"
  >
    {item.remarks}
  </TableCell>,
];

const DeliveriesTable: React.FC<DeliveriesTableProps> = ({ data }) => (
  <BaseTable<IDelivery> data={data} columns={columns} renderRow={renderedRow} />
);

export default DeliveriesTable;
