export const AccordionExpensesSummaryData = [
  {
    name: "Civil ",
    amountSpent: 1250000,
    subPackages: [
      {
        name: "Materials",
        amountSpent: 500000,
        packageBudget: 40,
      },
      {
        name: "Subcontractors",
        amountSpent: 500000,
        packageBudget: 40,
      },
      {
        name: "dsafs",
        amountSpent: 500000,
        packageBudget: 40,
      },
    ],
  },
  {
    name: "MEP",
    amountSpent: 1250000,
    subPackages: [
      {
        name: "Mfdsfdsaterials",
        amountSpent: 500000,
        packageBudget: 40,
      },
      {
        name: "Subcontrfdsfactors",
        amountSpent: 500000,
        packageBudget: 40,
      },
      {
        name: "dsfdsfewafs",
        amountSpent: 500000,
        packageBudget: 40,
      },
    ],
  },
  {
    name: "Landscape",
    amountSpent: 1250000,
    subPackages: [],
  },
];

export const ghanttData = [
  {
    id: "1",
    name: "2nd Floor Complete",
    startDate: "2025-01-07",
    endDate: "2025-02-14",
  },
  {
    id: "2",
    name: "Mep Start",
    startDate: "2025-02-20",
    endDate: "2025-03-14",
  },
  {
    id: "3",
    name: "Roofing Start",
    startDate: "2025-03-15",
    endDate: "2025-04-24",
  },
  {
    id: "4",
    name: "3rd Floor Start",
    startDate: "2025-04-22",
    endDate: "2025-05-28",
  },
  {
    id: "5",
    name: "5rd Floor Start",
    startDate: "2025-05-22",
    endDate: "2025-06-28",
  },
];
