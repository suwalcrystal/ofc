import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AccordionExpensesSummaryData } from "../data";
import ExpenseSummaryTable from "./ExpenseSummaryTable";
import { ExpenseSummaryCategory } from "../interface/expenseAccordiion";
import { useState } from "react";

export default function AccordionExpensesSummary() {
  const [openIndex, setOpenIndex] = useState(0);
  const expensesSummaryData: ExpenseSummaryCategory[] =
    AccordionExpensesSummaryData;

  return (
    <Card className="my-6 w-full max-w-6xl mx-auto border-0  shadow-[ 0px_4px_14px_2px rgba(0,0,0,0.02)]">
      <CardHeader>
        <CardTitle className="typography-paragraph-small text-text-500 font-semibold">
          Expenses Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {expensesSummaryData.map((category, index) => (
          <ExpenseSummaryTable
            key={index}
            category={category}
            isOpen={openIndex === index}
            onToggle={() => setOpenIndex(openIndex === index ? -1 : index)}
          />
        ))}
      </CardContent>
    </Card>
  );
}
