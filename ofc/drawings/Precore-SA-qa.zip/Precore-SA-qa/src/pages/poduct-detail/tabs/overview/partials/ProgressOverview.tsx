import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

const data = [
  { label: "Overall Time Progress", value: 52 },
  { label: "Planned Progress", value: 69 },
  { label: "Actual  Progress", value: 60 },
];

const ProgressOverview = () => {
  return (
    <div>
      <Card className="w-full lg:w-[400px] shadow-card border-[0.2px] border-boarder-300 rounded-[0.5rem] bg-section-bg-200 gap-2 py-5">
        <CardHeader className="px-5">
          <h2 className="typography-paragraph-small text-text-500 font-semibold">
            Progress Overview
          </h2>
        </CardHeader>
        <CardContent className="px-5">
          <div className="space-y-3">
            {data.map((item, index) => (
              <div className="flex gap-2" key={index}>
                <p className="text-text-400 font-medium typography-paragraph-small w-[40%]">
                  <span className="inline-block w-max">{item.label} :</span>
                </p>
                <div className="flex items-baseline gap-[0.62rem] grow">
                  <Progress
                    value={item?.value}
                    className="h-2 w-full rounded-md backdrop-blur-3xl *:bg-green-400"
                  />
                  <p className="typography-paragraph-small text-text-500 font-semibold">
                    {item?.value}%
                  </p>
                </div>
              </div>
            ))}
            <div className="flex ">
              <p className="text-text-400 font-medium typography-paragraph-small min-w-[40%]">
                Delay :
              </p>
              <Badge
                variant="outline"
                className={`bg-[#FFF5E8] text-[#A2845E] hover:bg-[#A2845E]/20 border-0 px-2 py-1.5 rounded-full typography-paragraph-small font-medium`}
              >
                Warning
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProgressOverview;
