import calendar from "@/assets/icons/calendar-line.svg";
import userIcon from "@/assets/icons/person-outline.svg";
import { formatDate } from "@/utils/formatDate";

interface Gallery {
  image: string;
  label: string;
  desc: string;
  user: string;
  timestamp: string | number | Date;
}

interface ImageModalProps {
  gallery: Gallery | null;
  onClose: () => void;
}

const ImageModal: React.FC<ImageModalProps> = ({ gallery, onClose }) => {
  if (!gallery) return null;

  return (
    <div
      className="fixed inset-0 bg-black/70 bg-opacity-70 flex items-center justify-center z-50"
      onClick={onClose}
    >
      <div
        className="shadow-lg max-w-[90vw] max-h-[90vh] overflow-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={gallery.image}
          alt="Preview"
          className="max-w-full max-h-[60vh] object-contain mb-4"
        />
        <div className="flex justify-between items-center">
          <div>
            <h2 className="typography-paragraph-regular font-semibold text-white mb-1">
              {gallery.label}
            </h2>
            <p className="typography-paragraph-small font-medium text-white">
              {gallery.desc}
            </p>
          </div>
          <div>
            <div className="flex gap-2">
              <div className="size-[0.875rem]">
                <img
                  src={userIcon}
                  alt="user-icon"
                  className="size-full object-cover"
                />
              </div>
              <p className="text-white typography-paragraph-small font-medium mb-1">
                {gallery.user}
              </p>
            </div>
            <div className="flex gap-2">
              <div className="size-[0.875rem]">
                <img
                  src={calendar}
                  alt="calendar-icon"
                  className="size-full object-cover"
                />
              </div>
              <p className="text-white typography-paragraph-small font-medium">
                {formatDate(new Date(gallery.timestamp), "d MMM yyyy, HH:mm")}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageModal;
