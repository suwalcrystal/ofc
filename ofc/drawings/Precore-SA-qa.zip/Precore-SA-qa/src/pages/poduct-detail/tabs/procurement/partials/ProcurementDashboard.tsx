import { Tabs, TabsContent } from "@/components/ui/tabs";
import FilterControls from "./FilterComponent";
import { useProcurementDashboard } from "../hooks/procurement.hook";

import InvoicesTab from "./InvoicesTable";
import DeliveriesTab from "./DeliveriesTable";
import PurchaseRequestsTab from "./PurchaseRequestsTable";
import RequestForQuoteTab from "./RequestForQuoteTable";
import PurchaseOrdersTab from "./PurchaseOrdersTable";
import TabNavigation from "./TabNavigation";
import {
  IDelivery,
  IInvoice,
  IPurchaseOrder,
  IPurchaseRequest,
  IRequestForQuote,
} from "../interface/procrument.interface";

const ProcurementDashboard: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    filterType,
    setFilterType,
    totalPendingCount,
    filteredPurchaseRequests,
    filteredRequestForQuote,
    filteredPurchaseOrders,
    filteredInvoices,
    filteredDeliveries,
  } = useProcurementDashboard();

  return (
    <div className="p-4">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
        <FilterControls
          filterType={filterType}
          setFilterType={setFilterType}
          totalPendingCount={totalPendingCount}
        />
      </div>

      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="mt-[1px] bg-white p-5 shadow-sm "
      >
        <TabsContent value="purchase-requests" className="mt-0">
          {filteredPurchaseRequests ? (
            <PurchaseRequestsTab
              data={filteredPurchaseRequests as IPurchaseRequest[]}
              filterType={filterType}
            />
          ) : (
            <div className="p-4 text-center text-gray-500">
              Loading or no data available
            </div>
          )}
        </TabsContent>
        <TabsContent value="request-for-quote" className="mt-0">
          {filteredRequestForQuote ? (
            <RequestForQuoteTab
              data={filteredRequestForQuote as IRequestForQuote[]}
            />
          ) : (
            <div className="p-4 text-center text-gray-500">
              Loading or no data available
            </div>
          )}
        </TabsContent>
        <TabsContent value="purchase-order" className="mt-0">
          {filteredPurchaseOrders ? (
            <PurchaseOrdersTab
              data={filteredPurchaseOrders as IPurchaseOrder[]}
            />
          ) : (
            <div className="p-4 text-center text-gray-500">
              Loading or no data available
            </div>
          )}
        </TabsContent>
        <TabsContent value="invoices" className="mt-0">
          {filteredInvoices ? (
            <InvoicesTab data={filteredInvoices as IInvoice[]} />
          ) : (
            <div className="p-4 text-center text-gray-500">
              Loading or no data available
            </div>
          )}
        </TabsContent>
        <TabsContent value="deliveries" className="mt-0">
          {filteredDeliveries ? (
            <DeliveriesTab data={filteredDeliveries as IDelivery[]} />
          ) : (
            <div className="p-4 text-center text-gray-500">
              Loading or no data available
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProcurementDashboard;
