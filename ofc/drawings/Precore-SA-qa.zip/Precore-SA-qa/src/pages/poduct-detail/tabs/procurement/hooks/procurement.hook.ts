import { useState } from "react";
import {
  deliveriesData,
  invoicesData,
  purchaseOrderData,
  purchaseRequestsData,
  requestForQuoteData,
} from "../data";

export interface PendingCounts {
  "purchase-requests": number;
  "request-for-quote": number;
  "purchase-order": number;
  invoices: number;
  deliveries: number;
}

export interface ProcurementDashboardState {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  filterType: string;
  setFilterType: (type: string) => void;
  totalPendingCount: number;
  filteredPurchaseRequests: typeof purchaseRequestsData;
  filteredRequestForQuote: typeof requestForQuoteData;
  filteredPurchaseOrders: typeof purchaseOrderData;
  filteredInvoices: typeof invoicesData;
  filteredDeliveries: typeof deliveriesData;
  pendingCounts: PendingCounts;
}

export const useProcurementDashboard = (): ProcurementDashboardState => {
  const [activeTab, setActiveTab] = useState("purchase-order");
  const [filterType, setFilterType] = useState("all");

  // Count pending items
  const pendingCounts: PendingCounts = {
    "purchase-requests": purchaseRequestsData.filter(
      (item) => item.status === "Pending"
    ).length,
    "request-for-quote": requestForQuoteData.filter(
      (item) => item.status === "Pending" || item.status === "In Progress"
    ).length,
    "purchase-order": purchaseOrderData.filter(
      (item) => item.status === "Pending"
    ).length,
    invoices: invoicesData.filter((item) => item.status === "Pending").length,
    deliveries: deliveriesData.filter(
      (item) => item.status === "Pending" || item.status === "In Transit"
    ).length,
  };

  const totalPendingCount = Object.values(pendingCounts).reduce(
    (sum, count) => sum + count,
    0
  );

  // Filter function
  const getFilteredData = <T extends { status: string }>(
    data: T[],
    statusField: keyof T = "status"
  ): T[] => {
    if (filterType === "all") return data;
    return data.filter(
      (item) =>
        item[statusField] === "Pending" ||
        item[statusField] === "In Progress" ||
        item[statusField] === "In Transit"
    );
  };

  // Filtered data
  const filteredPurchaseRequests = getFilteredData(purchaseRequestsData);
  const filteredRequestForQuote = getFilteredData(requestForQuoteData);
  const filteredPurchaseOrders = getFilteredData(purchaseOrderData);
  const filteredInvoices = getFilteredData(invoicesData);
  const filteredDeliveries = getFilteredData(deliveriesData);

  return {
    activeTab,
    setActiveTab,
    filterType,
    setFilterType,
    totalPendingCount,
    filteredPurchaseRequests,
    filteredRequestForQuote,
    filteredPurchaseOrders,
    filteredInvoices,
    filteredDeliveries,
    pendingCounts,
  };
};
