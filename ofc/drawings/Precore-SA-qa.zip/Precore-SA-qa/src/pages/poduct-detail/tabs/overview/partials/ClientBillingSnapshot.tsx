import { Badge } from "@/components/ui/badge";
import invoice from "@/assets/icons/invoice.svg";
import tickCircle from "@/assets/icons/tick-circle.svg";

const ClientBillingSnapshot = () => {
  return (
    <>
      <div className="rounded-[0.5rem] border border-boarder-300 bg-white shadow-card p-5 h-fit">
        <h2 className="text-text-500 typography-paragraph-regular font-semibold">
          Client Billing Snapshot
        </h2>
        <div className="my-[0.88rem]">
          <div className="flex items-center gap-[0.62rem] pb-[0.62rem]">
            <div className={"p-[0.31rem] rounded-[0.375rem] bg-text-50"}>
              <img
                src={invoice}
                alt="invoice-icon"
                className="h-[0.875rem] w-[0.875rem]"
              />
            </div>

            <p className="text-text-400 typography-paragraph-small font-medium">
              Next Invoice Due
            </p>
          </div>
          <p className="text-text-500 typography-paragraph-regular font-semibold">
            AED 11,382,233
          </p>
        </div>

        <div className="flex items-center gap-[0.62rem] pb-[0.62rem]">
          <div className={"p-[0.31rem] rounded-[0.375rem] bg-text-50"}>
            <img
              src={tickCircle}
              alt="tick-icon"
              className="h-[0.875rem] w-[0.875rem]"
            />
          </div>

          <p className="text-text-400 typography-paragraph-small font-medium">
            Current Invoice Status
          </p>
        </div>

        <Badge
          variant="outline"
          className={`bg-green-50 text-green-500 hover:bg-green-100 border-0 px-2 py-1.5 rounded-full typography-paragraph-caption font-semibold`}
        >
          Submitted
        </Badge>
      </div>
    </>
  );
};

export default ClientBillingSnapshot;
