import ExpenseSummary from "./ExpenseSummary";
import ChartFinancialHealth from "./ChartFinancialHealth";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FinancialHealth = () => {
  return (
    <div>
      <Accordion
        defaultValue="item-1"
        type="single"
        collapsible
        className="rounded-[0.5rem] border border-boarder-300 bg-white shadow-card p-5 w-full lg:w-[53.875rem] py-0"
      >
        <AccordionItem value="item-1">
          <AccordionTrigger className="flex justify-between items-center pb-[0.87rem] hover:no-underline cursor-pointer">
            <h2 className="text-text-500 typography-paragraph-regular font-semibold ">
              Financial Health
            </h2>
          </AccordionTrigger>
          <AccordionContent>
            <div className="flex gap-5">
              <ChartFinancialHealth />
              <ExpenseSummary />
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

export default FinancialHealth;
