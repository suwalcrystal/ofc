export interface Employee {
  id: string;
  name: string;
  position: string;
  role: string;
  department: string;
  reportingTo: string;
  startDate: string;
  status: "Active" | "Inactive";
  avatar: string;
}

export interface BudgetCategory {
  name: string;
  planned: number;
  spent: number;
  remaining: number;
  spentPercentage: number;
  progressPercentage: number;
  subPackages: SubPackage[];
}

export interface SubPackage {
  name: string;
  plannedMaterial: number;
  plannedSubContractor: number;
  actualMaterial: number;
  actualSubContractor: number;
  remainingMaterial: number;
  remainingSubContractor: number;
}
