import FilterProgressGallery from "./partials/FilterProgressGallery";
import PhotoGallery from "./partials/PhotoGallery";

const ProgressGalleryContent = () => {
  return (
    <div>
      <FilterProgressGallery />
      <PhotoGallery />
    </div>
  );
};

export default ProgressGalleryContent;
