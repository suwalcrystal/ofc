import addPerson from "@/assets/icons/person-add.svg";

const teamMembers = [
  {
    name: "Salman Khan",
    role: "Manager",
    profileLink: "#",
  },
  {
    name: "Alice Smith",
    role: "Quantity Surveyor",
    profileLink: "#",
  },
  {
    name: "Emma Wilsan",
    role: "QA/QC Engineer",
    profileLink: "#",
  },
  {
    name: "David Lee, Sarah Jones",
    role: "Site Engineer",
    profileLink: "#",
  },
  {
    name: "James Miller",
    role: "Planning Engineer",
    profileLink: "#",
  },
  {
    name: "Leura White",
    role: "Safety Officer",
    profileLink: "#",
  },
  {
    name: "David Lee, Sarah Jones",
    role: "Site Engineer",
    profileLink: "#",
  },
];

const TeamSnapshot = () => {
  return (
    <div className="rounded-[0.5rem] border border-boarder-300 bg-white shadow-card p-5 h-fit">
      <h2 className="text-text-500 typography-paragraph-regular font-semibold">
        Team Snapshot
      </h2>

      {teamMembers?.map((member, index) => (
        <div
          key={index}
          className="rounded-[0.25rem] border-[0.4px] border-boarder-300 bg-section-bg-100 p-[0.62rem] mt-3"
        >
          <div className="flex justify-between items-center">
            <div>
              <div className="flex items-baseline gap-1">
                <a
                  href={member.profileLink}
                  className="text-blue typography-paragraph-small font-bold pb-[0.25rem]"
                >
                  {member.name}
                </a>
                <div className="w-[0.375rem] h-[0.375rem] rounded-full bg-[#15CF09]" />
              </div>
              <p className="text-text-400 typography-paragraph-small font-medium">
                {member.role}
              </p>
            </div>

            <div>
              <img
                src={addPerson}
                alt="add-person-icon"
                className="w-[1.125rem] h-[1.125rem] object-cover"
              />
            </div>
          </div>
        </div>
      ))}

      <div className="rounded-[0.25rem] border-[0.4px] border-boarder-300 bg-section-bg-100 p-[0.62rem] mt-3">
        <div className="flex justify-between items-center">
          <div>
            <a
              href="#"
              className="text-text-400 typography-paragraph-small font-medium"
            >
              Add Custom Role
            </a>
          </div>

          <div>
            <img
              src={addPerson}
              alt="add-person-icon"
              className="w-[1.125rem] h-[1.125rem] object-cover"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeamSnapshot;
