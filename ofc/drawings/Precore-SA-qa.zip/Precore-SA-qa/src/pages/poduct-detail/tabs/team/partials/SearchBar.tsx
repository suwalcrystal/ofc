import { Input } from "@/components/ui/input";
import { FiSearch } from "react-icons/fi";

// Search Bar Component
interface SearchBarProps {
  filterValue: string;
  setFilterValue: (value: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({
  filterValue,
  setFilterValue,
}) => (
  <div className="relative">
    <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-text-200" />
    <Input
      placeholder="Search"
      value={filterValue}
      onChange={(e) => setFilterValue(e.target.value)}
      className="w-full pl-9 pr-3 py-[0.62rem] border border-boarder-300 bg-background-300 rounded-[1.375rem] focus:outline-none typography-paragraph-regular text-text-500 focus:ring-0"
    />
  </div>
);

export default SearchBar;
