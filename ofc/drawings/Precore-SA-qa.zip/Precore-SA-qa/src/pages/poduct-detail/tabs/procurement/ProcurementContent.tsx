import GlobalCard from "@components/GlobalCard";
import { ProcurementContent } from "./data";
import ProcurementDashboard from "./partials/ProcurementDashboard";

const BudgetContent = () => {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-5">
        {ProcurementContent?.map((card, index) => (
          <GlobalCard
            key={index}
            title={card.title}
            value={card.value}
            icon={card.icon}
            bgColor={card.bgColor}
          />
        ))}
      </div>
      <ProcurementDashboard />
    </div>
  );
};

export default BudgetContent;
