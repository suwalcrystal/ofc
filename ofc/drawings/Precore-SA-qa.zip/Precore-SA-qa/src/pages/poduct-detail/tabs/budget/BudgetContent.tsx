import BudgetAccordion from "./partials/BudgetAccordion";
import { budgetStatusCards } from "./data";
import GlobalCard from "@/components/GlobalCard";

const BudgetContent = () => {
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-5">
        {budgetStatusCards?.map((card, index) => (
          <GlobalCard
            key={index}
            title={card.title}
            value={card.value}
            icon={card.icon}
            bgColor={card.bgColor}
          />
        ))}
      </div>

      <BudgetAccordion />
    </>
  );
};

export default BudgetContent;
