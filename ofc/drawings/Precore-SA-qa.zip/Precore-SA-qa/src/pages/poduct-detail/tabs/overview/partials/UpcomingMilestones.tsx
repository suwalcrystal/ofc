import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import calendar from "@/assets/icons/calendar.svg";

const data = [
  { label: "2nd Floor Complete", value: "Feb 14, 2025" },
  { label: "MEP Start", value: "Mar 14, 2025" },
  { label: "Roofing Start", value: "Apr 24, 2025" },
];

const UpcomingMilestones = () => {
  return (
    <div>
      <Card className="w-full lg:w-[400px] shadow-card border-[0.2px] border-boarder-300 rounded-[0.5rem] bg-section-bg-200 gap-2 py-5 h-full">
        <CardHeader className="px-5">
          <h2 className="typography-paragraph-small text-text-500 font-semibold">
            Upcoming Milestones
          </h2>
        </CardHeader>
        <CardContent className="px-5">
          <div className="space-y-3">
            {data.map((item, index) => (
              <div className="flex gap-10" key={index}>
                <p className="text-text-400 font-medium typography-paragraph-small w-[40%]">
                  <span className="inline-block w-max">{item.label}:</span>
                </p>
                <div className="flex items-baseline gap-[0.62rem] grow text-text-400 font-medium typography-paragraph-small">
                  <img
                    src={calendar}
                    alt="invoice-icon"
                    className="h-[0.875rem] w-[0.875rem]"
                  />
                  <p>{item?.value}</p>
                </div>
              </div>
            ))}
            <div className="flex items-center gap-10 mt-1">
              <p className="text-text-400 font-medium typography-paragraph-small min-w-[40%]">
                Critical Path Risk Alert :
              </p>
              <Badge
                variant="outline"
                className={`bg-[#FFE3E3] text-error hover:bg-error/40 border-0 px-2 py-1.5 rounded-full typography-paragraph-small font-medium`}
              >
                At Risk
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UpcomingMilestones;
