import { Card, CardContent, CardHeader } from "@/components/ui/card";

const data = [
  { label: "Spent on Materials", value: "AED 323,545" },
  { label: "Spent on Subcontractors", value: "AED 2,323,545" },
  { label: "Spent on Equipment Rentals", value: "AED 323,545" },
  { label: "Spent on HR / Salaries", value: "AED 23,545" },
  { label: "Shared Office Expenses", value: "AED 3,545" },
];

const ExpenseSummary = () => {
  return (
    <div>
      <Card className="w-full lg:w-[400px] shadow-card border-[0.2px] border-boarder-300 rounded-[0.5rem] bg-section-bg-200 gap-2 py-5">
        <CardHeader className="px-5">
          <h2 className="typography-paragraph-small text-text-500 font-semibold">
            Expenses Summary
          </h2>
        </CardHeader>
        <CardContent className="px-5">
          <div className="space-y-3">
            {data.map((item, index) => (
              <div className="flex justify-between" key={index}>
                <span className="text-text-400 font-medium typography-paragraph-small">
                  {item.label} :
                </span>
                <span className="text-text-500 font-semibold typography-paragraph-small">
                  {item.value}
                </span>
              </div>
            ))}
            <div className="flex justify-between">
              <span className="text-text-400 font-medium typography-paragraph-small">
                Total Profit / Loss :
              </span>
              <span className="text-green-500 font-bold typography-paragraph-small">
                AED 11,323,545
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ExpenseSummary;
