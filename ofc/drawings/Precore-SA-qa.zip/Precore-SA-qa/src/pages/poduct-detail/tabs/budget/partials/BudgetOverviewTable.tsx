import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Download } from "lucide-react";
import { IoMdArrowDropdown, IoMdArrowDropup } from "react-icons/io";
import { BudgetCategory } from "../../team/interface/employee.interface";

const BudgetOverview = ({
  category,
  isOpen,
  onToggle,
}: {
  category: BudgetCategory;
  isOpen: boolean;
  onToggle: () => void;
}) => {
  return (
    <div className="border rounded-md overflow-hidden">
      <div className="flex items-center p-4 cursor-pointer" onClick={onToggle}>
        <div className="mr-1">
          {isOpen ? (
            <IoMdArrowDropup className="h-5 w-5 text-gray-500" />
          ) : (
            <IoMdArrowDropdown className="h-5 w-5 text-gray-500" />
          )}
        </div>

        <div className="typography-paragraph-small font-semibold text-text-500">
          {category.name}
        </div>
        <div className="ml-auto flex items-center space-x-6 typography-paragraph-caption text-text-400 font-medium">
          <div>
            <span>Planned:</span> {category.planned.toLocaleString()} AED
          </div>
          <div>
            <span>Spent:</span> {category.spent.toLocaleString()} AED
          </div>
          <div>
            <span>Remaining:</span> {category.remaining.toLocaleString()} AED
          </div>
          <div>
            <span>Budget Spent %:</span> {category.spentPercentage}%
          </div>
          <div>
            <span>Progress %:</span> {category.progressPercentage}%
          </div>
        </div>
      </div>

      {isOpen && category.subPackages.length > 0 && (
        <div className="px-4 pb-4">
          <div className="bg-[#F3F3F3] rounded-sm overflow-hidden">
            <Table>
              <TableHeader className="bg-[#F3F3F3]">
                <TableRow className="border-none">
                  <TableHead className="typography-paragraph-small text-text-500 font-medium text-center w-1/9">
                    Sub-Package
                  </TableHead>
                  <TableHead
                    colSpan={2}
                    className="typography-paragraph-small text-text-500 font-medium text-center w-2/9"
                  >
                    Planned Budget
                  </TableHead>
                  <TableHead
                    colSpan={2}
                    className="typography-paragraph-small text-text-500 font-medium text-center w-2/9"
                  >
                    Actual Spent
                  </TableHead>
                  <TableHead
                    colSpan={2}
                    className="typography-paragraph-small text-text-500 font-medium text-center w-2/9"
                  >
                    Remaining Budget
                  </TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-medium text-center w-2/9">
                    RFQ
                  </TableHead>
                </TableRow>
                <TableRow className="border-none">
                  <TableHead className="h-8"></TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-normal text-center">
                    Material
                  </TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-normal text-center">
                    Sub-contractor
                  </TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-normal text-center">
                    Material
                  </TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-normal text-center">
                    Sub-contractor
                  </TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-normal text-center">
                    Material
                  </TableHead>
                  <TableHead className="typography-paragraph-small text-text-500 font-normal text-center">
                    Sub-contractor
                  </TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {category.subPackages.map((subPackage, index) => (
                  <TableRow
                    key={index}
                    className="bg-white hover:bg-white  border-b"
                  >
                    <TableCell className="typography-paragraph-small font-semibold text-text-500">
                      {subPackage.name}
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-semibold text-center text-text-500">
                      {subPackage.plannedMaterial.toLocaleString()}
                      <br className="mb-[0.31rem]" />
                      <span className="typography-paragraph-caption text-text-300">
                        AED
                      </span>
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-semibold text-center text-text-500">
                      {subPackage.plannedSubContractor.toLocaleString()}
                      <br className="mb-[0.31rem]" />
                      <span className="typography-paragraph-caption text-text-300">
                        AED
                      </span>
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-semibold text-center text-text-500">
                      {subPackage.actualMaterial.toLocaleString()}
                      <br className="mb-[0.31rem]" />
                      <span className="typography-paragraph-caption text-text-300">
                        AED
                      </span>
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-semibold text-center text-text-500">
                      {subPackage.actualSubContractor.toLocaleString()}
                      <br className="mb-[0.31rem]" />
                      <span className="typography-paragraph-caption text-text-300">
                        AED
                      </span>
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-semibold text-center text-text-500">
                      {subPackage.remainingMaterial.toLocaleString()}
                      <br className="mb-[0.31rem]" />
                      <span className="typography-paragraph-caption text-text-300">
                        AED
                      </span>
                    </TableCell>
                    <TableCell className="typography-paragraph-small font-semibold text-center text-text-500">
                      {subPackage.remainingSubContractor.toLocaleString()}
                      <br className="mb-[0.31rem]" />
                      <span className="typography-paragraph-caption text-text-300">
                        AED
                      </span>
                    </TableCell>
                    <TableCell className="text-center ">
                      <Button
                        variant="ghost"
                        className="typography-paragraph-small font-semibold text-blue hover:bg-white hover:text-blue flex items-center gap-1 mx-auto"
                      >
                        <Download className="h-4 w-4" />
                        Download
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  );
};
export default BudgetOverview;
