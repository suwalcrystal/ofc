import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Tab Navigation Component
interface TabNavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const TabNavigation: React.FC<TabNavigationProps> = ({
  activeTab,
  setActiveTab,
}) => (
  <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
    <TabsList className="grid w-full grid-cols-2 sm:grid-cols-5 sm:w-auto">
      <TabsTrigger value="purchase-requests">Purchase Requests</TabsTrigger>
      <TabsTrigger value="request-for-quote">Request for Quote</TabsTrigger>
      <TabsTrigger value="purchase-order">Purchase Order</TabsTrigger>
      <TabsTrigger value="invoices">Invoices</TabsTrigger>
      <TabsTrigger value="deliveries">Deliveries</TabsTrigger>
    </TabsList>
  </Tabs>
);
export default TabNavigation;
