export interface Employee {
  id: string;
  name: string;
  position: string;
  role: string;
  department: string;
  reportingTo: string;
  startDate: string;
  status: "Active" | "Inactive";
  avatar: string;
}

export interface ExpenseSummaryCategory {
  name: string;
  amountSpent: number;
  subPackages: SubPackage[];
}

export interface SubPackage {
  name: string;
  amountSpent: number;
  packageBudget: number;
}
