import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { accordionTableData } from "../../../partials/data";
import { BudgetCategory } from "../../team/interface/employee.interface";
import BudgetOverview from "./BudgetOverviewTable";
import { useState } from "react";

export default function BudgetTable() {
  const [openIndex, setOpenIndex] = useState(0);

  const budgetCategories: BudgetCategory[] = accordionTableData;

  return (
    <Card className="w-full max-w-6xl mx-auto border-0  shadow-[ 0px_4px_14px_2px rgba(0,0,0,0.02)]">
      <CardHeader>
        <CardTitle className="typography-paragraph-small text-text-500 font-semibold">
          Budget Overview
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {budgetCategories.map((category, index) => (
          <BudgetOverview
            key={index}
            category={category}
            isOpen={openIndex === index}
            onToggle={() => setOpenIndex(openIndex === index ? -1 : index)}
          />
        ))}
      </CardContent>
    </Card>
  );
}
