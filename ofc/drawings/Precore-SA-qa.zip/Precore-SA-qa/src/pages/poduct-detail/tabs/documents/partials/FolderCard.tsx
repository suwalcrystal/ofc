import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreVertical } from "lucide-react";
import { Link } from "react-router-dom";

type FolderCardProps = {
  title: string;
  size: string;
  date: string;
  image: string;
};

const dropdownActions = [
  { label: "Copy Link", onClick: () => console.log("Copy Link") },
  { label: "Download", onClick: () => console.log("Download") },
  { label: "Edit", onClick: () => console.log("Edit") },
  { label: "Delete", onClick: () => console.log("Delete") },
];

const FolderCard = ({ title, size, date, image }: FolderCardProps) => {
  return (
    <Link
      to="/document-detail"
      className="bg-white border border-boarder-300 rounded-[0.75rem] shadow-card w-full max-w-[11.5rem] p-3 flex flex-col items-center hover:shadow-[0px_4px_10.8px_4px_rgba(0,0,0,0.08)] transition-all duration-200"
    >
      <div className="w-full flex justify-end mb-2">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="text-text-300 hover:text-text-700 focus:outline-none cursor-pointer "
              aria-label="More options"
              title="More options"
            >
              <MoreVertical size={20} />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="start"
            className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0"
          >
            {dropdownActions.map((action, index) => (
              <DropdownMenuItem
                key={index}
                onClick={action.onClick}
                className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
              >
                <span>{action.label}</span>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="mb-3 w-[3.875rem] h-[3.01388rem]">
        <img
          src={image}
          alt={`Folder representing ${title}`}
          className="w-full h-full object-cover"
        />
      </div>

      <h2 className="typography-paragraph-small font-semibold text-text-300 mb-[1.86rem]">
        {title}
      </h2>

      <div className="w-full flex justify-between text-text-300 typography-paragraph-caption">
        <span>{size}</span>
        <span>{date}</span>
      </div>
    </Link>
  );
};

export default FolderCard;
