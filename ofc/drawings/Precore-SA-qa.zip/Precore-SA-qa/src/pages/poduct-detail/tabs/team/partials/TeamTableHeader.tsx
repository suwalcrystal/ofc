import { TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Employee } from "../interface/employee.interface";

// Table Header Component
interface TableHeaderProps {
  sortConfig: {
    key: keyof Employee;
    direction: "ascending" | "descending";
  } | null;
  requestSort: (key: keyof Employee) => void;
}

const TeamTableHeader: React.FC<TableHeaderProps> = ({
  sortConfig,
  requestSort,
}) => {
  const getSortDirectionIcon = (key: keyof Employee) => {
    if (!sortConfig || sortConfig.key !== key) return null;
    return sortConfig.direction === "ascending" ? (
      <ChevronUp className="ml-1 h-4 w-4" />
    ) : (
      <ChevronDown className="ml-1 h-4 w-4" />
    );
  };

  const headers = [
    { key: "name", label: "Name" },
    { key: "role", label: "Role" },
    { key: "department", label: "Assigned Department" },
    { key: null, label: "Contact Info" },
    { key: "reportingTo", label: "Reporting To" },
    { key: "startDate", label: "Assignment Start" },
    { key: "status", label: "Status" },
    { key: null, label: "Action" },
  ];

  return (
    <TableHeader>
      <TableRow className="bg-background-600 hover:bg-background-600">
        {headers.map((header) => (
          <TableHead
            key={header.label}
            onClick={
              header.key
                ? () => requestSort(header.key as keyof Employee)
                : undefined
            }
            className="typography-paragraph-body-sm p-4"
          >
            <div
              className={`flex items-center gap-1 ${header.key ? "cursor-pointer" : ""}`}
            >
              {header.label}
              {header.key && getSortDirectionIcon(header.key as keyof Employee)}
              {(header.label === "Assigned Department" ||
                header.label === "Reporting To") && (
                <ChevronDown className="ml-1 h-4 w-4" />
              )}
            </div>
          </TableHead>
        ))}
      </TableRow>
    </TableHeader>
  );
};

export default TeamTableHeader;
