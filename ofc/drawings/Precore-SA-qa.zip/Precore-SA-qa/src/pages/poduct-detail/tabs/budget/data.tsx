import { Flag } from "lucide-react";
import { BsCartPlus } from "react-icons/bs";
import { LuChartNoAxesCombined } from "react-icons/lu";
import { TbUsersGroup } from "react-icons/tb";

export const budgetStatusCards = [
  {
    title: "% Committed vs Budget",
    value: "74%",
    icon: <LuChartNoAxesCombined className="h-5 w-5 text-green-600" />,
    bgColor: "bg-green-50",
  },
  {
    title: "% Spent vs Budget",
    value: "88%",
    icon: <Flag className="h-5 w-5 text-blue-600" />,
    bgColor: "bg-blue-50",
  },
  {
    title: "Available Budget",
    value: "112M AED",
    icon: <BsCartPlus className="h-5 w-5 text-purple-600" />,
    bgColor: "bg-purple-50",
  },
  {
    title: "Overrun Warning",
    value: "On Track",
    icon: <TbUsersGroup className="h-5 w-5 text-amber-600" />,
    bgColor: "bg-amber-50",
  },
];
