import AddButton from "@/components/headerBottom/AddButton";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { IoMdArrowDropdown } from "react-icons/io";

const dateOptions = [
  "Newest First",
  "Oldest First",
  "Last 7 Days",
  "Last 30 Days",
];
const location = ["All Files", "PDF", "Word", "Excel", "PowerPoint"];

const activity = ["All Files", "PDF", "Word", "Excel", "PowerPoint"];

const FilterProgressGallery = () => {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div className="flex gap-2 items-center">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium">
                Date <IoMdArrowDropdown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0">
              {dateOptions.map((option, index) => (
                <DropdownMenuItem
                  key={index}
                  onClick={() => console.warn(option)}
                  className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                >
                  {option}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium">
                Location <IoMdArrowDropdown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="start"
              className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0"
            >
              {location.map((type, index) => (
                <DropdownMenuItem
                  key={index}
                  onClick={() => console.warn(type)}
                  className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                >
                  {type}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium">
                Activity <IoMdArrowDropdown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="start"
              className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0"
            >
              {activity.map((type, index) => (
                <DropdownMenuItem
                  key={index}
                  onClick={() => console.warn(type)}
                  className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                >
                  {type}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div>
          <AddButton title="Upload" />
        </div>
      </div>
    </div>
  );
};

export default FilterProgressGallery;
