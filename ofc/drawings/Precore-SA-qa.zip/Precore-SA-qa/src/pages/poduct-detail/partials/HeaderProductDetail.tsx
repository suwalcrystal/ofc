import { FaRegHourglass, FaRegUser } from "react-icons/fa6";
import { BsPinAngle } from "react-icons/bs";
import { TbTargetArrow } from "react-icons/tb";
import CustomToolTip from "@/components/CustomToolTip";
import { Badge } from "@/components/ui/badge";

const HeaderProductDetail = () => {
  return (
    <div className="top-0 z-40 sticky pt-[0.88rem] bg-section-bg-400">
      <div className=" flex items-center justify-between border-b-2 border-white pb-[0.88rem]">
        <div className="flex items-baseline gap-2">
          <div className="flex items-baseline gap-1 text-text-500 font-semibold">
            <h3 className="typography-h3 leading-[130%]">Marina Tower</h3>
            <span className="typography-paragraph-small leading-[120%]">
              #V6
            </span>
          </div>
          <div>
            <Badge
              variant="outline"
              className={`bg-green-50 text-green-500 hover:bg-green-100 border-0 px-2 py-1.5 rounded-full typography-paragraph-caption font-semibold`}
            >
              On Track
            </Badge>
          </div>
        </div>

        <div className="flex items-baseline gap-5">
          <div className="flex items-center gap-1 text-text-400 typography-paragraph-small font-medium">
            <FaRegUser />
            <CustomToolTip label="Salman Khan" value="Manager" />
          </div>
          <div className="flex items-center gap-1 text-text-400 typography-paragraph-small font-medium">
            <BsPinAngle />
            <p></p>
            <CustomToolTip label="21.04.2025" value="Start Date" />
          </div>
          <div className="flex items-center gap-1 text-text-400 typography-paragraph-small font-medium">
            <TbTargetArrow />
            <CustomToolTip label="21.04.2025" value="Target Completion Date" />
          </div>
          <div className="flex items-center gap-1 text-text-400 typography-paragraph-small font-medium">
            <FaRegHourglass />
            <CustomToolTip label="21.04.2025" value="Contract End Date" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeaderProductDetail;
