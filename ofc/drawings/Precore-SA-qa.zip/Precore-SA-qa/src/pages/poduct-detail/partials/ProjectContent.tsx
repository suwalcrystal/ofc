import { useSearchParams } from "react-router-dom";
import TabNavigation from "../../../components/TabNavigation";
import BudgetContent from "../tabs/budget/BudgetContent";
import DocumentsContent from "../tabs/documents/DocumentsContent";
import OverviewContent from "../tabs/overview/OverviewContent";
import ProcurementContent from "../tabs/procurement/ProcurementContent";
import ProgressGalleryContent from "../tabs/progressGalary/ProgressGalleryContent";
import ScheduleContent from "../tabs/schedule/ScheduleContent";
import TeamContent from "../tabs/team/TeamContent";

const tabName = {
  overview: "Overview",
  schedule: "Schedule",
  team: "Team",
  budget: "Budget",
  procurement: "Procurement",
  documents: "Documents",
  progressGallery: "Progress Gallery",
};

const ProjectContent = () => {
  const [params, setSearchParams] = useSearchParams();
  const tabValue = params.get("tab") || "";

  const activeTab = Object.values(tabName).includes(tabValue)
    ? tabValue
    : tabName.overview;

  const setActiveTab = (tab: string) => {
    setSearchParams({ tab });
  };

  const tabs = [
    { name: tabName.overview, current: activeTab === tabName.overview },
    { name: tabName.schedule, current: activeTab === tabName.schedule },
    { name: tabName.team, current: activeTab === tabName.team },
    { name: tabName.budget, current: activeTab === tabName.budget },
    { name: tabName.procurement, current: activeTab === tabName.procurement },
    { name: tabName.documents, current: activeTab === tabName.documents },
    {
      name: tabName.progressGallery,
      current: activeTab === tabName.progressGallery,
    },
  ];

  const handleTabChange = (tabName: string) => {
    setActiveTab(tabName);
  };

  const renderContent = () => {
    switch (activeTab) {
      case tabName.overview:
        return <OverviewContent />;
      case tabName.schedule:
        return <ScheduleContent />;
      case tabName.team:
        return <TeamContent />;
      case tabName.budget:
        return <BudgetContent />;
      case tabName.procurement:
        return <ProcurementContent />;
      case tabName.documents:
        return <DocumentsContent />;
      case tabName.progressGallery:
        return <ProgressGalleryContent />;
      default:
        return <OverviewContent />;
    }
  };

  return (
    <>
      <TabNavigation tabs={tabs} onTabChange={handleTabChange} />
      {renderContent()}
    </>
  );
};

export default ProjectContent;
