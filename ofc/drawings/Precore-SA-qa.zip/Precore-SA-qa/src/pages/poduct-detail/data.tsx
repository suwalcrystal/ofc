import { FileText, Flag } from "lucide-react";

import { BsCartPlus } from "react-icons/bs";
import { LuChartNoAxesCombined } from "react-icons/lu";
import { TbUsersGroup } from "react-icons/tb";

export const statusCards = [
  {
    title: "Overall Progress",
    value: "74%",
    icon: <LuChartNoAxesCombined className="h-5 w-5 text-green-600" />,
    bgColor: "bg-green-50",
  },
  {
    title: "Current Phase",
    value: "Fit-Out",
    icon: <Flag className="h-5 w-5 text-blue-600" />,
    bgColor: "bg-blue-50",
  },
  {
    title: "Procurement Progress",
    value: "78%",
    icon: <BsCartPlus className="h-5 w-5 text-purple-600" />,
    bgColor: "bg-purple-50",
  },
  {
    title: "Subcontractor Progress",
    value: "Good",
    icon: <TbUsersGroup className="h-5 w-5 text-amber-600" />,
    bgColor: "bg-amber-50",
  },
  {
    title: "Pending Task",
    value: "12",
    icon: <FileText className="h-5 w-5 text-gray-600" />,
    bgColor: "bg-gray-100",
  },
];
