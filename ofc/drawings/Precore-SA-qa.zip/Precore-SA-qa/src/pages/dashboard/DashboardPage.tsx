import { useDashboardStatus } from "./hooks/useDashboardStatus";
import BottomSection from "./partials/BottomSection/BottomSection";
import ChartSection from "./partials/ChartSection/ChartSection";
import DashboardCardStatus from "./partials/DashboardCardStatus";
import DataSection from "./partials/DataSection/DataSection";
import HeaderDashboard from "./partials/Header/HeaderDashboard";

const DashboardPage = () => {
  const { statusCards } = useDashboardStatus();

  return (
    <div>
      <HeaderDashboard />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 my-5">
        {statusCards.map((card, index) => (
          <DashboardCardStatus
            key={index}
            title={card.title}
            value={card.value}
            valueBottom={card.valueBottom}
            icon={card.icon}
            bgColor={card.bgColor}
          />
        ))}
      </div>
      <ChartSection />
      <DataSection />
      <BottomSection />
    </div>
  );
};

export default DashboardPage;
