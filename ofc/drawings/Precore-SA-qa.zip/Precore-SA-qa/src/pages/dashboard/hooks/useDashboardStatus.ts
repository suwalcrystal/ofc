import { useMemo } from "react";
import { dashboardStatusCards } from "../data";

export const useDashboardStatus = () => {
  const statusCards = useMemo(() => dashboardStatusCards, []);

  return {
    statusCards,
  };
};
