import { ProjectOverviewCardProps } from "../partials/ProjectOverview";

export type ProjectOverviewStatus = "success" | "danger" | "warning";

export const useProjectOverview = () => {
  const ProjectOverviewData: ProjectOverviewCardProps[] = [
    {
      name: "AI Barsha Fit-Out",
      status: "success",
      category: "MEP",
      percentage: 94,
      budget: 12400000,
      actual: 11800000,
    },
    {
      name: "Marina Tower",
      status: "danger",
      category: "Fit-Out",
      percentage: 50,
      budget: 12400000,
      actual: 9500000,
    },
    {
      name: "AI Barsha Fit-Out",
      status: "success",
      category: "MEP",
      percentage: 34,
      budget: 12400000,
      actual: 11800000,
    },
    {
      name: "Marina Tower",
      status: "danger",
      category: "Fit-Out",
      percentage: 40,
      budget: 12400000,
      actual: 9500000,
    },
    {
      name: "AI Barsha Fit-Out",
      status: "success",
      category: "MEP",
      percentage: 64,
      budget: 12400000,
      actual: 11800000,
    },
    {
      name: "Marina Tower",
      status: "danger",
      category: "Fit-Out",
      percentage: 40,
      budget: 12400000,
      actual: 9500000,
    },
    {
      name: "AI Barsha Fit-Out",
      status: "success",
      category: "MEP",
      percentage: 94,
      budget: 12400000,
      actual: 11800000,
    },
    {
      name: "Marina Tower",
      status: "danger",
      category: "Fit-Out",
      percentage: 20,
      budget: 12400000,
      actual: 9500000,
    },
  ];

  return { ProjectOverviewData };
};
