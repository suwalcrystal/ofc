import arrowIcon from "@/assets/icons/arrow-growth-24-regular.svg";
import invoiceIcon from "@/assets/icons/invoice copy.svg";
import peopleIcon from "@/assets/icons/people.svg";
import projectIcon from "@/assets/icons/projectNo.svg";
import walletIcon from "@/assets/icons/wallet-linear.svg";
import { ArrowDown } from "lucide-react";

export const dashboardStatusCards = [
  {
    title: "Estimated Profit %",
    value: "14.3%",
    valueBottom: (
      <p className="flex items-center gap-1 text-text-400 typography-paragraph-caption">
        <ArrowDown className="size-[13px] text-error" />
        <span className="text-error">Below Target (20%)</span>
      </p>
    ),
    icon: <img src={arrowIcon} alt="invoice-icon" className="h-5 w-5 " />,
    bgColor: "bg-green-50",
  },
  {
    title: "Total Projects",
    value: "9",
    valueBottom: (
      <p className="text-text-400 typography-paragraph-caption">
        3 New This Month
      </p>
    ),
    icon: <img src={projectIcon} alt="invoice-icon" className="h-5 w-5 " />,
    bgColor: "bg-[#E1ECFF]",
  },
  {
    title: "Total Workers ",
    value: "176",
    valueBottom: (
      <p className="text-text-400 typography-paragraph-caption">
        Across 4 Sites
      </p>
    ),
    icon: <img src={peopleIcon} alt="invoice-icon" className="h-5 w-5 " />,
    bgColor: "bg-[#FFF8EB]",
  },
  {
    title: "Invoices Due ",
    value: "7 Invoices",
    valueBottom: (
      <p className="text-error typography-paragraph-caption">Worth NPR 12.4M</p>
    ),
    icon: <img src={invoiceIcon} alt="invoice-icon" className="h-5 w-5" />,
    bgColor: "bg-[#F5E2FF]",
  },
  {
    title: "Budget vs Spent",
    value: "87M / 112M",
    valueBottom: (
      <p className="text-text-400 typography-paragraph-caption">Spent: 77.7%</p>
    ),
    icon: <img src={walletIcon} alt="invoice-icon" className="h-5 w-5 " />,
    bgColor: "bg-[#FFF5E8]",
  },
];

export interface IRecentPOSData {
  id: string;
  status: "Approved" | "Pending" | "Rejected";
  amount: number;
  date: string; // ISO date string
  linkedPO: string;
}

export const RecentPOSData: IRecentPOSData[] = [
  {
    id: "#790955",
    status: "Pending",
    amount: 1200.5,
    date: "2025-05-10",
    linkedPO: "PO-001",
  },
  {
    id: "#790955",
    status: "Approved",
    amount: 4500,
    date: "2025-04-22",
    linkedPO: "PO-002",
  },
  {
    id: "#790955",
    status: "Approved",
    amount: 980.75,
    date: "2025-05-01",
    linkedPO: "PO-003",
  },
];
