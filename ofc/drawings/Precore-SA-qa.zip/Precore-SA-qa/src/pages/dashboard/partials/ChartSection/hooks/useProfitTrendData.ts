import { useState, useMemo } from "react";

interface ProfitDataPoint {
  name: string;
  profit: number;
}

const dataMap: Record<string, ProfitDataPoint[]> = {
  "3 Mon": [
    { name: "May", profit: 45 },
    { name: "Jun", profit: 55 },
    { name: "Jul", profit: 65 },
  ],
  "6 Mon": [
    { name: "Jan", profit: 55 },
    { name: "Feb", profit: 60 },
    { name: "Mar", profit: 40 },
    { name: "Apr", profit: 95 },
    { name: "Jun", profit: 55 },
    { name: "Jul", profit: 65 },
  ],
  "1 Year": [
    { name: "Jan", profit: 40 },
    { name: "Feb", profit: 60 },
    { name: "Mar", profit: 50 },
    { name: "Apr", profit: 95 },
    { name: "May", profit: 70 },
    { name: "Jun", profit: 55 },
    { name: "Jul", profit: 65 },
    { name: "Aug", profit: 75 },
    { name: "Sep", profit: 85 },
    { name: "Oct", profit: 45 },
    { name: "Nov", profit: 65 },
    { name: "Dec", profit: 90 },
  ],
};

export const useProfitTrendData = () => {
  const [timeframe, setTimeframe] = useState<"3 Mon" | "6 Mon" | "1 Year">(
    "6 Mon"
  );

  const data = useMemo(() => dataMap[timeframe], [timeframe]);

  return {
    timeframe,
    setTimeframe,
    timeframes: Object.keys(dataMap) as Array<"3 Mon" | "6 Mon" | "1 Year">,
    data,
    netProfit: "40%",
  };
};
