import CashFlowChart from "./CashFlowChart";
import LaborCostChart from "./LaborCostChart";
import { default as ProfitTrendChart } from "./ProfitTrendChart";
import ProjectOverview from "../ProjectOverview";
import ProjectWiseChart from "./ProjectWiseChart";

const ChartSection = () => {
  return (
    <div className="grid grid-cols-3 gap-5">
      <div className="col-span-2 grid grid-cols-2 gap-5">
        <ProfitTrendChart />
        <CashFlowChart />
        <ProjectWiseChart />
        <LaborCostChart />
      </div>

      <div>
        <ProjectOverview />
      </div>
    </div>
  );
};

export default ChartSection;
