"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { IoMdArrowDropdown } from "react-icons/io";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type TooltipProps,
} from "recharts";
import { useCashFlowData } from "./hooks/useCashFlowData";

const CashFlowChart = () => {
  const { timeframe, setTimeframe, timeframes, data, netFlow } =
    useCashFlowData();

  const CustomTooltip = ({ active, payload }: TooltipProps<number, string>) => {
    if (active && payload?.length) {
      return (
        <div className="bg-white p-2 border rounded shadow-sm">
          <p className="font-medium">{`Cash Flow: ${Math.abs(payload[0].value ?? 0)} M`}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="base-card">
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <h2 className="typography-paragraph-small font-semibold text-text-500">
            Cash Flow
          </h2>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="typography-paragraph-caption text-text-400 font-medium"
              >
                {timeframe} <IoMdArrowDropdown className="h-4 w-4 " />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {timeframes.map((label) => (
                <DropdownMenuItem
                  key={label}
                  onClick={() => setTimeframe(label)}
                >
                  {label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="relative mb-2">
          <ResponsiveContainer width="100%" aspect={2.5}>
            <BarChart
              data={data}
              margin={{ top: 5, right: 5, left: -10, bottom: 5 }}
              barGap={8}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#f0f0f0"
              />
              <XAxis
                dataKey="month"
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: "#666" }}
                padding={{ left: 20, right: 20 }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: "#666" }}
                tickFormatter={(value) => `${value} M`}
                domain={[-60, 100]}
                ticks={[-60, -30, 0, 30, 60, 90]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="value"
                radius={[4, 4, 0, 0]}
                barSize={24}
                isAnimationActive={false}
              >
                {data.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.value >= 0 ? "#63b192" : "#E2BD80"}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="typography-paragraph-caption text-text-400 px-4">
          Net Flow This Month: {netFlow}
        </div>
      </CardContent>
    </Card>
  );
};

export default CashFlowChart;
