export interface DeliveryStatusItem {
  name: string;
  status: "Alert" | "Warning";
}

export const useAlertsWarnings = () => {
  const alertsWarnings: DeliveryStatusItem[] = [
    {
      name: "Project P2 has exceeded its budget by 12%",
      status: "Warning",
    },
    {
      name: "Delay in delivery: Cement Type 44",
      status: "Alert",
    },
    {
      name: "Invoice #789103 is overdue by 10 days",
      status: "Warning",
    },
    {
      name: "Project P2 has exceeded its budget by 12%",
      status: "Alert",
    },
    {
      name: "Invoice #789103 is overdue by 10 days",
      status: "Warning",
    },
    {
      name: "Project P2 has exceeded its budget by 12%",
      status: "Alert",
    },
  ];

  return { alertsWarnings };
};
