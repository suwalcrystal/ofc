// hooks/useProcurementSnapshot.ts
export interface DeliveryStatusItem {
  name: string;
  variant: string;
  status: string;
  statusColor: string;
  bgColor: string;
}

export interface SpendItem {
  name: string;
  value: number;
}

export interface ProcurementSnapshotData {
  deliveryStatusData: DeliveryStatusItem[];
  spendItems: SpendItem[];
  pendingPOApprovals: number;
}

export const useProcurementSnapshot = () => {
  const data: ProcurementSnapshotData = {
    deliveryStatusData: [
      {
        name: "Cement",
        variant: "Type 33",
        status: "Delayed",
        statusColor: "text-error",
        bgColor: "bg-error-bg",
      },
      {
        name: "Iron Rods",
        variant: "12 mm",
        status: "No Delivery",
        statusColor: "text-warning",
        bgColor: "bg-warning-bg",
      },
      {
        name: "Cement",
        variant: "Type 44",
        status: "Delayed",
        statusColor: "text-error",
        bgColor: "bg-error-bg",
      },
    ],
    spendItems: [
      { name: "Cement", value: 90 },
      { name: "Steel", value: 75 },
      { name: "Tiles", value: 60 },
      { name: "Fixtures", value: 50 },
      { name: "Sand", value: 40 },
    ],
    pendingPOApprovals: 12,
  };

  const maxValue = Math.max(...data.spendItems.map((item) => item.value));

  return {
    ...data,
    maxValue,
  };
};
