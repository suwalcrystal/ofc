import { useState, useMemo } from "react";

interface CashFlowDataPoint {
  month: string;
  value: number;
}

const dataMap: Record<string, CashFlowDataPoint[]> = {
  "3 Mon": [
    { month: "May", value: 20 },
    { month: "Jun", value: 70 },
    { month: "Jul", value: -10 },
  ],
  "6 Mon": [
    { month: "Jan", value: 50 },
    { month: "Feb", value: -15 },
    { month: "Mar", value: 76 },
    { month: "Apr", value: 60 },
    { month: "Jun", value: 70 },
    { month: "Jul", value: -10 },
  ],
  "1 Year": [
    { month: "Jan", value: 30 },
    { month: "Feb", value: -10 },
    { month: "Mar", value: 50 },
    { month: "Apr", value: 60 },
    { month: "May", value: 40 },
    { month: "Jun", value: 70 },
    { month: "Jul", value: -10 },
    { month: "Aug", value: 35 },
    { month: "Sep", value: 65 },
    { month: "Oct", value: 80 },
    { month: "Nov", value: 45 },
    { month: "Dec", value: 90 },
  ],
};

export const useCashFlowData = () => {
  const [timeframe, setTimeframe] = useState<"3 Mon" | "6 Mon" | "1 Year">(
    "6 Mon"
  );

  const data = useMemo(() => dataMap[timeframe], [timeframe]);

  return {
    timeframe,
    setTimeframe,
    timeframes: Object.keys(dataMap) as Array<"3 Mon" | "6 Mon" | "1 Year">,
    data,
    netFlow: "AED 43 M", // This can be computed or fetched if needed
  };
};
