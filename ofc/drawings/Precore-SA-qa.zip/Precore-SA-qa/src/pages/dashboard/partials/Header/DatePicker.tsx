import * as React from "react";
import { format } from "date-fns";
import { DateRange } from "react-day-picker";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";

import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

import calendarIcon from "@/assets/icons/calendar.svg";

export function DatePickerWithRange({
  className,
}: React.HTMLAttributes<HTMLDivElement>) {
  const [date, setDate] = React.useState<DateRange>({
    from: undefined,
    to: undefined,
  });

  return (
    <div className={cn("flex gap-2.5", className)}>
      {/* From Date */}
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant={"outline"}
            className={cn(
              "justify-start text-left font-normal rounded-full text-text-300 typography-paragraph-small cursor-pointer"
            )}
          >
            {date.from ? format(date.from, "LLL dd, y") : "From"}
            <div className="size-4">
              <img
                src={calendarIcon}
                alt="calendar-icon"
                className="size-full object-cover"
              />
            </div>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={date.from}
            onSelect={(from) =>
              setDate((prev) => ({
                from: from ?? prev.from,
                to: prev.to,
              }))
            }
            defaultMonth={date.from}
            initialFocus
          />
        </PopoverContent>
      </Popover>

      {/* To Date */}
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant={"outline"}
            className={cn(
              "justify-start text-left font-normal rounded-full text-text-300 typography-paragraph-small cursor-pointer"
            )}
          >
            {date.to ? format(date.to, "LLL dd, y") : "To"}
            <div className="size-4">
              <img
                src={calendarIcon}
                alt="calendar-icon"
                className="size-full object-cover"
              />
            </div>{" "}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={date.to}
            onSelect={(to) =>
              setDate((prev) => ({
                from: prev.from,
                to: to ?? prev.to,
              }))
            }
            defaultMonth={date.to}
            initialFocus
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
