import AddButton from "@/components/headerBottom/AddButton";
import Search from "@/components/Search";
import { DatePickerWithRange } from "./DatePicker";

const HeaderDashboard = () => {
  return (
    <div className="top-0 z-40 sticky pt-[0.88rem] flex items-center justify-between border-b-2 border-white pb-[0.88rem] bg-section-bg-400 ">
      <div className="flex items-center gap-[1.25rem]">
        <h3 className="text-text-500 typography-h3 font-semibold">Dashboard</h3>
        <Search />
      </div>
      <div className="flex gap-2.5 items-center">
        <DatePickerWithRange />
        <AddButton title="Create" />
      </div>
    </div>
  );
};

export default HeaderDashboard;
