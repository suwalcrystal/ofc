import { Card, CardContent } from "@/components/ui/card";
import { FaCircleCheck } from "react-icons/fa6";
import { useMyTasks } from "./hooks/useMyTasks";

const MyTasks = () => {
  const { myTasks } = useMyTasks();

  return (
    <div className="h-full">
      <Card className="base-card">
        <CardContent>
          <h2 className="typography-paragraph-small font-semibold text-text-500 mb-[0.75rem]">
            My Tasks
          </h2>

          <div className="space-y-[0.88rem]">
            {myTasks.map((item, index) => {
              const isPending = item.status === "Pending";

              return (
                <div key={index} className="flex items-center justify-between">
                  <p className="text-text-400 typography-paragraph-small font-medium">
                    {item.name}
                  </p>
                  {isPending ? (
                    <div className="bg-text-50 text-text-300 border-[0.2px] border-boarder-300 shadow-[0px_4px_4px_0px_rgba(228,232,236,0.12)] px-[0.62rem] py-[0.25rem] rounded-full typography-paragraph-caption font-medium">
                      Pending
                    </div>
                  ) : (
                    <FaCircleCheck className="text-green-500 text-[1.25rem]" />
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MyTasks;
