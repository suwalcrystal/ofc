import {
  ProjectOverviewStatus,
  useProjectOverview,
} from "../hooks/useProjectOverview";
import PropertyStatusCard from "./PropertyStatusCard";

export interface ProjectOverviewCardProps {
  name: string;
  status: ProjectOverviewStatus;
  category: string;
  percentage: number;
  budget: number;
  actual: number;
  currency?: string;
}

const ProjectOverview = () => {
  const { ProjectOverviewData } = useProjectOverview();

  return (
    <div className="h-full">
      <div className="rounded-[0.5rem] border border-boarder-300 bg-white shadow-card p-5 h-full">
        <div className="flex items-center justify-between pb-[0.87rem]">
          <h2 className="text-text-500 typography-paragraph-small font-semibold ">
            Project Overview
          </h2>
          <button className="text-blue cursor-pointer typography-paragraph-caption font-semibold">
            View All
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {ProjectOverviewData.map(
            (property: ProjectOverviewCardProps, index) => (
              <PropertyStatusCard
                key={index}
                name={property.name}
                status={property.status}
                category={property.category}
                percentage={property.percentage}
                budget={property.budget}
                actual={property.actual}
                currency={property.currency || "AED"}
              />
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default ProjectOverview;
