import { useState, useMemo } from "react";

export interface ProjectSpendingDataPoint {
  name: string;
  budget: number;
  spent: number;
}

const dataMap: Record<string, ProjectSpendingDataPoint[]> = {
  Recent: [
    { name: "P1", budget: 65, spent: 75 },
    { name: "P2", budget: 45, spent: 30 },
    { name: "P3", budget: 75, spent: 60 },
    { name: "P4", budget: 40, spent: 50 },
    { name: "P5", budget: 80, spent: 70 },
    { name: "P6", budget: 75, spent: 60 },
  ],
  "Last Month": [
    { name: "P1", budget: 60, spent: 65 },
    { name: "P2", budget: 50, spent: 35 },
    { name: "P3", budget: 70, spent: 58 },
    { name: "P4", budget: 42, spent: 55 },
    { name: "P5", budget: 78, spent: 72 },
    { name: "P6", budget: 70, spent: 68 },
  ],
  "Last Quarter": [
    { name: "P1", budget: 68, spent: 70 },
    { name: "P2", budget: 48, spent: 42 },
    { name: "P3", budget: 74, spent: 64 },
    { name: "P4", budget: 43, spent: 52 },
    { name: "P5", budget: 79, spent: 71 },
    { name: "P6", budget: 73, spent: 66 },
  ],
  "Last Year": [
    { name: "P1", budget: 70, spent: 78 },
    { name: "P2", budget: 52, spent: 38 },
    { name: "P3", budget: 76, spent: 68 },
    { name: "P4", budget: 45, spent: 58 },
    { name: "P5", budget: 82, spent: 74 },
    { name: "P6", budget: 77, spent: 69 },
  ],
};

export const useProjectSpendingData = () => {
  const [timeframe, setTimeframe] = useState<keyof typeof dataMap>("Recent");

  const data = useMemo(() => dataMap[timeframe], [timeframe]);

  return {
    timeframe,
    setTimeframe,
    timeframes: Object.keys(dataMap) as (keyof typeof dataMap)[],
    data,
  };
};
