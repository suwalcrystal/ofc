import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { useUpcomingMilestonesDashboard } from "./hooks/useUpcomingMilestonesDashboard";

const UpcomingMilestonesDashboard = () => {
  const { upcomingDashboard } = useUpcomingMilestonesDashboard();

  return (
    <div className="h-full">
      <Card className="base-card">
        <CardContent>
          <h2 className="typography-paragraph-small font-semibold text-text-500 mb-[0.75rem]">
            Upcoming Milestones
          </h2>

          <div className="space-y-[0.88rem]">
            {upcomingDashboard.map((item, index) => {
              const isDelayed = item.status === "Delayed";
              const bgColor = isDelayed ? "bg-brown-bg" : "bg-section-bg-300";
              const statusColor = isDelayed ? "text-brown" : "text-text-500";

              return (
                <div key={index} className="flex items-center justify-between">
                  <div className="text-text-400 typography-paragraph-small font-medium">
                    {item.name}{" "}
                    <Link
                      to="#"
                      className="text-blue typography-paragraph-caption font-medium hover:underline"
                    >
                      ({item.variant})
                    </Link>
                  </div>
                  <div
                    className={`${bgColor} ${statusColor} border-[0.2px] border-boarder-300 shadow-[0px_4px_4px_0px_rgba(228,232,236,0.12)] px-[0.62rem] py-[0.25rem] rounded-full typography-paragraph-caption font-medium`}
                  >
                    {item.status}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UpcomingMilestonesDashboard;
