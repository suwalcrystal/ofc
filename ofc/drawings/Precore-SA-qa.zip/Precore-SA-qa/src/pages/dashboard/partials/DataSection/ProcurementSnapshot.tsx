import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { useProcurementSnapshot } from "./hooks/useProcurementSnapshot";

const ProcurementSnapshot = () => {
  const { deliveryStatusData, spendItems, maxValue, pendingPOApprovals } =
    useProcurementSnapshot();

  return (
    <div>
      <Card className="base-card">
        <CardContent>
          <h2 className="typography-paragraph-small font-semibold text-text-500 mb-[0.75rem]">
            Procurement Snapshot
          </h2>

          <div className="grid grid-cols-2 gap-[0.75rem]">
            {/* Pending PO Approvals */}
            <div className="flex flex-col gap-[0.75rem]">
              <div className="rounded-[0.5rem] border border-boarder-300 bg-section-bg-100 p-[0.88rem]">
                <p className="text-text-500 typography-paragraph-small font-medium">
                  Pending PO Approvals
                </p>
                <div className="flex justify-between items-center pt-[0.31rem]">
                  <p className="typography-paragraph-large font-semibold text-text-500">
                    {pendingPOApprovals}
                  </p>
                  <button className="bg-green-500 py-[0.25rem] px-[0.62rem] rounded-full typography-paragraph-caption font-semibold text-white hover:bg-green-700">
                    Review Now
                  </button>
                </div>
              </div>

              {/* Critical Material Delays */}
              <div className="rounded-[0.5rem] border border-boarder-300 bg-section-bg-100 p-[0.88rem]">
                <p className="text-text-500 typography-paragraph-small font-medium pb-[0.75rem]">
                  Critical Material Delays
                </p>

                <div className="space-y-2">
                  {deliveryStatusData.map((item, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between"
                    >
                      <div className="text-text-400 typography-paragraph-small font-medium">
                        {item.name}{" "}
                        <Link
                          to="#"
                          className="text-blue typography-paragraph-caption font-medium hover:underline"
                        >
                          {item.variant}
                        </Link>
                      </div>
                      <div
                        className={`${item.bgColor} ${item.statusColor} px-[0.62rem] py-[0.25rem] rounded-full typography-paragraph-caption font-medium`}
                      >
                        {item.status}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Top 5 Spend Items */}
            <div className="rounded-[0.5rem] border border-boarder-300 bg-section-bg-100 p-[0.88rem]">
              <p className="text-text-500 typography-paragraph-small font-medium pb-[0.75rem]">
                Top 5 Spend Items
              </p>
              <div className="space-y-4">
                {spendItems.map((item) => (
                  <div
                    key={item.name}
                    className="grid grid-cols-3 items-center"
                  >
                    <div className="w-20 text-text-400 typography-paragraph-small font-medium">
                      {item.name}
                    </div>
                    <div
                      className="col-span-2 h-3 bg-green-400 rounded-[0.125rem] rounded-b-none rounded-l-none"
                      style={{ width: `${(item.value / maxValue) * 100}%` }}
                    ></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProcurementSnapshot;
