import { Progress } from "@/components/ui/progress";
import { Circle } from "lucide-react";
import { ProjectOverviewCardProps } from "./ProjectOverview";

const PropertyStatusCard = ({
  name,
  status,
  category,
  percentage,
  budget,
  actual,
  currency = "AED",
}: ProjectOverviewCardProps) => {
  const statusTextColor = {
    success: "text-green-500",
    danger: "text-error",
    warning: "text-amber-500",
  }[status];

  const formatCurrency = (value: number) => {
    if (value >= 1_000_000) {
      return `${currency} ${(value / 1_000_000).toFixed(1)} M`;
    }
    return `${currency} ${value.toLocaleString()}`;
  };

  return (
    <div className="bg-section-bg-50 rounded-[0.5rem] p-[0.88rem] border border-boarder-300">
      <div className="flex items-center gap-1.5 mb-[0.62rem]">
        <Circle className={`h-3 w-3 fill-current ${statusTextColor}`} />
        <h3 className="text-text-500 typography-paragraph-small font-medium">
          {name}
        </h3>
      </div>

      <div className="flex justify-between items-center text-text-300 typography-paragraph-caption font-medium">
        <span>{category}</span>
        <span>{percentage}%</span>
      </div>

      <div className="my-[0.38rem]">
        <Progress
          value={percentage}
          className="h-2 w-full rounded-md backdrop-blur-3xl *:bg-green-400"
        />
      </div>

      <div className="flex justify-between items-center">
        <span className="text-text-300 typography-paragraph-caption font-medium">
          {formatCurrency(budget)}
        </span>
        <span
          className={`typography-paragraph-caption font-medium text-error `}
        >
          {formatCurrency(actual)}
        </span>
      </div>
    </div>
  );
};

export default PropertyStatusCard;
