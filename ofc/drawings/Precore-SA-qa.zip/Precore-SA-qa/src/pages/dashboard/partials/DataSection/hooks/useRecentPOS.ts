import { useMemo } from "react";

export interface IRecentPOSData {
  id: string;
  linkedPO: string;
  status: "Approved" | "Pending" | "Rejected";
  amount: number;
  date: string; // ISO date string
}

export const useRecentPOS = (initialData: IRecentPOSData[]) => {
  const columns = useMemo(
    () => ["PO Number", "Status", "Amount", "Date", "Action"],
    []
  );

  return {
    columns,
    data: initialData,
  };
};
