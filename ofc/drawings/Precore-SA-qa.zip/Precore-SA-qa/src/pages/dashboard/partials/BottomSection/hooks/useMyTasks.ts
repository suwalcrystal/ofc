export interface DeliveryStatusItem {
  name: string;
  status: "Pending" | "Completed";
}

export const useMyTasks = () => {
  const myTasks: DeliveryStatusItem[] = [
    {
      name: "Review PO #788945",
      status: "Completed",
    },
    {
      name: "Send Budget to Finance ",
      status: "Pending",
    },
    {
      name: "Follow up on MEP status",
      status: "Completed",
    },
    {
      name: "Review PO #788945",
      status: "Pending",
    },
    {
      name: "Send Budget to Finance ",
      status: "Pending",
    },
  ];

  return { myTasks };
};
