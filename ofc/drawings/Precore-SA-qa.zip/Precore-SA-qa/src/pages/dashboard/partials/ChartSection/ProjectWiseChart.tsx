"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { IoMdArrowDropdown } from "react-icons/io";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type TooltipProps,
} from "recharts";
import { useProjectSpendingData } from "./hooks/useProjectSpendingData";

const ProjectWiseChart = () => {
  const { timeframe, setTimeframe, timeframes, data } =
    useProjectSpendingData();

  const CustomTooltip = ({
    active,
    payload,
    label,
  }: TooltipProps<number, string>) => {
    if (active && payload?.length) {
      return (
        <div className="bg-white p-2 border rounded shadow-sm">
          <p className="font-medium">{label}</p>
          <p className="text-sm text-gray-600">Budget: {payload[0].value}%</p>
          <p className="text-sm text-gray-600">Spent: {payload[1].value}%</p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="base-card">
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <h2 className="typography-paragraph-small font-semibold text-text-500">
            Project-wise Spending
          </h2>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="typography-paragraph-caption text-text-400 font-medium"
              >
                {timeframe} <IoMdArrowDropdown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {timeframes.map((label) => (
                <DropdownMenuItem
                  key={label}
                  onClick={() => setTimeframe(label)}
                >
                  {label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="relative">
          <ResponsiveContainer width="100%" aspect={2.5}>
            <BarChart
              data={data}
              margin={{ top: 5, right: 5, left: -26, bottom: 5 }}
              barGap={8}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#f0f0f0"
              />
              <XAxis
                dataKey="name"
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: "#666" }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: "#666" }}
                tickFormatter={(value) => `${value}%`}
                domain={[0, 100]}
                interval={0}
                ticks={[0, 20, 40, 60, 80, 100]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="budget"
                fill="#d9dbdd"
                radius={[14, 14, 0, 0]}
                barSize={14}
              />
              <Bar
                dataKey="spent"
                fill="#63b192"
                radius={[14, 14, 0, 0]}
                barSize={14}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-2.5 px-2">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-section-bg-600 mr-1"></div>
            <span className="typography-paragraph-caption text-text-400">
              Budget
            </span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-300 mr-1"></div>
            <span className="typography-paragraph-caption text-text-400">
              Spent
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProjectWiseChart;
