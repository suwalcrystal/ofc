import { RecentPOSData } from "../../data";
import ProcurementSnapshot from "./ProcurementSnapshot";
import RecentPOSTable from "./RecentPOSTable";

const DataSection = () => {
  return (
    <div className="my-6">
      <div className="flex gap-5">
        <div className="w-full">
          <ProcurementSnapshot />
        </div>
        <div className="w-full">
          <RecentPOSTable data={RecentPOSData} />
        </div>
      </div>
    </div>
  );
};

export default DataSection;
