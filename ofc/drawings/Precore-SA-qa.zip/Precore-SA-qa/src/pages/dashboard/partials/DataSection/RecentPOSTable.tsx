import { Check, Eye, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { IRecentPOSData, useRecentPOS } from "./hooks/useRecentPOS";

interface RecentPOSTableProps {
  data: IRecentPOSData[];
}

const RecentPOSTable: React.FC<RecentPOSTableProps> = ({ data }) => {
  const { columns } = useRecentPOS(data);

  const renderHeader = () => (
    <div className="grid grid-cols-5 bg-section-bg-500 p-4 typography-paragraph-caption font-semibold text-text-500 ">
      {columns.map((column, index) => (
        <div key={index} className="truncate flex items-center">
          {column}
        </div>
      ))}
    </div>
  );

  const renderRow = (item: IRecentPOSData) => (
    <div key={item.id} className="grid grid-cols-5 p-4 items-center">
      {/* PO Number */}
      <div className="typography-paragraph-caption text-text-500 truncate">
        {item.linkedPO || "PO-008"}
      </div>

      {/* Status */}
      <div>
        <span
          className={`rounded-full px-3 py-1 typography-paragraph-caption font-medium ${
            item.status === "Approved"
              ? "bg-green-50 text-green-500"
              : item.status === "Pending"
                ? "bg-warning-bg text-warning"
                : "bg-text-50 text-text-500"
          }`}
        >
          {item.status}
        </span>
      </div>

      {/* Amount */}
      <div className="typography-paragraph-caption text-text-500 truncate">
        ${item.amount?.toFixed(2) || "0.00"}
      </div>

      {/* Date */}
      <div className="typography-paragraph-caption text-text-500 truncate">
        {item.date ? new Date(item.date).toLocaleDateString() : "—"}
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-2">
        <button className="text-gray-500 hover:text-gray-700" aria-label="View">
          <Eye className="h-4.5 w-4.5" />
        </button>
        <button
          className="text-green-500 hover:text-green-700"
          aria-label="Approve"
        >
          <Check className="h-4.5 w-4.5" />
        </button>
        <button className="text-red-500 hover:text-red-700" aria-label="Reject">
          <X className="h-4.5 w-4.5" />
        </button>
      </div>
    </div>
  );

  return (
    <Card className="base-card">
      <CardContent>
        <h2 className="typography-paragraph-small font-semibold text-text-500 mb-[0.75rem]">
          Recent POs Raised
        </h2>
        <div className="overflow-hidden">
          {renderHeader()}
          {data.length > 0 ? (
            data.map((item) => renderRow(item))
          ) : (
            <div className="p-4 text-center text-gray-500">
              No purchase requests found
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentPOSTable;
