import AlertsWarnings from "./AlertsWarnings";
import MyTasks from "./MyTasks";
import UpcomingMilestonesDashboard from "./UpcomingMilestonesDashboard";

const BottomSection = () => {
  return (
    <div className="grid grid-cols-3 gap-6 mb-[2.44rem]  items-stretch">
      <div className="h-full">
        <UpcomingMilestonesDashboard />
      </div>
      <div className="h-full">
        <MyTasks />
      </div>
      <div className="h-full">
        <AlertsWarnings />
      </div>
    </div>
  );
};

export default BottomSection;
