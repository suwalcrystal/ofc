"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { IoMdArrowDropdown } from "react-icons/io";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ReferenceDot,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  type TooltipProps,
} from "recharts";
import { useLaborCostData } from "./hooks/useLaborCostData";

const LaborCostChart = () => {
  const { timeframe, setTimeframe, timeframes, data, netLaborCost } =
    useLaborCostData();

  const CustomTooltip = ({ active, payload }: TooltipProps<number, string>) => {
    if (active && payload?.length) {
      return (
        <div className="bg-white p-2 border rounded shadow-sm">
          <p className="font-medium">{`${payload[0].value}M`}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="base-card">
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <h2 className="typography-paragraph-small font-semibold text-text-500">
            Labor Cost
          </h2>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="typography-paragraph-caption text-text-400 font-medium"
              >
                {timeframe} <IoMdArrowDropdown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {timeframes.map((label) => (
                <DropdownMenuItem
                  key={label}
                  onClick={() => setTimeframe(label)}
                >
                  {label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="relative mb-2">
          <ResponsiveContainer width="100%" aspect={2.5}>
            <AreaChart
              data={data}
              margin={{ top: 5, right: 5, left: -26, bottom: 5 }}
            >
              <defs>
                <linearGradient id="profitGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4EB89D" stopOpacity={0.6} />
                  <stop offset="50%" stopColor="#4EB89D" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="#4EB89D" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                vertical={false}
                stroke="#f0f0f0"
              />
              <XAxis
                dataKey="name"
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: "#666" }}
                dy={10}
              />
              <YAxis
                tickFormatter={(tick) => `${tick}M`}
                domain={[0, 50]}
                ticks={[0, 10, 20, 30, 40, 50]}
                axisLine={false}
                tickLine={false}
                interval={0}
                tick={{ fontSize: 12, fill: "#666" }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="profit"
                stroke="#4EB89D"
                strokeWidth={2.5}
                fill="url(#profitGradient)"
                dot={false}
                activeDot={{
                  r: 6,
                  fill: "#4EB89D",
                  stroke: "#fff",
                  strokeWidth: 2,
                }}
              />
              <ReferenceDot
                x="Apr"
                y={50}
                r={6}
                fill="#fff"
                stroke="#4EB89D"
                strokeWidth={2}
              />
              <ReferenceLine
                x="Apr"
                y={50}
                stroke="#4EB89D"
                strokeWidth={2}
                strokeOpacity={0.3}
                segment={[{ y: 50 }, { y: 0 }]}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="typography-paragraph-caption text-text-400 px-4">
          Net Labor Cost: {netLaborCost}
        </div>
      </CardContent>
    </Card>
  );
};

export default LaborCostChart;
