export interface DeliveryStatusItem {
  name: string;
  variant: string;
  status: string;
}

export const useUpcomingMilestonesDashboard = () => {
  const upcomingDashboard: DeliveryStatusItem[] = [
    {
      name: "MEP Design Completion",
      variant: "AL Barsha",
      status: "Due: Apr 28",
    },
    {
      name: "Material Delivery",
      variant: "Marina Tower",
      status: "Delayed",
    },
    {
      name: "Site Inspection",
      variant: "Project 3",
      status: "Due: Apr 28",
    },
    {
      name: "Material Delivery",
      variant: "Project 4",
      status: "Delayed",
    },
    {
      name: "Material Delivery",
      variant: "Project 5",
      status: "Delayed",
    },
  ];

  return { upcomingDashboard };
};
