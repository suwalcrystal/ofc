import { useState, useMemo } from "react";

interface LaborCostDataPoint {
  name: string;
  profit: number;
}

const dataMap: Record<string, LaborCostDataPoint[]> = {
  "3 Mon": [
    { name: "May", profit: 28 },
    { name: "Jun", profit: 29 },
    { name: "Jul", profit: 34 },
  ],
  "6 Mon": [
    { name: "Jan", profit: 29 },
    { name: "Feb", profit: 32 },
    { name: "Mar", profit: 21 },
    { name: "Apr", profit: 50 },
    { name: "Jun", profit: 29 },
    { name: "Jul", profit: 34 },
  ],
  "1 Year": [
    { name: "Jan", profit: 29 },
    { name: "Feb", profit: 32 },
    { name: "Mar", profit: 21 },
    { name: "Apr", profit: 50 },
    { name: "May", profit: 28 },
    { name: "Jun", profit: 29 },
    { name: "Jul", profit: 34 },
    { name: "Aug", profit: 26 },
    { name: "Sep", profit: 38 },
    { name: "Oct", profit: 42 },
    { name: "Nov", profit: 30 },
    { name: "Dec", profit: 48 },
  ],
};

export const useLaborCostData = () => {
  const [timeframe, setTimeframe] = useState<"3 Mon" | "6 Mon" | "1 Year">(
    "6 Mon"
  );

  const data = useMemo(() => dataMap[timeframe], [timeframe]);

  const netLaborCost = useMemo(() => {
    const lastValue = data[data.length - 1]?.profit ?? 0;
    return `AED ${lastValue} M`;
  }, [data]);

  return {
    timeframe,
    setTimeframe,
    timeframes: Object.keys(dataMap) as Array<"3 Mon" | "6 Mon" | "1 Year">,
    data,
    netLaborCost,
  };
};
