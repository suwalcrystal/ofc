import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { FaTriangleExclamation, FaCircleExclamation } from "react-icons/fa6";
import { useAlertsWarnings } from "./hooks/useAlertsWarnings";

const AlertsWarnings = () => {
  const { alertsWarnings } = useAlertsWarnings();

  return (
    <div className="h-full">
      <Card className="base-card">
        <CardContent className="h-full flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-[0.75rem]">
              <h2 className="typography-paragraph-small font-semibold text-text-500">
                Alerts & Warnings
              </h2>
              <Link
                to="#"
                className="text-blue typography-paragraph-caption font-semibold hover:underline"
              >
                View All
              </Link>
            </div>

            <div className="space-y-[0.88rem]">
              {alertsWarnings.map((item, index) => {
                const isAlert = item.status === "Alert";
                const Icon = isAlert
                  ? FaTriangleExclamation
                  : FaCircleExclamation;
                const iconColor = isAlert ? "text-error" : "text-warning";

                return (
                  <div key={index} className="flex items-center gap-2">
                    <Icon className={`text-[1rem] ${iconColor}`} />
                    <p
                      className={`${iconColor} typography-paragraph-small font-medium`}
                    >
                      {item.name}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AlertsWarnings;
