const Subcontractors = () => {
  return <div>Subcontractors</div>;
};

export default Subcontractors;
