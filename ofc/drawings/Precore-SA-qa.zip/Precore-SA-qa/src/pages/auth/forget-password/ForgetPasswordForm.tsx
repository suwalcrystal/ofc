import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PATH } from "@/constants/paths";
import { IoIosArrowBack } from "react-icons/io";
import { useForgetPassword } from "./hooks/useForgetPassword";

const ForgetPasswordForm = () => {
  const { formik } = useForgetPassword();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-[400px] space-y-8">
        {/* Logo */}
        <div className="w-[14.44rem] h-[6rem] mx-auto">
          <img
            src="/logo-login.png"
            alt="logo"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Forget Password Form */}
        <div>
          <h2 className="typography-paragraph-large font-bold text-text-500 mb-8">
            Forget Password
          </h2>

          <form onSubmit={formik.handleSubmit}>
            {/* Email Field */}
            <div className="space-y-3">
              <Label
                htmlFor="email"
                className="typography-paragraph-small font-medium text-text-500"
              >
                E-mail Address <span className="text-error">*</span>
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="E-mail Address"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.email}
                className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
              />
              {formik.touched.email && formik.errors.email && (
                <p className="text-red-500 typography-paragraph-small pl-3 ">
                  {formik.errors.email}
                </p>
              )}
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full cursor-pointer h-12 bg-green-600 hover:bg-green-700 text-white text-base font-medium rounded-full my-5"
            >
              Send
            </Button>

            <div className="text-center">
              <a
                href={PATH.auth.login}
                className="text-green-500 hover:text-green-700 typography-paragraph-small inline-flex items-center justify-center gap-1"
              >
                <IoIosArrowBack />
                Back to Login
              </a>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ForgetPasswordForm;
