import { useFormik } from "formik";
import * as Yup from "yup";

export const useForgetPassword = () => {
  const formik = useFormik({
    initialValues: {
      email: "",
    },
    validationSchema: Yup.object({
      email: Yup.string().email("Invalid email").required("Email is required"),
    }),
    onSubmit: (values) => {
      console.warn("Forgot Password attempt:", values);
    },
  });

  return {
    formik,
  };
};
