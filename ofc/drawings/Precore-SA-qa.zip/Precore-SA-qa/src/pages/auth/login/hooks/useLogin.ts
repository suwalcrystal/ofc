import { useState } from "react";
import { useFormik } from "formik";

import { useMutation } from "@tanstack/react-query";
import { LoginFormSchema, LoginFormSchemaType } from "../schema";
import { AxiosError } from "axios";
import axiosInstance from "@/utils/axios-instance";
import { setCookie } from "@/utils/cookie";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import { PATH } from "@/constants/paths";
import { useNavigate } from "react-router-dom";
import Endpoint from "@/api/endpoints";
import handleErrors from "@/service/api.error";

interface LoginResponse {
  status: string;
  statusCode: number;
  message: string;
  data: {
    accessToken: string;
    refreshToken: string;
  };
}

const Login = async (data: LoginFormSchemaType) => {
  const response = await axiosInstance.post(Endpoint.login, data);
  return response.data;
};

export const useLoginForm = () => {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);

  const { mutate } = useMutation<
    LoginResponse,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    LoginFormSchemaType
  >({
    mutationFn: Login,
    onSuccess: (res) => {
      showSuccessMessage(res?.message || "Login successful");
      setCookie({
        cookieName: "accessToken",
        value: res.data.accessToken,
      });
      setCookie({
        cookieName: "refreshToken",
        value: res.data.refreshToken,
      });

      navigate(PATH.dashboard);
      // setTimeout(() => {
      //   window.location.href = PATH.dashboard;
      // }, 500);
    },
    onError: (err) => {
      if (err?.response?.status === 422) {
        handleErrors(err, formik.setErrors);
      } else {
        showErrorMessage(err?.response?.data?.message || "Login failed");
      }
    },
  });

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: LoginFormSchema,
    onSubmit: (values) => {
      mutate(values);
    },
  });

  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  return {
    formik,
    showPassword,
    togglePasswordVisibility,
  };
};
