import LoginForm from "./partials/login-form";

const LoginPage = () => {
  return <LoginForm />;
};

export default LoginPage;
