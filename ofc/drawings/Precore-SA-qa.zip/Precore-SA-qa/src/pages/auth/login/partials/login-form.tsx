import { Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FcGoogle } from "react-icons/fc";
import { SiXero } from "react-icons/si";
import { useLoginForm } from "../hooks/useLogin";
import { PATH } from "@/constants/paths";

const LoginForm = () => {
  const { formik, showPassword, togglePasswordVisibility } = useLoginForm();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-[400px] space-y-8">
        {/* Logo */}
        <div className="w-[14.44rem] h-[6rem] mx-auto">
          <img
            src="/logo-login.png"
            alt="logo"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Login Form */}
        <div>
          <h2 className="typography-paragraph-large font-bold text-text-500 mb-8">
            Log In
          </h2>

          <form onSubmit={formik.handleSubmit}>
            {/* Email Field */}
            <div className="space-y-3">
              <Label
                htmlFor="email"
                className="typography-paragraph-small font-medium text-text-500"
              >
                E-mail Address <span className="text-error">*</span>
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="E-mail Address"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.email}
                className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
              />
              {formik.touched.email && formik.errors.email && (
                <p className="text-red-500 typography-paragraph-small pl-3 ">
                  {formik.errors.email}
                </p>
              )}
            </div>

            {/* Password Field */}
            <div className="space-y-3 mt-5">
              <Label
                htmlFor="password"
                className="typography-paragraph-small font-medium text-text-500"
              >
                Password <span className="text-error">*</span>
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Password"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.password}
                  className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px] pr-12"
                />
                <button
                  type="button"
                  onClick={togglePasswordVisibility}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-300 hover:text-text-600 cursor-pointer "
                >
                  {showPassword ? (
                    <Eye className="h-5 w-5" />
                  ) : (
                    <EyeOff className="h-5 w-5" />
                  )}
                </button>
              </div>
              {formik.touched.password && formik.errors.password && (
                <p className="text-red-500 typography-paragraph-small pl-3 ">
                  {formik.errors.password}
                </p>
              )}
              <div className="text-right">
                <a
                  href={PATH.auth.forgotPassword}
                  className="text-green-500 hover:text-green-700 typography-paragraph-small"
                >
                  Forgot Password?
                </a>
              </div>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full cursor-pointer h-12 bg-green-600 hover:bg-green-700 text-white text-base font-medium rounded-full mt-5"
            >
              Login
            </Button>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-boarder-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">OR</span>
              </div>
            </div>

            {/* Social Logins */}
            <div className="space-y-3">
              <Button
                type="button"
                variant="outline"
                className="w-full h-12 typography-paragraph-small cursor-pointer rounded-full border-boarder-300 hover:bg-boarder-50 bg-transparent"
              >
                <div className="flex items-center justify-center space-x-2">
                  <SiXero className="size-6 text-[#1FC0E7]" />
                  <span>Sign In with Xero</span>
                </div>
              </Button>

              <Button
                type="button"
                variant="outline"
                className="w-full h-12 typography-paragraph-small cursor-pointer rounded-full border-boarder-300 hover:bg-boarder-50 bg-transparent"
              >
                <div className="flex items-center justify-center space-x-2">
                  <FcGoogle className="size-6" />
                  <span>Sign In with Google</span>
                </div>
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
