import { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";

export const useResetPassword = () => {
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const formik = useFormik({
    initialValues: {
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema: Yup.object({
      newPassword: Yup.string()
        .required("New Password is required")
        .min(8, "Password must be at least 8 characters"),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref("newPassword")], "Passwords must match")
        .required("Confirm Password is required"),
    }),
    onSubmit: (values) => {
      console.warn("Password reset submitted:", values);
    },
  });

  const toggleNewPasswordVisibility = () => setShowNewPassword((prev) => !prev);

  const toggleConfirmPasswordVisibility = () =>
    setShowConfirmPassword((prev) => !prev);

  return {
    formik,
    showNewPassword,
    showConfirmPassword,
    toggleNewPasswordVisibility,
    toggleConfirmPasswordVisibility,
  };
};
