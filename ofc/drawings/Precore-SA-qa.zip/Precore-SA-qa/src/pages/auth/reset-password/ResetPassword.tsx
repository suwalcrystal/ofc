import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PATH } from "@/constants/paths";
import { Eye, EyeOff } from "lucide-react";
import { IoIosArrowBack } from "react-icons/io";
import { useResetPassword } from "./hooks/useResetPassword";

const ResetPassword = () => {
  const {
    formik,
    showNewPassword,
    showConfirmPassword,
    toggleNewPasswordVisibility,
    toggleConfirmPasswordVisibility,
  } = useResetPassword();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-[400px] space-y-8">
        {/* Logo */}
        <div className="w-[14.44rem] h-[6rem] mx-auto">
          <img
            src="/logo-login.png"
            alt="logo"
            className="w-full h-full object-cover"
          />
        </div>

        {/* ResetPassword Form */}
        <div>
          <h2 className="typography-paragraph-large font-bold text-text-500 mb-8">
            Reset Password
          </h2>

          <form onSubmit={formik.handleSubmit}>
            {/* New password Field */}
            <div className="space-y-3 ">
              <Label
                htmlFor="newPassword"
                className="typography-paragraph-small font-medium text-text-500"
              >
                New Password <span className="text-error">*</span>
              </Label>
              <div className="relative">
                <Input
                  id="newPassword"
                  name="newPassword"
                  type={showNewPassword ? "text" : "password"}
                  placeholder="New Password"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.newPassword}
                  className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px] pr-12"
                />
                <button
                  type="button"
                  onClick={toggleNewPasswordVisibility}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-300 hover:text-text-600 cursor-pointer "
                >
                  {showNewPassword ? (
                    <Eye className="h-5 w-5" />
                  ) : (
                    <EyeOff className="h-5 w-5" />
                  )}
                </button>
              </div>
              {formik.touched.newPassword && formik.errors.newPassword && (
                <p className="text-red-500 typography-paragraph-small pl-3 ">
                  {formik.errors.newPassword}
                </p>
              )}
            </div>

            {/* Confirm Password Field */}
            <div className="space-y-3 mt-5">
              <Label
                htmlFor="confirmPassword"
                className="typography-paragraph-small font-medium text-text-500"
              >
                Confirm Password <span className="text-error">*</span>
              </Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="Current Password"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.confirmPassword}
                  className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px] pr-12"
                />
                <button
                  type="button"
                  onClick={toggleConfirmPasswordVisibility}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-300 hover:text-text-600 cursor-pointer "
                >
                  {showConfirmPassword ? (
                    <Eye className="h-5 w-5" />
                  ) : (
                    <EyeOff className="h-5 w-5" />
                  )}
                </button>
              </div>
              {formik.touched.confirmPassword &&
                formik.errors.confirmPassword && (
                  <p className="text-red-500 typography-paragraph-small pl-3">
                    {formik.errors.confirmPassword}
                  </p>
                )}
            </div>

            {/* Button */}
            <Button
              type="submit"
              className="w-full cursor-pointer h-12 bg-green-600 hover:bg-green-700 text-white text-base font-medium rounded-full my-5"
            >
              Reset Password
            </Button>

            <div className="text-center">
              <a
                href={PATH.auth.login}
                className="text-green-500 hover:text-green-700 typography-paragraph-small inline-flex items-center justify-center gap-1"
              >
                <IoIosArrowBack />
                Back to Login
              </a>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
