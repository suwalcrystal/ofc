const BudgetsControl = () => {
  return <div>BudgetsControl</div>;
};

export default BudgetsControl;
