import { useEffect, useState } from "react";
import { Project } from "../interface/project.interface";

// Custom Hook for Table Logic
export const useProjectTableLogic = (initialData: Project[]) => {
  const [data] = useState<Project[]>(initialData);
  const [filteredData, setFilteredData] = useState<Project[]>(initialData);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Project;
    direction: "ascending" | "descending";
  } | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [filterValue, setFilterValue] = useState("");
  const [totalItems, setTotalItems] = useState(initialData.length);

  // Handle sorting
  const requestSort = (key: keyof Project) => {
    let direction: "ascending" | "descending" = "ascending";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "ascending"
    ) {
      direction = "descending";
    }
    setSortConfig({ key, direction });
  };

  // Apply sorting and filtering
  useEffect(() => {
    let sortedData = [...data];

    if (sortConfig !== null) {
      sortedData.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "ascending" ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "ascending" ? 1 : -1;
        }
        return 0;
      });
    }

    if (filterValue) {
      sortedData = sortedData.filter(
        (item) =>
          item.id.toLowerCase().includes(filterValue.toLowerCase()) ||
          item.project.toLowerCase().includes(filterValue.toLowerCase()) ||
          item.phase.toLowerCase().includes(filterValue.toLowerCase()) ||
          item.status.toLowerCase().includes(filterValue.toLowerCase())
      );
    }

    setFilteredData(sortedData);
    setTotalItems(sortedData.length);
    setCurrentPage(1);
  }, [sortConfig, filterValue, data]);

  // Get current items for pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredData.slice(indexOfFirstItem, indexOfLastItem);

  return {
    currentItems,
    sortConfig,
    requestSort,
    filterValue,
    setFilterValue,
    currentPage,
    setCurrentPage,
    itemsPerPage,
    setItemsPerPage,
    totalItems,
  };
};
