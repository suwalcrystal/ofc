import Search from "@/components/Search";
import ToolBar from "@/components/Toolbar/ToolbarTitle";
import AddButton from "@/components/headerBottom/AddButton";
import FilterComponent from "@/components/headerBottom/FilterComponent";
import ToggleSwitch from "@/components/headerBottom/ToggleSwitch";
import { useState } from "react";
import ProductCardView from "./partials/ProductCardView";
import ProjectTrackingTable from "./partials/ProjectTrackingTable";

const Projects = () => {
  const [view, setView] = useState("Card");

  return (
    <div>
      <ToolBar
        title="Projects"
        search={<Search />}
        addButton={<AddButton title="Add Project Button" />}
        toggler={
          <ToggleSwitch
            options={["Card", "Table"]}
            defaultSelected="Card"
            onChange={(selected) => setView(selected)}
          />
        }
        filter={<FilterComponent />}
      />

      <div className="mt-[1.5rem] pb-[1.5rem]">
        {view === "Card" ? <ProductCardView /> : <ProjectTrackingTable />}
      </div>
    </div>
  );
};

export default Projects;
