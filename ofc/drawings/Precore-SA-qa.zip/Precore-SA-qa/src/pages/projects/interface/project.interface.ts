// Define the data structure
export interface Project {
  id: string;
  status: "On Track" | "Delayed" | "Completed";
  project: string;
  email: string;
  phase: string;
  linkedPOs: number;
  budget: number;
  spent: number;
  action: string;
}
