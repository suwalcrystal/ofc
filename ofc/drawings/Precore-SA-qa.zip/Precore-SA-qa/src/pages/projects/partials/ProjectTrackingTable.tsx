import { useProjectTableLogic } from "../hooks/projectTable.hook";
import { extendedData } from "./data";
import { Project } from "../interface/project.interface";
import { Button } from "@/components/ui/button";
import { FiEdit3 } from "react-icons/fi";
import { Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import BaseTable from "@/components/BaseTable";
import { formatCurrency } from "@/utils/formatCurrency";
import { getStatusBadge } from "@/utils/getStatusBadge";
import CustomPagination from "@/components/CustomPagination";
import { TableCell } from "@/components/ui/table";
import { IColumn } from "@/interface/baseTable.interface";

const ProjectTrackingTable: React.FC = () => {
  const {
    currentItems,
    currentPage,
    setCurrentPage,
    itemsPerPage,
    setItemsPerPage,
    totalItems,
  } = useProjectTableLogic(extendedData);

  const columns: IColumn<Project>[] = [
    { key: "id", label: "ID", sortable: true },
    { key: "status", label: "Status", sortable: true },
    { key: "project", label: "Project", sortable: true },
    { key: "phase", label: "Phase", sortable: true },
    { key: "linkedPOs", label: "Linked POs", sortable: true },
    { key: "budget", label: "Budget", sortable: true },
    { key: "spent", label: "Spent", sortable: true },
    { key: "action", label: "Action", sortable: true },
  ];

  const renderRow = (item: Project): React.JSX.Element[] => [
    <TableCell key="id" className="font-medium   ">
      {item.id}
    </TableCell>,
    <TableCell key="status" className="font-medium ">
      {getStatusBadge(item.status)}
    </TableCell>,
    <TableCell key="project" className="font-medium ">
      <div className="pb-1">{item.project}</div>
      <div className="text-text-300 text-xs">{item.email}</div>
    </TableCell>,
    <TableCell key="phase" className="font-medium ">
      {item.phase}
    </TableCell>,
    <TableCell key="linkedPOs" className="font-medium ">
      <Link to="#" className="text-blue hover:underline">
        {item.linkedPOs}
      </Link>
    </TableCell>,
    <TableCell key="budget" className="font-medium ">
      <div className="pb-1 font-semibold">{formatCurrency(item.budget)}</div>
      <div className="text-text-300 text-xs">AED</div>
    </TableCell>,
    <TableCell key="spent" className="font-medium ">
      <div
        className={`pb-1 font-semibold ${item.status === "Completed" ? "text-green-600" : "text-red-500"}`}
      >
        {formatCurrency(item.spent)}
      </div>
      <div className="text-text-300 text-xs">AED</div>
    </TableCell>,
    <TableCell key="actions" className="font-medium ">
      <div className="flex justify-center space-x-1">
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <FiEdit3 className="h-4 w-4" />
          <span className="sr-only">Edit</span>
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Trash2 className="h-4 w-4" />
          <span className="sr-only">Delete</span>
        </Button>
      </div>
    </TableCell>,
  ];

  return (
    <div>
      <BaseTable<Project>
        columns={columns}
        data={currentItems}
        renderRow={renderRow}
      />
      <CustomPagination
        currentPage={currentPage}
        itemsPerPage={itemsPerPage}
        totalItems={totalItems}
        setCurrentPage={setCurrentPage}
        setItemsPerPage={setItemsPerPage}
      />
    </div>
  );
};

export default ProjectTrackingTable;
