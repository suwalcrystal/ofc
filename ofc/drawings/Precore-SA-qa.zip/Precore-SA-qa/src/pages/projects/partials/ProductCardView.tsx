import { projectData } from "@/data/projectData";
import ProjectStatusCard from "./ProjectStatusCard";

const ProductCardView = () => {
  return (
    <>
      <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3 ">
        {projectData?.map((project, index) => (
          <ProjectStatusCard key={index} project={project} />
        ))}
      </div>
    </>
  );
};

export default ProductCardView;
