import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import commentIcon from "@/assets/icons/comment.svg";
import { Link } from "react-router-dom";
import { PATH } from "@/constants/paths";

interface IProjectProps {
  project: {
    title: string;
    category: string;
    status: string;
    statusColor: string;
    progressPercentage: number;
    tasksOpen: string;
    linkedPOs: string;
    budgetVsSpent: string;
    milestones: string;
    commentsCount: number;
  };
}

const ProjectStatusCard: React.FC<IProjectProps> = ({ project }) => {
  const projectData = [
    { label: "Tasks", value: project?.tasksOpen },
    { label: "Linked POs", value: project?.linkedPOs },
    { label: "Budget vs Spent", value: project?.budgetVsSpent },
    { label: "Milestones", value: project?.milestones },
  ];

  return (
    <Card className="w-full  shadow-card border-[0.2px] border-boarder-300 rounded-[0.5rem] bg-white hover:shadow-lg transition-shadow duration-300">
      <CardHeader className="flex flex-row justify-between ">
        <Link to={PATH.projects.projectDetail}>
          <h2 className="typography-paragraph-regular text-text-500 font-medium">
            {project?.title}
          </h2>
          <div className="mt-[0.88rem]">
            <Badge
              variant="outline"
              className="rounded-full border border-boarder-300  py-[0.25rem] px-[0.62rem] typography-paragraph-small bg-text-50 text-text-400 hover:bg-text-100"
            >
              {project.category}
            </Badge>
          </div>
        </Link>

        <div>
          <span
            className={`typography-paragraph-small font-semibold ${
              project.status === "On Track"
                ? "text-success"
                : project.status === "Delayed"
                  ? "text-warning"
                  : project.status === "At Risk"
                    ? "text-error"
                    : "text-gray-500"
            }`}
          >
            {project.status}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div>
          <Progress
            value={project?.progressPercentage}
            className="h-4 rounded-md mb-[0.88rem] *:bg-green-500"
          />
          <p className="typography-paragraph-small text-text-300 font-medium pb-[1.25rem]">
            {project?.progressPercentage}% completed
          </p>
        </div>

        <div className="space-y-3">
          {projectData.map((item, index) => (
            <div key={index} className="flex justify-between">
              <span className="text-text-400 font-medium typography-paragraph-small">
                {item.label}:
              </span>
              <span className="text-text-500 font-semibold typography-paragraph-small">
                {item.value ?? "N/A"}
              </span>
            </div>
          ))}
        </div>

        <div className="flex items-center mt-[0.88rem] gap-[0.62rem]">
          <img
            src={commentIcon}
            alt="comment-icon"
            className="w-[1.125rem] h-[1.125rem]"
          />
          <span className="text-text-300 typography-paragraph-small font-medium">
            {project?.commentsCount}
          </span>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProjectStatusCard;
