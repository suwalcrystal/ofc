import { Project } from "../interface/project.interface";

// Sample data
const initialData: Project[] = [
  {
    id: "#790955",
    status: "On Track",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "Fit-Out",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    action: "View",
  },
  {
    id: "#790955",
    status: "Delayed",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "MEP",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    action: "View",
  },
  {
    id: "#790955",
    status: "On Track",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "Fit-Out",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    action: "View",
  },
  {
    id: "#790955",
    status: "Delayed",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "MEP",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    action: "View",
  },
  {
    id: "#790955",
    status: "Completed",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "Fit-Out",
    linkedPOs: 5,
    budget: 12000000,
    spent: 12000000,
    action: "View",
  },
  {
    id: "#790955",
    status: "On Track",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "Fit-Out",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    action: "View",
  },
];

// Add more data for pagination testing
export const extendedData = [...initialData];
for (let i = 0; i < 15; i++) {
  extendedData.push(...initialData.map((item) => ({ ...item })));
}
