const HRLaborCost = () => {
  return <div>HRLaborCost</div>;
};

export default HRLaborCost;
