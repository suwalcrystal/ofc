const PaymentsFinance = () => {
  return <div>PaymentsFinance</div>;
};

export default PaymentsFinance;
