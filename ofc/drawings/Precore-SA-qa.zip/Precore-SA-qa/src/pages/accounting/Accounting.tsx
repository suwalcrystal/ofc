const Accounting = () => {
  return <div>Accounting</div>;
};

export default Accounting;
