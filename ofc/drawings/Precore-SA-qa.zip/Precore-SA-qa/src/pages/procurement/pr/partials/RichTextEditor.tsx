// "use client";

// import type React from "react";

// import { useState } from "react";
// import {
//   Bold,
//   Italic,
//   Underline,
//   Strikethrough,
//   Code,
//   Link,
//   List,
//   ListOrdered,
//   AlignLeft,
//   ChevronDown,
// } from "lucide-react";
// import { Button } from "@/components/ui/button";
// import { Textarea } from "@/components/ui/textarea";
// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuTrigger,
// } from "@/components/ui/dropdown-menu";

// interface RichTextEditorProps {
//   value: string;
//   onChange: (value: string) => void;
// }

// export function RichTextEditor({ value, onChange }: RichTextEditorProps) {
//   const [selectedText, setSelectedText] = useState("");

//   const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
//     onChange(e.target.value);
//   };

//   const formatText = (format: string) => {
//     // This is a simplified implementation
//     // In a real app, you'd want to use a proper rich text editor library
//     console.log(`Formatting text with: ${format}`);
//   };

//   return (
//     <div className="border border-gray-200 rounded-md bg-white">
//       {/* Toolbar */}
//       <div className="flex items-center gap-1 p-2 border-b border-gray-200 bg-gray-50">
//         {/* Alignment Dropdown */}
//         <DropdownMenu>
//           <DropdownMenuTrigger asChild>
//             <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
//               <AlignLeft className="h-4 w-4" />
//               <ChevronDown className="h-3 w-3 ml-1" />
//             </Button>
//           </DropdownMenuTrigger>
//           <DropdownMenuContent>
//             <DropdownMenuItem onClick={() => formatText("align-left")}>
//               Align Left
//             </DropdownMenuItem>
//             <DropdownMenuItem onClick={() => formatText("align-center")}>
//               Align Center
//             </DropdownMenuItem>
//             <DropdownMenuItem onClick={() => formatText("align-right")}>
//               Align Right
//             </DropdownMenuItem>
//           </DropdownMenuContent>
//         </DropdownMenu>

//         <div className="w-px h-6 bg-gray-300 mx-1" />

//         {/* Formatting Buttons */}
//         <Button
//           variant="ghost"
//           size="sm"
//           className="h-8 w-8 p-0"
//           onClick={() => formatText("bold")}
//         >
//           <Bold className="h-4 w-4" />
//         </Button>

//         <Button
//           variant="ghost"
//           size="sm"
//           className="h-8 w-8 p-0"
//           onClick={() => formatText("italic")}
//         >
//           <Italic className="h-4 w-4" />
//         </Button>

//         <Button
//           variant="ghost"
//           size="sm"
//           className="h-8 w-8 p-0"
//           onClick={() => formatText("underline")}
//         >
//           <Underline className="h-4 w-4" />
//         </Button>

//         <Button
//           variant="ghost"
//           size="sm"
//           className="h-8 w-8 p-0"
//           onClick={() => formatText("strikethrough")}
//         >
//           <Strikethrough className="h-4 w-4" />
//         </Button>

//         <div className="w-px h-6 bg-gray-300 mx-1" />

//         <Button
//           variant="ghost"
//           size="sm"
//           className="h-8 w-8 p-0"
//           onClick={() => formatText("code")}
//         >
//           <Code className="h-4 w-4" />
//         </Button>

//         <Button
//           variant="ghost"
//           size="sm"
//           className="h-8 w-8 p-0"
//           onClick={() => formatText("link")}
//         >
//           <Link className="h-4 w-4" />
//         </Button>

//         <div className="w-px h-6 bg-gray-300 mx-1" />

//         <Button
//           variant="ghost"
//           size="sm"
//           className="h-8 w-8 p-0"
//           onClick={() => formatText("bullet-list")}
//         >
//           <List className="h-4 w-4" />
//         </Button>

//         <Button
//           variant="ghost"
//           size="sm"
//           className="h-8 w-8 p-0"
//           onClick={() => formatText("numbered-list")}
//         >
//           <ListOrdered className="h-4 w-4" />
//         </Button>
//       </div>

//       {/* Text Area */}
//       <Textarea
//         value={value}
//         onChange={handleTextareaChange}
//         placeholder="Enter your note here..."
//         className="min-h-[120px] border-0 resize-none focus-visible:ring-0 focus-visible:ring-offset-0"
//       />
//     </div>
//   );
// }
