import image from "@/assets/porcurement/STEELGRINDER.png";
import BaseTable from "@/components/BaseTable";
import { Button } from "@/components/ui/button";
import { MdAddBox } from "react-icons/md";
import { TableCell } from "@/components/ui/table";
import { IColumn } from "@/interface/baseTable.interface";

type IAddItem = {
  id: string | number;
  name: string;
  image: string;
  sku: string;
  category: string;
  supplier: string;
  quantity: number;
  unit: string;
  unitPrice: number;
};

const AddItemsTable = () => {
  const columns: IColumn<IAddItem>[] = [
    { key: "name", label: "Image/Item Name/SKU", sortable: true },
    { key: "category", label: "Category", sortable: true },
    { key: "supplier", label: "Supplier", sortable: true },
    { key: "quantity", label: "Quantity", sortable: true },
    { key: "unit", label: "Unit", sortable: true },
    { key: "unitPrice", label: "Unit Price", sortable: true },
    { key: "action" as keyof IAddItem, label: "Edit", sortable: true },
  ];

  const data: IAddItem[] = [
    {
      id: 1,
      name: "Stapler",
      image: image,
      sku: "SG001",
      category: "Materials",
      supplier: "Al Jessour Building Materials Trading LLC",
      quantity: 10,
      unit: "pcs",
      unitPrice: 5.5,
    },
    {
      id: 2,
      name: "Office Chair",
      image: image,
      sku: "SG001",
      category: "Materials",
      supplier: "Al Jessour Building Materials Trading LLC",
      quantity: 2,
      unit: "pcs",
      unitPrice: 120,
    },
    {
      id: 3,
      name: "Steel Grinder",
      image: image,
      sku: "SG001",
      category: "Materials",
      supplier: "Al Jessour Building Materials Trading LLC",
      quantity: 5,
      unit: "pcs",
      unitPrice: 250,
    },
    {
      id: 4,
      name: "Hammer Drill",
      image: image,
      sku: "SG001",
      category: "Materials",
      supplier: "Al Jessour Building Materials Trading LLC",
      quantity: 3,
      unit: "pcs",
      unitPrice: 150,
    },
    {
      id: 5,
      name: "Safety Helmet",
      image: image,
      sku: "SG001",
      category: "Materials",
      supplier: "Al Jessour Building Materials Trading LLC",
      quantity: 20,
      unit: "pcs",
      unitPrice: 10,
    },
  ];

  const renderRow = (item: IAddItem): React.JSX.Element[] => [
    <TableCell key="name" className="text-left">
      <div className="flex items-center gap-[0.42rem]">
        <div className="rounded-[0.25rem] border border-boarder-300 size-[2.375rem]">
          <img
            src={item.image}
            alt={item.name}
            className="size-full object-cover rounded-[0.25rem]"
          />
        </div>
        <div className="font-medium">
          <div className="typography-paragraph-small text-text-500 pb-[0.31rem]">
            {item.name}
          </div>
          <div className="typography-paragraph-caption text-text-300 text-start">
            {item.sku}
          </div>
        </div>
      </div>
    </TableCell>,

    <TableCell key="category" className="font-medium text-center">
      {item.category}
    </TableCell>,

    <TableCell key="supplier" className="font-medium text-center">
      {item.supplier}
    </TableCell>,

    <TableCell key="quantity" className="font-medium text-start">
      <div className="border border-boarder-300 bg-background-100 rounded-[0.5rem] p-[0.75rem] ml-4">
        {item.quantity}
      </div>
    </TableCell>,

    <TableCell key="unit" className="font-medium text-start">
      <div className="border border-boarder-300 bg-background-100 rounded-[0.5rem] p-[0.75rem] mx-4">
        {item.unit}
      </div>
    </TableCell>,

    <TableCell key="unitPrice" className="font-medium text-start">
      <div className="border border-boarder-300 bg-background-100 rounded-[0.5rem] p-[0.75rem] mr-4">
        {item.unitPrice} AED
      </div>
    </TableCell>,

    <TableCell key="action" className="text-center">
      <button>
        <MdAddBox className="cursor-pointer w-[1.5rem] h-[2rem] text-[#4b4b4b]" />
      </button>
    </TableCell>,
  ];

  return (
    <div>
      <BaseTable<IAddItem>
        columns={columns}
        renderRow={renderRow}
        data={data}
      />

      <Button
        type="submit"
        className="m-[0.75rem] bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer"
      >
        Add
      </Button>
    </div>
  );
};

export default AddItemsTable;
