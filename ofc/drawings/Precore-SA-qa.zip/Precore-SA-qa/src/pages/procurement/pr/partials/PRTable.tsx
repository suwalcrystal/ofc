import React, { JSX } from "react";
import { Link } from "react-router-dom";
import { Check, Eye, X } from "lucide-react";

import BaseTable from "@/components/BaseTable";
import CustomPagination from "@/components/CustomPagination";
import { getStatusBadge } from "@/utils/getStatusBadge";
import { TableCell } from "@/components/ui/table";
import { PATH } from "@/constants/paths";

import { usePRTable } from "../hooks/usePRTableLogic";
import type { IPurchaseRequest } from "../interface/pr.interface";
import { extendedPRData } from "../../purchaseRequestData";
import { IColumn } from "@/interface/baseTable.interface";

interface PRTableProps {
  filterType: string;
}

const PRTable: React.FC<PRTableProps> = ({ filterType }) => {
  const isBulkMode = filterType === "pending";

  const filteredData = isBulkMode
    ? extendedPRData.filter((item) => item.status.toLowerCase() === "pending")
    : extendedPRData;

  const {
    currentItems,
    currentPage,
    setCurrentPage,
    itemsPerPage,
    setItemsPerPage,
    totalItems,
    handleSelectItem,
    handleSelectAll,
    handleApprove,
    handleReject,
    selectedItems,
  } = usePRTable(filteredData);

  const columns: IColumn<IPurchaseRequest>[] = [
    ...(isBulkMode
      ? [
          {
            key: "select" as keyof IPurchaseRequest,
            label: "",
            sortable: false,
          },
        ]
      : []),
    { key: "id", label: "ID", sortable: true },
    { key: "status", label: "Status", sortable: true },
    { key: "type", label: "Type", sortable: true },
    { key: "ProjectRequester", label: "Project / Requester", sortable: true },
    { key: "OtherDetails", label: "Other Details", sortable: false },
    { key: "Total", label: "Total", sortable: true },
    { key: "RelatedDocuments", label: "Related Documents", sortable: false },
    { key: "DeliveryDate", label: "Delivery Date", sortable: true },
    { key: "PODate", label: "PO Date", sortable: true },
    {
      key: "action" as keyof IPurchaseRequest,
      label: "Action",
      sortable: false,
    },
  ];

  const renderRow = (item: IPurchaseRequest): JSX.Element[] => [
    ...(isBulkMode
      ? [
          <TableCell key={`checkbox-${item.id}`}>
            <input
              type="checkbox"
              className="h-4 w-4 rounded border-gray-300"
              checked={selectedItems.includes(item.id)}
              onChange={() => handleSelectItem(item.id)}
              aria-label={`Select ${item.id}`}
            />
          </TableCell>,
        ]
      : []),
    <TableCell key={`id-${item.id}`}>
      <Link
        to={`${PATH.procurement.procurementDetail}/${item.id}`}
        className="font-medium"
      >
        {item.id}
      </Link>
    </TableCell>,
    <TableCell key={`status-${item.id}`} className="font-medium">
      {getStatusBadge(item.status)}
    </TableCell>,
    <TableCell key={`type-${item.id}`} className="font-medium">
      {item.type}
    </TableCell>,
    <TableCell key={`project-${item.id}`} className="font-medium ">
      <div className="pb-[0.31rem]">{item.ProjectRequester}</div>
      {item.requesterEmail && (
        <div className="text-text-300 text-sm truncate">
          {item.requesterEmail}
        </div>
      )}
    </TableCell>,
    <TableCell key={`details-${item.id}`} className="font-medium space-y-1">
      <div className="text-sm text-text-300">Date Needed in Site</div>
      <div>{item.OtherDetails.dateNeeded}</div>
      <div className="text-sm text-text-300">Delivery Leadtime</div>
      <div>{item.OtherDetails.DeliveryLead}</div>
    </TableCell>,
    <TableCell key={`total-${item.id}`} className="font-medium">
      <div className="font-semibold pb-1">{item.Total}</div>
      <div className="text-text-300 text-sm">{item.currency}</div>
    </TableCell>,
    <TableCell key={`docs-${item.id}`} className="font-medium">
      <div className="text-sm text-text-300 pb-1">Purchase Order</div>
      <Link to="#" className="text-blue hover:underline text-sm">
        {item.RelatedDocuments}
      </Link>
    </TableCell>,
    <TableCell key={`delivery-${item.id}`} className="font-medium">
      <div className="pb-1">{item.DeliveryDate}</div>
      <div className="text-sm text-text-300">{item.actualDeliveryDate}</div>
    </TableCell>,
    <TableCell key={`po-date-${item.id}`} className="font-medium">
      {item.PODate}
    </TableCell>,
    <TableCell key={`actions-${item.id}`} className="font-medium">
      <div className="flex justify-center space-x-1">
        <button className="text-text-300 hover:text-text-500" aria-label="View">
          <Eye className="h-4.5 w-4.5" />
        </button>
        <button
          className="text-text-300 hover:text-text-500"
          aria-label="Approve"
        >
          <Check className="h-4.5 w-4.5" />
        </button>
        <button
          className="text-text-300 hover:text-text-500"
          aria-label="Reject"
        >
          <X className="h-4.5 w-4.5" />
        </button>
      </div>
    </TableCell>,
  ];

  return (
    <div className="my-2.5 space-y-4">
      {isBulkMode && currentItems.length > 0 && (
        <div className="flex gap-2 items-center">
          <button
            onClick={handleApprove}
            disabled={selectedItems.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white py-1.5 px-4 rounded-full font-medium disabled:opacity-50"
          >
            Approve
          </button>
          <button
            onClick={handleReject}
            disabled={selectedItems.length === 0}
            className="bg-red-500 hover:bg-red-600 text-white py-1.5 px-4 rounded-full font-medium disabled:opacity-50"
          >
            Reject
          </button>
        </div>
      )}

      <BaseTable<IPurchaseRequest>
        columns={columns}
        data={currentItems}
        renderRow={renderRow}
        tableHeight="69vh"
        selectAllCheckbox={
          isBulkMode && (
            <label className="flex items-center justify-center">
              <input
                type="checkbox"
                className="h-4 w-4 cursor-pointer"
                checked={
                  selectedItems.length > 0 &&
                  selectedItems.length === currentItems.length
                }
                onChange={handleSelectAll}
              />
            </label>
          )
        }
      />

      <CustomPagination
        currentPage={currentPage}
        itemsPerPage={itemsPerPage}
        totalItems={totalItems}
        setCurrentPage={setCurrentPage}
        setItemsPerPage={setItemsPerPage}
      />
    </div>
  );
};

export default PRTable;
