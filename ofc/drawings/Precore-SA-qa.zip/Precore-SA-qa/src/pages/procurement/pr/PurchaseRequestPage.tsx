import { useState } from "react";
import ProcurementHeader from "../components/ProcurementHeader";
import PRTable from "./partials/PRTable";

const PurchaseRequestPage = () => {
  const [filterType, setFilterType] = useState("all");

  return (
    <div>
      <ProcurementHeader
        filterType={filterType}
        setFilterType={setFilterType}
      />
      <PRTable filterType={filterType} />
    </div>
  );
};

export default PurchaseRequestPage;
