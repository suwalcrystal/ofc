import PrForm from "./PrForm";

const CreatePR = () => {
  return (
    <div>
      <div className="border-b-2 border-white py-[0.88rem] mb-6">
        <h3 className="text-text-500 typography-h3 font-semibold">
          Create Manual Purchase Requests
        </h3>
      </div>
      <PrForm />
    </div>
  );
};

export default CreatePR;
