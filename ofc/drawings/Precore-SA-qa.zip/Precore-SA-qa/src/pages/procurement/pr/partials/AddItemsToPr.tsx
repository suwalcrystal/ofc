import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { FiSearch } from "react-icons/fi";
import AddItemsTable from "./AddItemsTable";

const AddItemsToPr = () => {
  const [isToggled, setIsToggled] = useState(true);

  const statusFilter = {
    key: "status",
    label: "Status",
    options: [
      { label: "Supplier", value: "supplier" },
      { label: "Pending", value: "pending" },
      { label: "Approved", value: "approved" },
    ],
  };

  const categoryFilter = {
    key: "category",
    label: "Category",
    options: [
      { label: "Category", value: "category" },
      { label: "Office Supplies", value: "office-supplies" },
      { label: "Furniture", value: "furniture" },
    ],
  };

  const [filters, setFilters] = useState({
    status: "supplier",
    category: "category",
  });

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <>
      <div className="border-b-2 border-white py-[0.88rem] mb-6">
        <h3 className="text-text-500 typography-h3 font-semibold">
          Add Items to Purchase Request
        </h3>
      </div>

      <div className="bg-background-200  rounded-[0.5rem] shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)] ">
        <div className="flex justify-between items-center px-6 py-[0.88rem]">
          <div className="flex items-center gap-[0.5rem]">
            <div className="relative">
              <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-text-200" />
              <input
                type="text"
                placeholder="Search Items"
                // value={query}
                // onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-[0.62rem] border border-boarder-300 bg-background-300 rounded-[1.375rem] focus:outline-none typography-paragraph-regular text-text-500 "
              />
            </div>
            <div className="flex gap-[0.5rem] items-center">
              {/* Status Select */}
              <Select
                value={filters.status}
                onValueChange={(value) => handleFilterChange("status", value)}
              >
                <SelectTrigger className="cursor-pointer hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium focus-visible:outline-none">
                  <SelectValue placeholder={statusFilter.label} />
                </SelectTrigger>
                <SelectContent className="w-[10rem]">
                  {statusFilter.options.map((option) => (
                    <SelectItem
                      key={option.value}
                      value={option.value}
                      className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                    >
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Category Select */}
              <Select
                value={filters.category}
                onValueChange={(value) => handleFilterChange("category", value)}
              >
                <SelectTrigger className="cursor-pointer hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium focus-visible:outline-none">
                  <SelectValue placeholder={categoryFilter.label} />
                </SelectTrigger>
                <SelectContent className="w-[10rem]">
                  {categoryFilter.options.map((option) => (
                    <SelectItem
                      key={option.value}
                      value={option.value}
                      className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                    >
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <label
              htmlFor="toggle-switch"
              className="text-text-400 typography-paragraph-small font-semibold"
            >
              In Stock Only
            </label>
            <Switch
              id="toggle-switch"
              checked={isToggled}
              onCheckedChange={setIsToggled}
              className="data-[state=checked]:bg-green-500 h-6 w-9.5 data-[state=unchecked]:bg-gray-200 cursor-pointer"
            />
          </div>
        </div>

        <AddItemsTable />
      </div>
    </>
  );
};

export default AddItemsToPr;
