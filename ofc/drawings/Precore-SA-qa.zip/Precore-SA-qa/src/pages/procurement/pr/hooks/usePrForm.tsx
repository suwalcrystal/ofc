import { useFormik } from "formik";
import * as Yup from "yup";

export interface PrFormValues {
  project: string;
  prType: string;
  dateNeeded: Date | null;
  deliveryLeadtime: Date | null;
  budgetCategory: string;
  note: string;
}

export const usePrForm = () => {
  const formik = useFormik<PrFormValues>({
    initialValues: {
      project: "",
      prType: "",
      dateNeeded: null,
      deliveryLeadtime: null,
      budgetCategory: "",
      note: "",
    },
    validationSchema: Yup.object({
      project: Yup.string().required("Project is required"),
      prType: Yup.string().required("PR Type is required"),
      dateNeeded: Yup.date().required("Date Needed is required"),
      deliveryLeadtime: Yup.date().required("Delivery Leadtime is required"),
      budgetCategory: Yup.string().required("Budget Category is required"),
      note: Yup.string(),
    }),
    onSubmit: (values) => {
      console.warn("PR Form submitted:", values);
    },
  });

  return { formik };
};
