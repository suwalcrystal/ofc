import PrDetailTabs from "../../components/PrDetailTabs";
import ProcurementDetailHeader from "../../components/ProcurementDetailHeader";

const PrDetail = () => {
  return (
    <div>
      <ProcurementDetailHeader title="Purchase Requisition" />
      <PrDetailTabs />
    </div>
  );
};

export default PrDetail;
