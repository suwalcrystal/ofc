export interface IPurchaseRequest {
  id: string;
  status: "Approved" | "Completed" | "Pending" | "In Progress" | "Rejected";
  type: "Equipment" | "Subcontractor" | "Materials";
  ProjectRequester: string;
  requesterEmail?: string;
  OtherDetails: {
    dateNeeded: string;
    DeliveryLead: string;
  };
  Total: string;
  currency: string;
  RelatedDocuments: string;
  DeliveryDate: string;
  actualDeliveryDate: string;
  PODate: string;
  spent: number;
}
