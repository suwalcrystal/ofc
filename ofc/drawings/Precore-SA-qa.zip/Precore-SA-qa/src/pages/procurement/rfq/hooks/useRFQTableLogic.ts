import { useEffect, useMemo, useState } from "react";
import { IPurchaseRequest } from "../interface/pr.interface";

// Utility to parse numbers from formatted strings (e.g., "25,000.00")
const parseValue = (val: string | number) => {
  if (typeof val === "string" && /^\d{1,3}(,\d{3})*(\.\d+)?$/.test(val)) {
    return parseFloat(val.replace(/,/g, ""));
  }
  return val;
};

export const useRFQTable = (initialData: IPurchaseRequest[]) => {
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [data] = useState<IPurchaseRequest[]>(initialData);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof IPurchaseRequest;
    direction: "ascending" | "descending";
  } | null>(null);

  const [filterValue, setFilterValue] = useState("");
  const [filterType, setFilterType] = useState<"all" | "pending">("all");

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Derived: filtered, sorted, paginated data
  const filteredData = useMemo(() => {
    let result = [...data];

    // Filter by type (all or pending)
    if (filterType === "pending") {
      result = result.filter((item) => item.status === "Pending");
    }

    // Apply text filter
    if (filterValue) {
      const filter = filterValue.toLowerCase();
      result = result.filter(
        (item) =>
          item.id.toLowerCase().includes(filter) ||
          item.ProjectRequester.toLowerCase().includes(filter) ||
          item.status.toLowerCase().includes(filter)
      );
    }

    // Apply sorting
    if (sortConfig !== null) {
      result.sort((a, b) => {
        const aRaw = a[sortConfig.key];
        const bRaw = b[sortConfig.key];

        const aVal =
          typeof aRaw === "string" || typeof aRaw === "number"
            ? parseValue(aRaw)
            : "";
        const bVal =
          typeof bRaw === "string" || typeof bRaw === "number"
            ? parseValue(bRaw)
            : "";

        if (aVal < bVal) return sortConfig.direction === "ascending" ? -1 : 1;
        if (aVal > bVal) return sortConfig.direction === "ascending" ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [data, sortConfig, filterValue, filterType]);

  const totalItems = filteredData.length;

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredData.slice(indexOfFirstItem, indexOfLastItem);

  useEffect(() => {
    setCurrentPage(1);
  }, [filterValue, filterType]);

  const requestSort = (key: keyof IPurchaseRequest) => {
    let direction: "ascending" | "descending" = "ascending";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "ascending"
    ) {
      direction = "descending";
    }
    setSortConfig({ key, direction });
  };

  // Count of pending records for UI badges
  const totalPendingCount = useMemo(
    () => data.filter((item) => item.status === "Pending").length,
    [data]
  );

  const handleSelectItem = (id: string) => {
    setSelectedItems((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedItems.length === currentItems.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(currentItems.map((item) => item.id));
    }
  };

  const handleApprove = () => {
    console.log("Approving PRs:", selectedItems);
    setSelectedItems([]);
  };

  const handleReject = () => {
    console.log("Rejecting PRs:", selectedItems);
    setSelectedItems([]);
  };

  return {
    currentItems,
    sortConfig,
    requestSort,
    filterValue,
    setFilterValue,
    filterType,
    setFilterType,
    totalPendingCount,
    currentPage,
    setCurrentPage,
    itemsPerPage,
    setItemsPerPage,
    totalItems,
    handleSelectItem,
    handleSelectAll,
    handleApprove,
    handleReject,
    selectedItems,
  };
};
