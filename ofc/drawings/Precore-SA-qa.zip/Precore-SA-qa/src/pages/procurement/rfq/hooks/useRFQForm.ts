import { useFormik } from "formik";
import * as Yup from "yup";

export const useRFQForm = () => {
  const formik = useFormik({
    initialValues: {
      dueDate: undefined,
      dateNeeded: undefined,
      deliveryLeadtime: undefined,
      project: "",
      currency: "",
      budgetCategory: "",
      note: "",
    },
    validationSchema: Yup.object().shape({
      dueDate: Yup.date().required("Delivery date is required"),
      dateNeeded: Yup.date().required("Date needed is required"),
      deliveryLeadtime: Yup.date().required("Delivery leadtime is required"),
      project: Yup.string().required("Project is required"),
      currency: Yup.string().required("Currency is required"),
      budgetCategory: Yup.string().required("Budget category is required"),
      note: Yup.string().required("Note is required"),
    }),
    onSubmit: (values) => {
      console.warn(values, "Submitted RFQ values");
    },
  });

  return {
    formik,
  };
};
