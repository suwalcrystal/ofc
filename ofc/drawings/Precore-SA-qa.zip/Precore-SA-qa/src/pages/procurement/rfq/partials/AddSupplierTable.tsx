import { ErrorMessage, Form, Formik } from "formik";
import { useState } from "react";
import * as Yup from "yup";

import BaseTable from "@/components/BaseTable";
import { Input } from "@/components/ui/input";
import { TableCell } from "@/components/ui/table";
import { IColumn } from "@/interface/baseTable.interface";
import { getStatusBadge } from "@/utils/getStatusBadge";
import { RiAddBoxFill } from "react-icons/ri";

interface ISupplierData {
  sn: number;
  name: string;
  email: string;
  status: string;
  isFormRow?: boolean;
  action?: React.ReactNode;
}

const initialTableData: ISupplierData[] = [
  {
    sn: 1,
    name: "PINK CITY BUILDING MATERAILS TRADING L.L.C",
    email: "Pinkcitybm@gmail.com",
    status: "Approved",
    action: undefined,
  },
];

const columns: IColumn<ISupplierData>[] = [
  { key: "sn", label: "S.N", sortable: false },
  { key: "name", label: "Name", sortable: true },
  { key: "email", label: "Email Address", sortable: true },
  { key: "status", label: "Status", sortable: true },
  { key: "action", label: "Action", sortable: false },
];

const AddSupplierTable = () => {
  const [tableData, setTableData] = useState<ISupplierData[]>(initialTableData);

  const handleAddSupplier = (values: { name: string; email: string }) => {
    const newEntry: ISupplierData = {
      sn: tableData.length + 1,
      name: values.name,
      email: values.email,
      status: "Pending",
    };
    setTableData((prev) => [...prev, newEntry]);
  };

  const renderRow = (
    supplier: ISupplierData,
    index?: number
  ): React.JSX.Element[] => {
    // Form row
    if (supplier.isFormRow) {
      return [
        <TableCell key="sn">{tableData.length + 1}</TableCell>,

        <TableCell key="name">
          <Formik
            initialValues={{ name: "", email: "" }}
            validationSchema={Yup.object({
              name: Yup.string().required("Name is required"),
              email: Yup.string()
                .email("Invalid email")
                .required("Email is required"),
            })}
            onSubmit={(values, { resetForm }) => {
              handleAddSupplier(values);
              resetForm();
            }}
          >
            {({ handleSubmit }) => (
              <Form onSubmit={handleSubmit}>
                <div className="flex flex-col">
                  <Input
                    type="text"
                    name="name"
                    placeholder="Supplier Name"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="name"
                    component="div"
                    className="text-red-500 text-sm"
                  />
                </div>
                {/* Hidden submit button to keep table structure valid */}
                <button type="submit" className="hidden" />
              </Form>
            )}
          </Formik>
        </TableCell>,

        <TableCell key="email">
          <Formik
            initialValues={{ name: "", email: "" }}
            validationSchema={Yup.object({
              name: Yup.string().required("Name is required"),
              email: Yup.string()
                .email("Invalid email")
                .required("Email is required"),
            })}
            onSubmit={(values, { resetForm }) => {
              handleAddSupplier(values);
              resetForm();
            }}
          >
            {({ handleSubmit }) => (
              <Form onSubmit={handleSubmit}>
                <div className="flex flex-col">
                  <Input
                    type="email"
                    name="email"
                    placeholder="Supplier Email"
                    className="w-full"
                  />
                  <ErrorMessage
                    name="email"
                    component="div"
                    className="text-red-500 text-sm"
                  />
                </div>
                <button type="submit" className="hidden" />
              </Form>
            )}
          </Formik>
        </TableCell>,

        <TableCell>
          {" "}
          <div className="flex gap-2">
            <button
              type="submit"
              className="py-2 px-4 rounded-full border border-green-500 text-green-500 hover:bg-green-500 hover:text-white"
            >
              Add
            </button>
            <button
              type="button"
              onClick={() => alert("Request sent!")}
              className="py-2 px-4 rounded-full bg-green-600 text-white hover:bg-green-700"
            >
              Send Request
            </button>
          </div>
        </TableCell>,
      ];
    }

    // Normal data row
    return [
      <TableCell key="sn">{index !== undefined ? index + 1 : "-"}</TableCell>,
      <TableCell key="name">{supplier.name}</TableCell>,
      <TableCell key="email">{supplier.email}</TableCell>,
      <TableCell key="status">{getStatusBadge(supplier.status)}</TableCell>,
      <TableCell key="action" className="text-center">
        <button className="cursor-pointer">
          <RiAddBoxFill className="text-text-400 size-4.5" />
        </button>
      </TableCell>,
    ];
  };

  return (
    <div className="space-y-4">
      <BaseTable
        columns={columns}
        renderRow={renderRow}
        data={[
          ...tableData,
          { sn: -1, name: "", email: "", status: "", isFormRow: true },
        ]}
      />
    </div>
  );
};

export default AddSupplierTable;
