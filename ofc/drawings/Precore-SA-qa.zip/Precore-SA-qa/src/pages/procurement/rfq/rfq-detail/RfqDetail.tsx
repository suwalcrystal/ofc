import ProcurementDetailHeader from "../../components/ProcurementDetailHeader";
import RfqDetailTabs from "../../components/tabs/RfqDetailTabs";

const RfqDetail = () => {
  return (
    <div>
      <ProcurementDetailHeader title="Request for Quote " />
      <RfqDetailTabs />
    </div>
  );
};
export default RfqDetail;
