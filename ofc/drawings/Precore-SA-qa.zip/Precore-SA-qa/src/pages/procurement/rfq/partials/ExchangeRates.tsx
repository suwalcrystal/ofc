import {
  Accordion,
  AccordionContent,
  AccordionItem,
} from "@/components/ui/accordion";
import { useState } from "react";
import { IoMdArrowDropdown, IoMdArrowDropup } from "react-icons/io";

const ExchangeRates = () => {
  const [isOpen, setIsOpen] = useState(false);

  const exchangeRates = [
    {
      baseCurrency: "AED",
      conversions: [
        { target: "EUR", rate: "0.239964", label: "AED to EUR" },
        { target: "EUR", rate: "0.239964", label: "AED to EUR" },
      ],
    },
    {
      baseCurrency: "EUR",
      conversions: [
        { target: "AED", rate: "4.167292", label: "EUR to AED" },
        { target: "AED", rate: "4.167292", label: "EUR to AED" },
      ],
    },
    {
      baseCurrency: "USD",
      conversions: [
        { target: "AED", rate: "3.673008", label: "USD to AED" },
        { target: "AED", rate: "3.673008", label: "USD to AED" },
      ],
    },
  ];

  const handleToggle = () => {
    setIsOpen((prev) => !prev);
  };

  return (
    <div className="my-6 bg-background-200 p-6 rounded-[0.5rem] shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
      <Accordion
        type="single"
        collapsible
        value={isOpen ? "exchange-rates" : ""}
        className="border border-boarder-300 rounded-xl p-4 "
      >
        <AccordionItem value="exchange-rates">
          <div
            onClick={handleToggle}
            className=" typography-paragraph-small font-medium text-text-500 hover:no-underline cursor-pointer flex items-center"
          >
            <span className="mr-1">
              {isOpen ? (
                <IoMdArrowDropup className="h-5 w-5 text-gray-500" />
              ) : (
                <IoMdArrowDropdown className="h-5 w-5 text-gray-500" />
              )}
            </span>
            Exchange Rate
          </div>

          <AccordionContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
              {exchangeRates.map((currency) => (
                <div key={currency.baseCurrency} className="space-y-4">
                  <div className="border border-boarder-300">
                    <h3 className="bg-[#F3F3F3]  p-4 typography-paragraph-small font-medium text-text-500 ">
                      {currency.baseCurrency}
                    </h3>

                    <div className="space-y-4 p-4 ">
                      {currency.conversions.map((conversion, index) => (
                        <div key={index} className="space-y-2">
                          <div className="typography-paragraph-small text-text-500">
                            {conversion.label}
                          </div>
                          <div className="bg-background-100 rounded-[8px] border border-boarder-300 p-3">
                            <div className="typography-paragraph-small text-text-400">
                              {conversion.rate}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

export default ExchangeRates;
