import AddButton from "@/components/headerBottom/AddButton";
import Search from "@/components/Search";
import { PATH } from "@/constants/paths";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import FilterProcurement from "../components/FilterProcurement";
import ToggleFilter from "../components/ToggleFilter";
import RFQTable from "./partials/RFQTable";

const RequestForQuotePage = () => {
  const navigate = useNavigate();

  const totalPendingCount = 5;
  const [filterType, setFilterType] = useState("all");

  return (
    <section>
      <div className="top-0 z-40 sticky pt-[0.88rem] flex items-center justify-between border-b-2 border-white pb-[0.88rem] bg-section-bg-400">
        <div className="flex items-center gap-[1.25rem]">
          <div className="flex items-center gap-4">
            <h3 className="text-text-500 typography-h3 font-semibold">
              Requests for Quote
            </h3>
            <Search />
          </div>

          <ToggleFilter
            filterType={filterType}
            setFilterType={setFilterType}
            totalPendingCount={totalPendingCount}
          />

          <FilterProcurement />
        </div>
        <AddButton
          title="Create"
          onClick={() => {
            navigate(`${PATH.procurement.createRFQ}`);
          }}
        />
      </div>

      <RFQTable filterType={filterType} />
    </section>
  );
};

export default RequestForQuotePage;
