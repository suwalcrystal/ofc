import Search from "@/components/Search";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuRadioGroup,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { IoMdArrowDropdown } from "react-icons/io";
import AddSupplierTable from "./AddSupplierTable";

const filterConfig = [
  {
    label: "Supplier Category",
    key: "supplier",
    options: [
      { label: "Planning", value: "planning" },
      { label: "Development", value: "development" },
      { label: "Testing", value: "testing" },
      { label: "Production", value: "production" },
    ],
  },
];

const AddSupplierToRFQ = () => {
  const [filters, setFilters] = useState<Record<string, string>>({});

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };
  return (
    <div>
      <div className="border-b-2 border-white py-[0.88rem] mb-6">
        <h3 className="text-text-500 typography-h3 font-semibold">
          Add Supplier to Request for Quote
        </h3>
      </div>

      <div className="bg-white rounded-[12px] shadow-md ">
        <div className="flex gap-4 items-center pb-4 p-5">
          <Search />

          {filterConfig.map((filter) => (
            <DropdownMenu key={filter.key}>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  className="cursor-pointer hover:bg-background-50 border-boarder-300 bg-background-300 py-[1.2rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium focus-visible:outline-none"
                >
                  {filter.label}
                  <IoMdArrowDropdown className="h-4 w-4 ml-auto" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0">
                <DropdownMenuRadioGroup
                  value={filters[filter.key] || ""}
                  onValueChange={(value) =>
                    handleFilterChange(filter.key, value)
                  }
                >
                  {filter.options.map((option) => (
                    <DropdownMenuItem
                      className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                      key={option.value}
                    >
                      {option.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuRadioGroup>
              </DropdownMenuContent>
            </DropdownMenu>
          ))}
        </div>

        <AddSupplierTable />
      </div>
    </div>
  );
};

export default AddSupplierToRFQ;
