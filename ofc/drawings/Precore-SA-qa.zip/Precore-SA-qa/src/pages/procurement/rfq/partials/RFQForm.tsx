import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useRFQForm } from "../hooks/useRFQForm";
import DatePickerField from "@/components/DatePickerField";
import SelectField from "@/components/SelectField";

const currencies = [
  { label: "AED", value: "aed" },
  { label: "Secondary currency", value: "secondary-currency" },
  { label: "Remote currency", value: "remote-currency" },
];

const projects = [
  { label: "Main project", value: "main-project" },
  { label: "Secondary project", value: "secondary-project" },
  { label: "Remote project", value: "remote-project" },
];

const budgetCategories = [
  { label: "Marketing", value: "marketing" },
  { label: "Operations", value: "operations" },
  { label: "Development", value: "development" },
  { label: "Sales", value: "sales" },
];

const RFQForm = () => {
  const { formik } = useRFQForm();

  return (
    <form
      onSubmit={formik.handleSubmit}
      className="space-y-6 bg-background-200 p-6 rounded-[0.5rem] shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]"
    >
      {/* First Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DatePickerField
          label="Delivery Date"
          value={formik.values.dueDate}
          onChange={(date) => formik.setFieldValue("dueDate", date)}
          touched={formik.touched.dueDate}
          error={formik.errors.dueDate}
        />

        <SelectField
          label="Project"
          name="project"
          value={formik.values.project}
          onChange={(val) => formik.setFieldValue("project", val)}
          options={projects}
          placeholder="Select Project"
          touched={formik.touched.project}
          error={formik.errors.project}
        />

        <SelectField
          label="Budget Spend Category"
          name="Budget Spend Category"
          value={formik.values.budgetCategory}
          onChange={(val) => formik.setFieldValue("budgetCategory", val)}
          options={budgetCategories}
          placeholder="Select Budget Category"
          touched={formik.touched.budgetCategory}
          error={formik.errors.budgetCategory}
        />
      </div>

      {/* Second Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <SelectField
          label="Currency"
          name="Currency"
          value={formik.values.currency}
          onChange={(val) => formik.setFieldValue("currency", val)}
          options={currencies}
          placeholder="Select Currency"
          touched={formik.touched.currency}
          error={formik.errors.currency}
        />

        <DatePickerField
          label="Date Needed in Site"
          value={formik.values.dateNeeded}
          onChange={(date) => formik.setFieldValue("dateNeeded", date)}
          touched={formik.touched.dateNeeded}
          error={formik.errors.dateNeeded}
        />

        <DatePickerField
          label="Delivery Leadtime"
          value={formik.values.deliveryLeadtime}
          onChange={(date) => formik.setFieldValue("deliveryLeadtime", date)}
          touched={formik.touched.deliveryLeadtime}
          error={formik.errors.deliveryLeadtime}
        />
      </div>

      {/* Note */}
      <div className="flex flex-col space-y-2">
        <label className="typography-paragraph-small font-medium text-text-500">
          Note <span className="text-error">*</span>
        </label>
        <Textarea
          name="note"
          value={formik.values.note}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          placeholder="Note..."
          className="h-[7rem] border-boarder-300 bg-background-100 rounded-[8px] focus-visible:border-green-500 focus-visible:ring-0"
        />
        {formik.touched.note && formik.errors.note && (
          <div className="text-sm text-error">{formik.errors.note}</div>
        )}
      </div>

      {/* Submit Button */}
      <Button
        type="submit"
        className="bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer"
      >
        Create
      </Button>
    </form>
  );
};

export default RFQForm;
