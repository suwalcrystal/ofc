import ExchangeRates from "./ExchangeRates";
import RFQForm from "./RFQForm";

const CreateRFQ = () => {
  return (
    <div>
      <div className="border-b-2 border-white py-[0.88rem] mb-6">
        <h3 className="text-text-500 typography-h3 font-semibold">
          Create Request for Quote
        </h3>
      </div>
      <RFQForm />
      <ExchangeRates />
    </div>
  );
};

export default CreateRFQ;
