import { FaLocationDot, FaPhone, FaUser } from "react-icons/fa6";
import { HiReceiptTax } from "react-icons/hi";
import { HiOutlineBuildingOffice2 } from "react-icons/hi2";
import { IoMdMail } from "react-icons/io";
import { MdPayment } from "react-icons/md";

export const useSupplierInfo = () => ({
  infoItems: [
    {
      label: "Company",
      icon: (
        <HiOutlineBuildingOffice2 className="size-[1.25rem] text-text-300" />
      ),
      value: "Office Suppliers Pro Inc.",
    },
    {
      label: "Contact Person",
      icon: <FaUser className="size-[1.25rem] text-text-300" />,
      value: "Michael Chen",
    },
    {
      label: "Email",
      icon: <IoMdMail className="size-[1.25rem] text-text-300" />,
      value: "mchen@officesupplierspro.com",
      isLink: true,
      href: "mailto:mchen@officesupplierspro.com",
    },
    {
      label: "Phone",
      icon: <FaPhone className="size-[1.25rem] text-text-300" />,
      value: "+1 (414) 555-7890",
    },
    {
      label: "Tax Number",
      icon: <HiReceiptTax className="size-[1.25rem] text-text-300" />,
      value: "943890",
    },
    {
      label: "Address",
      icon: <FaLocationDot className="size-[1.25rem] text-text-300" />,
      value: "456 Supplier Street, Oakland, CA 94612",
    },
    {
      label: "Payment Terms",
      icon: <MdPayment className="size-[1.25rem] text-text-300" />,
      value: "Net 30",
    },
  ],
  poStatus: "Pending",
});
