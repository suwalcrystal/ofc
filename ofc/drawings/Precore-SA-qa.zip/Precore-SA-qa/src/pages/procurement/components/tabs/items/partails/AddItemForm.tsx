import React from "react";
import {
  Formik,
  FieldArray,
  FormikProvider,
  FormikHelpers,
  FormikErrors,
} from "formik";
import { IoTrashOutline } from "react-icons/io5";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import SelectField from "@/components/SelectField";
import { IoIosAddCircleOutline } from "react-icons/io";

interface ProjectOption {
  label: string;
  value: string;
}

interface ItemFormValues {
  itemName: string;
  description: string;
  quantity: string;
  uom: string;
  unitRate: string;
}

interface FormValues {
  prId: string;
  items: ItemFormValues[];
}

interface PurchaseRequestItem {
  id: string;
  itemCode: string;
  itemName: string;
  description: string;
  quantity: number;
  uom: string;
  unitRate: number;
  totalCost: number;
}

interface PurchaseRequest {
  id: string;
  prId: string;
  isExpanded: boolean;
  items: PurchaseRequestItem[];
}

interface AddItemFormProps {
  formId: number;
  idx: number;
  defaultFormValues: FormValues;
  projects: ProjectOption[];
  setPurchaseRequests: React.Dispatch<React.SetStateAction<PurchaseRequest[]>>;
  setActiveForms: React.Dispatch<React.SetStateAction<number[]>>;
  submitFunctionsRef: React.MutableRefObject<(() => void)[]>;
}

const AddItemForm: React.FC<AddItemFormProps> = ({
  formId,
  idx,
  defaultFormValues,
  projects,
  setPurchaseRequests,
  setActiveForms,
  submitFunctionsRef,
}) => {
  const handleSubmit = (
    values: FormValues,
    { resetForm }: FormikHelpers<FormValues>
  ) => {
    const prId = values.prId.trim();
    if (!prId) return;

    const newItems: PurchaseRequestItem[] = values.items.map((item) => {
      const timestamp = Date.now().toString();
      return {
        id: timestamp + Math.random().toString(36).substr(2, 5),
        itemCode: `ITEM-${timestamp}`,
        itemName: item.itemName,
        description: item.description,
        quantity: Number(item.quantity),
        uom: item.uom,
        unitRate: Number(item.unitRate),
        totalCost: Number(item.quantity) * Number(item.unitRate),
      };
    });

    setPurchaseRequests((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        prId,
        isExpanded: true,
        items: newItems,
      },
    ]);

    resetForm();
    setActiveForms((forms) => forms.filter((id) => id !== formId));
  };

  return (
    <Formik<FormValues>
      key={formId}
      initialValues={defaultFormValues}
      onSubmit={handleSubmit}
    >
      {(formik) => {
        submitFunctionsRef.current[idx] = formik.submitForm;

        return (
          <FormikProvider value={formik}>
            <form
              className="p-6 border-t bg-gray-50"
              onSubmit={formik.handleSubmit}
            >
              {/* Header */}
              <div className="flex justify-end">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() =>
                    setActiveForms((forms) =>
                      forms.filter((id) => id !== formId)
                    )
                  }
                  className="text-red-500 hover:text-red-700"
                >
                  <IoTrashOutline className="w-5 h-5 mr-1" />
                  Delete PR
                </Button>
              </div>

              <FieldArray name="items">
                {({ push, remove }) => (
                  <>
                    {formik.values.items.map((item, index) => (
                      <div key={index}>
                        <div className="flex items-center justify-between">
                          <div className="mb-4">
                            <Input
                              name="prId"
                              placeholder="PR-001"
                              value={formik.values.prId}
                              onChange={formik.handleChange}
                              className="w-20"
                            />
                          </div>
                          <div className="mb-6">
                            <Button
                              type="button"
                              variant="ghost"
                              onClick={() =>
                                push({
                                  itemName: "",
                                  description: "",
                                  quantity: "",
                                  uom: "",
                                  unitRate: "",
                                })
                              }
                              className="text-green-500 hover:text-green-700"
                            >
                              <IoIosAddCircleOutline className="w-5 h-5 mr-1" />
                              Add Item
                            </Button>
                          </div>
                        </div>

                        <div className="grid grid-cols-12 gap-4 mb-6 items-start">
                          <div></div>
                          <div></div>

                          <div className="col-span-2">
                            <SelectField
                              name={`items[${index}].itemName`}
                              value={item.itemName}
                              onChange={(val: string) =>
                                formik.setFieldValue(
                                  `items[${index}].itemName`,
                                  val
                                )
                              }
                              options={projects}
                              placeholder="Select Item"
                              touched={formik.touched.items?.[index]?.itemName}
                              error={
                                typeof formik.errors.items?.[index] ===
                                  "object" &&
                                formik.errors.items?.[index] !== null
                                  ? (
                                      formik.errors.items[
                                        index
                                      ] as FormikErrors<ItemFormValues>
                                    ).itemName
                                  : undefined
                              }
                            />
                          </div>

                          <div className="col-span-3">
                            <Textarea
                              name={`items[${index}].description`}
                              placeholder="Description"
                              value={item.description}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              className="border-boarder-300 bg-background-100 rounded-[8px] focus-visible:border-green-500 focus-visible:ring-0 h-[6rem]"
                            />
                          </div>

                          <div className="col-span-2 flex border border-boarder-300 bg-background-100 rounded-[8px]">
                            <input
                              type="number"
                              name={`items[${index}].quantity`}
                              placeholder="QTY"
                              value={item.quantity}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              className="px-3 w-20 outline-none border-r"
                            />
                            <Select
                              value={item.uom}
                              onValueChange={(value) =>
                                formik.setFieldValue(
                                  `items[${index}].uom`,
                                  value
                                )
                              }
                            >
                              <SelectTrigger className="rounded-none border-0 w-24 px-3 shadow-none cursor-pointer">
                                <SelectValue placeholder="UOM" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pcs">pcs</SelectItem>
                                <SelectItem value="kg">kg</SelectItem>
                                <SelectItem value="m">m</SelectItem>
                                <SelectItem value="m2">m²</SelectItem>
                                <SelectItem value="m3">m³</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="col-span-2">
                            <Input
                              name={`items[${index}].unitRate`}
                              type="number"
                              placeholder="Unit Rate"
                              value={item.unitRate}
                              onChange={formik.handleChange}
                              onBlur={formik.handleBlur}
                              className="border-boarder-300 bg-background-100 rounded-[8px] focus-visible:border-green-500 focus-visible:ring-0"
                            />
                          </div>

                          <div className="col-span-1 flex items-center">
                            <Button
                              type="button"
                              variant="ghost"
                              onClick={() => remove(index)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <IoTrashOutline className="w-5 h-5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </FieldArray>
            </form>
          </FormikProvider>
        );
      }}
    </Formik>
  );
};

export default AddItemForm;
