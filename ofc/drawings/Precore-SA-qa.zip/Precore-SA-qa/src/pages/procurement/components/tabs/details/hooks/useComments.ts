export interface Comment {
  initials: string;
  name: string;
  dateTime: string;
  text: string;
}

export const useComments = () => {
  const comments: Comment[] = [
    {
      initials: "SJ",
      name: "Sarah Johnson",
      dateTime: "May 2, 2025 at 10:32 AM",
      text: "Please ensure all items are delivered on the same day to minimize disruption to the office renovation schedule.",
    },
  ];

  return { comments };
};
