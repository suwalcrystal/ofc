import TabNavigation from "@/components/TabNavigation";
import { useSearchParams } from "react-router-dom";
import Detail from "./tabs/details/Detail";
import ProcurementDocuments from "./tabs/documents/ProcurementDocuments";
import ProcurementHistory from "./tabs/history/ProcurementHistory";
import PrItemsTable from "./tabs/items/PrItemsTable";

const tabName = {
  detail: "Details",
  items: "Items",
  documents: "Documents",
  history: "History",
};

const PrDetailTabs = () => {
  const [params, setSearchParams] = useSearchParams();
  const tabValue = params.get("tab") || "";

  const activeTab = Object.values(tabName).includes(tabValue)
    ? tabValue
    : tabName.detail;

  const setActiveTab = (tab: string) => {
    setSearchParams({ tab });
  };

  const tabs = [
    { name: tabName.detail, current: activeTab === tabName.detail },
    { name: tabName.items, current: activeTab === tabName.items },
    { name: tabName.documents, current: activeTab === tabName.documents },
    { name: tabName.history, current: activeTab === tabName.history },
  ];

  const handleTabChange = (tabName: string) => {
    setActiveTab(tabName);
  };

  const renderContent = () => {
    switch (activeTab) {
      case tabName.detail:
        return <Detail />;
      case tabName.items:
        return <PrItemsTable />;
      case tabName.documents:
        return <ProcurementDocuments />;
      case tabName.history:
        return <ProcurementHistory />;

      default:
        return <Detail />;
    }
  };

  return (
    <>
      <TabNavigation tabs={tabs} onTabChange={handleTabChange} />
      {renderContent()}
    </>
  );
};

export default PrDetailTabs;
