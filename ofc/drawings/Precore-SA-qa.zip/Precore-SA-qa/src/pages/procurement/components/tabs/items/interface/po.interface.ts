export interface IPoItem {
  sn?: number;
  itemName: string;
  description: string;
  quantity: number;
  unitPrice: number;
  netAmount: number;
  vatPercent: string;
  grossAmount: string;
}
