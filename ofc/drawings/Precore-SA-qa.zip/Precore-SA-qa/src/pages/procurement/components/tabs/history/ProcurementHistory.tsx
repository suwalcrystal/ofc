import HistoryLog from "./partials/HistoryLog";

const ProcurementHistory = () => {
  return (
    <div>
      <HistoryLog />
    </div>
  );
};

export default ProcurementHistory;
