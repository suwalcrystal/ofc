// src/hooks/useInternalAttachments.ts

import { useRef, useState } from "react";

export interface FileItem {
  id: string;
  name: string;
  size: string;
  author: string;
  date: string;
  type: "excel" | "word" | "other";
}

export const useInternalAttachments = () => {
  const [files, setFiles] = useState<FileItem[]>([
    {
      id: "1",
      name: "Layout_Plan.xls",
      size: "120 KB",
      author: "John Cena",
      date: "Mar 29, 2024",
      type: "excel",
    },
    {
      id: "2",
      name: "Specs.docx",
      size: "120 KB",
      author: "John Cena",
      date: "Mar 29, 2024",
      type: "word",
    },
  ]);

  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = (newFiles: File[]) => {
    const processedFiles = newFiles.map((file, index) => ({
      id: Date.now().toString() + index,
      name: file.name,
      size: formatFileSize(file.size),
      author: "Current User",
      date: new Date().toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      }),
      type: getFileType(file.name),
    }));
    setFiles((prev) => [...prev, ...processedFiles]);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    handleFiles(Array.from(e.dataTransfer.files));
  };

  const handleDownload = (file: FileItem) => {
    console.warn("Downloading:", file.name);
    // You can replace this with actual download logic
  };

  const handleDelete = (fileId: string) => {
    setFiles((prev) => prev.filter((file) => file.id !== fileId));
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  return {
    files,
    isDragOver,
    fileInputRef,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    handleFileSelect,
    handleBrowseClick,
    handleDownload,
    handleDelete,
  };
};

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${Number.parseFloat((bytes / Math.pow(k, i)).toFixed(0))} ${sizes[i]}`;
};

const getFileType = (fileName: string): "excel" | "word" | "other" => {
  const extension = fileName.split(".").pop()?.toLowerCase();
  if (extension === "xls" || extension === "xlsx") return "excel";
  if (extension === "doc" || extension === "docx") return "word";
  return "other";
};
