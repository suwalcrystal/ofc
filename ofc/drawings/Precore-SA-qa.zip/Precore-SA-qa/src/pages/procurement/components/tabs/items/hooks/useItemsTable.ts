import { useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";

export interface LineItem {
  id: string;
  itemCode: string;
  itemName: string;
  description: string;
  quantity: number;
  uom: string;
  unitRate: number;
  totalCost: number;
}

export interface PurchaseRequest {
  id: string;
  prId: string;
  items: LineItem[];
  isExpanded: boolean;
}

interface ItemFormValues {
  items: {
    itemName: string;
    description: string;
    quantity: number | string;
    uom: string;
    unitRate: number | string;
  }[];
}

export const useItemsTable = () => {
  const isLoading = false;
  const [purchaseRequests, setPurchaseRequests] = useState<PurchaseRequest[]>(
    []
  );

  const toggleExpanded = (prId: string) => {
    setPurchaseRequests((prev) =>
      prev.map((pr) =>
        pr.id === prId ? { ...pr, isExpanded: !pr.isExpanded } : pr
      )
    );
  };

  const formik = useFormik<ItemFormValues>({
    initialValues: {
      items: [
        {
          itemName: "",
          description: "",
          quantity: "",
          uom: "",
          unitRate: "",
        },
      ],
    },
    validationSchema: Yup.object({
      items: Yup.array()
        .of(
          Yup.object().shape({
            itemName: Yup.string().required("Item name is required"),
            description: Yup.string().required("Description is required"),
            quantity: Yup.number()
              .typeError("Must be a number")
              .required("Quantity is required"),
            uom: Yup.string().required("UOM is required"),
            unitRate: Yup.number()
              .typeError("Must be a number")
              .required("Unit rate is required"),
          })
        )
        .min(1, "At least one item is required"),
    }),
    onSubmit: (values, { resetForm }) => {
      const newItems: LineItem[] = values.items.map((item) => {
        const timestamp = Date.now().toString();
        return {
          id: timestamp + Math.random().toString(36).substr(2, 5),
          itemCode: `ITEM-${timestamp}`,
          itemName: item.itemName,
          description: item.description,
          quantity: Number(item.quantity),
          uom: item.uom,
          unitRate: Number(item.unitRate),
          totalCost: Number(item.quantity) * Number(item.unitRate),
        };
      });

      setPurchaseRequests((prev) => {
        if (prev.length === 0) {
          return [
            {
              id: "pr-1",
              prId: "PR-001",
              items: newItems,
              isExpanded: true,
            },
          ];
        }

        const updated = [...prev];
        updated[0] = {
          ...updated[0],
          items: [...updated[0].items, ...newItems],
        };
        return updated;
      });

      resetForm();
    },
  });

  return {
    purchaseRequests,
    toggleExpanded,
    formik,
    setPurchaseRequests,
    isLoading,
  };
};
