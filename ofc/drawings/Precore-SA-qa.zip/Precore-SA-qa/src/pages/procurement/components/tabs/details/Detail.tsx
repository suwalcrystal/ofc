import ActivityLog from "./partials/ActivityLog";
import BudgetInformation from "./partials/BudgetInformation";
import CommentsNotes from "./partials/CommentsNotes";
import GeneralInformation from "./partials/GeneralInformation";
import InternalAttachments from "./partials/InternalAttachments";
import QuickActions from "./partials/QuickActions";
import SupplierDetail from "./partials/SupplierDetail";

const Detail = () => {
  return (
    <div className="flex gap-5">
      <div className="w-full lg:w-[75%]">
        <GeneralInformation />
        <div className="my-[1.25rem]">
          <BudgetInformation />
        </div>

        <SupplierDetail />

        <div className="my-[1.25rem]">
          <CommentsNotes />
        </div>
      </div>

      <div className="w-full lg:w-[30%] flex flex-col gap-6">
        <div>
          <QuickActions />
        </div>
        <div>
          <InternalAttachments />
        </div>
        <div>
          <ActivityLog />
        </div>
      </div>
    </div>
  );
};

export default Detail;
