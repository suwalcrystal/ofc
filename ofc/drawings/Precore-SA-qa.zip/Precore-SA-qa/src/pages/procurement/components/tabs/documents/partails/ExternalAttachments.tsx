import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getFileIcon } from "@/utils/getFileIcon";
import { Download, Trash2 } from "lucide-react";
import { IoMdCloudUpload } from "react-icons/io";
import { useInternalAttachments } from "../../details/hooks/useInternalAttachments";

const ExternalAttachments = () => {
  const {
    files,
    isDragOver,
    fileInputRef,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    handleFileSelect,
    handleBrowseClick,
    handleDownload,
    handleDelete,
  } = useInternalAttachments();

  return (
    <div className="rounded-[0.5rem] bg-background-200 p-5 shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
      <p className="text-text-500 typography-paragraph-regular font-medium pb-[0.87rem]">
        External Attachment
      </p>

      {/* Upload Area */}
      <Card
        className={`p-4 text-center transition-colors mb-[0.75rem] ${
          isDragOver
            ? "border-green-400 bg-green-50"
            : "border-boarder-300 hover:border-green-200"
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="flex flex-col items-center space-y-2">
          <IoMdCloudUpload className="w-8 h-8 text-text-300" />

          <p className="typography-paragraph-caption font-normal text-text-400">
            Drag files here or click to upload
          </p>

          <Button
            variant="outline"
            onClick={handleBrowseClick}
            className="px-6 bg-transparent cursor-pointer rounded-full typography-paragraph-caption text-text-400"
          >
            Browse File
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileSelect}
            className="hidden"
            accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.png,.jpg,.jpeg"
          />
        </div>
      </Card>

      {/* File List */}
      <div className="space-y-3">
        {files.map((file) => (
          <Card key={file.id} className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="shrink-0">{getFileIcon(file.type)}</div>
                <div>
                  <h3 className="font-semibold text-text-500 typography-paragraph-small pb-[0.38rem]">
                    {file.name}
                  </h3>
                  <p className="typography-paragraph-caption text-text-300">
                    {file.size} • {file.author} • {file.date}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 ">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDownload(file)}
                  className="text-gray-500 cursor-pointer rounded-full bg-section-bg-300 hover:text-gray-700 "
                >
                  <Download className="w-[0.7rem] h-[0.7rem]" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDelete(file.id)}
                  className="text-gray-500 cursor-pointer  rounded-full bg-section-bg-300 hover:text-red-600"
                >
                  <Trash2 className="w-[0.7rem] h-[0.7rem]" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ExternalAttachments;
