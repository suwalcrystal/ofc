import { TableCell } from "@/components/ui/table";
import { useState, useEffect } from "react";
import { useFormik } from "formik";

import BaseTable from "@/components/BaseTable";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { initialRfqData } from "../data/RfqItem.data";
import { IRfqItem } from "../interface/rfq.interface";
import { IColumn } from "@/interface/baseTable.interface";
import { Button } from "@/components/ui/button";

const columns: IColumn<IRfqItem>[] = [
  { key: "sn", label: "S.N", sortable: true },
  { key: "sku", label: "SKU", sortable: true },
  { key: "itemName", label: "Item Name", sortable: true },
  { key: "description", label: "Description", sortable: false },
  { key: "quantity", label: "Quantity", sortable: true },
  { key: "unit", label: "Unit (AED)", sortable: true },
  { key: "rejected", label: "Rejected", sortable: true },
  { key: "ordered", label: "Ordered", sortable: true },
  { key: "price", label: "Price (AED)", sortable: true },
  { key: "total", label: "Total AED", sortable: true },
  { key: "category", label: "Category", sortable: true },
  { key: "supplier", label: "Supplier", sortable: true },
  { key: "relatedDocument", label: "Related Document", sortable: false },
  { key: "deliveryDate", label: "Delivery Date", sortable: true },
];

const RfqItemTable = () => {
  const [rfqData, setRfqData] = useState<IRfqItem[]>(initialRfqData);

  const formik = useFormik<IRfqItem>({
    initialValues: {
      sn: rfqData.length + 1,
      sku: "",
      itemName: "",
      description: "",
      quantity: 0,
      unit: 0,
      rejected: 0,
      ordered: 0,
      price: 0,
      total: 0,
      category: "",
      supplier: "",
      relatedDocument: "",
      deliveryDate: "",
    },
    onSubmit: (values, { resetForm }) => {
      setRfqData((prev) => [...prev, { ...values, sn: prev.length + 1 }]);
      resetForm({
        values: {
          ...values,
          sn: rfqData.length + 2,
          sku: "",
          itemName: "",
          description: "",
          quantity: 0,
          unit: 0,
          rejected: 0,
          ordered: 0,
          price: 0,
          total: 0,
          category: "",
          supplier: "",
          relatedDocument: "",
          deliveryDate: "",
        },
      });
    },
  });

  useEffect(() => {
    formik.setFieldValue(
      "total",
      Number(formik.values.quantity) * Number(formik.values.price)
    );
  }, [formik.values.quantity, formik.values.price]);

  const renderRow = (item: IRfqItem, index: number): React.JSX.Element[] => [
    <TableCell key="sn" className="font-medium text-center">
      {index + 1}
    </TableCell>,
    <TableCell key="sku" className="font-medium text-center">
      {item.sku}
    </TableCell>,
    <TableCell key="itemName" className="font-semibold text-center">
      {item.itemName}
    </TableCell>,
    <TableCell key="description" className="font-medium text-center">
      {item.description}
    </TableCell>,
    <TableCell key="quantity" className="font-medium text-center">
      {item.quantity.toLocaleString()}
    </TableCell>,
    <TableCell key="unit" className="font-semibold text-center">
      <div>
        {item.unit.toFixed(2)}
        <div className="font-medium text-text-300 text-center typography-paragraph-caption pt-1">
          AED
        </div>
      </div>
    </TableCell>,
    <TableCell key="rejected" className="font-medium text-center">
      {item.rejected}
    </TableCell>,
    <TableCell key="ordered" className="font-medium text-center">
      {item.ordered}
    </TableCell>,
    <TableCell key="price" className="font-medium text-center">
      <div>
        {item.price.toFixed(2)}
        <div className="font-medium text-text-300 text-center typography-paragraph-caption pt-1">
          AED
        </div>
      </div>
    </TableCell>,
    <TableCell key="total" className="font-medium text-center">
      {item.total.toFixed(2)}
    </TableCell>,
    <TableCell key="category" className="font-semibold">
      {item.category}
    </TableCell>,
    <TableCell key="supplier" className="text-center">
      <div className="font-semibold">{item.supplier}</div>
      <div className="font-medium text-text-300 text-center typography-paragraph-caption pt-1">
        1 LDV
      </div>
    </TableCell>,
    <TableCell key="relatedDocument" className="font-semibold text-center">
      {item.relatedDocument}
    </TableCell>,
    <TableCell key="deliveryDate" className="font-semibold">
      {item.deliveryDate}
    </TableCell>,
  ];

  const renderNewRow = (): React.JSX.Element[] => [
    <TableCell key="sn" className="text-center text-red-500">
      {formik.values.sn}
    </TableCell>,
    <TableCell key="sku" className="text-center">
      <Input
        name="sku"
        value={formik.values.sku}
        onChange={formik.handleChange}
        className="h-8 text-sm"
      />
    </TableCell>,
    <TableCell key="itemName" className="text-center">
      <Input
        name="itemName"
        value={formik.values.itemName}
        onChange={formik.handleChange}
        className="h-8 text-sm"
      />
    </TableCell>,
    <TableCell key="description" className="text-center">
      <Input
        name="description"
        value={formik.values.description}
        onChange={formik.handleChange}
        className="h-8 text-sm"
      />
    </TableCell>,
    <TableCell key="quantity" className="text-center">
      <Input
        name="quantity"
        type="number"
        value={formik.values.quantity}
        onChange={formik.handleChange}
        className="h-8 text-sm text-center"
      />
    </TableCell>,
    <TableCell key="unit" className="text-center">
      <Input
        name="unit"
        type="number"
        value={formik.values.unit}
        onChange={formik.handleChange}
        className="h-8 text-sm text-center"
      />
    </TableCell>,
    <TableCell key="rejected" className="text-center">
      <Input
        name="rejected"
        type="number"
        value={formik.values.rejected}
        onChange={formik.handleChange}
        className="h-8 text-sm text-center"
      />
    </TableCell>,
    <TableCell key="ordered" className="text-center">
      <Input
        name="ordered"
        type="number"
        value={formik.values.ordered}
        onChange={formik.handleChange}
        className="h-8 text-sm text-center"
      />
    </TableCell>,
    <TableCell key="price" className="text-center">
      <Input
        name="price"
        type="number"
        value={formik.values.price}
        onChange={formik.handleChange}
        className="h-8 text-sm text-center"
      />
    </TableCell>,
    <TableCell key="total" className="text-center">
      <Input
        name="total"
        type="number"
        value={formik.values.total}
        readOnly
        className="h-8 text-sm text-center bg-gray-100"
      />
    </TableCell>,
    <TableCell key="category" className="text-center">
      <Select
        value={formik.values.category}
        onValueChange={(value) => formik.setFieldValue("category", value)}
      >
        <SelectTrigger className="h-8 text-sm">
          <SelectValue placeholder="Category" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="Not Set">Not Set</SelectItem>
          <SelectItem value="Construction">Construction</SelectItem>
          <SelectItem value="Materials">Materials</SelectItem>
          <SelectItem value="Tools">Tools</SelectItem>
        </SelectContent>
      </Select>
    </TableCell>,
    <TableCell key="supplier" className="text-center">
      <Input
        name="supplier"
        value={formik.values.supplier}
        onChange={formik.handleChange}
        className="h-8 text-sm"
      />
    </TableCell>,
    <TableCell key="relatedDocument" className="text-center">
      <Input
        name="relatedDocument"
        value={formik.values.relatedDocument}
        onChange={formik.handleChange}
        className="h-8 text-sm"
      />
    </TableCell>,
    <TableCell key="deliveryDate" className="text-center">
      <Input
        name="deliveryDate"
        type="date"
        value={formik.values.deliveryDate}
        onChange={formik.handleChange}
        className="h-8 text-sm"
      />
    </TableCell>,
  ];

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="bg-background-100">
        <BaseTable<IRfqItem>
          data={[...rfqData, formik.values]}
          columns={columns}
          renderRow={(item, index) =>
            typeof index === "number" && index === rfqData.length
              ? renderNewRow()
              : renderRow(item, index ?? 0)
          }
        />

        {/* Buttons below table */}
        <div className="flex justify-between items-center p-2">
          <div className="flex flex-wrap gap-3">
            <Button
              type="submit"
              className="cursor-pointer bg-green-600 px-6 py-2 rounded-full shadow text-white font-medium hover:bg-green-700"
            >
              Add
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 rounded-full shadow font-medium cursor-pointer"
            >
              Catalog
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 rounded-full shadow font-medium cursor-pointer"
            >
              Add Shipping
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 rounded-full shadow font-medium cursor-pointer"
            >
              Import Items
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 rounded-full shadow font-medium cursor-pointer"
            >
              Update Items
            </Button>
          </div>
          <div className="w-full max-w-[16rem] space-y-2 typography-paragraph-small text-text-400">
            <div className="flex justify-between items-center">
              <span>Subtotal</span>
              <div className="flex gap-2 font-semibold">
                <span className="typography-paragraph-caption text-text-300">
                  AED
                </span>
                <span className="text-text-500 font-semibold">1,620.00</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span>VAT (5%)</span>
              <div className="flex gap-2 font-semibold">
                <span className="typography-paragraph-caption text-text-300">
                  AED
                </span>
                <span className="text-text-500 font-semibold">81.00</span>
              </div>
            </div>

            <div className="flex justify-between items-center ">
              <span className="font-medium">Grand Total</span>
              <div className="flex gap-2 font-bold">
                <span className="typography-paragraph-caption text-text-300">
                  AED
                </span>
                <span className="text-text-500 font-semibold">1,701.00</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default RfqItemTable;
