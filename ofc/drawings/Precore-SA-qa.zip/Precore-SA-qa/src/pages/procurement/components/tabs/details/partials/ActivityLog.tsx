import { useActivityLog } from "../hooks/useActivityLog";

const ActivityLog = () => {
  const { activityLogData } = useActivityLog();

  return (
    <div>
      <div className="rounded-[0.5rem] bg-background-200 p-5 shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
        <p className="text-text-500 typography-paragraph-regular font-medium pb-[0.87rem]">
          Activity Log
        </p>

        <div className="flex flex-col gap-[1rem]">
          {activityLogData.map((activity, index) => (
            <div key={index} className="flex items-center gap-4">
              <div className="w-[1.125rem] h-[3.0625rem]">
                <img
                  src={activity.icon}
                  alt={activity.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="typography-paragraph-small font-semibold text-text-500 pb-[0.25rem]">
                  {activity.title}
                </p>
                <p className="typography-paragraph-small text-text-400">
                  {activity.name} •{" "}
                  <span className="typography-paragraph-caption">
                    {activity.timestamp}
                  </span>
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ActivityLog;
