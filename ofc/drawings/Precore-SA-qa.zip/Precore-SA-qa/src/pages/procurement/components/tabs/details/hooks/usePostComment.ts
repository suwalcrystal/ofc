import { useState } from "react";

export const usePostComment = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const postComment = async (comment: string) => {
    setIsSubmitting(true);
    try {
      // Simulate POST request (replace with actual fetch/axios call)
      await new Promise((resolve) => setTimeout(resolve, 1000));
      console.warn("Comment submitted:", comment);
    } catch (error) {
      console.error("Error posting comment:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return { postComment, isSubmitting };
};
