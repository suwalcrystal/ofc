import { FaLocationDot, FaUser } from "react-icons/fa6";
import { IoCalendarClear } from "react-icons/io5";
import { IoMdMail } from "react-icons/io";
import { TbTruckDelivery } from "react-icons/tb";

export const useGeneralInfo = () => {
  return [
    {
      label: "Requester",
      icon: <FaUser className="size-[1.25rem] text-text-300" />,
      value: "Sarah Johnson",
      valueClass: "text-text-400",
    },
    {
      label: "Email",
      icon: <IoMdMail className="size-[1.25rem] text-text-300" />,
      value: "sarah.johnson@company.com",
      valueClass: "text-blue",
      isLink: true,
      href: "mailto:sarah.johnson@company.com",
    },
    {
      label: "Shipping Address",
      icon: <FaLocationDot className="size-[1.25rem] text-text-300" />,
      value:
        "V6 Villa PLOT No: 3940509, AL THANYAH FOURTH, DUBAI, UNITED ARAB EMIRATES",
      valueClass: "text-text-400",
    },
    {
      label: "Creation Date",
      icon: <IoCalendarClear className="size-[1.25rem] text-text-300" />,
      value: "May 2, 2025",
      valueClass: "text-text-400",
    },
    {
      label: "Delivery Date",
      icon: <TbTruckDelivery className="size-[1.25rem] text-text-300" />,
      value: "May 15, 2025",
      valueClass: "text-text-400",
    },
  ];
};
