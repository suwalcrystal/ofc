export interface IRfqItem {
  sn?: number;
  sku: string;
  itemName: string;
  description: string;
  quantity: number;
  unit: number;
  rejected: number;
  ordered: number;
  price: number;
  total: number;
  category: string;
  supplier: string;
  relatedDocument: string;
  deliveryDate: string;
}
