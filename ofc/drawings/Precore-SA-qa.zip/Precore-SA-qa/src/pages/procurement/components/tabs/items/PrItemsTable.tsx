import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { useRef, useState } from "react";
import { FiEdit3 } from "react-icons/fi";
import { IoMdArrowDropdown, IoMdArrowDropup } from "react-icons/io";
import { useItemsTable } from "./hooks/useItemsTable";
import AddItemForm from "./partails/AddItemForm";

// Interfaces
export interface Item {
  id?: string;
  itemCode?: string;
  itemName: string;
  description: string;
  quantity: number | string;
  uom: string;
  unitRate: number | string;
  totalCost?: number;
}

export interface PurchaseRequest {
  id: string;
  prId: string;
  isExpanded: boolean;
  items: Item[];
}

export interface ProjectOption {
  label: string;
  value: string;
}

// Constants
const projects: ProjectOption[] = [
  { label: "Main project", value: "main-project" },
  { label: "Secondary project", value: "secondary-project" },
  { label: "Remote project", value: "remote-project" },
];

const defaultFormValues = {
  prId: "",
  items: [
    {
      itemName: "",
      description: "",
      quantity: "",
      uom: "",
      unitRate: "",
    },
  ],
};

const PrItemsTable = () => {
  const { purchaseRequests, toggleExpanded, setPurchaseRequests } =
    useItemsTable();

  const submitFunctionsRef = useRef<Array<() => void>>([]);

  const [activeForms, setActiveForms] = useState<number[]>([]);

  const submitAll = () => {
    submitFunctionsRef.current.forEach((submitFn) => submitFn && submitFn());
  };

  return (
    <div className="bg-white">
      {/* Table Header */}
      <div className="grid grid-cols-12 gap-4 p-4 border-b bg-[#E1E3E4] typography-paragraph-small font-medium text-gray-700">
        <div className="col-span-1">PR ID</div>
        <div className="col-span-1">Item Code</div>
        <div className="col-span-2">Item Name</div>
        <div className="col-span-3">Description</div>
        <div className="col-span-1">QTY & UOM</div>
        <div className="col-span-1">Unit Rate</div>
        <div className="col-span-2">Total Cost</div>
        <div className="col-span-1">Action</div>
      </div>

      {/* Existing PRs */}
      {purchaseRequests?.map((pr) => (
        <div key={pr.id} className="border-b last:border-b-0">
          {/* PR Header */}
          <div className="grid grid-cols-12 gap-4 p-4 bg-gray-50">
            <div className="col-span-1 flex items-center">
              <button
                onClick={() => toggleExpanded(pr.id)}
                className="flex  typography-paragraph-small font-medium cursor-pointer"
              >
                {pr.isExpanded ? (
                  <IoMdArrowDropdown className="w-4 h-4 mr-1 shrink-0" />
                ) : (
                  <IoMdArrowDropup className="w-4 h-4 mr-1 shrink-0" />
                )}
                {pr.prId}
              </button>
            </div>
            <div className="col-span-10"></div>
            <div className="col-span-1 flex justify-end gap-1.5">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 cursor-pointer"
              >
                <FiEdit3 className="h-4 w-4" />
                <span className="sr-only">Edit</span>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 cursor-pointer"
              >
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Delete</span>
              </Button>
            </div>
          </div>

          {/* Items */}
          {pr.isExpanded &&
            pr.items.map((item) => (
              <div
                key={item.id}
                className="grid grid-cols-12 gap-4 p-4 border-t"
              >
                <div className="col-span-1"></div>
                <div className="col-span-1 typography-paragraph-small">
                  {item.itemCode}
                </div>
                <div className="col-span-2 typography-paragraph-small">
                  {item.itemName}
                </div>
                <div className="col-span-3 typography-paragraph-small">
                  {item.description}
                </div>
                <div className="col-span-1 typography-paragraph-small">
                  {item.quantity} {item.uom}
                </div>
                <div className="col-span-1 typography-paragraph-small">
                  {Number(item.unitRate).toLocaleString()}
                </div>
                <div className="col-span-2 font-medium typography-paragraph-small">
                  {Number(item.totalCost).toLocaleString()}{" "}
                  <span className="text-text-300 typography-paragraph-caption">
                    AED
                  </span>
                </div>
                <div className="col-span-1"></div>
              </div>
            ))}
        </div>
      ))}

      {/* Add PR Forms */}
      {activeForms.map((formId, idx) => (
        <AddItemForm
          key={formId}
          formId={formId}
          idx={idx}
          defaultFormValues={defaultFormValues}
          projects={projects}
          setPurchaseRequests={setPurchaseRequests}
          setActiveForms={setActiveForms}
          submitFunctionsRef={submitFunctionsRef}
        />
      ))}

      {/* Submit All PRs and Add PR Buttons */}
      <div className="p-6 flex gap-4">
        {activeForms.length > 0 && (
          <Button
            onClick={submitAll}
            className="bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer"
          >
            Submit
          </Button>
        )}

        <Button
          onClick={() => setActiveForms((prev) => [...prev, Date.now()])}
          variant="outline"
          className="p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium border border-green-500 text-green-500 hover:bg-green-500 hover:text-white cursor-pointer"
        >
          Add PR
        </Button>
      </div>
    </div>
  );
};

export default PrItemsTable;
