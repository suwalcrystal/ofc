import { useActivityLog } from "../../details/hooks/useActivityLog";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuRadioGroup,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { IoMdArrowDropdown } from "react-icons/io";

const filterConfig = [
  {
    label: "Filter Type",
    key: "type",
    options: [
      { label: "Active", value: "active" },
      { label: "Inactive", value: "inactive" },
      { label: "Pending", value: "pending" },
    ],
  },
  {
    label: "Date",
    key: "date",
    options: [
      { label: "Planning", value: "planning" },
      { label: "Development", value: "development" },
      { label: "Testing", value: "testing" },
      { label: "Production", value: "production" },
    ],
  },
];

const HistoryLog = () => {
  const { activityLogData } = useActivityLog();
  const [filters, setFilters] = useState<Record<string, string>>({});

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  return (
    <div>
      <div className="rounded-[0.5rem] bg-background-200 p-5 shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
        <div className="flex items-center justify-between">
          <p className="text-text-500 typography-paragraph-regular font-medium pb-[0.87rem]">
            Activity Log
          </p>

          <div className="flex gap-2">
            {/* Dynamic Dropdown Filters */}
            {filterConfig.map((filter) => (
              <DropdownMenu key={filter.key}>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="cursor-pointer hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium focus-visible:outline-none"
                  >
                    {filter.label}
                    <IoMdArrowDropdown className="h-4 w-4 ml-auto" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0">
                  <DropdownMenuRadioGroup
                    value={filters[filter.key] || ""}
                    onValueChange={(value) =>
                      handleFilterChange(filter.key, value)
                    }
                  >
                    {filter.options.map((option) => (
                      <DropdownMenuItem
                        className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                        key={option.value}
                      >
                        {option.label}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuRadioGroup>
                </DropdownMenuContent>
              </DropdownMenu>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-[1rem] mt-2">
          {activityLogData.map((activity, index) => (
            <div key={index}>
              <div className="flex items-center justify-between ">
                <div className="flex items-center gap-4 ">
                  <div className="w-[1.125rem] h-[3.0625rem]">
                    <img
                      src={activity.icon}
                      alt={activity.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <p className="typography-paragraph-small font-semibold text-text-500 pb-[0.25rem]">
                      {activity.title}
                    </p>
                    <p className="typography-paragraph-small text-text-400">
                      {activity.name} •{" "}
                      <span className="typography-paragraph-caption">
                        {activity.timestamp}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="text-right w-1/2">
                  <p className="text-text-500 typography-paragraph-small font-semibold pb-[0.25rem]">
                    {activity?.date}
                  </p>
                  <p className="typography-paragraph-small text-text-400">
                    by {activity?.name}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HistoryLog;
