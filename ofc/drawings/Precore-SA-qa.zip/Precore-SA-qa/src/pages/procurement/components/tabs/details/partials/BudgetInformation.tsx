import { Link } from "react-router-dom";
import { Progress } from "@/components/ui/progress";
import { useBudgetInfo } from "../hooks/useBudgetInfo";

const BudgetInformation = () => {
  const { infoItems, budgetProgress } = useBudgetInfo();

  return (
    <div>
      <div className="rounded-[0.5rem] bg-background-200 p-5 shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
        <p className="text-text-500 typography-paragraph-regular font-medium pb-[0.87rem]">
          Budget Information
        </p>

        <div className="grid grid-cols-3 gap-[1.88rem]">
          {infoItems.map((item, index) => (
            <div key={index}>
              <p className="typography-paragraph-caption text-text-400 font-medium pb-[0.62rem]">
                {item.label}
              </p>
              <div className="flex items-center gap-[0.38rem]">
                <div>{item.icon}</div>
                {item.isLink ? (
                  <Link
                    to={item.href}
                    className="text-blue font-semibold typography-paragraph-small"
                  >
                    {item.value}
                  </Link>
                ) : (
                  <p className="text-text-400 font-semibold typography-paragraph-small">
                    {item.value}
                  </p>
                )}
              </div>
            </div>
          ))}

          {/* Budget Status */}
          <div className="col-span-3">
            <p className="typography-paragraph-caption text-text-400 font-medium pb-[0.62rem]">
              Budget Status
            </p>

            <div className="flex items-center justify-between pb-[0.62rem]">
              <p className="text-text-400 font-semibold typography-paragraph-small">
                <span className="typography-paragraph-caption font-medium">
                  AED
                </span>{" "}
                {budgetProgress.used} / {budgetProgress.total}
              </p>
              <p className="text-text-400 font-semibold typography-paragraph-small">
                {budgetProgress.percentage}%
              </p>
            </div>

            <Progress
              value={budgetProgress.percentage}
              className="h-[0.75rem] w-full rounded-md backdrop-blur-3xl *:bg-green-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetInformation;
