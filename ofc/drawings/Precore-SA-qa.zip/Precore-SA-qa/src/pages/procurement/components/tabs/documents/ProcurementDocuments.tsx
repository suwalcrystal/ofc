import InternalAttachments from "../details/partials/InternalAttachments";
import ExternalAttachments from "./partails/ExternalAttachments";

const ProcurementDocuments = () => {
  return (
    <div className="grid grid-cols-2 gap-6">
      <InternalAttachments />
      <ExternalAttachments />
    </div>
  );
};

export default ProcurementDocuments;
