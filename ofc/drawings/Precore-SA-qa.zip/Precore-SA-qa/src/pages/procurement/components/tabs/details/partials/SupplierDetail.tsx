import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { useSupplierInfo } from "../hooks/useSupplierInfo";

const SupplierDetail = () => {
  const { infoItems, poStatus } = useSupplierInfo();

  return (
    <div>
      <div className="rounded-[0.5rem] bg-background-200 p-5 shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
        <p className="text-text-500 typography-paragraph-regular font-medium pb-[0.87rem]">
          Supplier Information
        </p>

        <div className="grid grid-cols-3 gap-[1.88rem]">
          {infoItems.map((item, index) => (
            <div key={index}>
              <p className="typography-paragraph-caption text-text-400 font-medium pb-[0.62rem]">
                {item.label}
              </p>
              <div className="flex items-center gap-[0.38rem]">
                {item.icon}
                {item.isLink ? (
                  <Link
                    to={item.href}
                    className="text-blue font-semibold typography-paragraph-small"
                  >
                    {item.value}
                  </Link>
                ) : (
                  <p className="text-text-400 font-semibold typography-paragraph-small">
                    {item.value}
                  </p>
                )}
              </div>
            </div>
          ))}

          {/* PO Status */}
          <div>
            <p className="typography-paragraph-caption text-text-400 font-medium pb-[0.62rem]">
              PO Status
            </p>
            <div className="flex items-center gap-[0.38rem]">
              <Badge className="bg-text-50 text-text-300 hover:bg-text-100 cursor-pointer px-3 py-1 font-medium rounded-full">
                {poStatus}
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupplierDetail;
