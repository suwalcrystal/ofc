import { useState } from "react";

export const useQuickActions = () => {
  const [loading, setLoading] = useState<string | null>(null);

  const simulateAction = async (action: string) => {
    setLoading(action);
    try {
      // Simulate async behavior (replace with real API calls)
      await new Promise((resolve) => setTimeout(resolve, 1000));
      console.warn(`${action} action completed`);
    } catch (error) {
      console.error(`Error with ${action} action`, error);
    } finally {
      setLoading(null);
    }
  };

  return {
    loading,
    approve: () => simulateAction("Approve"),
    reject: () => simulateAction("Reject"),
    sendForRevision: () => simulateAction("Send for Revision"),
    editPO: () => simulateAction("Edit Purchase Order"),
    cancel: () => simulateAction("Cancel"),
  };
};
