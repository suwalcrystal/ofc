import { BsBank2 } from "react-icons/bs";
import { HiReceiptTax } from "react-icons/hi";
import { IoCalendarClear } from "react-icons/io5";
import { MdCalculate, MdOutlineCalculate } from "react-icons/md";
import { TbLink } from "react-icons/tb";

export const useBudgetInfo = () => ({
  infoItems: [
    {
      label: "Legal Entity",
      icon: <BsBank2 className="size-[1.25rem] text-text-300" />,
      value: "Company HQ - US Division",
    },
    {
      label: "Linked Budget",
      icon: <TbLink className="size-[1.25rem] text-text-300" />,
      value: "CAPEX-2025-OFFICE-RENO",
      isLink: true,
      href: "CAPEX-2025-OFFICE-RENO",
    },
    {
      label: "Delivery Period",
      icon: <IoCalendarClear className="size-[1.25rem] text-text-300" />,
      value: "Q2 2025",
    },
    {
      label: "Net Total",
      icon: <MdOutlineCalculate className="size-[1.25rem] text-text-300" />,
      value: "AED 82,788",
    },
    {
      label: "Tax Sum",
      icon: <HiReceiptTax className="size-[1.25rem] text-text-300" />,
      value: "AED 122",
    },
    {
      label: "Gross Total",
      icon: <MdCalculate className="size-[1.25rem] text-text-300" />,
      value: "AED 122",
    },
  ],
  budgetProgress: {
    used: "43,788",
    total: "82,900",
    percentage: 52,
  },
});
