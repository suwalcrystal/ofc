import { Button } from "@/components/ui/button";
import { useQuickActions } from "../hooks/useQuickActions";

const QuickActions = () => {
  const { loading, approve, reject, sendForRevision, editPO, cancel } =
    useQuickActions();

  return (
    <div>
      <div className="rounded-[0.5rem] bg-background-200 p-5 shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
        <p className="text-text-500 typography-paragraph-regular font-medium pb-[0.87rem]">
          QuickActions
        </p>

        <div className="space-y-4">
          {/* Approve / Reject */}
          <div className="flex rounded-full overflow-hidden">
            <Button
              onClick={approve}
              disabled={loading === "Approve"}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-none rounded-l-full cursor-pointer disabled:opacity-50"
              size="lg"
            >
              {loading === "Approve" ? "Approving..." : "Approve"}
            </Button>
            <Button
              onClick={reject}
              disabled={loading === "Reject"}
              className="flex-1 bg-red-500 hover:bg-red-600 text-white font-medium py-3 px-6 rounded-none rounded-r-full cursor-pointer disabled:opacity-50"
              size="lg"
            >
              {loading === "Reject" ? "Rejecting..." : "Reject"}
            </Button>
          </div>

          {/* Send for Revision */}
          <Button
            onClick={sendForRevision}
            disabled={loading === "Send for Revision"}
            variant="outline"
            className="w-full py-3 px-6 text-gray-700 bg-white border-gray-300 hover:bg-gray-50 rounded-full font-medium cursor-pointer disabled:opacity-50"
            size="lg"
          >
            {loading === "Send for Revision"
              ? "Sending..."
              : "Send for Revision"}
          </Button>

          {/* Edit Purchase Order */}
          <Button
            onClick={editPO}
            disabled={loading === "Edit Purchase Order"}
            variant="outline"
            className="w-full py-3 px-6 text-gray-700 bg-white border-gray-300 hover:bg-gray-50 rounded-full font-medium cursor-pointer disabled:opacity-50"
            size="lg"
          >
            {loading === "Edit Purchase Order"
              ? "Opening..."
              : "Edit Purchase Order"}
          </Button>

          {/* Cancel */}
          <Button
            onClick={cancel}
            disabled={loading === "Cancel"}
            variant="outline"
            className="w-full py-3 px-6 text-red-500 bg-white border-red-300 hover:bg-red-50 rounded-full font-medium cursor-pointer disabled:opacity-50"
            size="lg"
          >
            {loading === "Cancel" ? "Cancelling..." : "Cancel"}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuickActions;
