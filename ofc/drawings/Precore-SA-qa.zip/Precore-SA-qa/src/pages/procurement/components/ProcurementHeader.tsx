import AddButton from "@/components/headerBottom/AddButton";
import Search from "@/components/Search";
import FilterProcurement from "./FilterProcurement";
import ToggleFilter from "./ToggleFilter";
import { useNavigate } from "react-router-dom";
import { PATH } from "@/constants/paths";

interface Props {
  filterType: string;
  setFilterType: (type: string) => void;
}

const ProcurementHeader: React.FC<Props> = ({ filterType, setFilterType }) => {
  const navigate = useNavigate();
  const totalPendingCount = 5;

  return (
    <div>
      <div className="top-0 z-40 sticky pt-[0.88rem] flex items-center justify-between border-b-2 border-white pb-[0.88rem] bg-section-bg-400">
        <div className="flex items-center gap-[1.25rem]">
          <div className="flex items-center gap-4">
            <h3 className="text-text-500 typography-h3 font-semibold">
              Purchase Requests
            </h3>
            <Search />
          </div>

          <ToggleFilter
            filterType={filterType}
            setFilterType={setFilterType}
            totalPendingCount={totalPendingCount}
          />

          <FilterProcurement />
        </div>
        <AddButton
          title="Create"
          onClick={() => {
            navigate(`${PATH.procurement.createPR}`);
          }}
        />
      </div>
    </div>
  );
};

export default ProcurementHeader;
