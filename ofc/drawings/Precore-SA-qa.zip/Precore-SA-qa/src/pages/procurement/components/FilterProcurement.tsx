import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuRadioGroup,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { IoMdArrowDropdown } from "react-icons/io";
import { MdFilterList } from "react-icons/md";

// Dynamic filters definition
const filterConfig = [
  {
    label: "Requester",
    key: "requester",
    options: [
      { label: "Active", value: "active" },
      { label: "Inactive", value: "inactive" },
      { label: "Pending", value: "pending" },
    ],
  },
  {
    label: "Supplier",
    key: "supplier",
    options: [
      { label: "Planning", value: "planning" },
      { label: "Development", value: "development" },
      { label: "Testing", value: "testing" },
      { label: "Production", value: "production" },
    ],
  },
];

const FilterProcurement = () => {
  const [filters, setFilters] = useState<Record<string, string>>({});

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  return (
    <div className="flex flex-wrap gap-0.5">
      {/* Filter Button */}
      <Button
        variant="default"
        className="bg-green-600 hover:bg-green-700 rounded-full text-white flex items-center gap-1 py-[0.23rem] px-[0.75rem]"
      >
        <MdFilterList className="h-4 w-4" />
        <span className="typography-paragraph-small cursor-pointer">
          Filter
        </span>
      </Button>

      {/* Dynamic Dropdown Filters */}
      {filterConfig.map((filter) => (
        <DropdownMenu key={filter.key}>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              className="cursor-pointer hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium focus-visible:outline-none"
            >
              {filter.label}
              <IoMdArrowDropdown className="h-4 w-4 ml-auto" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-[6.875rem] p-0 shadow-[0px_0px_8.7px_0px rgba(0,0,0,0.16)] rounded-sm border-0">
            <DropdownMenuRadioGroup
              value={filters[filter.key] || ""}
              onValueChange={(value) => handleFilterChange(filter.key, value)}
            >
              {filter.options.map((option) => (
                <DropdownMenuItem
                  className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                  key={option.value}
                >
                  {option.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      ))}
    </div>
  );
};

export default FilterProcurement;
