import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Formik, Form, Field } from "formik";
import { useComments } from "../hooks/useComments";
import { usePostComment } from "../hooks/usePostComment";

const CommentsNotes = () => {
  const { comments } = useComments();
  const { postComment, isSubmitting } = usePostComment();

  return (
    <div>
      <div className="rounded-[0.5rem] bg-background-200 p-5 shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
        <p className="text-text-500 typography-paragraph-regular font-medium pb-[0.87rem]">
          Comments & Notes
        </p>

        {/* Existing Comments */}
        {comments.map((comment, idx) => (
          <div className="flex gap-[0.88rem] mb-6" key={idx}>
            <div className="flex justify-center items-center bg-green-500 text-white rounded-full w-[2.5rem] h-[2.5rem] typography-paragraph-small font-semibold">
              {comment.initials}
            </div>
            <div>
              <div className="flex items-center gap-[0.23rem]">
                <p className="typography-paragraph-small font-semibold text-text-500">
                  {comment.name}
                </p>
                <span className="text-text-400 font-normal text-[0.625rem] mt-1">
                  {comment.dateTime}
                </span>
              </div>
              <p className="typography-paragraph-small text-text-400 font-normal mt-[0.25rem]">
                {comment.text}
              </p>
            </div>
          </div>
        ))}

        {/* Comment Form */}
        <Formik
          initialValues={{ comment: "" }}
          onSubmit={async (values, { resetForm }) => {
            await postComment(values.comment);
            resetForm();
          }}
        >
          {({ handleSubmit }) => (
            <Form onSubmit={handleSubmit}>
              <p className="typography-paragraph-small text-text-500 font-medium pb-2">
                Add a comment
              </p>

              <Field
                as={Textarea}
                name="comment"
                className="focus-visible:border-green-100 focus:ring-0 focus-visible:ring-0 h-28 resize-y"
              />

              <div className="flex justify-end">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="mt-[0.88rem] bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? "Submitting..." : "Add Comment"}
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default CommentsNotes;
