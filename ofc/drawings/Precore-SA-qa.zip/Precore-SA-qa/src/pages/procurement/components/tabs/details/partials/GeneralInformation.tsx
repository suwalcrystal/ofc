import { Link } from "react-router-dom";
import { useGeneralInfo } from "../hooks/useGeneralInfo";

const GeneralInformation = () => {
  const generalInfoData = useGeneralInfo();

  return (
    <div>
      <div className="rounded-[0.5rem] bg-background-200 p-5 shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]">
        <p className="text-text-500 typography-paragraph-regular font-medium pb-[0.87rem]">
          General Information
        </p>

        <div className="grid grid-cols-3 gap-[1.88rem]">
          {generalInfoData.map((item, index) => (
            <div key={index}>
              <p className="typography-paragraph-caption text-text-400 font-medium pb-[0.62rem]">
                {item.label}
              </p>
              <div className="flex items-center gap-[0.38rem]">
                <div className="shrink-0">{item.icon}</div>
                {item.isLink ? (
                  <Link
                    to={item.href}
                    className={`${item.valueClass} font-semibold typography-paragraph-small `}
                  >
                    {item.value}
                  </Link>
                ) : (
                  <p
                    className={`${item.valueClass} font-semibold typography-paragraph-small`}
                  >
                    {item.value}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default GeneralInformation;
