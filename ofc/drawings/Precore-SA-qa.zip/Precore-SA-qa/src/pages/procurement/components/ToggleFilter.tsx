import { cn } from "@/lib/utils";

interface ToggleFilterProps {
  filterType: string;
  setFilterType: (type: string) => void;
  totalPendingCount: number;
}

const ToggleFilter: React.FC<ToggleFilterProps> = ({
  filterType,
  setFilterType,
  totalPendingCount,
}) => {
  const options = [
    { label: "All Records", value: "all" },
    {
      label: (
        <div className="flex items-center gap-2">
          Pending
          <div className="w-4 h-4 bg-gray-200 rounded-full flex items-center justify-center">
            <span className="text-xs font-semibold text-gray-700">
              {totalPendingCount}
            </span>
          </div>
        </div>
      ),
      value: "pending",
    },
  ];

  return (
    <div className="flex items-center p-1 border border-gray-200 rounded-full bg-white">
      {options.map(({ label, value }) => (
        <button
          key={value}
          onClick={() => setFilterType(value)}
          className={cn(
            "px-3 py-1 text-sm font-medium rounded-full transition-all cursor-pointer",
            filterType === value
              ? "bg-green-50 text-green-500"
              : "bg-transparent text-gray-600 hover:bg-gray-100"
          )}
          aria-pressed={filterType === value}
        >
          {label}
        </button>
      ))}
    </div>
  );
};

export default ToggleFilter;
