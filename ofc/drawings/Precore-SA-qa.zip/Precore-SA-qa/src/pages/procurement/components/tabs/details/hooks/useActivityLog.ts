import activityblue from "@/assets/icons/activity-blue.svg";
import activitygreen from "@/assets/icons/activity-green.svg";
import activitypurple from "@/assets/icons/activity-purple.svg";
import activityyellow from "@/assets/icons/activity-yellow.svg";

export interface ActivityLogItem {
  title: string;
  name: string;
  timestamp: string;
  icon: string;
  date?: string;
}

export const useActivityLog = () => {
  const activityLogData: ActivityLogItem[] = [
    {
      title: "Purchase Order Created",
      name: "Sarah Johnson",
      timestamp: "Mar 29, 2024 at 09:50 AM",
      icon: activityblue,
      date: "Today, 14:30",
    },
    {
      title: "Approval from PM",
      name: "Emily Smith",
      timestamp: "Mar 29, 2024 at 09:50 AM",
      icon: activitygreen,
      date: "Today, 14:30",
    },
    {
      title: "Approval from Owner",
      name: "Santosh Shrestha",
      timestamp: "Mar 29, 2024 at 09:50 AM",
      icon: activitypurple,
      date: "Today, 14:30",
    },
    {
      title: "Purchase Order Placed",
      name: "Sarah Johnson",
      timestamp: "Mar 29, 2024 at 09:50 AM",
      icon: activityyellow,
      date: "Today, 14:30",
    },
  ];

  return { activityLogData };
};
