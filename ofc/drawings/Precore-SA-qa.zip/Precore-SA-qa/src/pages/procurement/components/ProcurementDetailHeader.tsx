import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { useState } from "react";

interface ProcurementDetailHeaderProps {
  title: string;
}

const ProcurementDetailHeader: React.FC<ProcurementDetailHeaderProps> = ({
  title,
}) => {
  const filter = {
    key: "status",
    label: "Status",
    options: [
      { label: "Actions", value: "actions" },
      { label: "Pending", value: "pending" },
      { label: "Approved", value: "approved" },
    ],
  };

  const [filters, setFilters] = useState({
    status: "actions",
  });

  const handleFilterChange = (value: string) => {
    setFilters((prev) => ({ ...prev, status: value }));
  };

  return (
    <div className="top-0 z-40 sticky pt-[0.88rem] bg-section-bg-400">
      <div className=" flex items-center justify-between border-b-2 border-white pb-[0.88rem]">
        <div className="flex items-baseline gap-2">
          <div className="flex items-baseline gap-1 text-text-500 font-semibold">
            <h3 className="typography-h3 font-semibold">{title}</h3>
            <span className="typography-paragraph-small leading-[120%]">
              #PR0012
            </span>
          </div>
          <div>
            <Badge
              variant="outline"
              className={`bg-text-50 text-text-300 hover:bg-text-100 border-0 px-2 py-1.5 rounded-full typography-paragraph-caption font-semibold`}
            >
              Pending
            </Badge>
          </div>
        </div>

        <div className="flex items-baseline gap-[0.68rem]">
          <Button
            type="submit"
            className="bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 cursor-pointer"
          >
            Send to Supplier
          </Button>

          <Select value={filters.status} onValueChange={handleFilterChange}>
            <SelectTrigger className="cursor-pointer hover:bg-background-50 border-boarder-300 bg-background-300 p-[1.25rem] rounded-full typography-paragraph-small text-text-400 font-medium focus-visible:outline-none">
              <SelectValue placeholder={filter.label} />
            </SelectTrigger>
            <SelectContent className="w-[6.875rem]">
              {filter.options.map((option) => (
                <SelectItem
                  key={option.value}
                  value={option.value}
                  className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem]"
                >
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};

export default ProcurementDetailHeader;
