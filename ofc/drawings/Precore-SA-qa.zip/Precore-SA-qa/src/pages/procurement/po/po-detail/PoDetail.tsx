import ProcurementDetailHeader from "../../components/ProcurementDetailHeader";
import PoDetailTabs from "./PoDetailTabs";

const PoDetail = () => {
  return (
    <div>
      <ProcurementDetailHeader title="Purchase Order" />
      <PoDetailTabs />
    </div>
  );
};

export default PoDetail;
