import { Eye } from "lucide-react";
import React, { JSX } from "react";
import { Link } from "react-router-dom";

import BaseTable from "@/components/BaseTable";
import CustomPagination from "@/components/CustomPagination";
import { TableCell } from "@/components/ui/table";
import { PATH } from "@/constants/paths";
import { getStatusBadge } from "@/utils/getStatusBadge";

import { IColumn } from "@/interface/baseTable.interface";
import { extendedPRData } from "../data/poData";
import { usePOTable } from "../hooks/usePo.hook";
import { IPo } from "../interface/Ipo.interface";

interface POTableProps {
  filterType: string;
}

const POTable: React.FC<POTableProps> = ({ filterType }) => {
  const isBulkMode = filterType === "pending";

  const filteredData = isBulkMode
    ? extendedPRData.filter((item) =>
        item.status.some((s) => s.toLowerCase() === "pending")
      )
    : extendedPRData;

  const {
    currentItems,
    currentPage,
    setCurrentPage,
    itemsPerPage,
    setItemsPerPage,
    totalItems,
    handleSelectItem,
    handleSelectAll,
    handleApprove,
    handleReject,
    selectedItems,
  } = usePOTable(filteredData);

  const columns: IColumn<IPo>[] = [
    ...(isBulkMode
      ? [
          {
            key: "select" as keyof IPo,
            label: "",
            sortable: false,
          },
        ]
      : []),
    { key: "id", label: "ID", sortable: true },
    { key: "status", label: "Status", sortable: true },
    { key: "type", label: "Type", sortable: true },
    { key: "LocationPurchaser", label: "Location / Purchaser", sortable: true },
    { key: "OtherDetails", label: "Other Details", sortable: false },
    { key: "GrossTotal", label: "Total", sortable: true },
    { key: "RelatedDocuments", label: "Related Documents", sortable: false },
    { key: "DeliveryDate", label: "Delivery Date", sortable: true },
    {
      key: "action" as keyof IPo,
      label: "Action",
      sortable: false,
    },
  ];

  const renderRow = (item: IPo): JSX.Element[] => [
    ...(isBulkMode
      ? [
          <TableCell key={`checkbox-${item.id}`}>
            <input
              type="checkbox"
              className="h-4 w-4 rounded border-gray-300"
              checked={selectedItems.includes(item.id)}
              onChange={() => handleSelectItem(item.id)}
              aria-label={`Select ${item.id}`}
            />
          </TableCell>,
        ]
      : []),
    <TableCell key={`id-${item.id}`} className="align-top">
      <Link
        to={`${PATH.procurement.poDetail}/${item.id}`}
        className="font-medium"
      >
        {item.id}
      </Link>
    </TableCell>,
    <TableCell
      key={`status-${item.id}`}
      className="font-medium align-top space-y-1 flex flex-col "
    >
      {item.status.map((s, index) => (
        <span key={index}>{getStatusBadge(s)}</span>
      ))}
    </TableCell>,

    <TableCell key={`type-${item.id}`} className="font-medium align-top ">
      {item.type}
    </TableCell>,
    <TableCell key={`location-${item.id}`} className="font-medium align-top ">
      <div className="pb-[0.31rem]">{item.LocationPurchaser}</div>
      {item.requesterEmail && (
        <div className="text-text-300 text-sm truncate">
          {item.requesterEmail}
        </div>
      )}
    </TableCell>,
    <TableCell
      key={`details-${item.id}`}
      className=" font-medium align-top space-y-1"
    >
      <div className="typography-paragraph-caption text-text-300">
        Payment Terms
      </div>
      <div>{item.OtherDetails.paymentTerms}</div>
      <div className="typography-paragraph-caption text-text-300">
        Supplier Reference No.
      </div>
      <div>{item.OtherDetails.supplierReferenceNo}</div>
      <div className="typography-paragraph-caption text-text-300">
        Types Of Work
      </div>
      <div>{item.OtherDetails.typesOfWork}</div>
      <div className="typography-paragraph-caption text-text-300">
        Date Needed on Site
      </div>
      <div>{item.OtherDetails.dateNeeded}</div>
      <div className="typography-paragraph-caption text-text-300">
        Delivery Lead Time
      </div>
      <div>{item.OtherDetails.DeliveryLead}</div>
    </TableCell>,
    <TableCell
      key={`total-${item.id}`}
      className="font-medium align-top items-start"
    >
      <div className="font-semibold"> {item.GrossTotal}</div>
      <div className="typography-paragraph-caption text-text-300 pt-1">AED</div>
    </TableCell>,
    <TableCell
      key={`docs-${item.id}`}
      className="font-medium align-top items-start"
    >
      <div className="text-sm text-text-300 pb-1">Purchase Order</div>
      <Link to="#" className="text-blue hover:underline text-sm">
        {item.RelatedDocuments}
      </Link>
    </TableCell>,
    <TableCell
      key={`delivery-${item.id}`}
      className="font-medium align-top items-start"
    >
      {item.DeliveryDate}
    </TableCell>,
    <TableCell
      key={`actions-${item.id}`}
      className="font-medium align-top items-start"
    >
      <div className="flex justify-center space-x-1">
        <button
          className="text-text-300 hover:text-text-500 cursor-pointer"
          aria-label="View"
        >
          <Eye className="h-4.5 w-4.5" />
        </button>
      </div>
    </TableCell>,
  ];

  return (
    <div className="my-2.5 space-y-4">
      {isBulkMode && currentItems.length > 0 && (
        <div className="flex gap-2 items-center">
          <button
            onClick={handleApprove}
            disabled={selectedItems.length === 0}
            className="bg-green-600 hover:bg-green-700 text-white py-1.5 px-4 rounded-full font-medium align-top disabled:opacity-50"
          >
            Approve
          </button>
          <button
            onClick={handleReject}
            disabled={selectedItems.length === 0}
            className="bg-red-500 hover:bg-red-600 text-white py-1.5 px-4 rounded-full font-medium align-top disabled:opacity-50"
          >
            Reject
          </button>
        </div>
      )}

      <BaseTable<IPo>
        columns={columns}
        data={currentItems}
        renderRow={renderRow}
        tableHeight="69vh"
        selectAllCheckbox={
          isBulkMode && (
            <label className="flex items-center justify-center">
              <input
                type="checkbox"
                className="h-4 w-4 cursor-pointer"
                checked={
                  selectedItems.length > 0 &&
                  selectedItems.length === currentItems.length
                }
                onChange={handleSelectAll}
              />
            </label>
          )
        }
      />

      <CustomPagination
        currentPage={currentPage}
        itemsPerPage={itemsPerPage}
        totalItems={totalItems}
        setCurrentPage={setCurrentPage}
        setItemsPerPage={setItemsPerPage}
      />
    </div>
  );
};

export default POTable;
