import React, { useState, useEffect } from "react";
import { useFormik } from "formik";
import { TableCell } from "@/components/ui/table";
import BaseTable from "@/components/BaseTable";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { IColumn } from "@/interface/baseTable.interface";
import { IPoItem } from "../../components/tabs/items/interface/po.interface";
import { initialPoData } from "../../components/tabs/items/data/poItems.data";

const columns: IColumn<IPoItem>[] = [
  { key: "sn", label: "S.N", sortable: true },
  { key: "itemName", label: "Item Name", sortable: true },
  {
    key: "description",
    label: "Description",
    sortable: false,
  },
  { key: "quantity", label: "Quantity", sortable: true },
  { key: "unitPrice", label: "Unit Price (AED)", sortable: true },
  { key: "netAmount", label: "Net Amount (AED)", sortable: true },
  { key: "vatPercent", label: "VAT (%)", sortable: true },
  { key: "grossAmount", label: "Gross Amount (AED)", sortable: true },
];

const PoItemTable = () => {
  const [items, setItems] = useState<IPoItem[]>(initialPoData);

  const formik = useFormik<IPoItem>({
    initialValues: {
      sn: items.length + 1,
      itemName: "",
      description: "",
      quantity: 0,
      unitPrice: 0,
      netAmount: 0,
      vatPercent: "5.00",
      grossAmount: "0.00",
    },
    onSubmit: (values, { resetForm }) => {
      setItems((prev) => [...prev, { ...values, sn: prev.length + 1 }]);
      resetForm({
        values: {
          ...values,
          sn: items.length + 2,
          itemName: "",
          description: "",
          quantity: 0,
          unitPrice: 0,
          netAmount: 0,
          vatPercent: "5.00",
          grossAmount: "0.00",
        },
      });
    },
  });

  // Auto-calculate net & gross amounts
  useEffect(() => {
    const net = formik.values.quantity * formik.values.unitPrice;
    const vat = (net * parseFloat(formik.values.vatPercent || "0")) / 100;
    const gross = net + vat;

    formik.setFieldValue("netAmount", net);
    formik.setFieldValue("grossAmount", gross.toFixed(2));
  }, [
    formik.values.quantity,
    formik.values.unitPrice,
    formik.values.vatPercent,
  ]);

  const renderRow = (item: IPoItem, index: number): React.JSX.Element[] => [
    <TableCell key="sn" className="font-medium p-4 ">
      {index + 1}
    </TableCell>,
    <TableCell key="itemName" className="font-medium p-4 ">
      {item.itemName}
    </TableCell>,
    <TableCell key="description" className="font-medium p-4  ">
      {item.description}
    </TableCell>,
    <TableCell key="quantity" className="font-medium p-4 ">
      {item.quantity}
    </TableCell>,
    <TableCell key="unitPrice" className="font-medium p-4 ">
      {item.unitPrice.toFixed(2)} AED
    </TableCell>,
    <TableCell key="netAmount" className="font-medium p-4 ">
      {item.netAmount.toFixed(2)} AED
    </TableCell>,
    <TableCell key="vatPercent" className="font-medium p-4 ">
      {item.vatPercent}%
    </TableCell>,
    <TableCell key="grossAmount" className="font-medium p-4 ">
      {parseFloat(item.grossAmount).toFixed(2)} AED
    </TableCell>,
  ];

  const renderNewRow = (): React.JSX.Element[] => [
    <TableCell key="sn" className="font-medium p-4  text-error">
      {formik.values.sn}
    </TableCell>,
    <TableCell key="itemName" className="font-medium p-4 ">
      <Input
        name="itemName"
        value={formik.values.itemName}
        onChange={formik.handleChange}
        className="h-8 text-sm"
      />
    </TableCell>,
    <TableCell key="description" className="font-medium p-4  ">
      <Input
        name="description"
        value={formik.values.description}
        onChange={formik.handleChange}
        className="h-8 text-sm"
      />
    </TableCell>,
    <TableCell key="quantity" className="font-medium p-4 ">
      <Input
        name="quantity"
        type="number"
        value={formik.values.quantity}
        onChange={formik.handleChange}
        className="h-font-medium p-4 "
      />
    </TableCell>,
    <TableCell key="unitPrice" className="font-medium p-4 ">
      <Input
        name="unitPrice"
        type="number"
        value={formik.values.unitPrice}
        onChange={formik.handleChange}
        className="h-font-medium p-4 "
      />
    </TableCell>,
    <TableCell key="netAmount" className="font-medium p-4 ">
      <Input
        value={formik.values.netAmount.toFixed(2)}
        readOnly
        className="h-font-medium p-4  bg-gray-100"
      />
    </TableCell>,
    <TableCell key="vatPercent" className="font-medium p-4 ">
      <Input
        name="vatPercent"
        type="number"
        value={formik.values.vatPercent}
        onChange={formik.handleChange}
        className="h-font-medium p-4 "
      />
    </TableCell>,
    <TableCell key="grossAmount" className="font-medium p-4 ">
      <Input
        value={formik.values.grossAmount}
        readOnly
        className="h-font-medium p-4  bg-gray-100"
      />
    </TableCell>,
  ];

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="bg-background-100 p-4">
        <BaseTable<IPoItem>
          columns={columns}
          data={[...items, formik.values]}
          renderRow={(item, index) =>
            index === items.length
              ? renderNewRow()
              : renderRow(item, typeof index === "number" ? index : 0)
          }
        />
        {/* Buttons below table */}
        <div className="flex justify-between items-center p-2">
          <div className="flex flex-wrap gap-3">
            <Button
              type="submit"
              className="cursor-pointer bg-green-600 px-6 py-2 rounded-full shadow text-white font-medium p-4 hover:bg-green-700"
            >
              Add
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 rounded-full shadow font-medium p-4 cursor-pointer"
            >
              Catalog
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 rounded-full shadow font-medium p-4 cursor-pointer"
            >
              Add Shipping
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 rounded-full shadow font-medium p-4 cursor-pointer"
            >
              Import Items
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 rounded-full shadow font-medium p-4 cursor-pointer"
            >
              Update Items
            </Button>
          </div>
          <div className="w-full max-w-[16rem] space-y-2 typography-paragraph-small text-text-400">
            <div className="flex justify-between items-center">
              <span>Subtotal</span>
              <div className="flex gap-2 font-semibold">
                <span className="typography-paragraph-caption text-text-300">
                  AED
                </span>
                <span className="text-text-500 font-semibold">1,620.00</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span>VAT (5%)</span>
              <div className="flex gap-2 font-semibold">
                <span className="typography-paragraph-caption text-text-300">
                  AED
                </span>
                <span className="text-text-500 font-semibold">81.00</span>
              </div>
            </div>

            <div className="flex justify-between items-center ">
              <span className="font-medium p-4">Grand Total</span>
              <div className="flex gap-2 font-bold">
                <span className="typography-paragraph-caption text-text-300">
                  AED
                </span>
                <span className="text-text-500 font-semibold">1,701.00</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default PoItemTable;
