import { IPo } from "../interface/Ipo.interface";

const poData: IPo[] = [
  {
    id: "#790955",
    status: ["Approved", "Not Received", "Not Billed", "Sent"],
    type: "Equipment",
    LocationPurchaser: "LDV Workshop",
    requesterEmail: "reyo.suman@ldv.ae",
    OtherDetails: {
      paymentTerms: "BLUE FIN HEAVY EQUIPMENT RENTAL L.L.C",
      supplierReferenceNo: "Quotation No : 20095033 (Dated 05-May-2025)",
      typesOfWork: "Supply Of Hanging Clamp with Rubber",
      dateNeeded: "25.04.2025",
      DeliveryLead: "3 days",
    },
    Supplier: "BLUE FIN HEAVY EQUIPMENT RENTAL L.L.C",
    GrossTotal: "0.00",
    RelatedDocuments: "344",
    DeliveryDate: "21.04.2025",
  },
  {
    id: "#790956",
    status: ["Approved", "Not Billed"],
    type: "Materials",
    LocationPurchaser: "Warehouse A",
    requesterEmail: "ali.hassan@ldv.ae",
    OtherDetails: {
      paymentTerms: "BLUE FIN HEAVY EQUIPMENT RENTAL L.L.C",
      supplierReferenceNo: "Quotation No : 20095033 (Dated 05-May-2025)",
      typesOfWork: "Supply Of Hanging Clamp with Rubber",
      dateNeeded: "25.04.2025",
      DeliveryLead: "3 days",
    },
    Supplier: "AL BURAQ SUPPLIES",
    GrossTotal: "1,250.00",
    RelatedDocuments: "112",
    DeliveryDate: "24.04.2025",
  },
  {
    id: "#790957",
    status: ["Approved", "Not Received", "Sent"],
    type: "Subcontractor",
    LocationPurchaser: "Main Office",
    requesterEmail: "mariam.yousuf@ldv.ae",
    OtherDetails: {
      paymentTerms: "BLUE FIN HEAVY EQUIPMENT RENTAL L.L.C",
      supplierReferenceNo: "Quotation No : 20095033 (Dated 05-May-2025)",
      typesOfWork: "Supply Of Hanging Clamp with Rubber",
      dateNeeded: "25.04.2025",
      DeliveryLead: "3 days",
    },
    Supplier: "CLEAN TECH SERVICES",
    GrossTotal: "3,700.00",
    RelatedDocuments: "NA",
    DeliveryDate: "28.04.2025",
  },
  {
    id: "#790958",
    status: ["Approved", "Not Billed", "Sent"],
    type: "Equipment",
    LocationPurchaser: "Site B",
    requesterEmail: "ahmed.rahman@ldv.ae",
    OtherDetails: {
      paymentTerms: "BLUE FIN HEAVY EQUIPMENT RENTAL L.L.C",
      supplierReferenceNo: "Quotation No : 20095033 (Dated 05-May-2025)",
      typesOfWork: "Supply Of Hanging Clamp with Rubber",
      dateNeeded: "25.04.2025",
      DeliveryLead: "3 days",
    },
    Supplier: "GULF MACHINES CO.",
    GrossTotal: "5,000.00",
    RelatedDocuments: "431",
    DeliveryDate: "04.05.2025",
  },
  {
    id: "#790959",
    status: ["Approved", "Not Received"],
    type: "Equipment",
    LocationPurchaser: "Project Yard",
    requesterEmail: "fatima.zain@ldv.ae",
    OtherDetails: {
      paymentTerms: "BLUE FIN HEAVY EQUIPMENT RENTAL L.L.C",
      supplierReferenceNo: "Quotation No : 20095033 (Dated 05-May-2025)",
      typesOfWork: "Supply Of Hanging Clamp with Rubber",
      dateNeeded: "25.04.2025",
      DeliveryLead: "3 days",
    },
    Supplier: "BUILDCORE MATERIAL SUPPLIERS",
    GrossTotal: "2,150.00",
    RelatedDocuments: "227",
    DeliveryDate: "23.04.2025",
  },
];

export const extendedPRData = [...poData];
for (let i = 0; i < 15; i++) {
  extendedPRData.push(...poData.map((item) => ({ ...item })));
}
