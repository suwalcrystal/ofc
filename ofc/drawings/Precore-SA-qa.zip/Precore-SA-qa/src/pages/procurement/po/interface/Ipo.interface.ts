export interface IPo {
  id: string;
  status: (
    | "Approved"
    | "Completed"
    | "Pending"
    | "In Progress"
    | "Rejected"
    | "Not Received"
    | "Not Billed"
    | "Sent"
  )[];
  type: "Equipment" | "Subcontractor" | "Materials";
  LocationPurchaser: string;
  requesterEmail: string;
  OtherDetails: {
    paymentTerms: string;
    supplierReferenceNo: string;
    typesOfWork: string;
    dateNeeded: string;
    DeliveryLead: string;
  };

  Supplier: string;
  GrossTotal: string;
  RelatedDocuments: string;
  DeliveryDate: string;
}
