import Search from "@/components/Search";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";
import { IoMdArrowDropdown } from "react-icons/io";
import FilterProcurement from "../components/FilterProcurement";
import ToggleFilter from "../components/ToggleFilter";
import POTable from "./partials/POTable";
import { useNavigate } from "react-router-dom";

const PurchaseOrder = () => {
  const dropdownOptions = [
    {
      label: "Create Purchase Order",
      value: "create-purchase-order",
      path: "/procurement/purchase-requests/create-pr",
    },
    {
      label: "Create Blanket PO",
      value: "create-blanket-po",
      path: "/purchase-order/create-blanket",
    },
    {
      label: "From Requestions",
      value: "from-requestions",
      path: "/purchase-order/from-requestions",
    },
  ] as const;

  const totalPendingCount = 5;
  const [filterType, setFilterType] = useState("all");
  const navigate = useNavigate();

  return (
    <div>
      <div className="top-0 z-40 sticky pt-[0.88rem] flex items-center justify-between border-b-2 border-white pb-[0.88rem] bg-section-bg-400">
        <div className="flex items-center gap-[1.25rem]">
          <div className="flex items-center gap-4">
            <h3 className="text-text-500 typography-h3 font-semibold">
              Purchase Order
            </h3>
            <Search />
          </div>

          <ToggleFilter
            filterType={filterType}
            setFilterType={setFilterType}
            totalPendingCount={totalPendingCount}
          />

          <FilterProcurement />
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              className="bg-green-600 p-[1.25rem] rounded-full shadow-[0px_4px_4px_0px_#E4E8EC] typography-paragraph-small font-medium text-white hover:bg-green-700 hover:text-white cursor-pointer focus-visible:border-none focus-visible:ring-0"
            >
              Create
              <IoMdArrowDropdown className="h-4 w-4 ml-auto" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="shadow-[0px_0px_8.7px_0px_rgba(0,0,0,0.16)] rounded-sm border-0">
            {dropdownOptions.map((option) => (
              <DropdownMenuItem
                key={option.value}
                onSelect={() => navigate(option.path)}
                className="focus:bg-green-50 rounded-none focus:text-green-500 text-text-500 typography-paragraph-small px-[0.62rem] py-[0.5rem] cursor-pointer"
              >
                {option.label}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <POTable filterType={filterType} />
    </div>
  );
};

export default PurchaseOrder;
