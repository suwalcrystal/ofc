import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAddTender } from "../hooks/useAddTender";
import { SingleDatePicker } from "@/components/SingleDatePicker";
import { cn } from "@/lib/utils";
import FormikQuillEditor from "@/components/FormikQuillEditor";
import { FormikProvider } from "formik";
import ExtendedButton from "@/components/ExtendedButton";

const TenderForm = () => {
  const { formik, isPending } = useAddTender();
  return (
    <FormikProvider value={formik}>
      <form
        onSubmit={formik.handleSubmit}
        className="space-y-6 bg-background-200 p-6 rounded-[0.5rem] shadow-[0px_1px_22px_0px_rgba(0,0,0,0.04)]"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Tender Name */}
          <div className="space-y-2">
            <Label
              htmlFor="name"
              className="typography-paragraph-small font-medium text-text-500"
            >
              Tender Name <span className="text-error">*</span>
            </Label>
            <Input
              id="name"
              name="name"
              type="text"
              placeholder="Tender Name"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.name}
              className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
            />
            {formik.touched.name && formik.errors.name && (
              <p className="text-red-500 typography-paragraph-small  ">
                {formik.errors.name}
              </p>
            )}
          </div>

          {/* Project Name */}
          <div className="space-y-2">
            <Label
              htmlFor="projectName"
              className="typography-paragraph-small font-medium text-text-500"
            >
              Project Name <span className="text-error">*</span>
            </Label>
            <Input
              id="projectName"
              name="projectName"
              type="text"
              placeholder="Project Name"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.projectName}
              className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
            />
            {formik.touched.projectName && formik.errors.projectName && (
              <p className="text-red-500 typography-paragraph-small  ">
                {formik.errors.projectName}
              </p>
            )}
          </div>

          {/* Project Scope */}
          <div className="space-y-2">
            <Label
              htmlFor="projectScope"
              className="typography-paragraph-small font-medium text-text-500"
            >
              Project Scope <span className="text-error">*</span>
            </Label>
            <Input
              id="projectScope"
              name="projectScope"
              type="text"
              placeholder="Project Scope"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.projectScope}
              className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
            />
            {formik.touched.projectScope && formik.errors.projectScope && (
              <p className="text-red-500 typography-paragraph-small  ">
                {formik.errors.projectScope}
              </p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* location */}
          <div className="space-y-2">
            <Label
              htmlFor="location"
              className="typography-paragraph-small font-medium text-text-500"
            >
              Project Location <span className="text-error">*</span>
            </Label>
            <Input
              id="location"
              name="location"
              type="text"
              placeholder="Project Location"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.location}
              className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
            />
            {formik.touched.location && formik.errors.location && (
              <p className="text-red-500 typography-paragraph-small  ">
                {formik.errors.name}
              </p>
            )}
          </div>

          {/* Tender Deadline */}
          <div className="space-y-2">
            <Label
              htmlFor="tenderDeadline"
              className="typography-paragraph-small font-medium text-text-500"
            >
              Tender Deadline <span className="text-error">*</span>
            </Label>

            <SingleDatePicker
              id="tenderDeadline"
              name="tenderDeadline"
              placeholder="Select Tender Deadline"
              value={formik.values.tenderDeadline}
              onChange={(date) => formik.setFieldValue("tenderDeadline", date)}
              onBlur={formik.handleBlur}
              className={cn(
                "h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px] "
              )}
            />

            {formik.errors.tenderDeadline && (
              <p className="text-red-500 typography-paragraph-small ">
                {formik.errors.tenderDeadline}
              </p>
            )}
          </div>

          {/* Issuing Organization */}
          <div className="space-y-2">
            <Label
              htmlFor="issuingOrganization"
              className="typography-paragraph-small font-medium text-text-500"
            >
              Issuing Organization <span className="text-error">*</span>
            </Label>

            <Input
              id="issuingOrganization"
              name="issuingOrganization"
              type="text"
              placeholder="Issuing Organization"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.issuingOrganization}
              className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
            />
            {formik.touched.issuingOrganization &&
              formik.errors.issuingOrganization && (
                <p className="text-red-500 typography-paragraph-small  ">
                  {formik.errors.issuingOrganization}
                </p>
              )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Tender Value Estimate */}
          <div className="space-y-2">
            <Label
              htmlFor="location"
              className="typography-paragraph-small font-medium text-text-500"
            >
              Tender Value Estimate <span className="text-error">*</span>
            </Label>
            <Input
              id="tenderValueEstimate"
              name="tenderValueEstimate"
              type="number"
              onKeyDown={(e) => {
                if (e.key === "ArrowUp" || e.key === "ArrowDown") {
                  e.preventDefault();
                }
              }}
              placeholder="Tender Value Estimate"
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.tenderValueEstimate}
              className="h-12 typography-paragraph-small border-boarder-300 focus-visible:border-green-500 focus-visible:ring-0 rounded-[8px]"
            />
            {formik.touched.tenderValueEstimate &&
              formik.errors.tenderValueEstimate && (
                <p className="text-red-500 typography-paragraph-small  ">
                  {formik.errors.tenderValueEstimate}
                </p>
              )}
          </div>
        </div>

        <div className="w-full">
          {/* Note */}
          <div className="space-y-2">
            <FormikQuillEditor name="note" label="Note" placeholder="Note..." />

            {formik.touched.tenderValueEstimate &&
              formik.errors.tenderValueEstimate && (
                <p className="text-red-500 typography-paragraph-small  ">
                  {formik.errors.tenderValueEstimate}
                </p>
              )}
          </div>
        </div>

        <ExtendedButton
          loadingText="Saving Tender..."
          isLoading={isPending}
          type="submit"
          text="Save Tender"
        />
      </form>
    </FormikProvider>
  );
};

export default TenderForm;
