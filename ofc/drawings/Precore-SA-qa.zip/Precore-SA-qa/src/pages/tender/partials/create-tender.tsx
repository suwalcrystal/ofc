import TenderForm from "./tender-form";

const CreateTender = () => {
  return (
    <div>
      <div className="border-b-2 border-white py-4 mb-6">
        <h3 className="text-text-500 typography-h3 font-semibold">
          Prepare Tender
        </h3>
      </div>

      <TenderForm />
    </div>
  );
};

export default CreateTender;
