import { useFormik } from "formik";
import { useMutation } from "@tanstack/react-query";
import { AxiosError } from "axios";
import axiosInstance from "@/utils/axios-instance";
import { showErrorMessage, showSuccessMessage } from "@/utils/toast";
import { useNavigate } from "react-router-dom";
import { TenderFormSchema, TenderFormSchemaType } from "../schema";
import { PATH } from "@/constants/paths";
import { ApiResponseType } from "@/lib/type";
import { ITenderType } from "../type";
import Endpoint from "@/api/endpoints";
import handleErrors from "@/service/api.error";

const addTender = async (data: TenderFormSchemaType) => {
  const response = await axiosInstance.post(Endpoint.tender, data);
  return response.data;
};

export const useAddTender = () => {
  const navigate = useNavigate();

  const { mutate, isPending } = useMutation<
    ApiResponseType<ITenderType>,
    AxiosError<{ message: string; error: Record<string, unknown> }>,
    TenderFormSchemaType
  >({
    mutationFn: addTender,
    onSuccess: (res) => {
      navigate(PATH.tender.tender);
      showSuccessMessage(res?.message || "Tender Created Successfully");
    },
    onError: (err) => {
      if (err?.response?.status === 422) {
        handleErrors(err, formik.setErrors);
      } else {
        showErrorMessage(err?.response?.data?.message || "Error occurred");
      }
    },
  });

  const formik = useFormik({
    initialValues: {
      name: "",
      projectName: "",
      projectScope: "",
      location: "",
      issuingOrganization: "",
      tenderDeadline: new Date().toISOString().split("T")[0],
      tenderValueEstimate: 0,
      note: "",
    },
    validationSchema: TenderFormSchema,
    onSubmit: (values) => {
      mutate(values);
    },
  });

  return {
    formik,
    isPending,
  };
};
