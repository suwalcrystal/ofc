import { useQuery } from "@tanstack/react-query";
import { AxiosError } from "axios";
import { useSearchParams } from "react-router-dom";
import { ApiResponseType } from "@/lib/type";
import { KEYS } from "@/lib/keys";
import axiosInstance from "@/utils/axios-instance";
import { ITenderType } from "../type";
import Endpoint from "@/api/endpoints";

const useGetTender = () => {
  const [searchParams] = useSearchParams();
  const page = searchParams.get("page") ?? "1";

  return useQuery<
    ApiResponseType<ITenderType[]>,
    AxiosError<{ message: string; error: Record<string, unknown> }>
  >({
    queryKey: [KEYS.tender, page],
    queryFn: async () => {
      const response = await axiosInstance.get(Endpoint.tender, {
        params: {
          page: page,
        },
      });
      return response?.data;
    },
  });
};

export default useGetTender;
