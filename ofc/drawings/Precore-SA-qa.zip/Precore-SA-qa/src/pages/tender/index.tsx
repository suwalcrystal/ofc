import TenderHeader from "./components/tender-header";

const Tender = () => {
  return (
    <div>
      <TenderHeader />
    </div>
  );
};

export default Tender;
