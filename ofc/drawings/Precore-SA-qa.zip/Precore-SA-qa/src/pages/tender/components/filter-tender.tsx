import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import useFilter from "@/hooks/useFilter";
import { useEffect, useState } from "react";
import { IoMdArrowDropdown } from "react-icons/io";
import { MdFilterList } from "react-icons/md";

const filterConfig = [
  {
    label: "Status",
    key: "status",
    options: [
      { label: "Active", value: "active" },
      { label: "Inactive", value: "inactive" },
      { label: "Pending", value: "pending" },
    ],
  },
];

const FilterTender = () => {
  const { status, updateSearchParams } = useFilter();
  const [filters, setFilters] = useState<Record<string, string>>({});

  useEffect(() => {
    setFilters((prev) => ({
      ...prev,
      status,
    }));
  }, [status]);

  const handleFilterChange = (key: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
    updateSearchParams({ [key]: value });
  };

  return (
    <div className="flex flex-wrap gap-1">
      <Button
        variant="default"
        className="bg-green-600 hover:bg-green-700 rounded-full text-white flex items-center gap-1 py-[0.23rem] px-[0.75rem]"
      >
        <MdFilterList className="h-4 w-4" />
        <span className="typography-paragraph-small">Filter</span>
      </Button>

      {filterConfig.map((filter) => {
        const selectedValue = filters[filter.key];

        return (
          <DropdownMenu key={filter.key}>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                className="cursor-pointer hover:bg-background-50 border-boarder-300 bg-background-300 py-[0.38rem] px-[0.75rem] rounded-full typography-paragraph-small text-text-400 font-medium focus-visible:outline-none flex items-center capitalize"
              >
                {selectedValue ? selectedValue : filter.label}
                <IoMdArrowDropdown className="h-4 w-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>

            <DropdownMenuContent className="w-[7rem] p-0 shadow-[0_0_8.7px_rgba(0,0,0,0.16)] rounded-sm border-0">
              {filter.options.map((option) => (
                <DropdownMenuItem
                  key={option.value}
                  onSelect={() => handleFilterChange(filter.key, option.value)}
                  className={`px-3 py-2 typography-paragraph-small text-text-500 cursor-pointer hover:bg-green-50 hover:text-green-500 ${
                    selectedValue === option.value
                      ? "font-semibold text-green-600"
                      : ""
                  }`}
                >
                  {option.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        );
      })}
    </div>
  );
};

export default FilterTender;
