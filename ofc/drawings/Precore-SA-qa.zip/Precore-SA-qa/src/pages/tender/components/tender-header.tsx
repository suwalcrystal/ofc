import AddButton from "@/components/headerBottom/AddButton";
import Search from "@/components/Search";
import { useNavigate } from "react-router-dom";
import { PATH } from "@/constants/paths";
import { useState } from "react";
import ToggleFilter from "./toggle-filter";
import FilterTender from "./filter-tender";

const TenderHeader = () => {
  const [filterType, setFilterType] = useState("all");
  const navigate = useNavigate();
  const totalFinalizedCount = 5;

  return (
    <div>
      <div className="top-0 z-40 sticky pt-[0.88rem] flex items-center justify-between border-b-2 border-white pb-[0.88rem] bg-section-bg-400">
        <div className="flex items-center gap-[1.25rem]">
          <div className="flex items-center gap-4">
            <h3 className="text-text-500 typography-h3 font-semibold">
              Tender Management
            </h3>
            <Search />
          </div>

          <ToggleFilter
            filterType={filterType}
            setFilterType={setFilterType}
            totalFinalizedCount={totalFinalizedCount}
          />

          <FilterTender />
        </div>
        <AddButton
          title="Prepare Tender"
          onClick={() => {
            navigate(`${PATH.tender.createTender}`);
          }}
        />
      </div>
    </div>
  );
};

export default TenderHeader;
