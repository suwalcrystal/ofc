export interface ITenderType {
  id: string;
  name: string;
  projectName: string;
  projectScope: string;
  location: string;
  tenderDeadline: string;
  issuingOrganization: string;
  tenderValueEstimate: number;
  documentRegistryId: string;
  tenderStatus: string;
  createdAt: string;
  updatedAt: string;
}
