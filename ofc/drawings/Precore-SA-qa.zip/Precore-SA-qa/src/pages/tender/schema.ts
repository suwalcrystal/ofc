import * as Yup from "yup";

export const TenderFormSchema = Yup.object({
  name: Yup.string().required("Tender name is required."),
  projectName: Yup.string().required("Project name is required."),
  projectScope: Yup.string().required("Project scope is required."),
  location: Yup.string().required("Location is required."),
  issuingOrganization: Yup.string().required(
    "Issuing organization is required."
  ),
  tenderDeadline: Yup.string().required("Tender deadline is required."),
  tenderValueEstimate: Yup.number()
    .typeError("Tender value estimate must be a number.")
    .required("Tender value estimate is required."),
  note: Yup.string().notRequired(),
});
export type TenderFormSchemaType = Yup.InferType<typeof TenderFormSchema>;
