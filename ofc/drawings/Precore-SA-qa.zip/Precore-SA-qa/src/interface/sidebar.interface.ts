import { ReactNode } from "react";

export interface SidebarChild {
  title: string;
  icon: ReactNode;
  link?: string;
}

export interface SidebarItem {
  title: string;
  icon: ReactNode;
  link?: string;
  children?: SidebarChild[];
}
