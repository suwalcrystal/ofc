export interface IColumn<T> {
  key: keyof T;
  label: string;
  sortable?: boolean;
  width?: string;
}

export interface IBaseTableProps<T> {
  data: T[];
  columns: IColumn<T>[];
  renderRow: (
    item: T,
    index?: number,
    columns?: IColumn<T>[]
  ) => React.JSX.Element[];
  tableHeight?: string;
  selectAllCheckbox?: React.ReactNode;
}
