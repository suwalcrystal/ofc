export const DashboardIcon = () => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="stroke-current"
    >
      <path
        d="M1.66669 6.66667L9.77669 2.61167C9.84604 2.57705 9.9225 2.55902 10 2.55902C10.0775 2.55902 10.154 2.57705 10.2234 2.61167L18.3334 6.66667M16.6667 9.16667V15.8333C16.6667 16.2754 16.4911 16.6993 16.1785 17.0118C15.866 17.3244 15.442 17.5 15 17.5H5.00002C4.55799 17.5 4.13407 17.3244 3.82151 17.0118C3.50895 16.6993 3.33335 16.2754 3.33335 15.8333V9.16667"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
