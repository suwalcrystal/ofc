export const CartIcon = () => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="stroke-current"
    >
      <path
        d="M1.6665 1.66675H3.11651C4.01651 1.66675 4.2415 2.33341 4.1665 3.22508M4.1665 3.22508L3.95817 11.6334C3.8415 12.9917 4.9165 14.1584 6.28317 14.1584H15.1582C16.3582 14.1584 17.4082 13.1751 17.4998 11.9834L17.9498 5.73342C18.0498 4.35009 16.9998 3.22508 15.6082 3.22508H4.1665Z"
        stroke="currentColor"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13.5417 18.3333C14.117 18.3333 14.5833 17.867 14.5833 17.2917C14.5833 16.7164 14.117 16.25 13.5417 16.25C12.9664 16.25 12.5 16.7164 12.5 17.2917C12.5 17.867 12.9664 18.3333 13.5417 18.3333Z"
        stroke="currentColor"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.87516 18.3333C7.45046 18.3333 7.91683 17.867 7.91683 17.2917C7.91683 16.7164 7.45046 16.25 6.87516 16.25C6.29987 16.25 5.8335 16.7164 5.8335 17.2917C5.8335 17.867 6.29987 18.3333 6.87516 18.3333Z"
        stroke="currentColor"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.5 6.66675H17.5"
        stroke="currentColor"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
