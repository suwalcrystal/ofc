export const ReportsIcon = () => {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0"
    >
      <path
        d="M4.5 13.25L2 15.7V8.66667H4.5M8.66667 11.7167L7.35833 10.6L6.16667 11.7V5.33333H8.66667M12.8333 10.3333L10.3333 12.8333V2H12.8333M15.175 10.175L13.6667 8.66667H17.8333V12.8333L16.3417 11.3417L10.3333 17.3L7.44167 14.7833L4.29167 17.8333H2L7.39167 12.55L10.3333 15.0333"
        fill="currentColor"
      />
    </svg>
  );
};
