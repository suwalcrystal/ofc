import { useLocation, useNavigate, useSearchParams } from "react-router-dom";

const useFilter = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();

  const status = searchParams.get("status") ?? "";

  const updateSearchParams = (params: { status?: string }) => {
    const updatedSearchParams = new URLSearchParams(searchParams);

    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        if (value === "") {
          updatedSearchParams.delete(key);
        } else {
          updatedSearchParams.set(key, value);
        }
      }
    });

    navigate(`${location.pathname}?${updatedSearchParams.toString()}`, {
      replace: true,
    });
  };

  return {
    status,
    updateSearchParams,
  };
};

export default useFilter;
