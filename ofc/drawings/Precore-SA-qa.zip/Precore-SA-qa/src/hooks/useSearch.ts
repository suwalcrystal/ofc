import { useLocation, useNavigate, useSearchParams } from "react-router-dom";

const useSearch = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();

  const search = searchParams.get("search") ?? "";

  const updateSearchParams = (params: { search?: string }) => {
    const updatedSearchParams = new URLSearchParams(searchParams.toString());

    if (params.search !== undefined) {
      if (params.search === "" || params.search === null) {
        updatedSearchParams.delete("search");
      } else {
        updatedSearchParams.set("search", params.search);
      }
    }

    navigate(`${location.pathname}?${updatedSearchParams.toString()}`, {
      replace: true,
    });
  };
  const handleSearch = (val: string) => {
    updateSearchParams({ search: val });
  };

  return {
    handleSearch,
    search,
  };
};

export default useSearch;
