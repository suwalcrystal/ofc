import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import MainRoutes from "./routes/route";
import { Suspense } from "react";

function App() {
  const router = createBrowserRouter(MainRoutes);

  return (
    <>
      <ToastContainer stacked />
      <Suspense fallback={<div>Loading...</div>}>
        <RouterProvider router={router} />
      </Suspense>
    </>
  );
}

export default App;
