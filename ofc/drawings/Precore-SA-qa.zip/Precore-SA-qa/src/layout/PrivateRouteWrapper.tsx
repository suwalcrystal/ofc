import React from "react";
import { Navigate } from "react-router-dom";
import { PATH } from "@/constants/paths";
import { getCookie } from "@/utils/cookie";

const PrivateRouteWrapper = ({ children }: { children?: React.ReactNode }) => {
  const isLoggedIn = !!getCookie("accessToken");

  if (!isLoggedIn) {
    return <Navigate to={PATH.auth.login} />;
  }

  return <>{children}</>;
};

export default PrivateRouteWrapper;
