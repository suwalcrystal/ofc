import { Navigate, Outlet } from "react-router-dom";
import { PATH } from "@/constants/paths";
import { getCookie } from "@/utils/cookie";

const PublicRouteWrapper = () => {
  const isLoggedIn = !!getCookie("accessToken");

  // If logged in, redirect to dashboard
  return isLoggedIn ? <Navigate to={PATH.dashboard} /> : <Outlet />;
};

export default PublicRouteWrapper;
