interface Props {
  children: React.ReactElement;
}

const Main: React.FC<Props> = ({ children }) => {
  return <div className="px-5  bg-section-bg-400">{children}</div>;
};

export default Main;
