import { useEffect, useRef, useState } from "react";
import { Outlet } from "react-router-dom";
import SideBar from "@components/sidebar/SideBar";
import Main from "./Main";
import Header from "@/components/header/header";

const Layout = () => {
  const layoutref = useRef<HTMLDivElement>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(() => {
    const stored = localStorage.getItem("sidebar-expanded");
    return stored === "true";
  });

  useEffect(() => {
    localStorage.setItem("sidebar-expanded", String(sidebarExpanded));
    document.body.classList.toggle("sidebar-expanded", sidebarExpanded);
  }, [sidebarExpanded]);

  return (
    <div className="flex h-screen overflow-x-hidden">
      <SideBar
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        sidebarExpanded={sidebarExpanded}
        setSidebarExpanded={setSidebarExpanded}
      />
      <div
        ref={layoutref}
        className="relative flex flex-col flex-1 overflow-x-hidden overflow-y-auto"
      >
        <Header
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
          sidebarExpanded={sidebarExpanded}
          setSidebarExpanded={setSidebarExpanded}
        />
        <Main>
          <div className="min-h-screen">
            <Outlet />
          </div>
        </Main>
      </div>
    </div>
  );
};

export default Layout;
