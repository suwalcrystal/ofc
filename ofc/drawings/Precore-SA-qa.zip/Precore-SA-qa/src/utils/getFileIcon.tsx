import exel from "@/assets/icons/exel.svg";
import word from "@/assets/icons/word.svg";
import { FileText } from "lucide-react";

export const getFileIcon = (type: string) => {
  switch (type) {
    case "excel":
      return <img src={exel} className="w-[2.5rem] h-[2.5rem] " />;
    case "word":
      return <img src={word} className="w-[2.5rem] h-[2.5rem]" />;
    default:
      return <FileText className="w-6 h-6 text-gray-600" />;
  }
};
