import { Badge } from "@/components/ui/badge";

export const getStatusBadge = (status: string) => {
  switch (status) {
    case "On Track":
      return (
        <Badge className="bg-green-50 text-green-500 hover:bg-green-100 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "Delayed":
      return (
        <Badge className="bg-[#FFF8EB] text-warning hover:bg-warning/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "Completed":
      return (
        <Badge className="bg-[#E1ECFF] text-blue hover:bg-blue/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "Sent":
      return (
        <Badge className="bg-[#E1ECFF] text-blue hover:bg-blue/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "Approved":
      return (
        <Badge className="bg-green-50 text-green-500 hover:bg-green-100 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "Pending":
      return (
        <Badge className="bg-[#E1ECFF] text-blue hover:bg-blue/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "In Progress":
      return (
        <Badge className="bg-[#E1ECFF] text-blue hover:bg-blue/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "Rejected":
      return (
        <Badge className="bg-error-bg text-error hover:bg-error/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );

    case "Not Received":
      return (
        <Badge className="bg-purple-bg text-purple hover:bg-purple/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );

    case "Active":
      return (
        <Badge className="bg-green-50 text-green-500 hover:bg-green-100 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "Inactive":
      return (
        <Badge className="bg-[#FFF8EB] text-warning hover:bg-warning/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    case "Not Billed":
      return (
        <Badge className="bg-[#FFF8EB] text-warning hover:bg-warning/40 px-3 py-1 font-medium rounded-full">
          {status}
        </Badge>
      );
    default:
      return <Badge>{status}</Badge>;
  }
};
