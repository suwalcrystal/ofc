/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios";
import createAuthRefreshInterceptor from "axios-auth-refresh";
import { clearAllCookies, getCookie, setCookie } from "@/utils/cookie";
import { PATH } from "@/constants/paths";
import { BASE_URL } from "../lib/baseURL";

const axiosInstance = axios.create({
  baseURL: `${BASE_URL}/api`,
  headers: {
    accept: "application/json",
  },
});
axiosInstance.interceptors.request.use(
  function (config) {
    const accessToken = getCookie("accessToken");

    if (accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
    }

    return config;
  },
  function (error) {
    return Promise.reject(error);
  }
);

const refreshTokenLogic = async (failedRequest: any) => {
  const refreshToken = getCookie("refreshToken");

  if (!refreshToken) {
    clearAllCookies();
    window.location.href = PATH.auth.login;
    return Promise.reject("Refresh token missing");
  }

  try {
    const res = await axios.post(`${BASE_URL}/api/auth/refresh-token`, {
      refreshToken,
    });

    const { accessToken: newAccessToken, refreshToken: newRefreshToken } =
      res.data;

    // Update token in cookies
    setCookie({
      cookieName: "accessToken",
      value: newAccessToken,
    });

    // If a new refresh token is provided, update it in cookies
    if (newRefreshToken) {
      setCookie({
        cookieName: "refreshToken",
        value: newRefreshToken,
      });
    }

    // Update failed request with new token
    failedRequest.response.config.headers.Authorization = `Bearer ${newAccessToken}`;

    return Promise.resolve();
  } catch (error) {
    clearAllCookies();
    window.location.href = PATH.auth.login;
    return Promise.reject(error);
  }
};
createAuthRefreshInterceptor(axiosInstance, refreshTokenLogic, {
  shouldRefresh: (error: any) => {
    return (
      error?.response?.status === 401 &&
      !error.config.__isRetryRequest &&
      !error.config?.url?.includes("/auth/refresh-token")
    );
  },
});

export default axiosInstance;
