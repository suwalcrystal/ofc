export const itemData = [
  {
    id: "1",
    prId: "PR-001",
    isExpanded: true,
    items: [
      {
        id: "1",
        itemCode: "EXC-01",
        itemName: "Excavation of foundation",
        description:
          "30 mm Concrete Cover Block, Heavy-Duty Spacer for Reinforcement Protection",
        quantity: 350,
        uom: "pcs",
        unitRate: 2200,
        totalCost: 20000,
      },
      {
        id: "2",
        itemCode: "EXC-01",
        itemName: "Excavation of foundation",
        description:
          "30 mm Concrete Cover Block, Heavy-Duty Spacer for Reinforcement Protection",
        quantity: 350,
        uom: "pcs",
        unitRate: 2200,
        totalCost: 20000,
      },
      {
        id: "3",
        itemCode: "EXC-01",
        itemName: "Excavation of foundation",
        description:
          "30 mm Concrete Cover Block, Heavy-Duty Spacer for Reinforcement Protection",
        quantity: 350,
        uom: "pcs",
        unitRate: 2200,
        totalCost: 20000,
      },
    ],
  },
  {
    id: "2",
    prId: "PR-001",
    isExpanded: true,
    items: [
      {
        id: "4",
        itemCode: "EXC-01",
        itemName: "Excavation of foundation",
        description:
          "30 mm Concrete Cover Block, Heavy-Duty Spacer for Reinforcement Protection",
        quantity: 350,
        uom: "pcs",
        unitRate: 2200,
        totalCost: 20000,
      },
      {
        id: "5",
        itemCode: "EXC-01",
        itemName: "Excavation of foundation",
        description:
          "30 mm Concrete Cover Block, Heavy-Duty Spacer for Reinforcement Protection",
        quantity: 350,
        uom: "pcs",
        unitRate: 2200,
        totalCost: 20000,
      },
      {
        id: "6",
        itemCode: "EXC-01",
        itemName: "Excavation of foundation",
        description:
          "30 mm Concrete Cover Block, Heavy-Duty Spacer for Reinforcement Protection",
        quantity: 350,
        uom: "pcs",
        unitRate: 2200,
        totalCost: 20000,
      },
    ],
  },
];
