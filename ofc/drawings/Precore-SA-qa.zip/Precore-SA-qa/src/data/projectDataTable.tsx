type Project = {
  id: string;
  status: "On Track" | "Delayed" | "Completed";
  project: string;
  email: string;
  phase: string;
  margin: string;
  target: string;
  linkedPOs: number;
  budget: number;
  spent: number;
  currency: string;
};

export const projectDataTable: Project[] = [
  {
    id: "#790955",
    status: "On Track",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "Fit-Out",
    margin: "8%",
    target: "12%",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    currency: "AED",
  },
  {
    id: "#790955",
    status: "Delayed",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "MEP",
    margin: "8%",
    target: "12%",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    currency: "AED",
  },
  {
    id: "#790955",
    status: "On Track",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "Fit-Out",
    margin: "8%",
    target: "12%",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    currency: "AED",
  },
  {
    id: "#790955",
    status: "Delayed",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "MEP",
    margin: "8%",
    target: "12%",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    currency: "AED",
  },
  {
    id: "#790955",
    status: "Completed",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "Fit-Out",
    margin: "8%",
    target: "12%",
    linkedPOs: 5,
    budget: 12000000,
    spent: 12000000,
    currency: "AED",
  },
  {
    id: "#790955",
    status: "On Track",
    project: "LDV Workshop",
    email: "reyo.suman@ldv.ae",
    phase: "Fit-Out",
    margin: "8%",
    target: "12%",
    linkedPOs: 5,
    budget: 12000000,
    spent: 2000000,
    currency: "AED",
  },
];
