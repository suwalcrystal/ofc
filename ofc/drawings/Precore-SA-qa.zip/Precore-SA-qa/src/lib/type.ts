export interface ApiResponseType<T> {
  data: T;
  message: string;
  status: string;
  statusCode: number;
  pagination?: {
    totalRecords: number;
    perPage: string;
    currentPage: string;
    totalPages: number;
    next: string | null;
    prev: string | null;
    pagingCounter: number;
    hasPrevious: boolean;
    hasNext: boolean;
    recordShown: number;
  };
}
