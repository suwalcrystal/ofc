export const KEYS = {
  tender: "tender",
  unit: "unit",
  category: "category",
  item: "item",
  supplier: "supplier",
  itemType: "itemType",
};
