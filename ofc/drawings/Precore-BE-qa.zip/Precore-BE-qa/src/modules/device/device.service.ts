import { Injectable,Param } from "@nestjs/common";
import { CreateDeviceDto } from "./dto/create-device.dto";
import { UpdateDeviceDto } from "./dto/update-device.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { DeviceRepository } from "./device.repository";
@Injectable()
export class DeviceService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: DeviceRepository) {}

  create(data: CreateDeviceDto) {
    return this.crud.create("device", data);
  }

  findAll() {
    return this.crud.findAll("device");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("device", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateDeviceDto) {
    return this.crud.update("device", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("device", id);
  }
}