import { Injectable } from "@nestjs/common";
import { Device, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class DeviceRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Device | null> {
    return this.prisma.device.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(data: Prisma.DeviceUncheckedCreateInput): Promise<Device> {
    return this.prisma.device.create({ data });
  }

  async update(id: string, data: Partial<Device>): Promise<Device> {
    return this.prisma.device.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<Device> {
    return this.prisma.device.delete({
      where: {
        id: id,
      },
    });
  }
}
