import { Type } from "class-transformer";
import {
  IsNotEmpty,
  IsOptional,
  IsRFC3339,
  IsString,
  IsUUID,
} from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreateDeviceDto {
  @ApiProperty({
    example: "Device Name",
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    example: "12we34",
  })
  @IsNotEmpty()
  @IsString()
  token: string;

  @ApiProperty({
    example: "3fe8733d-0624-4dd2-988e-31aa78ec4021",
  })
  @IsNotEmpty()
  @IsUUID()
  userId: string;
}
