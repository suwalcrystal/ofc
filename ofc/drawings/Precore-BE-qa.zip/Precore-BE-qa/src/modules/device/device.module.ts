import { Module } from "@nestjs/common";
import { DeviceService } from "./device.service";
import { DeviceController } from "./device.controller";
import { CommonModule } from "src/common/common.module";
import { DeviceRepository } from "./device.repository";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Module({
  imports: [CommonModule],
  controllers: [DeviceController],
  providers: [
    DeviceService,
    DeviceRepository,
    PrismaService,
    GenerateResponseMessage,
  ],
})
export class DeviceModule {}
