import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { DeviceService } from './device.service';
import { CreateDeviceDto } from './dto/create-device.dto';
import { UpdateDeviceDto } from './dto/update-device.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('device')
export class DeviceController {
  constructor(
    private readonly deviceService: DeviceService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createDeviceDto: CreateDeviceDto) {
    return {
      data: await this.deviceService.create(createDeviceDto),
      message: this.generateResponseService.generateCreateMessage('Device'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.deviceService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('Device'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.deviceService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('Device'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateDeviceDto: UpdateDeviceDto
  ) {
    return {
      data: await this.deviceService.update(id, updateDeviceDto),
      message: this.generateResponseService.generateUpdateMessage('Device'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.deviceService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('Device'),
    };
  }
}