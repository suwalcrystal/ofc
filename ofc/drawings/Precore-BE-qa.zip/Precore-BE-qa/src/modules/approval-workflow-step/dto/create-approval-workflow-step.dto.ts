import { Type } from "class-transformer";
import { IsInt, IsNotEmpty, IsString, IsUUID } from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreateApprovalWorkflowStepDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  title: string;

  @ApiProperty({
    type: "string",
    description: "The ID of the approver",
    example: "123e4567-e89b-12d3-a456-426614174000",
  })
  @IsNotEmpty()
  @IsString()
  @IsUUID()
  approverId: string;

  @ApiProperty({
    type: "string",
    description: "The ID of the approver",
    example: "123e4567-e89b-12d3-a456-426614174000",
  })
  @IsNotEmpty()
  @IsString()
  @IsUUID()
  approvalWorkflowId: string;
}
