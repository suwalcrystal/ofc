import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ApprovalWorkflowStepService } from './approval-workflow-step.service';
import { CreateApprovalWorkflowStepDto } from './dto/create-approval-workflow-step.dto';
import { UpdateApprovalWorkflowStepDto } from './dto/update-approval-workflow-step.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('approval-workflow-step')
export class ApprovalWorkflowStepController {
  constructor(
    private readonly approvalWorkflowStepService: ApprovalWorkflowStepService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createApprovalWorkflowStepDto: CreateApprovalWorkflowStepDto) {
    return {
      data: await this.approvalWorkflowStepService.create(createApprovalWorkflowStepDto),
      message: this.generateResponseService.generateCreateMessage('ApprovalWorkflowStep'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.approvalWorkflowStepService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('ApprovalWorkflowStep'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.approvalWorkflowStepService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('ApprovalWorkflowStep'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateApprovalWorkflowStepDto: UpdateApprovalWorkflowStepDto
  ) {
    return {
      data: await this.approvalWorkflowStepService.update(id, updateApprovalWorkflowStepDto),
      message: this.generateResponseService.generateUpdateMessage('ApprovalWorkflowStep'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.approvalWorkflowStepService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('ApprovalWorkflowStep'),
    };
  }
}