import { Injectable, Param } from "@nestjs/common";
import { CreateApprovalWorkflowStepDto } from "./dto/create-approval-workflow-step.dto";
import { UpdateApprovalWorkflowStepDto } from "./dto/update-approval-workflow-step.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { ApprovalWorkflowStepRepository } from "./approval-workflow-step.repository";
import { PrismaService } from "src/prisma/prisma.service";
@Injectable()
export class ApprovalWorkflowStepService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly approvalWorkflowStepRepository: ApprovalWorkflowStepRepository,
    private readonly prisma: PrismaService
  ) {}

  async create(data: CreateApprovalWorkflowStepDto) {
    this.prisma.approvalWorkflowStep;
    const highestOrderNumber = await this.crud.getHighestOrderNumber(
      "approvalWorkflowStep",
      {}
    );
    return this.crud.create("approvalWorkflowStep", {
      ...data,
      orderNumber: highestOrderNumber + 1,
    });
  }

  findAll() {
    return this.crud.findAll("approvalWorkflowStep");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("approvalWorkflowStep", id);
  }

  update(@Param("id") id: string, data: UpdateApprovalWorkflowStepDto) {
    return this.crud.update("approvalWorkflowStep", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("approvalWorkflowStep", id);
  }
}
