export class ApprovalWorkflowStep {}
