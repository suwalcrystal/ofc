import { Module } from "@nestjs/common";
import { ApprovalWorkflowStepService } from "./approval-workflow-step.service";
import { ApprovalWorkflowStepController } from "./approval-workflow-step.controller";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";
import { CommonModule } from "src/common/common.module";
import { ApprovalWorkflowStepRepository } from "./approval-workflow-step.repository";

@Module({
  imports: [CommonModule],
  controllers: [ApprovalWorkflowStepController],
  providers: [
    ApprovalWorkflowStepService,
    GenerateResponseMessage,
    PrismaService,
    ApprovalWorkflowStepRepository,
  ],
})
export class ApprovalWorkflowStepModule {}
