import { Injectable } from "@nestjs/common";
import { ApprovalWorkflowStep, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class ApprovalWorkflowStepRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<ApprovalWorkflowStep | null> {
    return this.prisma.approvalWorkflowStep.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.ApprovalWorkflowStepUncheckedCreateInput
  ): Promise<ApprovalWorkflowStep> {
    return this.prisma.approvalWorkflowStep.create({ data });
  }

  async update(
    id: string,
    data: Partial<ApprovalWorkflowStep>
  ): Promise<ApprovalWorkflowStep> {
    return this.prisma.approvalWorkflowStep.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<ApprovalWorkflowStep> {
    return this.prisma.approvalWorkflowStep.delete({
      where: {
        id: id,
      },
    });
  }
}
