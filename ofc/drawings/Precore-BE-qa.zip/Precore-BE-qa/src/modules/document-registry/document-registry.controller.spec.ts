import { Test, TestingModule } from '@nestjs/testing';
import { DocumentRegistryController } from './document-registry.controller';
import { DocumentRegistryService } from './document-registry.service';

describe('DocumentRegistryController', () => {
  let controller: DocumentRegistryController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DocumentRegistryController],
      providers: [DocumentRegistryService],
    }).compile();

    controller = module.get<DocumentRegistryController>(DocumentRegistryController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
