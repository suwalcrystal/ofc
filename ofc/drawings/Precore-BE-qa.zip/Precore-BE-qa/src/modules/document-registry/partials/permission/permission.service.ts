import { Injectable } from "@nestjs/common";
import { CreatePermissionDto } from "./dto/create-permission.dto";
import { UpdatePermissionDto } from "./dto/update-permission.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";

@Injectable()
export class PermissionService {
  constructor(private readonly crud: GenericCrudService) {}
  create(createPermissionDto: CreatePermissionDto) {
    return this.crud.create("permission", createPermissionDto);
  }

  findAll() {
    return `This action returns all permission`;
  }

  findOne(id: number) {
    return `This action returns a #${id} permission`;
  }

  update(id: number, updatePermissionDto: UpdatePermissionDto) {
    return `This action updates a #${id} permission`;
  }

  remove(id: number) {
    return `This action removes a #${id} permission`;
  }
}
