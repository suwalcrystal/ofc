import { Module } from "@nestjs/common";
import { RoleService } from "./role.service";
import { RoleController } from "./role.controller";
import { CommonModule } from "src/common/common.module";
import { RoleRepository } from "./role.repository";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
  imports: [CommonModule],
  controllers: [RoleController],
  providers: [RoleService, RoleRepository, PrismaService],
  exports: [RoleService, RoleRepository],
})
export class RoleModule {}
