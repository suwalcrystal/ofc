import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";
import { IsUnique } from "src/validators/validators.service";
export class CreatePermissionDto {
  @ApiProperty({
    example: "create",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  @IsUnique(["permission", "action"], {
    message: "Permission is already in use",
  })
  action: string;
}
