import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";

export class CreateRoleDto {
  @ApiProperty({
    example: "Quantity Surveyor",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  title: string;

  @ApiProperty({
    example: "quantity-surveyor",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  roleCode: string;
}
