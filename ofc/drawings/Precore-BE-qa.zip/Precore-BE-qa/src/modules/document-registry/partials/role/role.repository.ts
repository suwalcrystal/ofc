import { Injectable, NotFoundException } from "@nestjs/common";
import { Role } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class RoleRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Role | null> {
    return this.prisma.role.findUnique({ where: { id } });
  }
  async getByRoleCode(code: string): Promise<Role> {
    const roleData = await this.prisma.role.findFirst({
      where: { roleCode: code },
    });
    if (!roleData) {
      throw new NotFoundException("Role not found");
    }
    return roleData;
  }

  async getPermissionsForRoleCode(roleCode: string) {
    return this.prisma.role.findFirst({
      where: { roleCode: roleCode },
      include: {
        rolePermissions: {
          include: {
            permission: true,
          },
        },
      },
    });
  }
}
