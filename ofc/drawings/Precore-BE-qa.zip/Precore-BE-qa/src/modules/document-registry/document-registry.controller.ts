import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { DocumentRegistryService } from './document-registry.service';
import { CreateDocumentRegistryDto } from './dto/create-document-registry.dto';
import { UpdateDocumentRegistryDto } from './dto/update-document-registry.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('document-registry')
export class DocumentRegistryController {
  constructor(
    private readonly documentRegistryService: DocumentRegistryService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createDocumentRegistryDto: CreateDocumentRegistryDto) {
    return {
      data: await this.documentRegistryService.create(createDocumentRegistryDto),
      message: this.generateResponseService.generateCreateMessage('DocumentRegistry'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.documentRegistryService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('DocumentRegistry'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.documentRegistryService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('DocumentRegistry'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateDocumentRegistryDto: UpdateDocumentRegistryDto
  ) {
    return {
      data: await this.documentRegistryService.update(id, updateDocumentRegistryDto),
      message: this.generateResponseService.generateUpdateMessage('DocumentRegistry'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.documentRegistryService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('DocumentRegistry'),
    };
  }
}