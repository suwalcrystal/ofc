import { PartialType } from '@nestjs/swagger';
import { CreateDocumentRegistryDto } from './create-document-registry.dto';

export class UpdateDocumentRegistryDto extends PartialType(CreateDocumentRegistryDto) {}
