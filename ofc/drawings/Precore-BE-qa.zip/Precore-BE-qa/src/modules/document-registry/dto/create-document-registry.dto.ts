export class CreateDocumentRegistryDto {}
