export class DocumentRegistry {}
