import { Injectable,Param } from "@nestjs/common";
import { CreateDocumentRegistryDto } from "./dto/create-document-registry.dto";
import { UpdateDocumentRegistryDto } from "./dto/update-document-registry.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { DocumentRegistryRepository } from "./document-registry.repository";
@Injectable()
export class DocumentRegistryService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: DocumentRegistryRepository) {}

  create(data: CreateDocumentRegistryDto) {
    return this.crud.create("documentRegistry", data);
  }

  findAll() {
    return this.crud.findAll("documentRegistry");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("documentRegistry", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateDocumentRegistryDto) {
    return this.crud.update("documentRegistry", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("documentRegistry", id);
  }
}