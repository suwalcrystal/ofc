import { Injectable } from "@nestjs/common";
import { DocumentRegistry, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class DocumentRegistryRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<DocumentRegistry | null> {
    return this.prisma.documentRegistry.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.DocumentRegistryUncheckedCreateInput
  ): Promise<DocumentRegistry> {
    return this.prisma.documentRegistry.create({ data });
  }

  async update(
    id: string,
    data: Partial<DocumentRegistry>
  ): Promise<DocumentRegistry> {
    return this.prisma.documentRegistry.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<DocumentRegistry> {
    return this.prisma.documentRegistry.delete({
      where: {
        id: id,
      },
    });
  }
}
