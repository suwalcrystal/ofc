import { Module } from "@nestjs/common";
import { DocumentRegistryService } from "./document-registry.service";
import { DocumentRegistryController } from "./document-registry.controller";
import { CommonModule } from "src/common/common.module";
import { DocumentRegistryRepository } from "./document-registry.repository";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Module({
  imports: [CommonModule],

  controllers: [DocumentRegistryController],
  providers: [
    DocumentRegistryService,
    DocumentRegistryRepository,
    PrismaService,
    GenerateResponseMessage,
  ],
})
export class DocumentRegistryModule {}
