import { Module } from "@nestjs/common";
import { ApprovalWorkflowService } from "./approval-workflow.service";
import { ApprovalWorkflowController } from "./approval-workflow.controller";
import { CommonModule } from "src/common/common.module";
import { ApprovalWorkflowRepository } from "./approval-workflow.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
  imports: [CommonModule],
  controllers: [ApprovalWorkflowController],
  providers: [
    ApprovalWorkflowService,
    ApprovalWorkflowRepository,
    GenerateResponseMessage,
    PrismaService,
  ],
})
export class ApprovalWorkflowModule {}
