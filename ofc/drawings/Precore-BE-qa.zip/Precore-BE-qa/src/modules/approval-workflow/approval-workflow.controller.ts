import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ApprovalWorkflowService } from './approval-workflow.service';
import { CreateApprovalWorkflowDto } from './dto/create-approval-workflow.dto';
import { UpdateApprovalWorkflowDto } from './dto/update-approval-workflow.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('approval-workflow')
export class ApprovalWorkflowController {
  constructor(
    private readonly approvalWorkflowService: ApprovalWorkflowService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createApprovalWorkflowDto: CreateApprovalWorkflowDto) {
    return {
      data: await this.approvalWorkflowService.create(createApprovalWorkflowDto),
      message: this.generateResponseService.generateCreateMessage('ApprovalWorkflow'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.approvalWorkflowService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('ApprovalWorkflow'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.approvalWorkflowService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('ApprovalWorkflow'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateApprovalWorkflowDto: UpdateApprovalWorkflowDto
  ) {
    return {
      data: await this.approvalWorkflowService.update(id, updateApprovalWorkflowDto),
      message: this.generateResponseService.generateUpdateMessage('ApprovalWorkflow'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.approvalWorkflowService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('ApprovalWorkflow'),
    };
  }
}