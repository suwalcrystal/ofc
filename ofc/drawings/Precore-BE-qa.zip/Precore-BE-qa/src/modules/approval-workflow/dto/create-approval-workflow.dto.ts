import { Type } from "class-transformer";
import { IsNotEmpty, IsOptional, IsString, IsUUID } from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreateApprovalWorkflowDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  title: string;

  @ApiProperty({
    type: "string",
    description: "if its only single approval flow for whole company",
    example: true,
  })
  @IsNotEmpty()
  isCompanyWide: boolean;

  @ApiProperty()
  @IsOptional()
  @IsUUID()
  projectId: string;

  //document with type enum
  @ApiProperty({
    enum: ["purchase_request", "tender", "project"],
    description: "Type of document for the approval workflow",
    example: "tender",
  })
  @IsNotEmpty()
  @IsString()
  document: "purchase_request" | "tender" | "contract" | "project";
}
