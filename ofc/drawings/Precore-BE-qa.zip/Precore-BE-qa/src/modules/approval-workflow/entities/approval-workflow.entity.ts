export class ApprovalWorkflow {}
