import { Injectable } from "@nestjs/common";
import { ApprovalWorkflow, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class ApprovalWorkflowRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<ApprovalWorkflow | null> {
    return this.prisma.approvalWorkflow.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.ApprovalWorkflowUncheckedCreateInput
  ): Promise<ApprovalWorkflow> {
    return this.prisma.approvalWorkflow.create({ data });
  }

  async update(
    id: string,
    data: Partial<ApprovalWorkflow>
  ): Promise<ApprovalWorkflow> {
    return this.prisma.approvalWorkflow.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<ApprovalWorkflow> {
    return this.prisma.approvalWorkflow.delete({
      where: {
        id: id,
      },
    });
  }
}
