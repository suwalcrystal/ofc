import { Injectable,Param } from "@nestjs/common";
import { CreateApprovalWorkflowDto } from "./dto/create-approval-workflow.dto";
import { UpdateApprovalWorkflowDto } from "./dto/update-approval-workflow.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { ApprovalWorkflowRepository } from "./approval-workflow.repository";
@Injectable()
export class ApprovalWorkflowService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: ApprovalWorkflowRepository) {}

  create(data: CreateApprovalWorkflowDto) {
    return this.crud.create("approvalWorkflow", data);
  }

  findAll() {
    return this.crud.findAll("approvalWorkflow");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("approvalWorkflow", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateApprovalWorkflowDto) {
    return this.crud.update("approvalWorkflow", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("approvalWorkflow", id);
  }
}