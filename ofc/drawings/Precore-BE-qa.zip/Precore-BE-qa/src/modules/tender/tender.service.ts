import { Injectable, Param } from "@nestjs/common";
import { CreateTenderDto } from "./dto/create-tender.dto";
import {
  ApproveTenderDto,
  BOQItemPriceDto,
  UpdateTenderDto,
} from "./dto/update-tender.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { TenderRepository } from "./tender.repository";
import { PrismaService } from "src/prisma/prisma.service";
import * as _ from "lodash";
import {
  BOQ_ITEM_PRICE_TYPE,
  BOQItemPrice,
  UnitOfMeasure,
} from "@prisma/client";
import { title } from "process";
import { QueryTenderDto } from "./dto/query-tender.dto";
@Injectable()
export class TenderService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: TenderRepository,
    private readonly prisma: PrismaService
  ) {}

  create(data: CreateTenderDto, userId: string) {
    //start transaction
    //create document and get the id
    //create tender with the document id
    //commit transaction
    return this.prisma.$transaction(async (tx) => {
      const documentRegistry = await this.crud.createWithTransaction(
        tx,
        "documentRegistry",
        { type: "tender", createdBy: userId }
      );
      return this.crud.createWithTransaction(tx, "tender", {
        ...data,
        documentRegistryId: documentRegistry.id,
      });
    });
  }

  findAll(query: QueryTenderDto) {
    let args: any = {};
    const { deadline_left_date, deadline_right_date } = query;
    if (deadline_left_date && deadline_right_date) {
      args.where = {
        tenderDeadline: {
          gte: deadline_left_date,
          lte: deadline_right_date,
        },
      };
    }
    return this.crud.findAll("tender", [], args);
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("tender", id);
  }

  async update(id: string, data: UpdateTenderDto, userId: string) {
    // Step 1: Update Tender
    const {
      name,
      projectName,
      projectScope,
      location,
      tenderDeadline,
      issuingOrganization,
      tenderValueEstimate,
    } = data;

    const updatedTender = await this.prisma.tender.update({
      where: { id },
      data: {
        name,
        projectName,
        projectScope,
        location,
        tenderDeadline,
        issuingOrganization,
        tenderValueEstimate,
      },
    });
    return updatedTender;
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("tender", id);
  }

  async approveOrReject(id: string, data: ApproveTenderDto, userId: string) {
    let { status, comment } = data;
    const tender = await this.prisma.tender.findUnique({
      where: { id },
      include: {
        documentRegistry: true,
      },
    });
    if (status === "approve") {
      const updatedDocument = await this.prisma.documentRegistry.update({
        where: {
          id: tender.documentRegistryId,
        },
        data: {
          currentStepNumber: tender.documentRegistry.currentStepNumber + 1,
        },
      });
      const step = await this.prisma.approvalWorkflowStep.findFirst({
        where: {
          approvalWorkflowId: tender.documentRegistry.approvalWorkflowId,
          orderNumber: updatedDocument.currentStepNumber,
        },
        include: {
          approver: true,
        },
      });
      if (!step) {
        this.prisma.documentRegistry.update({
          where: {
            id: tender.documentRegistryId,
          },
          data: {
            approvedStatus: true,
          },
        });
      } else {
        status = "SUBMITTED_FOR_REVIEW";
        const tender = await this.prisma.tender.findUnique({
          where: { id: id },
          include: {
            documentRegistry: true,
          },
        });

        await this.prisma.$transaction(async (tx) => {
          const step = await tx.approvalWorkflowStep.findFirst({
            where: {
              approvalWorkflowId: tender.documentRegistry.approvalWorkflowId,
              orderNumber: tender.documentRegistry.currentStepNumber,
            },
            include: {
              approver: {
                include: {
                  devices: true,
                },
              },
            },
          });

          const notification = await tx.notification.create({
            data: {
              title: "Document Submitted for Review",
              content: `The tender "${tender.name}" has been submitted for your review.`,
              redirectEntity: "tender",
              redirectId: tender.id,
            },
          });

          const deviceNotificationsData = step.approver.devices.map(
            (device) => ({
              deviceId: device.id,
              notificationId: notification.id,
            })
          );

          await tx.deviceNotification.createMany({
            data: deviceNotificationsData,
            skipDuplicates: true,
          });
        });
      }
    } else if (status === "revision_requested") {
      //handle comment update for the document registryid
      //get the highest order number of the particular document registry id in the comments table
      const highestOrderNumber = await this.crud.getHighestOrderNumber(
        "comment",
        { documentRegistryId: tender.documentRegistryId }
      );
      await this.prisma.comment.create({
        data: {
          documentRegistryId: tender.documentRegistryId,
          content: comment,
          orderNumber: highestOrderNumber + 1,
          commentedBy: userId,
        },
      });

      // notification: get createdby for tender.documentregistryid
      const createdBy = await this.prisma.documentRegistry.findUnique({
        where: {
          id: tender.documentRegistryId,
        },
        select: {
          createdBy: true,
        },
      });

      await this.prisma.$transaction(async (tx) => {
        const user = await tx.user.findUnique({
          where: {
            id: createdBy.createdBy,
          },
          include: {
            devices: true,
          },
        });

        const notification = await tx.notification.create({
          data: {
            title: "Revision requested",
            content: `The tender "${tender.name}" has been submitted for your review.`,
            redirectEntity: "tender",
            redirectId: tender.id,
          },
        });

        const deviceNotificationsData = user.devices.map((device) => ({
          deviceId: device.id,
          notificationId: notification.id,
        }));

        await tx.deviceNotification.createMany({
          data: deviceNotificationsData,
          skipDuplicates: true,
        });
      });
    }
    // return this.prisma.tender.update({
    //   where: { id },
    //   data: { status },
    // });
  }
}
