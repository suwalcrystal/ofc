export class Tender {}
