import { Module } from "@nestjs/common";
import { TenderService } from "./tender.service";
import { TenderController } from "./tender.controller";
import { CommonModule } from "src/common/common.module";
import { TenderRepository } from "./tender.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";
import { Role } from "src/generated-docs/role.entity";
import { RoleModule } from "../document-registry/partials/role/role.module";
import { ProjectRole } from "src/generated-docs/project-role.entity";
import { ProjectRoleRepository } from "../project-role/project-role.repository";

@Module({
  imports: [CommonModule, RoleModule],
  controllers: [TenderController],
  providers: [
    TenderService,
    TenderRepository,
    GenerateResponseMessage,
    PrismaService,
    ProjectRoleRepository,
  ],
})
export class TenderModule {}
