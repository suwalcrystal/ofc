import { Transform, Type } from "class-transformer";
import {
  IsDate,
  isISO8601,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from "class-validator";
import { ApiProperty } from "@nestjs/swagger";
import { BadRequestException } from "@nestjs/common";
import { isTodayOrFuture } from "src/common/utils/common.utils";

export class CreateTenderDto {
  @ApiProperty({
    example:
      " B+G+1+ROOF RESIDENTIAL VILLA + SWIMMING POOL +BOUNDARY WALLS AT PLOT No: 3940509, AL THANYAH FOURTH,DUBAI, UNITED ARAB EMIRATES",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    example: " B+G+1",
    required: true,
  })
  @IsOptional()
  @IsString()
  projectName?: string;

  @ApiProperty({
    example:
      " B+G+1+ROOF RESIDENTIAL VILLA + SWIMMING POOL +BOUNDARY WALLS AT PLOT No: 3940509, AL THANYAH FOURTH,DUBAI, UNITED ARAB EMIRATES",
    required: true,
  })
  @IsOptional()
  @IsString()
  projectScope?: string;

  @ApiProperty({
    example: "ALTHANYAH FOURTH , DUBAI, UNITED ARAB EMIRATES",
    required: true,
  })
  @IsOptional()
  @IsString()
  location?: string;

  @ApiProperty({
    example: "SERGIO RAFAEL DE MARCO CRUZ",
    required: true,
  })
  @IsOptional()
  @IsString()
  issuingOrganization?: string;

  @ApiProperty({
    example: "SERGIO RAFAEL DE MARCO CRUZ",
    required: true,
  })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiProperty({
    example: "2025-06-19",
    required: true,
  })
  @IsOptional()
  @Transform(({ value }) => {
    if (typeof value === "string" && !isISO8601(value)) {
      throw new BadRequestException({
        errors: [
          {
            field: "tenderDeadline",
            errors: ["Date must be a valid ISO8601 string"],
          },
        ],
      });
    }
    if (!isTodayOrFuture(value)) {
      throw new BadRequestException({
        errors: [
          {
            field: "tenderDeadline",
            errors: ["Date must be in the future"],
          },
        ],
      });
    }
    return new Date(value);
  })
  @IsDate()
  tenderDeadline?: Date;

  @ApiProperty({
    type: `number`,
    format: `float`,
    example: 10232.5,
    required: true,
  })
  @IsOptional()
  @IsNumber()
  tenderValueEstimate?: number;
}
