import { ApiProperty, PartialType } from "@nestjs/swagger";
import { CreateTenderDto } from "./create-tender.dto";
import {
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  ValidateNested,
} from "class-validator";
import { Type } from "class-transformer";

export class BOQItemPriceDto {
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsUUID()
  id?: string;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  unitRate?: number;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  type: string;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsUUID()
  boqItemId?: string;
}

export class BOQItemDto {
  @ApiProperty()
  @IsOptional()
  @IsUUID()
  id?: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  unitOfMeasure?: string;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  quantity?: number;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  unitRate?: number;

  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsOptional()
  @IsInt()
  orderNumber?: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  boqDescription?: string;

  @ApiProperty({ type: () => BOQItemPriceDto }) // <-- Important
  @IsOptional()
  @ValidateNested()
  @Type(() => BOQItemPriceDto)
  price?: BOQItemPriceDto;
}
export class UpdateTenderDto extends PartialType(CreateTenderDto) {}

export class UpdateBOQItemDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  status?: "SUBMITTED_FOR_REVIEW" | "CLOSED" | "APPROVED";

  @IsOptional()
  @ApiProperty({ type: () => BOQItemDto, isArray: true })
  @ValidateNested({ each: true })
  @Type(() => BOQItemDto)
  boqItems?: BOQItemDto[];
}

export class ApproveTenderDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  status?: "approve" | "revision_requested" | "SUBMITTED_FOR_REVIEW";

  @ApiProperty()
  @IsOptional()
  @IsString()
  comment?: string;
}
