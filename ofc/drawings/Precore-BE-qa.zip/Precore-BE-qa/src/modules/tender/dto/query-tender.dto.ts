// dto/query-tender.dto.ts
import {
  IsOptional,
  IsEnum,
  IsInt,
  Min,
  IsDateString,
  ValidateNested,
  IsDate,
  IsISO8601,
  isISO8601,
} from "class-validator";
import { Transform, Type } from "class-transformer";
import { ApiPropertyOptional } from "@nestjs/swagger";
import { IsValidDate } from "src/validators/is-valid-date.validator";
import { BadRequestException } from "@nestjs/common";

class DateRangeDto {
  @ApiPropertyOptional({ type: String, example: "2025-06-19" })
  @IsOptional()
  @IsDateString()
  @Transform(({ value }) => new Date(value))
  left_date?: string;

  @IsOptional()
  @ApiPropertyOptional({ type: String, example: "2025-06-19" })
  @IsDateString()
  @Transform(({ value }) => new Date(value))
  right_date?: string;
}

// export class QueryTenderDto {
//   @IsOptional()
//   @ValidateNested()
//   @Type(() => DateRangeDto)
//   deadline?: DateRangeDto;
// }
export class QueryTenderDto {
  @ApiPropertyOptional({ type: String, example: "2025-06-19" })
  @IsOptional()
  @Transform(({ value }) => {
    if (typeof value === "string" && !isISO8601(value)) {
      throw new Error("Not a valid ISO8601 string");
    }
    return new Date(value);
  })
  @IsDate()
  deadline_left_date?: Date;

  @ApiPropertyOptional({ type: String, example: "2025-06-19" })
  @IsOptional()
  @Transform(({ value }) => {
    const date = new Date(value);

    if (isNaN(date.getTime())) {
      throw new BadRequestException(`Invalid date: ${value}`);
    }
    return date;
  })
  deadline_right_date?: Date;
}
