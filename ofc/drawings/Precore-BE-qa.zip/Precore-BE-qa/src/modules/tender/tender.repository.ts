import { Injectable } from "@nestjs/common";
import { Tender, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class TenderRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Tender | null> {
    return this.prisma.tender.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(data: Prisma.TenderUncheckedCreateInput): Promise<Tender> {
    return this.prisma.tender.create({ data });
  }

  async update(id: string, data: Partial<Tender>): Promise<Tender> {
    return this.prisma.tender.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<Tender> {
    return this.prisma.tender.delete({
      where: {
        id: id,
      },
    });
  }
}
