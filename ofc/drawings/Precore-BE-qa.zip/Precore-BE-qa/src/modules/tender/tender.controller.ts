import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Request,
  Query,
} from "@nestjs/common";
import { TenderService } from "./tender.service";
import { CreateTenderDto } from "./dto/create-tender.dto";
import { ApproveTenderDto, UpdateTenderDto } from "./dto/update-tender.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard";
import { ApiBearerAuth } from "@nestjs/swagger";
import { log } from "console";
import { QueryTenderDto } from "./dto/query-tender.dto";
import { PermissionGuard } from "../auth/guards/permissions.guard";
import { Permissions } from "../auth/guards/permissions.decorator";
import { ParamsUnitDto } from "../item/partials/unit/dto/params-unit.dto";

@UseGuards(JwtAuthGuard)
@ApiBearerAuth("access-token")
@Controller("tender")
export class TenderController {
  constructor(
    private readonly tenderService: TenderService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  // @Post(":projectId")
  // async create(
  //   @Request() req,
  //   @Param("projectId") id: string,
  //   @Body() createTenderDto: CreateTenderDto
  // ) {
  //   return {
  //     data: await this.tenderService.create(createTenderDto, req.user.id),
  //     message: this.generateResponseService.generateCreateMessage("Tender"),
  //   };
  // }
  @Post("")
  async create(@Request() req, @Body() createTenderDto: CreateTenderDto) {
    return {
      data: await this.tenderService.create(createTenderDto, req.user.id),
      message: this.generateResponseService.generateCreateMessage("Tender"),
    };
  }

  @Get()
  async findAll(@Query() query: QueryTenderDto = {}) {
    return {
      data: await this.tenderService.findAll(query),
      message: this.generateResponseService.generateFindAllMessage("Tender"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.tenderService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage("Tender"),
    };
  }

  @Patch(":id")
  async update(
    @Request() req,
    @Param() params: ParamsUnitDto,
    @Body() updateTenderDto: UpdateTenderDto
  ) {
    return {
      data: await this.tenderService.update(
        params.id,
        updateTenderDto,
        req.user.id
      ),
      message: this.generateResponseService.generateUpdateMessage("Tender"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.tenderService.remove(id),
      message: this.generateResponseService.generateDeleteMessage("Tender"),
    };
  }

  @Post(":id/approve")
  async approveOrReject(
    @Request() req,
    @Param("id") id: string,
    @Body() data: ApproveTenderDto
  ) {
    return {
      data: await this.tenderService.approveOrReject(id, data, req.user.id),
      message: this.generateResponseService.generateDeleteMessage("Tender"),
    };
  }
}
