import { Injectable,Param } from "@nestjs/common";
import { CreateItemTypeDto } from "./dto/create-item-type.dto";
import { UpdateItemTypeDto } from "./dto/update-item-type.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { ItemTypeRepository } from "./item-type.repository";
@Injectable()
export class ItemTypeService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: ItemTypeRepository) {}

  create(data: CreateItemTypeDto) {
    return this.crud.create("itemType", data);
  }

  findAll() {
    return this.crud.findAll("itemType");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("itemType", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateItemTypeDto) {
    return this.crud.update("itemType", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("itemType", id);
  }
}