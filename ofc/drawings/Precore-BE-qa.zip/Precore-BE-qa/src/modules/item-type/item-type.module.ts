import { Module } from "@nestjs/common";
import { ItemTypeService } from "./item-type.service";
import { ItemTypeController } from "./item-type.controller";
import { CommonModule } from "src/common/common.module";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { ItemTypeRepository } from "./item-type.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Module({
  imports: [CommonModule],
  controllers: [ItemTypeController],
  providers: [
    ItemTypeService,
    PrismaService,
    ItemTypeRepository,
    GenerateResponseMessage,
  ],
})
export class ItemTypeModule {}
