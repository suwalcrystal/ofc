import { Injectable } from "@nestjs/common";
import { ItemType, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class ItemTypeRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<ItemType | null> {
    return this.prisma.itemType.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(data: Prisma.ItemTypeUncheckedCreateInput): Promise<ItemType> {
    return this.prisma.itemType.create({ data });
  }

  async update(id: string, data: Partial<ItemType>): Promise<ItemType> {
    return this.prisma.itemType.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<ItemType> {
    return this.prisma.itemType.delete({
      where: {
        id: id,
      },
    });
  }
}
