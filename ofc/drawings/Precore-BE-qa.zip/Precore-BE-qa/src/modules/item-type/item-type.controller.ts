import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ItemTypeService } from './item-type.service';
import { CreateItemTypeDto } from './dto/create-item-type.dto';
import { UpdateItemTypeDto } from './dto/update-item-type.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('item-type')
export class ItemTypeController {
  constructor(
    private readonly itemTypeService: ItemTypeService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createItemTypeDto: CreateItemTypeDto) {
    return {
      data: await this.itemTypeService.create(createItemTypeDto),
      message: this.generateResponseService.generateCreateMessage('ItemType'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.itemTypeService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('ItemType'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.itemTypeService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('ItemType'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateItemTypeDto: UpdateItemTypeDto
  ) {
    return {
      data: await this.itemTypeService.update(id, updateItemTypeDto),
      message: this.generateResponseService.generateUpdateMessage('ItemType'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.itemTypeService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('ItemType'),
    };
  }
}