import { Type } from "class-transformer";
import { IsIn, IsNotEmpty, IsOptional, IsString } from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";
import { ACTIVE_INACTIVE } from "@prisma/client";

export class CreateItemTypeDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    enum: ACTIVE_INACTIVE,
  })
  @IsNotEmpty()
  @IsOptional()
  @IsIn(["active", "inactive"])
  status?: ACTIVE_INACTIVE;
}
