import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Request,
  UseGuards,
} from "@nestjs/common";
import { RequestForQuoteService } from "./request-for-quote.service";
import { CreateRequestForQuoteDto } from "./dto/create-request-for-quote.dto";
import { UpdateRequestForQuoteDto } from "./dto/update-request-for-quote.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard";
import { ApiBearerAuth } from "@nestjs/swagger";

@UseGuards(JwtAuthGuard)
@ApiBearerAuth("access-token")
@Controller("request-for-quote")
export class RequestForQuoteController {
  constructor(
    private readonly requestForQuoteService: RequestForQuoteService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(
    @Request() req,
    @Body() createRequestForQuoteDto: CreateRequestForQuoteDto
  ) {
    return {
      data: await this.requestForQuoteService.create(
        createRequestForQuoteDto,
        req.user.id
      ),
      message:
        this.generateResponseService.generateCreateMessage("RequestForQuote"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.requestForQuoteService.findAll(),
      message:
        this.generateResponseService.generateFindAllMessage("RequestForQuote"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.requestForQuoteService.findOne(id),
      message:
        this.generateResponseService.generateFindOneMessage("RequestForQuote"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateRequestForQuoteDto: UpdateRequestForQuoteDto
  ) {
    return {
      data: await this.requestForQuoteService.update(
        id,
        updateRequestForQuoteDto
      ),
      message:
        this.generateResponseService.generateUpdateMessage("RequestForQuote"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.requestForQuoteService.remove(id),
      message:
        this.generateResponseService.generateDeleteMessage("RequestForQuote"),
    };
  }
}
