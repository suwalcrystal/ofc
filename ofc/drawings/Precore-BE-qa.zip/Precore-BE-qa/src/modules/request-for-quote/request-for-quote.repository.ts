import { Injectable } from "@nestjs/common";
import { RequestForQuote, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class RequestForQuoteRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<RequestForQuote | null> {
    return this.prisma.requestForQuote.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.RequestForQuoteUncheckedCreateInput
  ): Promise<RequestForQuote> {
    return this.prisma.requestForQuote.create({ data });
  }

  async update(
    id: string,
    data: Partial<RequestForQuote>
  ): Promise<RequestForQuote> {
    return this.prisma.requestForQuote.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<RequestForQuote> {
    return this.prisma.requestForQuote.delete({
      where: {
        id: id,
      },
    });
  }
}
