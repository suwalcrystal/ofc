import { Injectable, Param } from "@nestjs/common";
import { CreateRequestForQuoteDto } from "./dto/create-request-for-quote.dto";
import { UpdateRequestForQuoteDto } from "./dto/update-request-for-quote.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { RequestForQuoteRepository } from "./request-for-quote.repository";
import { PrismaService } from "src/prisma/prisma.service";
@Injectable()
export class RequestForQuoteService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: RequestForQuoteRepository,
    private readonly prisma: PrismaService
  ) {}

  create(data: CreateRequestForQuoteDto, userId: string) {
    // return this.crud.create("requestForQuote", data);
    return this.prisma.$transaction(async (tx) => {
      const documentRegistry = await this.crud.createWithTransaction(
        tx,
        "documentRegistry",
        { type: "requestForQuote", createdBy: userId }
      );
      await this.crud.createWithTransaction(tx, "requestForQuote", {
        ...data,
        documentRegistryId: documentRegistry.id,
        requesterId: userId,
      });
    });
  }

  findAll() {
    return this.crud.findAll("requestForQuote");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("requestForQuote", id);
  }

  update(@Param("id") id: string, data: UpdateRequestForQuoteDto) {
    return this.crud.update("requestForQuote", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("requestForQuote", id);
  }
}
