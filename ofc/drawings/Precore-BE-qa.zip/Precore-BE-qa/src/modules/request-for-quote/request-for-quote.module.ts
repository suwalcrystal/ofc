import { Module } from "@nestjs/common";
import { RequestForQuoteService } from "./request-for-quote.service";
import { RequestForQuoteController } from "./request-for-quote.controller";
import { CommonModule } from "src/common/common.module";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { RequestForQuoteRepository } from "./request-for-quote.repository";

@Module({
  imports: [CommonModule],
  controllers: [RequestForQuoteController],
  providers: [
    RequestForQuoteService,
    PrismaService,
    GenerateResponseMessage,
    RequestForQuoteRepository,
  ],
})
export class RequestForQuoteModule {}
