export class RequestForQuote {}
