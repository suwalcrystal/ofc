import { PartialType } from '@nestjs/swagger';
import { CreateRequestForQuoteDto } from './create-request-for-quote.dto';

export class UpdateRequestForQuoteDto extends PartialType(CreateRequestForQuoteDto) {}
