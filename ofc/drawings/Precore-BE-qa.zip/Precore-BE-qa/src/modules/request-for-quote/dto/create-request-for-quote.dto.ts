import { Transform, Type } from "class-transformer";
import {
  IsDate,
  IsIn,
  isISO8601,
  IsISO8601,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsRFC3339,
  IsString,
  IsUUID,
} from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";
import { PACKAGE_TYPE } from "@prisma/client";

export class CreateRequestForQuoteDto {
  @ApiProperty({
    example: "2025-06-19",
    required: true,
  })
  @IsOptional()
  @Transform(({ value }) => {
    if (typeof value === "string" && !isISO8601(value)) {
      throw new Error("Not a valid ISO8601 string");
    }
    return new Date(value);
  })
  @IsDate()
  desiredDeliveryDate?: Date;

  @ApiProperty({
    enum: PACKAGE_TYPE,
  })
  @IsNotEmpty()
  @IsIn([
    "enabling",
    "civil",
    "mep",
    "fitout",
    "joinery",
    "furnitures",
    "facade",
    "landscape",
    "swimming_pool",
    "water_features",
  ])
  packageName: PACKAGE_TYPE;

  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsNotEmpty()
  @IsUUID()
  projectId: string;
}

// export class CreateRFQLineItemDto {
//   @ApiProperty({
//     type: `number`,
//     format: `float`,
//   })
//   @IsNotEmpty()
//   @IsNumber()
//   quantity: number;
//   @ApiProperty()
//   @IsOptional()
//   @IsString()
//   notes?: string;
// }
