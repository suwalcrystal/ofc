export class Boqitem {}
