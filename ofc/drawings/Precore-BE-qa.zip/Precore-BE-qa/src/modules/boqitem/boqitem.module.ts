import { Module } from "@nestjs/common";
import { TenderBOQItemController } from "./tender-boq-item.controller";
import { BOQItemService } from "./boq-item.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { BOQItemRepository } from "./boq-item.repository";
import { CommonModule } from "src/common/common.module";
import { PrismaService } from "src/prisma/prisma.service";
import { ProjectBOQItemController } from "./project-boq-item.controller";
import { TenderRepository } from "../tender/tender.repository";

@Module({
  imports: [CommonModule],
  controllers: [TenderBOQItemController, ProjectBOQItemController],
  providers: [
    BOQItemService,
    GenerateResponseMessage,
    TenderRepository,
    BOQItemRepository,
    PrismaService,
  ],
})
export class BoqitemModule {}
