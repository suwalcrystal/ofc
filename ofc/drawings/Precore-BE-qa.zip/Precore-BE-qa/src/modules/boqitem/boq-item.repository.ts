import { Injectable } from "@nestjs/common";
import { BOQItem, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class BOQItemRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<BOQItem | null> {
    return this.prisma.bOQItem.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(data: Prisma.BOQItemUncheckedCreateInput): Promise<BOQItem> {
    return this.prisma.bOQItem.create({ data });
  }

  async update(id: string, data: Partial<BOQItem>): Promise<BOQItem> {
    return this.prisma.bOQItem.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<BOQItem> {
    return this.prisma.bOQItem.delete({
      where: {
        id: id,
      },
    });
  }
}
