import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
} from "@nestjs/common";
import { BOQItemService } from "./boq-item.service";

import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import {
  CreateBOQItemDto,
  CreateBOQItemsFromArrayDto,
} from "./dto/create-boq-item.dto";
import { UpdateBoqitemDto } from "./dto/update-boq-item.dto";
import { S3Service } from "src/common/s3/s3.service";
import { FileInterceptor } from "@nestjs/platform-express";

@Controller("tender/:tenderId/boq-item")
export class TenderBOQItemController {
  constructor(
    private readonly s3Service: S3Service,
    private readonly bOQItemService: BOQItemService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  @UseInterceptors(FileInterceptor("file"))
  async create(
    @Param("tenderId") tenderId: string,
    @Body() createBOQItemDto: CreateBOQItemsFromArrayDto
  ) {
    return {
      data: await this.bOQItemService.createMany(
        tenderId,
        "tender",
        createBOQItemDto.boqItems
      ),
      message: this.generateResponseService.generateCreateMessage("BOQItem"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.bOQItemService.findAll(),
      message: this.generateResponseService.generateFindAllMessage("BOQItem"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.bOQItemService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage("BOQItem"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateBOQItemDto: UpdateBoqitemDto
  ) {
    return {
      data: await this.bOQItemService.update(id, updateBOQItemDto),
      message: this.generateResponseService.generateUpdateMessage("BOQItem"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.bOQItemService.remove(id),
      message: this.generateResponseService.generateDeleteMessage("BOQItem"),
    };
  }
}
