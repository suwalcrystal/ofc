import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { BOQItemService } from "./boq-item.service";

import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { UpdateBoqitemDto } from "./dto/update-boq-item.dto";
import { CreateBOQItemsFromArrayDto } from "./dto/create-boq-item.dto";

@Controller("project/:projectId/boq-item")
export class ProjectBOQItemController {
  constructor(
    private readonly bOQItemService: BOQItemService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(
    @Param("projectId") projectId: string,
    @Body() createBOQItemDto: CreateBOQItemsFromArrayDto
  ) {
    console.log("here");

    return {
      data: await this.bOQItemService.createMany(
        projectId,
        "project",
        createBOQItemDto.boqItems
      ),
      message: this.generateResponseService.generateCreateMessage("BOQItem"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.bOQItemService.findAll(),
      message: this.generateResponseService.generateFindAllMessage("BOQItem"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.bOQItemService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage("BOQItem"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateBOQItemDto: UpdateBoqitemDto
  ) {
    return {
      data: await this.bOQItemService.update(id, updateBOQItemDto),
      message: this.generateResponseService.generateUpdateMessage("BOQItem"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.bOQItemService.remove(id),
      message: this.generateResponseService.generateDeleteMessage("BOQItem"),
    };
  }
}
