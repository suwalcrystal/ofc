import { Injectable, Param } from "@nestjs/common";

import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { BOQItemRepository } from "./boq-item.repository";
import { UpdateBoqitemDto } from "./dto/update-boq-item.dto";
import {
  CreateBOQItemDto,
  CreateBOQItemsFromArrayDto,
} from "./dto/create-boq-item.dto";
import { DocumentRegistryRepository } from "../document-registry/document-registry.repository";
import { TenderRepository } from "../tender/tender.repository";
import { PrismaService } from "src/prisma/prisma.service";
import { BOQ_ITEM_PRICE_TYPE, Prisma } from "@prisma/client";
@Injectable()
export class BOQItemService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: BOQItemRepository,
    private readonly prisma: PrismaService,
    private readonly tenderRepository: TenderRepository
  ) {}

  create(tenderId: string, type: string, data: CreateBOQItemDto) {
    return this.crud.create("bOQItem", data);
  }

  async createMany(resourceId: string, type: string, data: CreateBOQItemDto[]) {
    //create the data for boqitem
    //get document registry id for given tender id with type tender
    let documentRegistryId = "";
    if (type === "tender") {
      const tender = await this.prisma.tender.findUnique({
        where: {
          id: resourceId,
        },
      });

      try {
        const boqItems = [];
        for (const item of data) {
          let currentHighestOrderNumber = await this.crud.getHighestOrderNumber(
            "bOQItem",
            {
              documentRegistryId: tender.documentRegistryId,
            }
          );
          const boqItem = await this.prisma.$transaction(async (tx) => {
            const { price, ...boqData } = item;

            // if (item.id) {
            // Update existing BOQ item
            // const boqId = item.id;

            // await this.crud.updateWithTransaction(tx, "bOQItem", boqId, {
            //   ...boqData,
            // });

            // const updatedPrice = await this.prisma.bOQItemPrice.upsert({
            //   where: { id: price.id },
            //   update: {
            //     unitRate: price.unitRate,
            //     type: price.type as BOQ_ITEM_PRICE_TYPE,
            //   },
            //   create: {
            //     unitRate: price.unitRate,
            //     type: price.type as BOQ_ITEM_PRICE_TYPE,
            //     boqItemId: boqId,
            //   },
            // });
            // }
            //  else {
            // Create new BOQ item
            const boqItem = await this.crud.createWithTransaction(
              tx,
              "bOQItem",
              {
                ...boqData,
                type: "tender",
                orderNumber: ++currentHighestOrderNumber,
                documentRegistryId: tender.documentRegistryId,
              }
            );

            const priceObj = {
              boqItemId: boqItem.id,
              ...price,
            };

            await this.crud.createWithTransaction(tx, "bOQItemPrice", priceObj);
            return boqItem;
          });

          boqItems.push(boqItem);
        }
        return boqItems;
      } catch (error) {
        console.log(error, "errorr");
      }
    } else if (type === "project") {
      const project = await this.prisma.project.findUnique({
        where: {
          id: resourceId,
        },
      });

      try {
        for (const item of data) {
          let currentHighestOrderNumber = await this.crud.getHighestOrderNumber(
            "bOQItem",
            {
              documentRegistryId: project.documentRegistryId,
            }
          );
          await this.prisma.$transaction(async (tx) => {
            const { price, ...boqData } = item;

            // if (item.id) {
            //   // Update existing BOQ item
            //   const boqId = item.id;

            //   await this.crud.updateWithTransaction(tx, "bOQItem", boqId, {
            //     ...boqData,
            //   });

            //   const updatedPrice = await this.prisma.bOQItemPrice.upsert({
            //     where: { id: price.id },
            //     update: {
            //       unitRate: price.unitRate,
            //       type: price.type as BOQ_ITEM_PRICE_TYPE,
            //     },
            //     create: {
            //       unitRate: price.unitRate,
            //       type: price.type as BOQ_ITEM_PRICE_TYPE,
            //       boqItemId: boqId,
            //     },
            //   });
            // }
            //  else {
            // Create new BOQ item
            const boqItem = await this.crud.createWithTransaction(
              tx,
              "bOQItem",
              {
                ...boqData,
                type: "project",
                orderNumber: ++currentHighestOrderNumber,
                documentRegistryId: project.documentRegistryId,
              }
            );

            const priceObj = {
              boqItemId: boqItem.id,
              ...price,
              type: "project",
            };

            await this.crud.createWithTransaction(tx, "bOQItemPrice", priceObj);
            // }
          });
        }
      } catch (error) {
        console.log(error, "errorr");
      }
    }
  }

  findAll() {
    return this.crud.findAll("bOQItem");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("bOQItem", id);
  }

  update(@Param("id") id: string, data: UpdateBoqitemDto) {
    return this.crud.update("bOQItem", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("bOQItem", id);
  }

  async getBOQItemsForProject(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: { tender: true },
    });

    const registryId = project.createdFromTender
      ? project.tender?.documentRegistryId
      : project.documentRegistryId;

    return this.prisma.bOQItem.findMany({
      where: { documentRegistryId: registryId },
    });
  }
}
