import { ApiProperty, PartialType } from "@nestjs/swagger";
import { BOQItemPriceDto, CreateBOQItemDto } from "./create-boq-item.dto";
import {
  IsIn,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  ValidateNested,
} from "class-validator";
export class UpdateBoqitemDto extends PartialType(CreateBOQItemDto) {
  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsOptional()
  @IsInt()
  orderNumber?: number;
}

export class UpdateBOQItemPriceDto extends PartialType(BOQItemPriceDto) {
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsUUID()
  id?: string;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsUUID()
  boqItemId?: string;
}
