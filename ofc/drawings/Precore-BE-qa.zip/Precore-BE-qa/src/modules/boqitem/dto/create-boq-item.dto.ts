import { UnitOfMeasure } from "@prisma/client";

import { Type } from "class-transformer";

import {
  IsEnum,
  IsIn,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  ValidateNested,
} from "class-validator";

import { ApiProperty, getSchemaPath } from "@nestjs/swagger";
import { UpdateBoqitemDto } from "./update-boq-item.dto";

export class BOQItemPriceDto {
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  unitRate?: number;

  @ApiProperty({
    example: "tender",
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  type: string;
}

export class CreateBOQItemDto {
  // @ApiProperty({
  //   type: `number`,
  //   format: `float`,
  // })
  // @IsOptional()
  // @IsUUID()
  // id?: string;

  @ApiProperty({
    enum: UnitOfMeasure,
    example: "cubic_meters",
  })
  @Type(() => String)
  @IsOptional()
  @IsEnum(UnitOfMeasure)
  // @IsIn([
  //   "square_meters",
  //   "cubic_meters",
  //   "kilograms",
  //   "liters",
  //   "pieces",
  //   "hours",
  //   "days",
  //   "weeks",
  //   "months",
  // ])
  unitOfMeasure?: UnitOfMeasure;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  quantity?: number;

  @ApiProperty({
    example: "blinding concrete",
  })
  @IsOptional()
  @IsString()
  boqDescription?: string;

  @ApiProperty({ type: () => BOQItemPriceDto }) // <-- Important
  @IsOptional()
  @ValidateNested()
  @Type(() => BOQItemPriceDto)
  price?: BOQItemPriceDto;
}

export class CreateBOQItemsFromArrayDto {
  @IsOptional()
  @ApiProperty({ type: () => CreateBOQItemDto, isArray: true })
  @ValidateNested({ each: true })
  @Type(() => CreateBOQItemDto)
  boqItems?: CreateBOQItemDto[];
}
// "boqItems": [
//   {
//     "id": "<string>",
//     "unitOfMeasure": "<string>",
//     "quantity": "<float>",
//     "unitRate": "<float>",
//     "orderNumber": "<integer>",
//     "boqDescription": "<string>",
//     "price": {
//       "id": "<float>",
//       "unitRate": "<float>",
//       "type": "<float>",
//       "boqItemId": "<float>"
//     }
//   },
//   {
//     "id": "<string>",
//     "unitOfMeasure": "<string>",
//     "quantity": "<float>",
//     "unitRate": "<float>",
//     "orderNumber": "<integer>",
//     "boqDescription": "<string>",
//     "price": {
//       "id": "<float>",
//       "unitRate": "<float>",
//       "type": "<float>",
//       "boqItemId": "<float>"
//     }
//   }
// ],
