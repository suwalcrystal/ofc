import { Injectable, NotFoundException } from "@nestjs/common";
import { Prisma, Supplier } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { CreateSupplierDto } from "./dto/create-supplier.dto";

@Injectable()
export class SupplierRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Supplier | null> {
    return this.prisma.supplier.findUnique({ where: { id } });
  }

  async getSuppliers(id: string): Promise<Supplier[] | null> {
    // return this.prisma.supplier.findMany({ where: { deletedAt: null } });

    return this.prisma.supplier.findMany({});
  }

  async create(data: Prisma.SupplierUncheckedCreateInput): Promise<Supplier> {
    return this.prisma.supplier.create({ data });
  }

  async update(id: string, data: Partial<Supplier>): Promise<Supplier> {
    return this.prisma.supplier.update({ where: { id }, data });
  }

  async delete(id: string) {
    // const transaction = await this.prisma.$transaction([
    //   this.prisma.supplier.update({
    //     where: { id },
    //     data: { deletedAt: new Date() },
    //   }),

    //   this.prisma.paymentDetails.updateMany({
    //     where: { supplierId: id },
    //     data: { deletedAt: new Date() },
    //   }),
    // ]);

    // return transaction;
    return this.prisma.client.delete({
      where: {
        id: id,
      },
    });
  }
}
