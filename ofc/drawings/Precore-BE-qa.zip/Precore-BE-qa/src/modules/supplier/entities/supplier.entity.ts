export class Supplier {}
