import { Injectable, NotFoundException } from "@nestjs/common";
import { CreateSupplierDto } from "./dto/create-supplier.dto";
import { UpdateSupplierDto } from "./dto/update-supplier.dto";
import { SupplierRepository } from "./supplier.repository";
import { Prisma } from "@prisma/client";

@Injectable()
export class SupplierService {
  constructor(private readonly supplierRepository: SupplierRepository) {}
  create(createSupplierDto: CreateSupplierDto, file: Express.Multer.File) {
    const data: Prisma.SupplierUncheckedCreateInput = {
      ...createSupplierDto,
      image: file.filename,
    };
    return this.supplierRepository.create(data);
  }

  findAll() {
    return `This action returns all supplier`;
  }

  async findOne(id: string) {
    const supplier = await this.supplierRepository.getById(id);
    if (!supplier) {
      throw new NotFoundException(`User with ID "${id}" not found`);
    }
    return supplier;
  }

  update(id: number, updateSupplierDto: UpdateSupplierDto) {
    return `This action updates a #${id} supplier`;
  }

  remove(id: number) {
    return `This action removes a #${id} supplier`;
  }
}
