import { ApiProperty } from "@nestjs/swagger";
import { IsDateString, IsNotEmpty, IsString, IsUUID } from "class-validator";
import { IsUnique } from "src/validators/validators.service";
export class CreateSupplierDto {
  @ApiProperty({
    example: "Structure Complete",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    example: "Structure Complete",
    required: false,
  })
  @IsString()
  description: string;

  @ApiProperty({
    example: "985730948953",
    required: false,
  })
  @IsString()
  paymentDetailsId: string;
}
