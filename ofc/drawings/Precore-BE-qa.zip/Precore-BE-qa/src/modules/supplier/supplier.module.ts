import { Module } from "@nestjs/common";
import { SupplierService } from "./supplier.service";
import { SupplierController } from "./supplier.controller";
import { SupplierRepository } from "./supplier.repository";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { CommonModule } from "src/common/common.module";

@Module({
  imports: [CommonModule],
  controllers: [SupplierController],
  providers: [
    SupplierService,
    SupplierRepository,
    PrismaService,
    GenerateResponseMessage,
  ],
  exports: [SupplierService, SupplierRepository],
})
export class SupplierModule {}
