import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UploadedFile,
  Request,
} from "@nestjs/common";
import { SupplierService } from "./supplier.service";
import { CreateSupplierDto } from "./dto/create-supplier.dto";
import { UpdateSupplierDto } from "./dto/update-supplier.dto";
import { FileInterceptor } from "@nestjs/platform-express";
import { storage } from "../../helperServices/fileHelper";
import { ApiBody, ApiConsumes } from "@nestjs/swagger";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { paginatedData } from "src/utils/pagination";
import { PrismaService } from "src/prisma/prisma.service";
import { Prisma } from "@prisma/client";
@Controller("supplier")
export class SupplierController {
  constructor(
    private readonly supplierService: SupplierService,
    private readonly generateResponseService: GenerateResponseMessage,
    private readonly prisma: PrismaService
  ) {}

  @Post()
  @UseInterceptors(
    FileInterceptor("image", {
      storage,
      // fileFilter,
      limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
    })
  )
  @ApiConsumes("multipart/form-data")
  @ApiBody({
    schema: {
      type: "object",
      properties: {
        image: {
          type: "string",
          format: "binary",
        },
        name: {
          type: "string",
          example: "Gary and Wilson",
        },
        description: {
          type: "Gary and Wilson",
        },
        paymentDetailsId: {
          type: "a26dc3b3-1bce-4af2-9b08-bdb2f4e40f4f",
        },
      },
    },
  })
  create(
    @UploadedFile() file: Express.Multer.File,
    @Body() createSupplierDto: CreateSupplierDto
  ) {
    return this.supplierService.create(createSupplierDto, file);
  }

  @Get()
  async findAll(@Request() req) {
    const match = {};
    const sort = {};
    const includeObj: Prisma.SupplierInclude = {
      paymentDetails: true,
    };
    const { page = 1, perPage = 10 } = req.query;
    const { records, pagination } = await paginatedData(
      this.prisma.supplier,
      match,
      sort,
      page,
      perPage,
      includeObj
    );

    return {
      data: records,
      pagination,
      message: this.generateResponseService.generateFindAllMessage("Supplier"),
    };
  }

  @Get(":id")
  findOne(@Param("id") id: string) {
    return this.supplierService.findOne(id);
  }

  @Patch(":id")
  update(
    @Param("id") id: string,
    @Body() updateSupplierDto: UpdateSupplierDto
  ) {
    return this.supplierService.update(+id, updateSupplierDto);
  }

  @Delete(":id")
  remove(@Param("id") id: string) {
    return this.supplierService.remove(+id);
  }
}
