import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { CurrencyService } from "./currency.service";
import { CreateCurrencyDto } from "./dto/create-currency.dto";
import { UpdateCurrencyDto } from "./dto/update-currency.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Controller("currency")
export class CurrencyController {
  constructor(
    private readonly currencyService: CurrencyService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createCurrencyDto: CreateCurrencyDto) {
    return {
      data: await this.currencyService.create(createCurrencyDto),
      message: this.generateResponseService.generateCreateMessage("Currency"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.currencyService.findAll(),
      message: this.generateResponseService.generateFindAllMessage("Currency"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.currencyService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage("Currency"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateCurrencyDto: UpdateCurrencyDto
  ) {
    return {
      data: await this.currencyService.update(id, updateCurrencyDto),
      message: this.generateResponseService.generateUpdateMessage("Currency"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.currencyService.remove(id),
      message: this.generateResponseService.generateDeleteMessage("Currency"),
    };
  }
}
