import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";
import { IsUnique } from "src/validators/validators.service";

export class CreateCurrencyDto {
  @ApiProperty({
    example: "US Dollar",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  @IsUnique(["currency", "name"], { message: "Currency is already in use" })
  name: string;

  @ApiProperty({
    example: "$",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  @IsUnique(["currency", "symbol"], {
    message: "Currency symbol is already in use",
  })
  symbol: string;
}
