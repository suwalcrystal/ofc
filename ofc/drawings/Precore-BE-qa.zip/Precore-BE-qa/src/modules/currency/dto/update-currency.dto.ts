import { PartialType } from "@nestjs/swagger";
import { CreateCurrencyDto } from "./create-currency.dto";
import { IsNotEmpty, IsString } from "class-validator";
import { IsUnique } from "src/validators/validators.service";

export class UpdateCurrencyDto extends PartialType(CreateCurrencyDto) {
  id?: string;

  @IsNotEmpty()
  @IsString()
  @IsUnique(["currency", "name", "id"]) // 'id' will now be in dto
  name: string;

  @IsNotEmpty()
  @IsString()
  @IsUnique(["currency", "symbol", "id"]) // validator uses it to exclude current record
  symbol: string;
}
