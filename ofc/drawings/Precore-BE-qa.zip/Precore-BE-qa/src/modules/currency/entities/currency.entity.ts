export class Currency {}
