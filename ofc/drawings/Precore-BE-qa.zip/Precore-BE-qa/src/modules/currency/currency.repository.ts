import { Injectable, NotFoundException } from "@nestjs/common";
import { Currency } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { CreateCurrencyDto } from "./dto/create-currency.dto";

@Injectable()
export class CurrencyRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Currency | null> {
    return this.prisma.currency.findUnique({ where: { id } });
  }

  async create(data: CreateCurrencyDto): Promise<Currency> {
    return this.prisma.currency.create({ data });
  }

  async update(id: string, data: Partial<Currency>): Promise<Currency> {
    return this.prisma.currency.update({ where: { id }, data });
  }

  async delete(id: string): Promise<Currency> {
    return this.prisma.currency.delete({ where: { id } });
  }
}
