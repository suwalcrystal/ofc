import { MiddlewareConsumer, Module } from "@nestjs/common";
import { CurrencyService } from "./currency.service";
import { CurrencyController } from "./currency.controller";
import { AttachIdToBodyMiddleware } from "src/middlewares/AttachIdToRequestBody.middleware";
import { CommonModule } from "src/common/common.module";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Module({
  imports: [CommonModule],
  controllers: [CurrencyController],
  providers: [CurrencyService, GenerateResponseMessage],
})
export class CurrencyModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(AttachIdToBodyMiddleware).forRoutes("currency/:id"); // or CurrencyController if you want all
  }
}
