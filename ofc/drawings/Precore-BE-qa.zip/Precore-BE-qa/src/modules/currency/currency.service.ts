import { Injectable } from "@nestjs/common";
import { CreateCurrencyDto } from "./dto/create-currency.dto";
import { UpdateCurrencyDto } from "./dto/update-currency.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";

@Injectable()
export class CurrencyService {
  constructor(private readonly crud: GenericCrudService) {}

  create(data: CreateCurrencyDto) {
    return this.crud.create("currency", data);
  }

  findAll() {
    return this.crud.findAll("currency");
  }

  findOne(id: string) {
    return this.crud.findOne("currency", id);
  }

  update(id: string, data: UpdateCurrencyDto) {
    return this.crud.update("currency", id, data);
  }

  remove(id: string) {
    return this.crud.remove("currency", id);
  }
}
