import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { SiteDiaryEntryService } from './site-diary-entry.service';
import { CreateSiteDiaryEntryDto } from './dto/create-site-diary-entry.dto';
import { UpdateSiteDiaryEntryDto } from './dto/update-site-diary-entry.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('site-diary-entry')
export class SiteDiaryEntryController {
  constructor(
    private readonly siteDiaryEntryService: SiteDiaryEntryService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createSiteDiaryEntryDto: CreateSiteDiaryEntryDto) {
    return {
      data: await this.siteDiaryEntryService.create(createSiteDiaryEntryDto),
      message: this.generateResponseService.generateCreateMessage('SiteDiaryEntry'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.siteDiaryEntryService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('SiteDiaryEntry'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.siteDiaryEntryService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('SiteDiaryEntry'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateSiteDiaryEntryDto: UpdateSiteDiaryEntryDto
  ) {
    return {
      data: await this.siteDiaryEntryService.update(id, updateSiteDiaryEntryDto),
      message: this.generateResponseService.generateUpdateMessage('SiteDiaryEntry'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.siteDiaryEntryService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('SiteDiaryEntry'),
    };
  }
}