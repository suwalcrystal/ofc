import { Injectable,Param } from "@nestjs/common";
import { CreateSiteDiaryEntryDto } from "./dto/create-site-diary-entry.dto";
import { UpdateSiteDiaryEntryDto } from "./dto/update-site-diary-entry.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { SiteDiaryEntryRepository } from "./site-diary-entry.repository";
@Injectable()
export class SiteDiaryEntryService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: SiteDiaryEntryRepository) {}

  create(data: CreateSiteDiaryEntryDto) {
    return this.crud.create("siteDiaryEntry", data);
  }

  findAll() {
    return this.crud.findAll("siteDiaryEntry");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("siteDiaryEntry", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateSiteDiaryEntryDto) {
    return this.crud.update("siteDiaryEntry", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("siteDiaryEntry", id);
  }
}