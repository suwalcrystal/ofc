import { Injectable } from "@nestjs/common";
import { SiteDiaryEntry, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class SiteDiaryEntryRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<SiteDiaryEntry | null> {
    return this.prisma.siteDiaryEntry.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.SiteDiaryEntryUncheckedCreateInput
  ): Promise<SiteDiaryEntry> {
    return this.prisma.siteDiaryEntry.create({ data });
  }

  async update(
    id: string,
    data: Partial<SiteDiaryEntry>
  ): Promise<SiteDiaryEntry> {
    return this.prisma.siteDiaryEntry.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<SiteDiaryEntry> {
    return this.prisma.siteDiaryEntry.delete({
      where: {
        id: id,
      },
    });
  }
}
