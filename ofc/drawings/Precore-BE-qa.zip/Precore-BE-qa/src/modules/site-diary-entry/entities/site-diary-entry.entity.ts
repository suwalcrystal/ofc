export class SiteDiaryEntry {}
