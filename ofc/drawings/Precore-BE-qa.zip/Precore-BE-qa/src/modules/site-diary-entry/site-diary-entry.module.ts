import { Module } from "@nestjs/common";
import { SiteDiaryEntryService } from "./site-diary-entry.service";
import { SiteDiaryEntryController } from "./site-diary-entry.controller";
import { CommonModule } from "src/common/common.module";
import { PrismaService } from "src/prisma/prisma.service";
import { SiteDiaryEntryRepository } from "./site-diary-entry.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Module({
  imports: [CommonModule],
  controllers: [SiteDiaryEntryController],
  providers: [
    SiteDiaryEntryService,
    PrismaService,
    SiteDiaryEntryRepository,
    GenerateResponseMessage,
  ],
})
export class SiteDiaryEntryModule {}
