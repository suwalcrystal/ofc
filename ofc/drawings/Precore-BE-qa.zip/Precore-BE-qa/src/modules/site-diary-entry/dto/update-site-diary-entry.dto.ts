import { PartialType } from '@nestjs/swagger';
import { CreateSiteDiaryEntryDto } from './create-site-diary-entry.dto';

export class UpdateSiteDiaryEntryDto extends PartialType(CreateSiteDiaryEntryDto) {}
