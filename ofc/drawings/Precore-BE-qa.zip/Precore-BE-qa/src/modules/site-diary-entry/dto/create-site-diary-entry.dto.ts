import { SITE_DIARY_ENTRY_APPROVAL_STATUS } from "@prisma/client";
import { Type } from "class-transformer";
import {
  IsBoolean,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreateSiteDiaryEntryDto {
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  quantityCompleted?: number;
  @ApiProperty()
  @IsOptional()
  @IsBoolean()
  isCompleted?: boolean;
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  totalManualPercentCompleted?: number;
  @ApiProperty({
    enum: SITE_DIARY_ENTRY_APPROVAL_STATUS,
  })
  @IsNotEmpty()
  @IsIn(["PENDING", "APPROVED"])
  approvalStatus: SITE_DIARY_ENTRY_APPROVAL_STATUS;
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  notes: string;
  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsNotEmpty()
  @IsInt()
  numberOfPeople: number;
  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsNotEmpty()
  @IsInt()
  totalWorkingHours: number;
  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsNotEmpty()
  @IsInt()
  workingHoursPerPerson: number;
}
