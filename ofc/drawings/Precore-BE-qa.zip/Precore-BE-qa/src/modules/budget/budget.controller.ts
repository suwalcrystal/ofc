import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Request,
  UseGuards,
} from "@nestjs/common";
import { BudgetService } from "./budget.service";
import { CreateBudgetDto } from "./dto/create-budget.dto";
import { UpdateBudgetDto } from "./dto/update-budget.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard";
import { ApiBearerAuth } from "@nestjs/swagger";

@UseGuards(JwtAuthGuard)
@ApiBearerAuth("access-token")
@Controller("project/:projectId/budget")
export class BudgetController {
  constructor(
    private readonly budgetService: BudgetService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(
    @Request() req,
    @Body() createBudgetDto: CreateBudgetDto,
    @Param("projectId") projectId: string
  ) {
    return {
      data: await this.budgetService.create(
        projectId,
        createBudgetDto,
        req.user.id
      ),
      message: this.generateResponseService.generateCreateMessage("Budget"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.budgetService.findAll(),
      message: this.generateResponseService.generateFindAllMessage("Budget"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.budgetService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage("Budget"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateBudgetDto: UpdateBudgetDto
  ) {
    return {
      data: await this.budgetService.update(id, updateBudgetDto),
      message: this.generateResponseService.generateUpdateMessage("Budget"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.budgetService.remove(id),
      message: this.generateResponseService.generateDeleteMessage("Budget"),
    };
  }
}
