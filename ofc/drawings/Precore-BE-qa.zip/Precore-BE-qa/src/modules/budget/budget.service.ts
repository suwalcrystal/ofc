import { Injectable, Param } from "@nestjs/common";
import { CreateBudgetDto } from "./dto/create-budget.dto";
import { UpdateBudgetDto } from "./dto/update-budget.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { BudgetRepository } from "./budget.repository";
import { PrismaService } from "src/prisma/prisma.service";
@Injectable()
export class BudgetService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly prisma: PrismaService,
    private readonly repository: BudgetRepository
  ) {}

  create(projectId: string, data: CreateBudgetDto, userId: string) {
    //format data
    //insert into boqitemprice with type budget and adjusted unit price
    //get the price and boqitemid for that

    const { boqItems, budgetCode } = data;

    return this.prisma.$transaction(async (tx) => {
      let boqItemPrices = boqItems.map((item: any) => {
        //  {
        //    adjustedUnitRate: number;
        //    boqItemId: string;
        //  }
        console.log(item, "item");

        return {
          unitRate: item.adjustedUnitPrice,
          type: "budget",
          boqItemId: item.boqItemId,
        };
      });

      const documentRegistry = await this.crud.createWithTransaction(
        tx,
        "documentRegistry",
        { type: "tender", createdBy: userId }
      );

      await this.crud.createMany("bOQItemPrice", boqItemPrices);
      //for this only get the project id, budget code from data
      const budget = await this.crud.createWithTransaction(tx, "budget", {
        documentRegistryId: documentRegistry.id,
        createdBy: userId,
        projectId,
        budgetCode,
      });

      let boqItemBudgetDetails = boqItems.map((item: any) => {
        return {
          boqItemId: item.boqItemId,
          packageName: item.package,
          budgetId: budget.id,
        };
      });
      const bOQItemBudgetDetails = await this.crud.createManyWithTransaction(
        tx,
        "bOQItemBudgetDetails",
        boqItemBudgetDetails
      );
    });
    // return this.crud.create("budget", { ...data, createdBy: userId });
  }

  findAll() {
    return this.crud.findAll("budget");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("budget", id);
  }

  update(@Param("id") id: string, data: UpdateBudgetDto) {
    return this.crud.update("budget", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("budget", id);
  }
}
