import { Transform, Type } from "class-transformer";
import {
  IsDate,
  isISO8601,
  IsISO8601,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsRFC3339,
  IsString,
  IsUUID,
  ValidateNested,
} from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";
import { PACKAGE_TYPE } from "@prisma/client";

export class BOQItemBudgetDetails {
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsUUID()
  id?: string;

  @ApiProperty({
    type: `string`,
  })
  @IsUUID()
  boqItemId: string;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  adjustedUnitPrice?: number;

  @ApiProperty({
    example: "enabling",
    type: `string`,
  })
  @IsString()
  package: PACKAGE_TYPE;
}

export class CreateBudgetDto {
  @ApiProperty({
    type: `string`,
  })
  @IsString()
  budgetCode: string;

  @IsOptional()
  @ApiProperty({ type: () => BOQItemBudgetDetails, isArray: true })
  @ValidateNested({ each: true })
  boqItems?: BOQItemBudgetDetails[];
}
