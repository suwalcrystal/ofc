import { Module } from "@nestjs/common";
import { BudgetService } from "./budget.service";
import { BudgetController } from "./budget.controller";
import { CommonModule } from "src/common/common.module";
import { PrismaService } from "src/prisma/prisma.service";
import { BudgetRepository } from "./budget.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Module({
  imports: [CommonModule],
  controllers: [BudgetController],
  providers: [
    BudgetService,
    PrismaService,
    GenerateResponseMessage,
    BudgetRepository,
  ],
})
export class BudgetModule {}
