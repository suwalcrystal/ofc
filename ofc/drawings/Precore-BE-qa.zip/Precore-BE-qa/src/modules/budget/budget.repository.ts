import { Injectable } from "@nestjs/common";
import { Budget, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class BudgetRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Budget | null> {
    return this.prisma.budget.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(data: Prisma.BudgetUncheckedCreateInput): Promise<Budget> {
    return this.prisma.budget.create({ data });
  }

  async update(id: string, data: Partial<Budget>): Promise<Budget> {
    return this.prisma.budget.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<Budget> {
    return this.prisma.budget.delete({
      where: {
        id: id,
      },
    });
  }
}
