import { Type } from "class-transformer";

import { IsNotEmpty, IsOptional, IsString } from "class-validator";

import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreateNotificationDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  title: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  content: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  redirectEntity?: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  redirectId?: string;
}
