import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { NotificationService } from "./notification.service";
import { CreateNotificationDto } from "./dto/create-notification.dto";
import {
  ChangeNotificationStatusDto,
  UpdateNotificationDto,
} from "./dto/update-notification.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Controller("notification")
export class NotificationController {
  constructor(
    private readonly notificationService: NotificationService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createNotificationDto: CreateNotificationDto) {
    return {
      data: await this.notificationService.create(createNotificationDto),
      message:
        this.generateResponseService.generateCreateMessage("Notification"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.notificationService.findAll(),
      message:
        this.generateResponseService.generateFindAllMessage("Notification"),
    };
  }

  @Patch(":id/status")
  async changeStatus(
    @Param("id") id: string,
    data: ChangeNotificationStatusDto
  ) {
    return {
      data: await this.notificationService.changeStatus(id, data),
      message:
        this.generateResponseService.generateFindOneMessage("Notification"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateNotificationDto: UpdateNotificationDto
  ) {
    return {
      data: await this.notificationService.update(id, updateNotificationDto),
      message:
        this.generateResponseService.generateUpdateMessage("Notification"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.notificationService.remove(id),
      message:
        this.generateResponseService.generateDeleteMessage("Notification"),
    };
  }
}
