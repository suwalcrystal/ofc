import { Module } from "@nestjs/common";
import { NotificationService } from "./notification.service";
import { NotificationController } from "./notification.controller";
import { CommonModule } from "src/common/common.module";
import { NotificationRepository } from "./notification.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
  imports: [CommonModule],
  controllers: [NotificationController],
  providers: [
    NotificationService,
    NotificationRepository,
    GenerateResponseMessage,
    PrismaService,
  ],
})
export class NotificationModule {}
