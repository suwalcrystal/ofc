import { Injectable } from "@nestjs/common";
import { Notification, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class NotificationRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Notification | null> {
    return this.prisma.notification.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.NotificationUncheckedCreateInput
  ): Promise<Notification> {
    return this.prisma.notification.create({ data });
  }

  async update(id: string, data: Partial<Notification>): Promise<Notification> {
    return this.prisma.notification.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<Notification> {
    return this.prisma.notification.delete({
      where: {
        id: id,
      },
    });
  }

  async changeStatus(
    id: string,
    data: Partial<Notification>
  ): Promise<Notification> {
    return this.prisma.notification.update({
      where: {
        id: id,
      },
      data: {
        isRead: data.isRead,
      },
    });
  }
}
