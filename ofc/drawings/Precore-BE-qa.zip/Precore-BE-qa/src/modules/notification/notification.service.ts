import { Injectable, Param } from "@nestjs/common";
import { CreateNotificationDto } from "./dto/create-notification.dto";
import {
  ChangeNotificationStatusDto,
  UpdateNotificationDto,
} from "./dto/update-notification.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { NotificationRepository } from "./notification.repository";
@Injectable()
export class NotificationService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: NotificationRepository
  ) {}

  create(data: CreateNotificationDto) {
    return this.crud.create("notification", data);
  }

  findAll() {
    return this.crud.findAll("notification");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("notification", id);
  }

  changeStatus(@Param("id") id: string, data: ChangeNotificationStatusDto) {
    return this.repository.changeStatus(id, data);
  }

  update(@Param("id") id: string, data: UpdateNotificationDto) {
    return this.crud.update("notification", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("notification", id);
  }
}
