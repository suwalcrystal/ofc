import { Module } from "@nestjs/common";
import { ProjectRoleService } from "./project-role.service";
import { ProjectRoleController } from "./project-role.controller";
import { ProjectRoleRepository } from "./project-role.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";
import { CommonModule } from "src/common/common.module";

@Module({
  imports: [CommonModule],
  controllers: [ProjectRoleController],
  providers: [
    ProjectRoleService,
    ProjectRoleRepository,
    GenerateResponseMessage,
    PrismaService,
  ],
  exports: [ProjectRoleRepository],
})
export class ProjectRoleModule {}
