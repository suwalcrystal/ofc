import { Injectable,Param } from "@nestjs/common";
import { CreateProjectRoleDto } from "./dto/create-project-role.dto";
import { UpdateProjectRoleDto } from "./dto/update-project-role.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { ProjectRoleRepository } from "./project-role.repository";
@Injectable()
export class ProjectRoleService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: ProjectRoleRepository) {}

  create(data: CreateProjectRoleDto) {
    return this.crud.create("projectRole", data);
  }

  findAll() {
    return this.crud.findAll("projectRole");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("projectRole", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateProjectRoleDto) {
    return this.crud.update("projectRole", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("projectRole", id);
  }
}