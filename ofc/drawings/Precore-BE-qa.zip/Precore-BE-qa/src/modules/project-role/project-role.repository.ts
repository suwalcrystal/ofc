import { Injectable } from "@nestjs/common";
import { ProjectRole, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class ProjectRoleRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<ProjectRole | null> {
    return this.prisma.projectRole.findUnique({
      where: {
        id: id,
      },
    });
  }

  async getPermissionsForUserIdProjectId(userId: string, projectId: string) {
    const projectRole = await this.prisma.projectRole.findFirst({
      where: {
        userId: "3fe8733d-0624-4dd2-988e-31aa78ec4021",
        projectId: "f47ac10b-58cc-4372-a567-0e02b2c3e481",
      },
      include: {
        role: {
          include: { rolePermissions: { include: { permission: true } } },
        },
      },
    });
    return projectRole.role.rolePermissions;
  }

  async create(
    data: Prisma.ProjectRoleUncheckedCreateInput
  ): Promise<ProjectRole> {
    return this.prisma.projectRole.create({ data });
  }

  async update(id: string, data: Partial<ProjectRole>): Promise<ProjectRole> {
    return this.prisma.projectRole.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<ProjectRole> {
    return this.prisma.projectRole.delete({
      where: {
        id: id,
      },
    });
  }
}
