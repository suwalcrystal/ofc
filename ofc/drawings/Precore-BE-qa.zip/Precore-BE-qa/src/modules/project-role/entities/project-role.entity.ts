export class ProjectRole {}
