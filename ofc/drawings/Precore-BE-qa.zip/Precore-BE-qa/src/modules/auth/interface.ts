// import { ROLE } from "@prisma/client";

export interface UserDetails {
  email: string;
  name: string;
  // role: ROLE;
}

export interface CreateUserDto {
  name: string;
  email: string;
  password?: string;
  role: string;
  isEmailVerified: boolean;
}

export interface ValidatedUserPayload {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface JwtPayload {
  id: string;
  name: string;
  email: string;
  roleId: string;
}

export interface IChatUserListQuery {
  keyword?: string;
  page?: string;
  limit?: string;
}

export interface VerificationTokenPayload {
  email: string;
}

export interface IPagination {
  skip: number;
  take: number;
}
