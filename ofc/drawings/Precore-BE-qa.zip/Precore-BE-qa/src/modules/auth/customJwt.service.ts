import { BadRequestException, Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { JwtService } from "@nestjs/jwt";
import { JwtPayload, VerificationTokenPayload } from "./interface";

@Injectable()
export class CustomJwtService {
  constructor(
    private jwtService: JwtService,
    private configService: ConfigService
  ) {}

  generateAccessJwtToken(payload: JwtPayload) {
    return this.jwtService.signAsync(payload, {
      secret: this.configService.get<string>("jwt.access_token_secret"),
      expiresIn: this.configService.get<string>("jwt.access_expiration_time"),
    });
  }

  generateRefreshJwtToken(payload: JwtPayload) {
    return this.jwtService.signAsync(payload, {
      secret: this.configService.get<string>("jwt.refresh_token_secret"),
      expiresIn: this.configService.get<string>("jwt.refresh_expiration_time"),
    });
  }

  async generateAccessAndRefreshToken(payload: JwtPayload) {
    const access_token = await this.generateAccessJwtToken(payload);
    const refresh_token = await this.generateRefreshJwtToken(payload);
    return { access_token, refresh_token };
  }

  generateReferralJwtToken(payload: any) {
    return this.jwtService.signAsync(payload, {
      secret: this.configService.get<string>("jwt.referral_token_secret"),
      expiresIn: this.configService.get<string>("jwt.referral_expiration_time"),
    });
  }

  generateVerificationEmailToken(payload: VerificationTokenPayload) {
    return this.jwtService.signAsync(payload, {
      secret: this.configService.get<string>(
        "jwt.email_verification_token_secret"
      ),
      expiresIn: this.configService.get<string>(
        "jwt.email_verification_token_expiration_time"
      ),
    });
  }

  async decodeConfirmationToken(token: string) {
    try {
      const payload: VerificationTokenPayload = await this.jwtService.verify(
        token,
        {
          secret: this.configService.get("jwt.email_verification_token_secret"),
        }
      );

      if (typeof payload === "object" && "email" in payload) {
        return payload.email;
      }
      throw new BadRequestException();
    } catch (error) {
      if (error?.name === "TokenExpiredError") {
        throw new BadRequestException("Email confirmation token expired");
      }
      throw new BadRequestException("Bad confirmation token");
    }
  }
}
