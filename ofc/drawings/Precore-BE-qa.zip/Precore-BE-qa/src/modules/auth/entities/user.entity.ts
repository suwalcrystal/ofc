// import { User } from '@prisma/client';
// import { ApiProperty } from '@nestjs/swagger';
// export enum ROLE {
//   ADMIN = 'ADMIN',
//   COACH = 'COACH',
//   COACHEE = 'COACHEE',
// }
// export class UserEntity implements User {
//   @ApiProperty()
//   id: number;

//   @ApiProperty()
//   email: string;

//   @ApiProperty({
//     type: 'string',
//     enum: ROLE,
//     default: ROLE.COACHEE
//   })
//   role: ROLE;

//   @ApiProperty({ required: false, nullable: true })
//   name: string | null;

//   @ApiProperty({ required: false, nullable: true })
//   password: string | null;

//   @ApiProperty()
//   createdAt: Date;

//   @ApiProperty()
//   updatedAt: Date;
// }
