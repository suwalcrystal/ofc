import { ExtractJwt, Strategy } from "passport-jwt";
import { PassportStrategy } from "@nestjs/passport";
import {
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from "@nestjs/common";
import { AuthService } from "../auth.service";
import { Request as RequestType } from "express";
import { ConfigService } from "@nestjs/config";
import { JwtPayload, ValidatedUserPayload } from "src/modules/auth/interface";
import { RoleRepository } from "src/modules/document-registry/partials/role/role.repository";

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, "jwt") {
  constructor(
    private readonly authService: AuthService,
    private configService: ConfigService,
    private readonly roleRepository: RoleRepository
  ) {
    const secret = configService.get<string>("JWT.ACCESS_TOKEN_SECRET");
    if (!secret) {
      throw new Error(
        "JWT access token secret is not defined in the configuration."
      );
    }

    super({
      ignoreExpiration: false,
      secretOrKey: secret,
      jwtFromRequest: ExtractJwt.fromExtractors([
        // JwtStrategy.extractJwt, // Uncommented to enable cookie-based token extraction
        ExtractJwt.fromAuthHeaderAsBearerToken(),
      ]),
    });
  }

  async validate(payload: JwtPayload): Promise<ValidatedUserPayload> {
    const user = await this.authService.findUser(payload.id);
    //JWTPayload includes roleId with roleId field value roleId
    //validated user payload includes role field whose value is roleCode
    if (!user) {
      throw new UnauthorizedException("Please log in to continue");
    }

    const role = await this.roleRepository.getById(user.roleId);
    if (!role) {
      throw new NotFoundException("Role not found");
    }
    // Uncomment this block if email verification is required
    // if (!user.isEmailVerified) {
    //   console.error("Forbidden: Email not verified"); // Debugging log
    //   throw new ForbiddenException('Confirm your email first');
    // }

    return {
      id: user.id,
      email: user.email,
      name: user.name,
      role: role?.roleCode,
    };
  }

  private static extractJwt(req: RequestType): string | null {
    if (
      req.cookies &&
      "access_token" in req.cookies &&
      req.cookies.access_token.length > 0
    ) {
      return req.cookies.access_token;
    }

    return null;
  }
}
