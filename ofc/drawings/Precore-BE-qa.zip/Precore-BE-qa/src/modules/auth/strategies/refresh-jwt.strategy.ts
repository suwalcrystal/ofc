import { Strategy as CustomStrategy } from "passport-custom";
import { PassportStrategy } from "@nestjs/passport";
import { Injectable, UnauthorizedException } from "@nestjs/common";
import { AuthService } from "../auth.service";
import { Request } from "express";
import { ValidatedUserPayload } from "../interface";

@Injectable()
export class RefreshJwtStrategy extends PassportStrategy(
  CustomStrategy,
  "refresh-jwt",
) {
  constructor(private readonly authService: AuthService) {
    super(); // No arguments here
  }

  async validate(req: Request): Promise<ValidatedUserPayload> {
    const token: string | undefined = req.body?.refreshToken;

    if (!token) {
      throw new UnauthorizedException("Refresh token missing");
    }

    const payload = await this.authService.verifyRefreshToken(token);
    const user = await this.authService.findUser(payload.id);

    if (!user) {
      throw new UnauthorizedException("User not found");
    }

    return payload; // This will be attached to req.user
  }
}
