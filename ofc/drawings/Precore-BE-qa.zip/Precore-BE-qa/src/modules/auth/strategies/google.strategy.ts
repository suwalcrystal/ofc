import { Injectable } from "@nestjs/common";
import { PassportStrategy } from "@nestjs/passport";
import { Profile, Strategy } from "passport-google-oauth20";
import { AuthService } from "../auth.service";
import { ConfigService } from "@nestjs/config";

@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy) {
  constructor(
    private readonly authService: AuthService,
    private readonly configService: ConfigService,
  ) {
    super({
      clientID: configService.get<string>("GOOGLE_OAUTH.CLIENT_ID"),
      clientSecret: configService.get<string>("GOOGLE_OAUTH.CLIENT_SECRET"),
      callbackURL: configService.get<string>("GOOGLE_OAUTH.CALL_BACK_URL"),
      scope: ["profile", "email"],
    });
  }

  async validate(
    _accessToken: string,
    _refreshToken: string,
    profile: Profile,
  ) {
    if (!profile.emails) return null;
    const user = "ji";
    // const user = await this.authService.validateUser({
    //   email: profile.emails[0].value,
    //   name: profile.displayName,
    // });

    return user || null;
  }
}
