import { Injectable } from "@nestjs/common";
import { PrismaService } from "src/prisma/prisma.service";
import { UserDetails } from "src/utils/types";
import { CreateUserDto } from "./dtos/user.dto";
import { Prisma } from "@prisma/client";
import { RoleRepository } from "src/modules/document-registry/partials/role/role.repository";

@Injectable()
export class AuthRepository {
  constructor(
    private prisma: PrismaService,
    private readonly roleRepository: RoleRepository
  ) {}

  async findOneByEmail(email: string) {
    return await this.prisma.user.findFirst({ where: { email } });
  }

  async getDeviceToken(userId: string) {
    return await this.prisma.user.findFirst({
      where: { id: userId },
      include: { devices: true },
    });
  }
  async createNewUser(details: CreateUserDto) {
    const { role: roleCode, name, email, password } = details;
    const role = await this.roleRepository.getByRoleCode(roleCode);

    const userInput: Prisma.UserUncheckedCreateInput = {
      name: details.name,
      email: details.email,
      password: details.password,
      roleId: role.id,
    };

    return this.prisma.user.create({ data: userInput });
  }
  async findOneById(id: string) {
    return await this.prisma.user.findFirst({ where: { id } });
  }

  async getIdByRoleCode(code: string) {
    return await this.prisma.role.findFirst({ where: { roleCode: code } });
  }
}
