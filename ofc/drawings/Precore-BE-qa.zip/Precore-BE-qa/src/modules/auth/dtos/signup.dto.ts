import { IsBoolean, IsString } from "class-validator";
import { LoginUserDto } from "./login.dto";

export class CreateUserDto extends LoginUserDto {
  @IsString()
  name: string;

  // @IsBoolean()
  // isCoach: boolean;
}
