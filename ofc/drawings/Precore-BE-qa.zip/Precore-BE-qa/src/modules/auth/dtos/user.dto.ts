import { ApiProperty } from "@nestjs/swagger";
import { Exclude, Expose } from "class-transformer";
import {
  IsEmail,
  IsNotEmpty,
  IsString,
  IsOptional,
  IsDate,
  IsNumber,
} from "class-validator";
import { IsUnique } from "src/validators/validators.service";

export class CreateUserDto {
  @ApiProperty({
    example: "dikpalregime",
    required: true,
  })
  @IsNotEmpty({ message: "Name is required" })
  @IsString({ message: "Must be a string" })
  name: string;

  @ApiProperty({
    example: "rabinabaga@gmail.com",
    required: true,
  })
  @IsNotEmpty()
  @IsEmail()
  @IsUnique(["user", "email"], { message: "Email is already in use" })
  email: string;

  @ApiProperty({
    example: "quantity-surveyor",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  role: string;

  @ApiProperty({
    example: "123456",
    required: false,
  })
  @IsNotEmpty()
  @IsString()
  password: string;
}

export class UserResponseDto {
  @Expose()
  id: string;

  @IsString()
  @Expose()
  name: string;

  @IsNumber()
  @Expose()
  email: string;

  @IsString()
  @Exclude()
  password: string | null;

  @IsDate()
  @Expose()
  createdAt: Date;

  @IsDate()
  @Expose()
  updatedAt: Date;
}
