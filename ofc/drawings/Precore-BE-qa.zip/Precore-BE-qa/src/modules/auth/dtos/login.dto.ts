import { ApiProperty } from "@nestjs/swagger";
import { IsEmail, IsString } from "class-validator";

export class LoginUserDto {
  @ApiProperty({
    example: "rabinabag@gmail.com",
    required: true,
  })
  @IsEmail()
  email: string;

  @ApiProperty({
    example: "123456",
    required: true,
  })
  @IsString()
  password: string;
}

export class RefreshTokenDto {
  @IsString()
  refreshToken: string;
}
