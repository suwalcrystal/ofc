import { Module } from "@nestjs/common";
import { AuthService } from "./auth.service";
import { AuthController } from "./auth.controller";
import { PrismaService } from "src/prisma/prisma.service";
import { AuthRepository } from "./auth.repository";
import { GoogleStrategy } from "./strategies/google.strategy";
import { SessionSerializer } from "./strategies/serializer.util";
import { JwtStrategy } from "./strategies/jwt.strategy";
import { CustomJwtService } from "./customJwt.service";
import { ValidatorsModule } from "src/validators/validators.module";
import { RefreshJwtStrategy } from "./strategies/refresh-jwt.strategy";
import { RoleModule } from "src/modules/document-registry/partials/role/role.module";

@Module({
  imports: [ValidatorsModule, RoleModule],
  controllers: [AuthController],
  providers: [
    PrismaService,
    AuthRepository,
    GoogleStrategy,
    RefreshJwtStrategy,
    SessionSerializer,
    JwtStrategy,
    AuthService,
    CustomJwtService,
  ],
  exports: [
    JwtStrategy,
    RefreshJwtStrategy,
    AuthRepository,
    AuthService,
    CustomJwtService,
  ],
})
export class AuthModule {}
