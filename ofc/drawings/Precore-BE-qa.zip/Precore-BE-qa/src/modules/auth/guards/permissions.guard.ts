// roles.guard.ts
import { CanActivate, ExecutionContext, Injectable } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { RoleRepository } from "src/modules/document-registry/partials/role/role.repository";
import { ProjectRoleRepository } from "src/modules/project-role/project-role.repository";

@Injectable()
export class PermissionGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private readonly roleRepository: RoleRepository,
    private readonly projectRoleRepository: ProjectRoleRepository
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredPermissions = this.reflector.get<string[]>(
      "permissions",
      context.getHandler()
    );
    if (!requiredPermissions) return true;

    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const userId = request.user.id;
    const projectId = request.params.projectId;
    let permissionTitles: string[];
    if (projectId) {
      //check for role of user in a project from project role table
      const projectRole =
        await this.projectRoleRepository.getPermissionsForUserIdProjectId(
          userId,
          projectId
        );
      permissionTitles = projectRole.map((rp) => rp.permission.title);
    } else {
      const permissionsForRole =
        await this.roleRepository.getPermissionsForRoleCode(user.role);
      permissionTitles = permissionsForRole.rolePermissions.map(
        (rp) => rp.permission.title
      );
    }

    const hasPermission = requiredPermissions.some((permission) =>
      permissionTitles.includes(permission)
    );
    return hasPermission;
  }
}
