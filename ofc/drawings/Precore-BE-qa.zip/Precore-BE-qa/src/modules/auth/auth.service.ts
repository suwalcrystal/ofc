import {
  BadRequestException,
  Injectable,
  InternalServerErrorException,
  UnauthorizedException,
} from "@nestjs/common";

import jwt from "jsonwebtoken";

import { AuthRepository } from "./auth.repository";
import { UserDetails } from "src/utils/types";
import { JwtService } from "@nestjs/jwt";
import { CustomJwtService } from "./customJwt.service";
import { User } from "@prisma/client";
import { LoginUserDto } from "./dtos/login.dto";
import { JwtPayload, ValidatedUserPayload } from "./interface";
import { ConfigService } from "@nestjs/config";
import { CreateUserDto } from "./dtos/user.dto";
import { RoleRepository } from "src/modules/document-registry/partials/role/role.repository";
import * as bcrypt from "bcrypt";
const saltOrRounds = 10;

@Injectable()
export class AuthService {
  constructor(
    private readonly repository: AuthRepository,
    private readonly roleRepository: RoleRepository,
    private jwtService: JwtService,
    private configService: ConfigService,
    private readonly customJwtService: CustomJwtService
  ) {}
  async signup(payload: CreateUserDto) {
    const { email, name, password, role } = payload;
    const oldUser = await this.findUserByEmail(email);
    if (oldUser)
      throw new BadRequestException("User already exist with given email");

    const hashedPassword = await bcrypt.hash(password, saltOrRounds);

    const user = await this.repository.createNewUser(
      {
        name: name,
        email,
        password: hashedPassword,
        role: role,
        // role: isCoach ? ROLE.coach : ROLE.trainee,
        // isEmailVerified: false,
      }
      // false
    );

    // const { access_token, refresh_token } =
    //   await this.generateAccessAndRefreshTokenAndRevokedOldToken(user);

    // await this.sendVerificationEmail(user.email);

    return user;
  }

  // async generateAccessAndRefreshTokenAndRevokedOldToken(payload: User) {
  //   const { id, name, email } = payload;
  //   const { access_token, refresh_token } =
  //     await this.customJwtService.generateAccessAndRefreshToken({
  //       id,
  //       name,
  //       email,
  //     });

  //   // await this.repository.storeAndRevokedOldRefreshToken({
  //   //   userId: id,
  //   //   refreshToken: refresh_token,
  //   // });
  //   return { access_token, refresh_token };
  // }

  // async signIn(payload: CreateUserDto) {
  //   if (!payload) throw new BadRequestException("Unauthenticated");

  //   const user = await this.findUserByEmail(payload.email);
  //   if (!user) {
  //     return this.registerUser(payload);
  //   }

  //   const { access_token, refresh_token } =
  //     await this.generateAccessAndRefreshTokenAndRevokedOldToken(user);
  //   return { access_token, refresh_token, user };
  // }
  async validateUser(details: CreateUserDto) {
    const user = await this.repository.findOneByEmail(details.email);
    if (user) return user;

    return await this.repository.createNewUser(details);
  }

  generateJwt(payload: JwtPayload) {
    return this.jwtService.signAsync(payload, {
      secret: this.configService.get<string>("JWT.ACCESS_TOKEN_SECRET"),
      expiresIn: this.configService.get<string>("JWT.ACCESS_EXPIRATION_TIME"),
    });
  }

  generateRefreshJwt(payload: JwtPayload) {
    return this.jwtService.signAsync(payload, {
      secret: this.configService.get<string>(
        "REFRESH_JWT.REFRESH_TOKEN_SECRET"
      ),
      expiresIn: this.configService.get<string>(
        "REFRESH_JWT.REFRESH_EXPIRATION_TIME"
      ),
    });
  }

  async signIn(user: LoginUserDto): Promise<Record<string, string>> {
    if (!user) {
      throw new BadRequestException("Unauthenticated");
    }

    const userExists = await this.findUserByEmail(user.email);

    if (!userExists) {
      throw new BadRequestException("User not found");
    }

    const accessToken = await this.generateJwt({
      id: userExists.id,
      email: userExists.email,
      name: userExists.name,
      roleId: userExists.roleId,
    });

    const refreshToken = await this.generateRefreshJwt({
      id: userExists.id,
      email: userExists.email,
      name: userExists.name,
      roleId: userExists.roleId,
    });

    return { accessToken, refreshToken };
  }

  async handleRefreshToken(payload: ValidatedUserPayload) {
    const user = await this.findUser(payload.id); // You already have this in your service

    if (!user) {
      throw new UnauthorizedException("Invalid refresh token: user not found.");
    }

    const newPayload: JwtPayload = {
      id: user.id,
      email: user.email,
      name: user.name,
      roleId: user.roleId,
    }; // include what you need
    const accessToken = await this.generateJwt(newPayload);

    return {
      accessToken,
    };
  }

  async verifyRefreshToken(token: string): Promise<any> {
    try {
      const secret = this.configService.get<string>(
        "REFRESH_JWT.REFRESH_TOKEN_SECRET"
      );

      if (!secret) {
        throw new Error("Refresh token secret not configured.");
      }
      const decoded = this.jwtService.decode(token);

      const payload = await this.jwtService.verifyAsync(token, {
        secret,
      });

      return payload;
    } catch (err) {
      throw new UnauthorizedException("Invalid or expired refresh token.");
    }
  }

  // async registerUser(user: CreateUserDto) {
  //   try {
  //     const newUser = await this.repository.createNewUser(user);

  //     return this.generateJwt({
  //       sub: "1",
  //       email: newUser.email,
  //       name: newUser.name || "no name",
  //     });
  //   } catch {
  //     throw new InternalServerErrorException();
  //   }
  // }

  async findUserByEmail(email: string) {
    const user = await this.repository.findOneByEmail(email);

    if (!user) {
      return null;
    }

    return user;
  }

  async getDeviceToken(userId: string) {
    const user = await this.repository.getDeviceToken(userId);

    if (!user) {
      return null;
    }

    const devices = user.devices ? user.devices : [];
    let devicesTokens: string[];
    devices.forEach((device) => {
      if (device.token) {
        devicesTokens.push(device.token);
      }
    });
    return devicesTokens;
  }

  async findUser(id: string) {
    return await this.repository.findOneById(id);
  }
}
