import {
  Controller,
  Get,
  UseGuards,
  Req,
  Res,
  HttpStatus,
  Post,
  Body,
} from "@nestjs/common";
import { AuthService } from "./auth.service";
import { GoogleAuthGuard } from "./guards/google-oauth.guard";
import { Response } from "express";
import { UserDetails } from "src/utils/types";
import { JwtAuthGuard } from "./guards/jwt-auth.guard";
import { LoginUserDto, RefreshTokenDto } from "./dtos/login.dto";
import { CreateUserDto, UserResponseDto } from "./dtos/user.dto";
import { Serialize } from "src/interceptors/serialize.interceptor";
import { RefreshJwtAuthGuard } from "./guards/refresh-jwt.guard";
import { ValidatedUserPayload } from "./interface";

@Controller("auth")
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  // @Get("google/login")
  // @UseGuards(GoogleAuthGuard)
  // handleLogin() {
  //   return { msg: "Google authentication" };
  // }

  @Post("signup")
  @Serialize(UserResponseDto)
  async signup(@Body() body: CreateUserDto) {
    const user = await this.authService.signup(body);
    return { data: user, message: "Signup successful" };
  }

  @Post("signin")
  // @Serialize(TokenResponseDto)
  async signIn(@Body() body: LoginUserDto) {
    const { accessToken, refreshToken } = await this.authService.signIn(body);
    return {
      message: "Successfully signin.",
      data: { accessToken, refreshToken },
    };
  }

  @UseGuards(RefreshJwtAuthGuard)
  @Post("refresh")
  // @Serialize(TokenResponseDto)
  async refresh(
    @Req() req: Request & { user: ValidatedUserPayload },
    @Body() body: RefreshTokenDto
  ) {
    const { accessToken } = await this.authService.handleRefreshToken(req.user);
    return {
      message: "Successfully signin.",
      data: { accessToken },
    };
  }

  // @Get("google/redirect")
  // @UseGuards(GoogleAuthGuard)
  // async handleRedirect(@Req() req: Request, @Res() res: Response) {
  //   const token = await this.authService.signIn(req.user as CreateUserDto);

  //   res.cookie("access_token", token, {
  //     maxAge: 2592000000,
  //     sameSite: true,
  //     secure: false,
  //   });

  //   return res.status(HttpStatus.OK).json({ access_token: token });
  // }

  // @Get("status")
  // @UseGuards(JwtAuthGuard)
  // getStatus(@Req() req: Request) {
  //   return { ...req.user };
  // }
}
