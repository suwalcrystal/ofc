import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Query,
  Request,
} from "@nestjs/common";
import { ProjectService } from "./project.service";
import { CreateProjectDto } from "./dto/create-project.dto";
import { UpdateProjectDto } from "./dto/update-project.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { RolesGuard } from "../auth/guards/roles.guard";
import { PermissionGuard } from "../auth/guards/permissions.guard";
import { Permissions } from "../auth/guards/permissions.decorator";
import { query } from "express";
import { QueryProjectDto } from "./dto/query-project-dto";
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard";
import { ApiBearerAuth } from "@nestjs/swagger";

@UseGuards(JwtAuthGuard)
@ApiBearerAuth("access-token")
@Controller("project")
export class ProjectController {
  constructor(
    private readonly projectService: ProjectService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @UseGuards(PermissionGuard)
  @Permissions("manage_project")
  @Post()
  async create(@Request() req, @Body() createProjectDto: CreateProjectDto) {
    return {
      data: await this.projectService.create(createProjectDto, req.user.id),
      message: this.generateResponseService.generateCreateMessage("Project"),
    };
  }

  @Get()
  async findAll(@Query() query: QueryProjectDto = {}) {
    return {
      data: await this.projectService.findAll(query),
      message: this.generateResponseService.generateFindAllMessage("Project"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.projectService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage("Project"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateProjectDto: UpdateProjectDto
  ) {
    return {
      data: await this.projectService.update(id, updateProjectDto),
      message: this.generateResponseService.generateUpdateMessage("Project"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.projectService.remove(id),
      message: this.generateResponseService.generateDeleteMessage("Project"),
    };
  }
}
