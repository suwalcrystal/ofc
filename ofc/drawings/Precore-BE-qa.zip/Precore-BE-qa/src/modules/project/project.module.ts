import { Module } from "@nestjs/common";
import { ProjectService } from "./project.service";
import { ProjectController } from "./project.controller";
import { CommonModule } from "src/common/common.module";
import { ProjectRepository } from "./project.repository";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { RoleModule } from "../document-registry/partials/role/role.module";
import { ProjectRoleModule } from "../project-role/project-role.module";

@Module({
  imports: [CommonModule, RoleModule, ProjectRoleModule],
  controllers: [ProjectController],
  providers: [
    ProjectService,
    ProjectRepository,
    PrismaService,
    GenerateResponseMessage,
  ],
})
export class ProjectModule {}
