import { Type } from "class-transformer";
import { IsNotEmpty, IsOptional, IsRFC3339, IsString } from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";
import { PROJECT_TYPE } from "@prisma/client";

export class CreateProjectDto {
  @ApiProperty({
    example: "Proposed",
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    example: "P-MN",
  })
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  code: string;

  @ApiProperty({ example: "residential" })
  @IsNotEmpty()
  @IsString()
  type: PROJECT_TYPE;

  @ApiProperty({ example: "Dubai" })
  @IsNotEmpty()
  @IsString()
  location: string;

  @ApiProperty({ example: "Joseph" })
  @IsNotEmpty()
  @IsString()
  clientName: string;

  @ApiProperty({ example: "Proposed B+1" })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: "Villa in Dubai" })
  @IsOptional()
  @IsString()
  strategicGoals?: string;

  @ApiProperty({ example: "30ce3c59-1469-4c99-a7d8-72fadfc4566b" })
  @IsOptional()
  @IsString()
  tenderId?: string;
}
