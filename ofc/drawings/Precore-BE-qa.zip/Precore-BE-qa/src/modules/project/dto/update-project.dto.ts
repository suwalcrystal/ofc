import { PartialType } from "@nestjs/swagger";
import { CreateProjectDto } from "./create-project.dto";
import { Type } from "class-transformer";
import { IsNotEmpty, IsOptional, IsRFC3339, IsString } from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class UpdateProjectDto extends PartialType(CreateProjectDto) {
  @ApiProperty()
  @IsOptional()
  @IsString()
  status?: string;

  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsOptional()
  @IsRFC3339()
  actualEndDate?: Date;

  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsOptional()
  @IsRFC3339()
  actualStartDate?: Date;
}
