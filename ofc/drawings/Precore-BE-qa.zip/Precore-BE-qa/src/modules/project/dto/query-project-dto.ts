// dto/query-tender.dto.ts
import {
  IsOptional,
  IsEnum,
  IsInt,
  Min,
  IsDateString,
  ValidateNested,
  IsDate,
  IsISO8601,
  isISO8601,
  IsBoolean,
} from "class-validator";
import { Transform, Type } from "class-transformer";
import { ApiPropertyOptional } from "@nestjs/swagger";
import { IsValidDate } from "src/validators/is-valid-date.validator";
import { BadRequestException } from "@nestjs/common";

class DateRangeDto {
  @ApiPropertyOptional({ type: String, example: "2025-06-19" })
  @IsOptional()
  @IsDateString()
  @Transform(({ value }) => new Date(value))
  left_date?: string;

  @IsOptional()
  @ApiPropertyOptional({ type: String, example: "2025-06-19" })
  @IsDateString()
  @Transform(({ value }) => new Date(value))
  right_date?: string;
}

// export class QueryTenderDto {
//   @IsOptional()
//   @ValidateNested()
//   @Type(() => DateRangeDto)
//   deadline?: DateRangeDto;
// }
export class QueryProjectDto {
  @ApiPropertyOptional({ type: Boolean, example: true })
  @IsOptional()
  @Transform(({ value }) => value === "true")
  @IsBoolean()
  approvedStatus?: boolean;

  @ApiPropertyOptional({ type: Boolean, example: true })
  @Transform(({ value }) => value === "true")
  @IsOptional()
  @IsBoolean()
  fulfilledStatus?: boolean;
}
