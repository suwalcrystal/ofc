import { Injectable } from "@nestjs/common";
import { Project, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class ProjectRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Project | null> {
    return this.prisma.project.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(data: Prisma.ProjectUncheckedCreateInput): Promise<Project> {
    return this.prisma.project.create({ data });
  }

  async update(id: string, data: Partial<Project>): Promise<Project> {
    return this.prisma.project.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<Project> {
    return this.prisma.project.delete({
      where: {
        id: id,
      },
    });
  }
}
