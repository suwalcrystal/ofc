import { BadRequestException, Injectable, Param } from "@nestjs/common";
import { CreateProjectDto } from "./dto/create-project.dto";
import { UpdateProjectDto } from "./dto/update-project.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { ProjectRepository } from "./project.repository";
import { QueryProjectDto } from "./dto/query-project-dto";
import { PrismaService } from "src/prisma/prisma.service";
@Injectable()
export class ProjectService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: ProjectRepository,
    private readonly prisma: PrismaService
  ) {}

  async create(data: CreateProjectDto, userId: string) {
    if (data.code) {
      const project = await this.crud.findAll("project", [], {
        where: { code: data.code },
      });
      if (project.length > 0) {
        throw new BadRequestException("Project code already exists");
      }
    }
    return this.prisma.$transaction(async (tx) => {
      const documentRegistry = await this.crud.createWithTransaction(
        tx,
        "documentRegistry",
        { type: "project", createdBy: userId }
      );

      let dataWithTenderId: any = { ...data };
      if (data.tenderId) {
        dataWithTenderId = { ...data, createdFromTender: true };
      }
      return await this.crud.createWithTransaction(tx, "project", {
        ...dataWithTenderId,
        documentRegistryId: documentRegistry.id,
      });
    });
  }

  findAll(query: QueryProjectDto = {}) {
    if (query.approvedStatus && !query.fulfilledStatus) {
      return this.crud.findAll("project", ["documentRegistry"], {
        where: {
          documentRegistry: {
            approvedStatus: query.approvedStatus,
            fulfilledStatus: query.fulfilledStatus,
          },
        },
      });
    }
    return this.crud.findAll("project");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("project", id);
  }

  update(@Param("id") id: string, data: UpdateProjectDto) {
    return this.crud.update("project", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("project", id);
  }
}
