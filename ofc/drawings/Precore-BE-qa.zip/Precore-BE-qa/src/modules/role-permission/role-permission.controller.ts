import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { RolePermissionService } from './role-permission.service';
import { CreateRolePermissionDto } from './dto/create-role-permission.dto';
import { UpdateRolePermissionDto } from './dto/update-role-permission.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('role-permission')
export class RolePermissionController {
  constructor(
    private readonly rolePermissionService: RolePermissionService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createRolePermissionDto: CreateRolePermissionDto) {
    return {
      data: await this.rolePermissionService.create(createRolePermissionDto),
      message: this.generateResponseService.generateCreateMessage('RolePermission'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.rolePermissionService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('RolePermission'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.rolePermissionService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('RolePermission'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateRolePermissionDto: UpdateRolePermissionDto
  ) {
    return {
      data: await this.rolePermissionService.update(id, updateRolePermissionDto),
      message: this.generateResponseService.generateUpdateMessage('RolePermission'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.rolePermissionService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('RolePermission'),
    };
  }
}