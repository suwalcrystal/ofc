export class CreateRolePermissionDto {}
