import { Injectable,Param } from "@nestjs/common";
import { CreateRolePermissionDto } from "./dto/create-role-permission.dto";
import { UpdateRolePermissionDto } from "./dto/update-role-permission.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { RolePermissionRepository } from "./role-permission.repository";
@Injectable()
export class RolePermissionService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: RolePermissionRepository) {}

  create(data: CreateRolePermissionDto) {
    return this.crud.create("rolePermission", data);
  }

  findAll() {
    return this.crud.findAll("rolePermission");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("rolePermission", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateRolePermissionDto) {
    return this.crud.update("rolePermission", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("rolePermission", id);
  }
}