import { Module } from "@nestjs/common";
import { RolePermissionService } from "./role-permission.service";
import { RolePermissionController } from "./role-permission.controller";
import { CommonModule } from "src/common/common.module";
import { RolePermissionRepository } from "./role-permission.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
  imports: [CommonModule],

  controllers: [RolePermissionController],
  providers: [
    RolePermissionService,
    RolePermissionRepository,
    GenerateResponseMessage,
    PrismaService,
  ],
})
export class RolePermissionModule {}
