import { Injectable } from "@nestjs/common";
import { RolePermission, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class RolePermissionRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<RolePermission | null> {
    return this.prisma.rolePermission.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.RolePermissionUncheckedCreateInput
  ): Promise<RolePermission> {
    return this.prisma.rolePermission.create({ data });
  }

  async update(
    id: string,
    data: Partial<RolePermission>
  ): Promise<RolePermission> {
    return this.prisma.rolePermission.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<RolePermission> {
    return this.prisma.rolePermission.delete({
      where: {
        id: id,
      },
    });
  }
}
