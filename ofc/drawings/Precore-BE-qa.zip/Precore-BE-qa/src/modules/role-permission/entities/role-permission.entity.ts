export class RolePermission {}
