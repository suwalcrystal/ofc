import { Injectable } from "@nestjs/common";
import { Task, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class TaskRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Task | null> {
    return this.prisma.task.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(data: Prisma.TaskUncheckedCreateInput): Promise<Task> {
    return this.prisma.task.create({ data });
  }

  async update(id: string, data: Partial<Task>): Promise<Task> {
    return this.prisma.task.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<Task> {
    return this.prisma.task.delete({
      where: {
        id: id,
      },
    });
  }
}
