import { Module } from "@nestjs/common";
import { TaskService } from "./task.service";
import { TaskController } from "./task.controller";
import { CommonModule } from "src/common/common.module";
import { TaskRepository } from "./task.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
  imports: [CommonModule],
  controllers: [TaskController],
  providers: [
    TaskService,
    TaskRepository,
    GenerateResponseMessage,
    PrismaService,
  ],
})
export class TaskModule {}
