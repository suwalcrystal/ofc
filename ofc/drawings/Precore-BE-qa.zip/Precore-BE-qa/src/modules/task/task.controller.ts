import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { TaskService } from "./task.service";
import { CreateTaskDto } from "./dto/create-task.dto";
import { UpdateTaskDto } from "./dto/update-task.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Controller("projects/:projectId/tasks")
export class TaskController {
  constructor(
    private readonly taskService: TaskService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(
    @Param("projectId") projectId: string,
    @Body() createTaskDto: CreateTaskDto
  ) {
    return {
      data: await this.taskService.create({
        ...createTaskDto,
        projectId: projectId,
      }),
      message: this.generateResponseService.generateCreateMessage("Task"),
    };
  }

  @Get()
  async findAll(@Param("projectId") projectId: string) {
    return {
      data: projectId
        ? await this.taskService.findAll(projectId)
        : await this.taskService.findAll(),
      message: this.generateResponseService.generateFindAllMessage("Task"),
    };
  }

  @Get(":id")
  async findOne(
    @Param("projectId") projectId: string,
    @Param("id") id: string
  ) {
    return {
      data: await this.taskService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage("Task"),
    };
  }

  @Patch(":id")
  async update(
    @Param("projectId") projectId: string,
    @Param("id") id: string,
    @Body() updateTaskDto: UpdateTaskDto
  ) {
    return {
      data: await this.taskService.update(id, updateTaskDto),
      message: this.generateResponseService.generateUpdateMessage("Task"),
    };
  }

  @Delete(":id")
  async remove(@Param("projectId") projectId: string, @Param("id") id: string) {
    return {
      data: await this.taskService.remove(id),
      message: this.generateResponseService.generateDeleteMessage("Task"),
    };
  }
}
