import { PartialType } from "@nestjs/swagger";
import { CreateTaskDto } from "./create-task.dto";
import { IsInt, IsOptional, IsRFC3339 } from "class-validator";
import { ApiProperty } from "@nestjs/swagger";

export class UpdateTaskDto extends PartialType(CreateTaskDto) {
  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsOptional()
  @IsRFC3339()
  updatedStartDate?: Date;

  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsOptional()
  @IsRFC3339()
  updatedEndDate?: Date;

  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsOptional()
  @IsInt()
  updatedDuration?: number;

  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsOptional()
  @IsRFC3339()
  actualStartDate?: Date;

  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsOptional()
  @IsRFC3339()
  actualFinishDate?: Date;
}
