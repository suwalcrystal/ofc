import {
  IsBoolean,
  IsInt,
  IsISO8601,
  IsNotEmpty,
  IsOptional,
  IsRFC3339,
  IsString,
} from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreateTaskDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    example: "2025-05-07T05:55:50Z",
    required: true,
  })
  @IsNotEmpty()
  @IsISO8601()
  baselineStartDate: Date;

  @ApiProperty({
    example: "2025-05-07T05:55:50Z",
    required: true,
  })
  @IsNotEmpty()
  @IsISO8601()
  @IsRFC3339()
  baselineEndDate: Date;

  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsNotEmpty()
  @IsInt()
  baselineDuration: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  critical: boolean;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  isMilestone: boolean;
}
