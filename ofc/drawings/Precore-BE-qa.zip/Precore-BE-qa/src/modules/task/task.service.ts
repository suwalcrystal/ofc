import { Injectable, Param } from "@nestjs/common";
import { CreateTaskDto } from "./dto/create-task.dto";
import { UpdateTaskDto } from "./dto/update-task.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { TaskRepository } from "./task.repository";
@Injectable()
export class TaskService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: TaskRepository
  ) {}

  create(data: CreateTaskDto & { projectId: string }) {
    return this.crud.create("task", data);
  }

  findAll(projectId?: string) {
    if (projectId)
      return this.crud.findAll("task", [], { where: { projectId } });
    return this.crud.findAll("task");
  }

  findOne(@Param("id") id: string, projectId?: string) {
    return this.crud.findOne("task", id);
  }

  update(@Param("id") id: string, data: UpdateTaskDto) {
    return this.crud.update("task", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("task", id);
  }
}
