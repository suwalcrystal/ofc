import { ApiProperty } from "@nestjs/swagger";
import { ACTIVE_INACTIVE, Currency, XeroChartOfAccounts } from "@prisma/client";
import { Type } from "class-transformer";
import {
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
} from "class-validator";
import { IsUnique } from "src/validators/validators.service";
export class CreateItemDto {
  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsOptional()
  @IsString()
  image?: string;

  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  description: string;

  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsNotEmpty()
  @IsNumber()
  @Type(() => Number)
  pricePerUnit: number;

  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  sku;

  @IsNotEmpty()
  @IsIn(["AED", "USD", "EUR"])
  currency: Currency;

  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsNotEmpty()
  @IsUUID()
  unitId;

  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsUUID()
  @IsOptional()
  supplierId;

  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsNotEmpty()
  @IsUUID()
  itemTypeId;

  @IsNotEmpty()
  @IsIn([
    "COST_OF_GOODS_SOLD",
    "EQUIPMENT_RENTALS",
    "OFFICE_EXPENSES",
    "SUB_CONTRACTOR",
  ])
  xeroChartOfAccounts: XeroChartOfAccounts;

  @ApiProperty({
    enum: ACTIVE_INACTIVE,
  })
  @IsNotEmpty()
  @IsOptional()
  @IsIn(["active", "inactive"])
  status?: ACTIVE_INACTIVE;

  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsNotEmpty()
  @IsUUID()
  itemCategoryId: string;
}
