import { Injectable } from "@nestjs/common";
import { CreateItemDto } from "./dto/create-item.dto";
import { UpdateItemDto } from "./dto/update-item.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { Prisma } from "@prisma/client";

@Injectable()
export class ItemService {
  constructor(private readonly crud: GenericCrudService) {}
  create(data: CreateItemDto, file: Express.Multer.File) {
    return this.crud.create("item", { ...data, image: file.filename });
  }

  findAll() {
    return this.crud.findAll("item");
  }

  findOne(id: string, includeObj: Prisma.ItemInclude) {
    return this.crud.findOne("item", id, Object.keys(includeObj));
  }

  update(id: string, data: UpdateItemDto, file: Express.Multer.File) {
    return this.crud.update(
      "item",
      id,
      file ? { ...data, image: file.filename } : data
    );
  }

  remove(id: string) {
    return this.crud.remove("item", id);
  }
}
