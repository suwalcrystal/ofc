import { Injectable, NotFoundException } from "@nestjs/common";
import { Prisma, Unit } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { CreateUnitDto } from "./dto/create-unit.dto";

@Injectable()
export class UnitRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<Unit | null> {
    return this.prisma.unit.findUnique({ where: { id } });
  }

  async create(data: Prisma.UnitUncheckedCreateInput): Promise<Unit> {
    return this.prisma.unit.create({ data });
  }

  async update(id: string, data: Partial<Unit>): Promise<Unit> {
    return this.prisma.unit.update({ where: { id }, data });
  }

  async delete(id: string): Promise<Unit> {
    return this.prisma.unit.delete({ where: { id } });
  }
}
