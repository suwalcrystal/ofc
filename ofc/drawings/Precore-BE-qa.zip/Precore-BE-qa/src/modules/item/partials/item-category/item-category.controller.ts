import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { ItemCategoryService } from "./item-category.service";
import { CreateItemCategoryDto } from "./dto/create-item-category.dto";
import { UpdateItemCategoryDto } from "./dto/update-item-category.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Controller("item-category")
export class ItemCategoryController {
  constructor(
    private readonly itemCategoryService: ItemCategoryService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createItemCategoryDto: CreateItemCategoryDto) {
    return {
      data: await this.itemCategoryService.create(createItemCategoryDto),
      message:
        this.generateResponseService.generateCreateMessage("Item Category"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.itemCategoryService.findAll(),
      message:
        this.generateResponseService.generateFindAllMessage("Item Category"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.itemCategoryService.findOne(id),
      message:
        this.generateResponseService.generateFindOneMessage("Item Category"),
    };
  }

  @Patch(":id")
  update(
    @Param("id") id: string,
    @Body() updateItemCategoryDto: UpdateItemCategoryDto
  ) {
    return this.itemCategoryService.update(id, updateItemCategoryDto);
  }

  @Delete(":id")
  remove(@Param("id") id: string) {
    return this.itemCategoryService.remove(id);
  }
}
