import { PartialType } from "@nestjs/swagger";
import { CreateUnitDto } from "./create-unit.dto";
import { IsOptional, IsString } from "class-validator";

export class UpdateUnitDto extends PartialType(CreateUnitDto) {}
