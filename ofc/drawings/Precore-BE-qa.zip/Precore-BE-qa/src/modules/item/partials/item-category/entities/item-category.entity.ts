export class ItemCategory {}
