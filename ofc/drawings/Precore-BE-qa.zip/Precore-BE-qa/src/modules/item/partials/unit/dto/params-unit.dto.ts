import { IsNotEmpty, IsUUID } from "class-validator";

export class ParamsUnitDto {
  @IsNotEmpty({ message: "ID is required" })
  @IsUUID()
  id: string;
}
