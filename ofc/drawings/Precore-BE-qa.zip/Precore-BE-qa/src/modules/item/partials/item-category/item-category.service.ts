import { Injectable } from "@nestjs/common";
import { CreateItemCategoryDto } from "./dto/create-item-category.dto";
import { UpdateItemCategoryDto } from "./dto/update-item-category.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";

@Injectable()
export class ItemCategoryService {
  constructor(private readonly crud: GenericCrudService) {}
  create(data: CreateItemCategoryDto) {
    return this.crud.create("itemCategory", data);
  }

  findAll() {
    return this.crud.findAll("itemCategory");
  }

  findOne(id: string) {
    return this.crud.findOne("itemCategory", id);
  }

  update(id: string, updateItemCategoryDto: UpdateItemCategoryDto) {
    return this.crud.update("itemCategory", id, updateItemCategoryDto);
  }

  remove(id: string) {
    return this.crud.remove("itemCategory", id);
  }
}
