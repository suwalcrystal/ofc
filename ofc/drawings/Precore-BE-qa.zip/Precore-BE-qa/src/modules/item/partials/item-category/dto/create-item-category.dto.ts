import { ApiProperty } from "@nestjs/swagger";
import { ACTIVE_INACTIVE } from "@prisma/client";
import { IsIn, IsNotEmpty, IsOptional, IsString } from "class-validator";
import { IsUnique } from "src/validators/validators.service";
export class CreateItemCategoryDto {
  @ApiProperty({
    example: "packs",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  name: string;

  @ApiProperty({
    enum: ACTIVE_INACTIVE,
  })
  @IsNotEmpty()
  @IsOptional()
  @IsIn(["active", "inactive"])
  status?: ACTIVE_INACTIVE;
}
