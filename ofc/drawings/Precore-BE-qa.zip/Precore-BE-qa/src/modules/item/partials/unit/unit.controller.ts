import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  BadRequestException,
  Request,
} from "@nestjs/common";
import { UnitService } from "./unit.service";
import { CreateUnitDto } from "./dto/create-unit.dto";
import { UpdateUnitDto } from "./dto/update-unit.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { ParamsUnitDto } from "./dto/params-unit.dto";
import { plainToInstance } from "class-transformer";
import { validateOrReject } from "class-validator";
import { paginatedData } from "src/utils/pagination";
import { PrismaService } from "src/prisma/prisma.service";

@Controller("unit")
export class UnitController {
  constructor(
    private readonly unitService: UnitService,
    private readonly generateResponseService: GenerateResponseMessage,
    private readonly prisma: PrismaService
  ) {}

  @Post()
  async create(@Body() createUnitDto: CreateUnitDto) {
    return {
      data: await this.unitService.create(createUnitDto),
      message: this.generateResponseService.generateCreateMessage("Unit"),
    };
  }

  @Get()
  async findAll(@Request() req) {
    const match = {};
    const sort = {};

    const { page = 1, perPage = 10 } = req.query;
    const result = await this.unitService.findAll();
    const { records, pagination } = await paginatedData(
      this.prisma.unit,
      match,
      sort,
      page,
      perPage
    );

    return {
      data: records,
      pagination,
      message: this.generateResponseService.generateFindAllMessage("Unit"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.unitService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage("Unit"),
    };
  }

  @Patch(":id")
  async update(@Param("id") id: string, @Body() body: any) {
    const dto = plainToInstance(UpdateUnitDto, { ...body, id });

    try {
      await validateOrReject(dto);
    } catch (errors) {
      const formattedErrors = errors.map((err) => {
        return {
          field: err.property,
          errors: {
            [err.property]: Object.values(err.constraints || {})[0],
          },
        };
      });

      throw new BadRequestException({
        statusCode: 422,
        message: "Validation failed",
        errors: formattedErrors,
      });
    }

    return {
      data: await this.unitService.update(id, body),
      message: this.generateResponseService.generateUpdateMessage("Unit"),
    };
  }

  @Delete(":id")
  async remove(@Param() params: ParamsUnitDto) {
    return {
      data: await this.unitService.remove(params.id),
      message: this.generateResponseService.generateDeleteMessage("Unit"),
    };
  }
}
