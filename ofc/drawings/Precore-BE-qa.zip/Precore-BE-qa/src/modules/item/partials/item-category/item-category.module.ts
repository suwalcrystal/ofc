import { Module } from "@nestjs/common";
import { ItemCategoryService } from "./item-category.service";
import { ItemCategoryController } from "./item-category.controller";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { CommonModule } from "src/common/common.module";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
  imports: [CommonModule],
  exports: [ItemCategoryService],
  controllers: [ItemCategoryController],
  providers: [ItemCategoryService, GenerateResponseMessage, PrismaService],
})
export class ItemCategoryModule {}
