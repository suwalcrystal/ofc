import { Injectable } from "@nestjs/common";
import { CreateUnitDto } from "./dto/create-unit.dto";
import { UpdateUnitDto } from "./dto/update-unit.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";

@Injectable()
export class UnitService {
  constructor(private readonly crud: GenericCrudService) {}

  create(data: CreateUnitDto) {
    return this.crud.create("unit", data);
  }

  findAll() {
    return this.crud.findAll("unit");
  }

  findOne(id: string) {
    return this.crud.findOne("unit", id);
  }

  update(id: string, data: UpdateUnitDto) {
    return this.crud.update("unit", id, data);
  }

  remove(id: string) {
    return this.crud.remove("unit", id);
  }
}
