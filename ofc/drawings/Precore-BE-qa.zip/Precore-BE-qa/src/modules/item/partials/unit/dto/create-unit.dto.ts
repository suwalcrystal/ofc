import { ApiProperty } from "@nestjs/swagger";
import { ACTIVE_INACTIVE } from "@prisma/client";
import {
  IsIn,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUUID,
} from "class-validator";
import { IsUnique } from "src/validators/validators.service";

export class CreateUnitDto {
  @IsOptional()
  @IsUUID()
  id?: string;

  @ApiProperty({
    example: "square_meters",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  @IsUnique(["unit", "name"], { message: "Unit name is already in use" })
  name: string;

  @ApiProperty({
    example: "m2",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  @IsUnique(["unit", "symbol"], { message: "Unit symbol is already in use" })
  symbol: string;

  @ApiProperty({
    enum: ACTIVE_INACTIVE,
  })
  @IsNotEmpty()
  @IsOptional()
  @IsIn(["active", "inactive"])
  status?: ACTIVE_INACTIVE;
}
