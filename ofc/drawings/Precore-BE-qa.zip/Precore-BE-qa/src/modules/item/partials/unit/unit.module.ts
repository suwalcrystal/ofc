import { Module } from "@nestjs/common";
import { UnitService } from "./unit.service";
import { UnitController } from "./unit.controller";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { CommonModule } from "src/common/common.module";
import { ValidatorsModule } from "src/validators/validators.module";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
  imports: [CommonModule, ValidatorsModule],
  controllers: [UnitController],
  providers: [UnitService, GenerateResponseMessage, PrismaService],
})
export class UnitModule {}
