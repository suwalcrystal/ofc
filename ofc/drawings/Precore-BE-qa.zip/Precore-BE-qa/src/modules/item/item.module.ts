import { Module, forwardRef } from "@nestjs/common";
import { ItemService } from "./item.service";
import { ItemController } from "./item.controller";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { CommonModule } from "src/common/common.module";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";
// import { GraphqlModule } from "src/graphql/graphql.module";

@Module({
  imports: [CommonModule],
  controllers: [ItemController],
  providers: [ItemService, GenerateResponseMessage, PrismaService],
  exports: [ItemService],
})
export class ItemModule {}
