import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Request,
  UseInterceptors,
  UploadedFile,
} from "@nestjs/common";
import { ItemService } from "./item.service";
import { CreateItemDto } from "./dto/create-item.dto";
import { UpdateItemDto } from "./dto/update-item.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";
import { paginatedData } from "src/utils/pagination";
import { buildItemFilter } from "src/common/utils/pagination/matchSortTypes.ts/item.types";
import { Prisma } from "@prisma/client";
import { FileInterceptor } from "@nestjs/platform-express";
import { storage } from "../../helperServices/fileHelper";

@Controller("item")
export class ItemController {
  private readonly includeObj: Prisma.ItemInclude;
  constructor(
    private readonly itemService: ItemService,
    private readonly generateResponseService: GenerateResponseMessage,
    private readonly prisma: PrismaService
  ) {
    this.includeObj = {
      supplier: true,
      itemCategory: true,
      itemType: true,
      unit: true,
    };
  }

  @Post()
  @UseInterceptors(
    FileInterceptor("image", {
      storage,
      // fileFilter,
      limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
    })
  )
  create(
    @UploadedFile() file: Express.Multer.File,
    @Body() createItemDto: CreateItemDto
  ) {
    return this.itemService.create(createItemDto, file);
  }

  @Get()
  async findAll(@Request() req) {
    const match = buildItemFilter(req.query);
    const sort = {};
    const includeObj: Prisma.ItemInclude = {
      supplier: true,
      itemCategory: true,
      itemType: true,
      unit: true,
    };
    const { page = 1, perPage = 10 } = req.query;
    const { records, pagination } = await paginatedData(
      this.prisma.item,
      match,
      sort,
      page,
      perPage,
      includeObj
    );

    return {
      data: records,
      pagination,
      message: this.generateResponseService.generateFindAllMessage("Item"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.itemService.findOne(id, this.includeObj),
      message: this.generateResponseService.generateFindOneMessage("Item"),
    };
  }

  @Patch(":id")
  @UseInterceptors(
    FileInterceptor("image", {
      storage,
      // fileFilter,
      limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
    })
  )
  async update(
    @Param("id") id: string,
    @UploadedFile() file: Express.Multer.File,
    @Body() updateItemDto: UpdateItemDto
  ) {
    return {
      data: await this.itemService.update(id, updateItemDto, file),
      message: this.generateResponseService.generateUpdateMessage("Item"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.itemService.remove(id),
      message: this.generateResponseService.generateFindOneMessage("Item"),
    };
  }
}
