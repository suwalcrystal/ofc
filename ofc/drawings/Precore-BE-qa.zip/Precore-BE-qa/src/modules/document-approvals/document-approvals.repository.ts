import { Injectable } from "@nestjs/common";
import { DocumentApprovals, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class DocumentApprovalsRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<DocumentApprovals | null> {
    return this.prisma.documentApprovals.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.DocumentApprovalsUncheckedCreateInput
  ): Promise<DocumentApprovals> {
    return this.prisma.documentApprovals.create({ data });
  }

  async update(
    id: string,
    data: Partial<DocumentApprovals>
  ): Promise<DocumentApprovals> {
    return this.prisma.documentApprovals.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<DocumentApprovals> {
    return this.prisma.documentApprovals.delete({
      where: {
        id: id,
      },
    });
  }
}
