import { PartialType } from "@nestjs/swagger";
import { CreateDocumentApprovalsDto } from "./create-document-approvals.dto";

export class UpdateDocumentApprovalsDto extends PartialType(
  CreateDocumentApprovalsDto
) {}
