import { DOCUMENT_APPROVAL_STATUS } from "@prisma/client";
import { ApiProperty } from "@nestjs/swagger";

export class CreateDocumentApprovalsDto {
  id: string;
  @ApiProperty({
    enum: DOCUMENT_APPROVAL_STATUS,
  })
  status: DOCUMENT_APPROVAL_STATUS;
  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  createdAt: Date;
  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  updatedAt: Date;
}
