import { Injectable, Param } from "@nestjs/common";

import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { DocumentApprovalsRepository } from "./document-approvals.repository";
import { CreateDocumentApprovalsDto } from "./dto/create-document-approvals.dto";
import { UpdateDocumentApprovalsDto } from "./dto/update-document-approvals.dto";
@Injectable()
export class DocumentApprovalsService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: DocumentApprovalsRepository
  ) {}

  create(data: CreateDocumentApprovalsDto) {
    return this.crud.create("documentApprovals", data);
  }

  findAll() {
    return this.crud.findAll("documentApprovals");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("documentApprovals", id);
  }

  update(@Param("id") id: string, data: UpdateDocumentApprovalsDto) {
    return this.crud.update("documentApprovals", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("documentApprovals", id);
  }
}
