import { Module } from "@nestjs/common";
import { DocumentApprovalsService } from "./document-approvals.service";
import { DocumentApprovalsController } from "./document-approvals.controller";
import { DocumentApprovalsRepository } from "./document-approvals.repository";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { CommonModule } from "src/common/common.module";

@Module({
  imports: [CommonModule],
  controllers: [DocumentApprovalsController],
  providers: [
    DocumentApprovalsService,
    DocumentApprovalsRepository,
    PrismaService,
    GenerateResponseMessage,
  ],
})
export class DocumentApprovalsModule {}
