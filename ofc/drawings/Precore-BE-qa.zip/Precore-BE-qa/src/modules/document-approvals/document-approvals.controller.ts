import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from "@nestjs/common";
import { DocumentApprovalsService } from "./document-approvals.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

import { UpdateDocumentApprovalsDto } from "./dto/update-document-approvals.dto";
import { CreateDocumentApprovalsDto } from "./dto/create-document-approvals.dto";

@Controller("document-approvals")
export class DocumentApprovalsController {
  constructor(
    private readonly documentApprovalsService: DocumentApprovalsService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createDocumentApprovalsDto: CreateDocumentApprovalsDto) {
    return {
      data: await this.documentApprovalsService.create(
        createDocumentApprovalsDto
      ),
      message:
        this.generateResponseService.generateCreateMessage("DocumentApprovals"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.documentApprovalsService.findAll(),
      message:
        this.generateResponseService.generateFindAllMessage(
          "DocumentApprovals"
        ),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.documentApprovalsService.findOne(id),
      message:
        this.generateResponseService.generateFindOneMessage(
          "DocumentApprovals"
        ),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateDocumentApprovalsDto: UpdateDocumentApprovalsDto
  ) {
    return {
      data: await this.documentApprovalsService.update(
        id,
        updateDocumentApprovalsDto
      ),
      message:
        this.generateResponseService.generateUpdateMessage("DocumentApprovals"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.documentApprovalsService.remove(id),
      message:
        this.generateResponseService.generateDeleteMessage("DocumentApprovals"),
    };
  }
}
