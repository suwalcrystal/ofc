export class DocumentApproval {}
