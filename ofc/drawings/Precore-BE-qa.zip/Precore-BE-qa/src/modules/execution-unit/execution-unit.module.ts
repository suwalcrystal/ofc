import { Module } from "@nestjs/common";
import { ExecutionUnitService } from "./execution-unit.service";
import { ExecutionUnitController } from "./execution-unit.controller";
import { CommonModule } from "src/common/common.module";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { ExecutionUnitRepository } from "./execution-unit.repository";

@Module({
  imports: [CommonModule],
  controllers: [ExecutionUnitController],
  providers: [
    ExecutionUnitService,
    PrismaService,
    GenerateResponseMessage,
    ExecutionUnitRepository,
  ],
})
export class ExecutionUnitModule {}
