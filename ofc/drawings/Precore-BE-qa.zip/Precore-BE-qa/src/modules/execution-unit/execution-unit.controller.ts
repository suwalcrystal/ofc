import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ExecutionUnitService } from './execution-unit.service';
import { CreateExecutionUnitDto } from './dto/create-execution-unit.dto';
import { UpdateExecutionUnitDto } from './dto/update-execution-unit.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('execution-unit')
export class ExecutionUnitController {
  constructor(
    private readonly executionUnitService: ExecutionUnitService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createExecutionUnitDto: CreateExecutionUnitDto) {
    return {
      data: await this.executionUnitService.create(createExecutionUnitDto),
      message: this.generateResponseService.generateCreateMessage('ExecutionUnit'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.executionUnitService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('ExecutionUnit'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.executionUnitService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('ExecutionUnit'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateExecutionUnitDto: UpdateExecutionUnitDto
  ) {
    return {
      data: await this.executionUnitService.update(id, updateExecutionUnitDto),
      message: this.generateResponseService.generateUpdateMessage('ExecutionUnit'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.executionUnitService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('ExecutionUnit'),
    };
  }
}