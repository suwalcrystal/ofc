import { Injectable,Param } from "@nestjs/common";
import { CreateExecutionUnitDto } from "./dto/create-execution-unit.dto";
import { UpdateExecutionUnitDto } from "./dto/update-execution-unit.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { ExecutionUnitRepository } from "./execution-unit.repository";
@Injectable()
export class ExecutionUnitService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: ExecutionUnitRepository) {}

  create(data: CreateExecutionUnitDto) {
    return this.crud.create("executionUnit", data);
  }

  findAll() {
    return this.crud.findAll("executionUnit");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("executionUnit", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateExecutionUnitDto) {
    return this.crud.update("executionUnit", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("executionUnit", id);
  }
}