import { EXECUTION_UNIT_TRACKING_MODE } from "@prisma/client";
import { Type } from "class-transformer";
import {
  IsBoolean,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsRFC3339,
  IsString,
} from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreateExecutionUnitDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  title: string;
  @ApiProperty({
    enum: EXECUTION_UNIT_TRACKING_MODE,
  })
  @IsNotEmpty()
  @IsIn(["manual_percent", "primary_unit_of_measure", "binary"])
  trackingMode: EXECUTION_UNIT_TRACKING_MODE;
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  totalQuantity?: number;
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsNumber()
  completedQuantity?: number;
  @ApiProperty()
  @IsOptional()
  @IsBoolean()
  isCompleted?: boolean;
  @ApiProperty()
  @IsOptional()
  @IsBoolean()
  manualPercentEntry?: boolean;
  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsNotEmpty()
  @IsRFC3339()
  startDate: Date;
  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsNotEmpty()
  @IsRFC3339()
  endDate: Date;
  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsNotEmpty()
  @IsInt()
  duration: number;
}
