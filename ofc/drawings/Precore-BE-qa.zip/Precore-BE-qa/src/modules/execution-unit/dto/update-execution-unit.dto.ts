import { PartialType } from '@nestjs/swagger';
import { CreateExecutionUnitDto } from './create-execution-unit.dto';

export class UpdateExecutionUnitDto extends PartialType(CreateExecutionUnitDto) {}
