import { Injectable } from "@nestjs/common";
import { ExecutionUnit, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class ExecutionUnitRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<ExecutionUnit | null> {
    return this.prisma.executionUnit.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.ExecutionUnitUncheckedCreateInput
  ): Promise<ExecutionUnit> {
    return this.prisma.executionUnit.create({ data });
  }

  async update(
    id: string,
    data: Partial<ExecutionUnit>
  ): Promise<ExecutionUnit> {
    return this.prisma.executionUnit.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<ExecutionUnit> {
    return this.prisma.executionUnit.delete({
      where: {
        id: id,
      },
    });
  }
}
