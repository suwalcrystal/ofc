import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  Request,
} from "@nestjs/common";
import { PurchaseRequestsService } from "./purchase-requests.service";
import { CreatePurchaseRequestsDto } from "./dto/create-purchase-requests.dto";
import { UpdatePurchaseRequestsDto } from "./dto/update-purchase-requests.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard";
import { ApiBearerAuth } from "@nestjs/swagger";
import { RolesGuard } from "../auth/guards/roles.guard";
import { Roles } from "../auth/guards/roles.decorator";

@UseGuards(JwtAuthGuard)
@ApiBearerAuth("access-token")
@Controller("purchase-requests")
export class PurchaseRequestsController {
  constructor(
    private readonly purchaseRequestsService: PurchaseRequestsService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(
    @Request() req,
    @Body() createPurchaseRequestsDto: CreatePurchaseRequestsDto
  ) {
    return {
      data: await this.purchaseRequestsService.create(
        {
          ...createPurchaseRequestsDto,
          deliveryLeadTime: createPurchaseRequestsDto.deliveryLeadTime,
          dateNeededInSite: createPurchaseRequestsDto.dateNeededInSite,
        },
        req.user.id
      ),
      message:
        this.generateResponseService.generateCreateMessage("PurchaseRequests"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.purchaseRequestsService.findAll(),
      message:
        this.generateResponseService.generateFindAllMessage("PurchaseRequests"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.purchaseRequestsService.findOne(id),
      message:
        this.generateResponseService.generateFindOneMessage("PurchaseRequests"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updatePurchaseRequestsDto: UpdatePurchaseRequestsDto
  ) {
    return {
      data: await this.purchaseRequestsService.update(
        id,
        updatePurchaseRequestsDto
      ),
      message:
        this.generateResponseService.generateUpdateMessage("PurchaseRequests"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.purchaseRequestsService.remove(id),
      message:
        this.generateResponseService.generateDeleteMessage("PurchaseRequests"),
    };
  }
}
