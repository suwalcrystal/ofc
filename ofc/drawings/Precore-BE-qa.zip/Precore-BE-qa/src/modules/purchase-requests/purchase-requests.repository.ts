import { Injectable } from "@nestjs/common";
import { PurchaseRequests, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class PurchaseRequestsRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<PurchaseRequests | null> {
    return this.prisma.purchaseRequests.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.PurchaseRequestsUncheckedCreateInput
  ): Promise<PurchaseRequests> {
    return this.prisma.purchaseRequests.create({ data });
  }

  async update(
    id: string,
    data: Partial<PurchaseRequests>
  ): Promise<PurchaseRequests> {
    return this.prisma.purchaseRequests.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<PurchaseRequests> {
    return this.prisma.purchaseRequests.delete({
      where: {
        id: id,
      },
    });
  }
}
