export class PurchaseRequest {}
