import { PACKAGE_TYPE, PURCHASE_REQUEST_TYPE } from "@prisma/client";

import {
  IsIn,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  ValidateNested,
} from "class-validator";

import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreatePurchaseRequestLineItemsDto {
  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsOptional()
  @IsUUID()
  id?: string;

  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsOptional()
  @IsInt()
  orderNumber?: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  itemId: string;

  @ApiProperty({
    type: `number`,
    format: `float`,
  })
  @IsNotEmpty()
  @IsNumber()
  quantity: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  unitId: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  perUnitPrice: string;
}

export class PurchaseRequestWithBOQItem {
  @ApiProperty({
    example: "be409336-423d-40d3-81c3-7bb273fa7a4e",
  })
  @IsNotEmpty()
  @IsUUID()
  boqItemId: string;

  @ApiProperty()
  @IsNotEmpty()
  @ApiProperty({ type: () => CreatePurchaseRequestLineItemsDto, isArray: true })
  @ValidateNested({ each: true })
  actualLineItems: CreatePurchaseRequestLineItemsDto[];
}

export class CreatePurchaseRequestsDto {
  @ApiProperty({
    enum: PURCHASE_REQUEST_TYPE,
  })
  @IsNotEmpty()
  @IsIn(["materials", "subContractor", "equipment"])
  prType: PURCHASE_REQUEST_TYPE;

  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsNotEmpty()
  dateNeededInSite: Date;

  @ApiProperty({
    enum: PACKAGE_TYPE,
  })
  @IsNotEmpty()
  @IsIn([
    "enabling",
    "civil",
    "mep",
    "fitout",
    "joinery",
    "furnitures",
    "facade",
    "landscape",
    "swimming_pool",
    "water_features",
  ])
  packageName: PACKAGE_TYPE;

  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsNotEmpty()
  @IsUUID()
  projectId: string;

  @ApiProperty({
    example: "10 days",
  })
  @IsNotEmpty()
  @IsString()
  deliveryLeadTime: string;

  @IsOptional()
  @ApiProperty({ type: () => CreatePurchaseRequestLineItemsDto, isArray: true })
  @ValidateNested({ each: true })
  // @Type(() => UpdateBoqitemDto)
  lineItems?: PurchaseRequestWithBOQItem[];
}
// {
//   "prType": "materials",
//   "packageName":"enabling";
//   "dateNeededInSite": "2025-07-10T00:00:00.000Z",
//   "projectId": "c1e8e3d7-9012-4f8e-b32b-1de85ad2f91a",
//   "deliveryLeadTime": "3 days",
//   "lineItems": [
//     {
//       "boqITemId": "b12f5c4e-85ec-4891-9911-64be6ec0f74c",
//       "actualLineItems": [
//         {
//           "id": "b42fd892-5e0b-43f4-a580-bb53e1e4f8e9",
//           "orderNumber": 1,
//           "itemId": "cement-type1",

//           "quantity": 100,
//           "unitId": "bag",
//           "perUnitPrice": "4.50"
//         },
//         {
//           "orderNumber": 2,
//           "itemId": "sand-fine",

//           "quantity": 5,
//           "unitId": "ton",
//           "perUnitPrice": "30.00"
//         }
//       ]
//     },
//     {
//       "boqITemId": "e45ad86a-2b92-41c5-a312-a9623c10b0f7",
//       "actualLineItems": [
//         {
//           "itemId": "steel-bar-t10",

//           "quantity": 200,
//           "unitId": "kg",
//           "perUnitPrice": "2.10"
//         }
//       ]
//     }
//   ]
// }
