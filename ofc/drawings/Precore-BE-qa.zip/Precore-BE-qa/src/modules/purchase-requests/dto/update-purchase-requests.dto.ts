import { PartialType } from "@nestjs/swagger";
import { CreatePurchaseRequestsDto } from "./create-purchase-requests.dto";

export class UpdatePurchaseRequestsDto extends PartialType(
  CreatePurchaseRequestsDto
) {}
