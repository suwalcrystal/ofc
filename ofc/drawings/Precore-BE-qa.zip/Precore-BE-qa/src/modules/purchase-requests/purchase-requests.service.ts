import { Injectable, Param } from "@nestjs/common";
import { CreatePurchaseRequestsDto } from "./dto/create-purchase-requests.dto";
import { UpdatePurchaseRequestsDto } from "./dto/update-purchase-requests.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { PurchaseRequestsRepository } from "./purchase-requests.repository";
import { PrismaService } from "src/prisma/prisma.service";
@Injectable()
export class PurchaseRequestsService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly prisma: PrismaService,
    private readonly repository: PurchaseRequestsRepository
  ) {}

  create(data: CreatePurchaseRequestsDto, userId: string) {
    //TODO: check if create from warehouse requests and the items in the included warehouse request are unfulfilled
    //  if (data.code) {
    //     const project = await this.crud.findAll("project", [], {
    //       where: { code: data.code },
    //     });
    //     if (project.length > 0) {
    //       throw new BadRequestException("Project code already exists");
    //     }
    //   }
    const { lineItems, packageName, ...purchaseRequestMainInfo } = data;
    return this.prisma.$transaction(async (tx) => {
      const documentRegistry = await this.crud.createWithTransaction(
        tx,
        "documentRegistry",
        { type: "purchase_request", createdBy: userId }
      );

      const purchaseRequest = await this.crud.createWithTransaction(
        tx,
        "purchaseRequests",
        {
          ...purchaseRequestMainInfo,
          documentRegistryId: documentRegistry.id,
          requesterId: userId,
        }
      );

      //prepare data for purchase request line items
      await Promise.all(
        lineItems.map(async (item) => {
          const { boqItemId, actualLineItems } = item;

          const transformedLineItems = actualLineItems.map((item) => {
            return {
              ...item,
              boqItemId,
              projectId: data.projectId,
              packageName,
              purchaseRequestId: purchaseRequest.id,
            };
          });

          await this.crud.createManyWithTransaction(
            tx,
            "purchaseRequestLineItems",
            transformedLineItems
          );
        })
      );
    });
  }

  findAll() {
    return this.crud.findAll("purchaseRequests");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("purchaseRequests", id);
  }

  update(@Param("id") id: string, data: UpdatePurchaseRequestsDto) {
    return this.crud.update("purchaseRequests", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("purchaseRequests", id);
  }
}
