import { Module } from "@nestjs/common";
import { PurchaseRequestsService } from "./purchase-requests.service";
import { PurchaseRequestsController } from "./purchase-requests.controller";
import { CommonModule } from "src/common/common.module";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PurchaseRequestsRepository } from "./purchase-requests.repository";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Module({
  imports: [CommonModule],
  controllers: [PurchaseRequestsController],
  providers: [
    PurchaseRequestsService,
    GenerateResponseMessage,
    PurchaseRequestsRepository,
    PrismaService,
  ],
})
export class PurchaseRequestsModule {}
