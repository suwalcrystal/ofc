import { Type } from "class-transformer";
import {
  IsDecimal,
  IsNotEmpty,
  IsOptional,
  IsRFC3339,
  IsString,
  IsUUID,
  ValidateNested,
} from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreatePOLineItem {
  @ApiProperty()
  @IsUUID()
  @IsOptional()
  id?: string;

  @ApiProperty({
    example: "60789ef8-9b78-40a6-8158-b9919bc8f637",
  })
  @IsUUID()
  itemId;

  @ApiProperty()
  @IsDecimal()
  quantity;

  @ApiProperty()
  @IsUUID()
  unit: string;

  @ApiProperty()
  @IsDecimal()
  unitPrice;

  @ApiProperty()
  @IsOptional()
  @IsUUID()
  sourcePrLineItemId?: string;
}
export class CreatePurchaseOrderDto {
  @ApiProperty({
    type: `string`,
    format: `date-time`,
  })
  @IsOptional()
  expectedDelivery?: Date;

  @ApiProperty()
  @IsOptional()
  @IsString()
  notes?: string;

  @IsOptional()
  @ApiProperty({ type: () => CreatePOLineItem, isArray: true })
  @ValidateNested({ each: true })
  // @Type(() => UpdateBoqitemDto)
  lineItems?: CreatePOLineItem[];
}

// export class CreatePRLineItemFulfillmentDto {
//   @ApiProperty()
//   @IsNotEmpty()
//   @IsString()
//   poLineItemId: string;
//   @ApiProperty({
//     type: `number`,
//     format: `float`,
//   })
//   @IsNotEmpty()
//   @IsNumber()
//   quantityFulfilled: number;
// }
