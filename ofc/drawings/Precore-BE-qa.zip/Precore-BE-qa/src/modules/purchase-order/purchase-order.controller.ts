import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Request,
  UseGuards,
} from "@nestjs/common";
import { PurchaseOrderService } from "./purchase-order.service";
import { CreatePurchaseOrderDto } from "./dto/create-purchase-order.dto";
import { UpdatePurchaseOrderDto } from "./dto/update-purchase-order.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard";
import { ApiBearerAuth, ApiParam } from "@nestjs/swagger";

@UseGuards(JwtAuthGuard)
@ApiBearerAuth("access-token")
@Controller("purchase-order")
export class PurchaseOrderController {
  constructor(
    private readonly purchaseOrderService: PurchaseOrderService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @ApiParam({ name: "supplierId", type: String, required: true })
  @Post("supplier/:supplierId")
  async create(
    @Request() req,
    @Param("supplierId") supplierId,
    @Body() createPurchaseOrderDto: CreatePurchaseOrderDto
  ) {
    return {
      data: await this.purchaseOrderService.create(
        createPurchaseOrderDto,
        req.user.id,
        supplierId
      ),
      message:
        this.generateResponseService.generateCreateMessage("PurchaseOrder"),
    };
  }

  @Get("/create/from_pr_requests/group-suppliers")
  async getDataGroupSuppliersForCreateFromPurchaseRequests() {
    return {
      data: await this.purchaseOrderService.getDataGroupSuppliersForCreateFromPurchaseRequests(),
      message:
        this.generateResponseService.generateCreateMessage("PurchaseOrder"),
    };
  }

  @Get("/create/from_pr_requests/suppliers/:supplierId")
  async getDataGroupProjectsForCreateFromPurchaseRequests(
    @Param("supplierId") supplierId: string
  ) {
    return {
      data: await this.purchaseOrderService.getDataGroupProjectsForCreateFromPurchaseRequests(
        supplierId
      ),
      message:
        this.generateResponseService.generateCreateMessage("PurchaseOrder"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.purchaseOrderService.findAll(),
      message:
        this.generateResponseService.generateFindAllMessage("PurchaseOrder"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.purchaseOrderService.findOne(id),
      message:
        this.generateResponseService.generateFindOneMessage("PurchaseOrder"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updatePurchaseOrderDto: UpdatePurchaseOrderDto
  ) {
    return {
      data: await this.purchaseOrderService.update(id, updatePurchaseOrderDto),
      message:
        this.generateResponseService.generateUpdateMessage("PurchaseOrder"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.purchaseOrderService.remove(id),
      message:
        this.generateResponseService.generateDeleteMessage("PurchaseOrder"),
    };
  }
}
