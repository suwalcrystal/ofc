import { Injectable, Param } from "@nestjs/common";
import {
  CreatePOLineItem,
  CreatePurchaseOrderDto,
} from "./dto/create-purchase-order.dto";
import { UpdatePurchaseOrderDto } from "./dto/update-purchase-order.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { PurchaseOrderRepository } from "./purchase-order.repository";
import * as _ from "lodash";
import { PrismaService } from "src/prisma/prisma.service";
import { Prisma } from "@prisma/client";
@Injectable()
export class PurchaseOrderService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: PurchaseOrderRepository,
    private readonly prisma: PrismaService
  ) {}

  async create(
    data: CreatePurchaseOrderDto,
    userId: string,
    supplierId: string
  ) {
    return this.prisma.$transaction(async (tx) => {
      const { lineItems, ...dataSpread } = data;
      const sourcePRId = _.get(data, "sourcePRId", null); // optional chaining fallback

      // 1. Create DocumentRegistry
      const documentRegistry = await this.crud.createWithTransaction(
        tx,
        "documentRegistry",
        {
          type: "purchase_order",
          createdBy: userId,
        }
      );

      // 2. Create PurchaseOrder with the registry ID
      const purchaseOrder = await this.crud.createWithTransaction(
        tx,
        "purchaseOrder",
        {
          ...dataSpread,
          supplierId,
          createdById: userId,
          documentRegistryId: documentRegistry.id,
        }
      );

      // 3. Insert Line Items
      await this.insertPOLineItems(tx, lineItems, supplierId, purchaseOrder.id);

      return purchaseOrder; // optional return
    });
  }

  insertPOLineItems(
    tx: Prisma.TransactionClient,
    lineItems: CreatePOLineItem[],
    supplierId: string,
    purchaseOrderId: string
  ) {
    const result = lineItems.map((item: CreatePOLineItem) => ({
      ...item,
      purchaseOrderId,
    }));

    return tx.purchaseOrderLineItem.createMany({ data: result });
  }

  getDataGroupSuppliersForCreateFromPurchaseRequests() {
    return this.repository.getDataGroupSuppliersForCreateFromPurchaseRequests();
  }

  async getDataGroupProjectsForCreateFromPurchaseRequests(supplierId: string) {
    const result =
      await this.repository.getDataGroupProjectsForCreateFromPurchaseRequests(
        supplierId
      );
    //group by project code and package name
    const groupedResult = _.groupBy(result, (row) => {
      return `${row.code} - ${row.packageName}`;
    });
    return groupedResult;
  }

  findAll() {
    return this.crud.findAll("purchaseOrder");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("purchaseOrder", id);
  }

  update(@Param("id") id: string, data: UpdatePurchaseOrderDto) {
    return this.crud.update("purchaseOrder", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("purchaseOrder", id);
  }
}
