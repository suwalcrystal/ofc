import { Injectable } from "@nestjs/common";
import { PurchaseOrder, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class PurchaseOrderRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<PurchaseOrder | null> {
    return this.prisma.purchaseOrder.findUnique({
      where: {
        id: id,
      },
    });
  }

  async getDataGroupSuppliersForCreateFromPurchaseRequests(): Promise<any> {
    //execute this sql and return results
    const result = await this.prisma.$queryRaw`SELECT 
  COALESCE(s.id::text, 'no_supplier') AS supplier_id,
  COALESCE(s.name, 'No Supplier Specified') AS supplier_name,
  json_agg(DISTINCT prli."projectId" || ' - ' || prli."packageName") AS locations,
  json_agg(DISTINCT pr.id) AS purchase_requisition_ids,
  COUNT(*)::int AS total_items
FROM "PurchaseRequestLineItems" prli
JOIN "PurchaseRequests" pr ON prli."purchaseRequestId" = pr.id
JOIN "DocumentRegistry" dr ON pr."documentRegistryId" = dr.id
JOIN "Item" i ON prli."itemId" = i.id
LEFT JOIN "Supplier" s ON i."supplierId" = s.id
WHERE dr."approvedStatus" = true
  AND dr."fulfilledStatus" = false
GROUP BY COALESCE(s.id::text, 'no_supplier'), COALESCE(s.name, 'No Supplier Specified')
ORDER BY supplier_name;
`;
    return result;
  }

  async getDataGroupProjectsForCreateFromPurchaseRequests(
    supplierId: string
  ): Promise<any> {
    const result = await this.prisma.$queryRaw`
  SELECT 
    prli.id as source_Pr_Id,
    project."code", 
    prli."packageName",
    prli."quantity",
    unit."name" ,
    i.description,
    s.name AS supplier_name
  FROM 
    "PurchaseRequestLineItems" prli
  JOIN "Item" i ON prli."itemId" = i.id
  JOIN "Supplier" s ON i."supplierId" = s.id
  JOIN "Unit" unit ON i."unitId" = unit.id 
  JOIN "Project" project ON prli."projectId" = project.id
  JOIN "PurchaseRequests" pr ON prli."purchaseRequestId" = pr.id
  JOIN "DocumentRegistry" dr ON pr."documentRegistryId" = dr.id
  WHERE 
    s.id = ${supplierId}
    AND dr."approvedStatus" = true
    AND dr."fulfilledStatus" = false;
`;

    return result;
  }

  async create(
    data: Prisma.PurchaseOrderUncheckedCreateInput
  ): Promise<PurchaseOrder> {
    return this.prisma.purchaseOrder.create({ data });
  }

  async update(
    id: string,
    data: Partial<PurchaseOrder>
  ): Promise<PurchaseOrder> {
    return this.prisma.purchaseOrder.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<PurchaseOrder> {
    return this.prisma.purchaseOrder.delete({
      where: {
        id: id,
      },
    });
  }
}
