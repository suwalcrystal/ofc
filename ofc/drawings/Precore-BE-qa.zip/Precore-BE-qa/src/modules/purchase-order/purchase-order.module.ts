import { Module } from "@nestjs/common";
import { PurchaseOrderService } from "./purchase-order.service";
import { PurchaseOrderController } from "./purchase-order.controller";
import { CommonModule } from "src/common/common.module";
import { PurchaseOrderRepository } from "./purchase-order.repository";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";

@Module({
  imports: [CommonModule],
  controllers: [PurchaseOrderController],
  providers: [
    PurchaseOrderService,
    PurchaseOrderRepository,
    PrismaService,
    GenerateResponseMessage,
  ],
})
export class PurchaseOrderModule {}
