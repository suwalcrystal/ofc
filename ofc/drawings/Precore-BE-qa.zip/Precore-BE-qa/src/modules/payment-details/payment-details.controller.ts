import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { PaymentDetailsService } from './payment-details.service';
import { CreatePaymentDetailsDto } from './dto/create-payment-details.dto';
import { UpdatePaymentDetailsDto } from './dto/update-payment-details.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('payment-details')
export class PaymentDetailsController {
  constructor(
    private readonly paymentDetailsService: PaymentDetailsService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createPaymentDetailsDto: CreatePaymentDetailsDto) {
    return {
      data: await this.paymentDetailsService.create(createPaymentDetailsDto),
      message: this.generateResponseService.generateCreateMessage('PaymentDetails'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.paymentDetailsService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('PaymentDetails'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.paymentDetailsService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('PaymentDetails'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updatePaymentDetailsDto: UpdatePaymentDetailsDto
  ) {
    return {
      data: await this.paymentDetailsService.update(id, updatePaymentDetailsDto),
      message: this.generateResponseService.generateUpdateMessage('PaymentDetails'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.paymentDetailsService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('PaymentDetails'),
    };
  }
}