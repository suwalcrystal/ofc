import { Injectable, Param } from "@nestjs/common";

import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { PaymentDetailsRepository } from "./payment-details.repository";
import { CreatePaymentDetailsDto } from "./dto/create-payment-details.dto";
import { UpdatePaymentDetailsDto } from "./dto/update-payment-details.dto";
@Injectable()
export class PaymentDetailsService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: PaymentDetailsRepository
  ) {}

  create(data: CreatePaymentDetailsDto) {
    return this.crud.create("paymentDetails", data);
  }

  findAll() {
    return this.crud.findAll("paymentDetails");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("paymentDetails", id);
  }

  update(@Param("id") id: string, data: UpdatePaymentDetailsDto) {
    return this.crud.update("paymentDetails", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("paymentDetails", id);
  }
}
