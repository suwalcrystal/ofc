import { Module } from "@nestjs/common";
import { PaymentDetailsService } from "./payment-details.service";
import { PaymentDetailsController } from "./payment-details.controller";
import { CommonModule } from "src/common/common.module";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { PrismaService } from "src/prisma/prisma.service";
import { PaymentDetailsRepository } from "./payment-details.repository";

@Module({
  imports: [CommonModule],
  controllers: [PaymentDetailsController],
  providers: [
    PaymentDetailsService,
    GenerateResponseMessage,
    PrismaService,
    PaymentDetailsRepository,
  ],
})
export class PaymentDetailsModule {}
