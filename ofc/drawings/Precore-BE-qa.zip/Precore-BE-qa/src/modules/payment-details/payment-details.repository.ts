import { Injectable } from "@nestjs/common";
import { PaymentDetails, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class PaymentDetailsRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<PaymentDetails | null> {
    return this.prisma.paymentDetails.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.PaymentDetailsUncheckedCreateInput
  ): Promise<PaymentDetails> {
    return this.prisma.paymentDetails.create({ data });
  }

  async update(
    id: string,
    data: Partial<PaymentDetails>
  ): Promise<PaymentDetails> {
    return this.prisma.paymentDetails.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<PaymentDetails> {
    return this.prisma.paymentDetails.delete({
      where: {
        id: id,
      },
    });
  }
}
