import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsNumber, IsString } from "class-validator";
export class CreatePaymentDetailsDto {
  @ApiProperty({
    example: "Standard Chartered",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  bankName: string;

  @ApiProperty({
    example: "Standard Chartered",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  bankAccountNumber: string;
}
