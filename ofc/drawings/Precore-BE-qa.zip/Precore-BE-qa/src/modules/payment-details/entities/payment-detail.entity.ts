export class PaymentDetail {}
