import { Injectable, Param } from "@nestjs/common";
import { CreateDocumentFilesDto } from "./dto/create-document-files.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { DocumentFilesRepository } from "./document-files.repository";
import { UpdateDocumentFilesDto } from "./dto/update-document-files.dto";
@Injectable()
export class DocumentFilesService {
  constructor(
    private readonly crud: GenericCrudService,
    private readonly repository: DocumentFilesRepository
  ) {}

  create(data: CreateDocumentFilesDto, userId: string) {
    return this.crud.create("documentFiles", { ...data, uploadedBy: userId });
  }

  findAll() {
    return this.crud.findAll("documentFiles");
  }

  findOne(@Param("id") id: string) {
    return this.crud.findOne("documentFiles", id);
  }

  update(@Param("id") id: string, data: UpdateDocumentFilesDto) {
    return this.crud.update("documentFiles", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("documentFiles", id);
  }
}
