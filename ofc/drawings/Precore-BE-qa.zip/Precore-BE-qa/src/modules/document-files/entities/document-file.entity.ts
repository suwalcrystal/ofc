export class DocumentFile {}
