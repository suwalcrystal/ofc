// s3.service.ts
import { Injectable } from "@nestjs/common";
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  ListObjectsV2Command,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

@Injectable()
export class S3Service {
  private s3 = new S3Client({
    // region: process.env.AWS_REGION,

    region: "ap-south-1",
    credentials: {
      // accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
      // secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
      accessKeyId: "AKIA4VDBLYPLOQUVBLG2",
      secretAccessKey: "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",
    },
  });

  async getPresignedUploadUrl(key: string, contentType: string) {
    const command = new PutObjectCommand({
      // Bucket: process.env.AWS_BUCKET_NAME!,
      Bucket: "ukjoboffer-s3",

      Key: key,
      ContentType: contentType,
    });

    const signedUrl = await getSignedUrl(this.s3, command, {
      expiresIn: 300, // 5 mins
    });

    return signedUrl;
  }

  async getPresignedViewUrl(key: string): Promise<string> {
    const command = new GetObjectCommand({
      Bucket: "ukjoboffer-s3",
      Key: key,
    });

    const signedUrl = await getSignedUrl(this.s3, command, {
      expiresIn: 60 * 10, // 5 mins
    });

    return signedUrl;
  }

  async listAllKeys(): Promise<string[]> {
    const command = new ListObjectsV2Command({
      Bucket: "ukjoboffer-s3",
    });

    try {
      const data = await this.s3.send(command);
      if (data.Contents) {
        return data.Contents.map((obj) => obj.Key || "");
      }
      return [];
    } catch (error) {
      console.error("Error listing S3 objects:", error);
      throw error;
    }
  }
}
