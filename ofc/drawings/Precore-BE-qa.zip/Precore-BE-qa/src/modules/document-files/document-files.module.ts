import { Module } from "@nestjs/common";
import { DocumentFilesService } from "./document-files.service";
import { DocumentFilesController } from "./document-files.controller";
import { CommonModule } from "src/common/common.module";
import { PrismaService } from "src/prisma/prisma.service";
import { DocumentFilesRepository } from "./document-files.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { S3Service } from "./s3.service";

@Module({
  imports: [CommonModule],
  controllers: [DocumentFilesController],
  providers: [
    DocumentFilesService,
    PrismaService,
    DocumentFilesRepository,
    GenerateResponseMessage,
    S3Service,
  ],
})
export class DocumentFilesModule {}
