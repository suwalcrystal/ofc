import { Injectable } from "@nestjs/common";
import { DocumentFiles, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class DocumentFilesRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<DocumentFiles | null> {
    return this.prisma.documentFiles.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.DocumentFilesUncheckedCreateInput
  ): Promise<DocumentFiles> {
    return this.prisma.documentFiles.create({ data });
  }

  async update(
    id: string,
    data: Partial<DocumentFiles>
  ): Promise<DocumentFiles> {
    return this.prisma.documentFiles.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<DocumentFiles> {
    return this.prisma.documentFiles.delete({
      where: {
        id: id,
      },
    });
  }
}
