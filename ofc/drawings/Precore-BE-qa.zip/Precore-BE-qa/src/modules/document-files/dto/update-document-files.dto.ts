import { PartialType } from "@nestjs/swagger";
import { CreateDocumentFilesDto } from "./create-document-files.dto";

export class UpdateDocumentFilesDto extends PartialType(
  CreateDocumentFilesDto
) {}
