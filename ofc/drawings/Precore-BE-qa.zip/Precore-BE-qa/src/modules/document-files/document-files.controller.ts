import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Request,
  UseGuards,
  Query,
} from "@nestjs/common";
import { DocumentFilesService } from "./document-files.service";
import { CreateDocumentFilesDto } from "./dto/create-document-files.dto";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { UpdateDocumentFilesDto } from "src/generated-docs/update-document-files.dto";
import { S3Service } from "./s3.service";
import { AuthGuard } from "@nestjs/passport";
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard";
import { ApiBearerAuth } from "@nestjs/swagger";

@UseGuards(JwtAuthGuard)
@ApiBearerAuth("access-token")
@Controller("document-files")
export class DocumentFilesController {
  constructor(
    private readonly s3Service: S3Service,
    private readonly documentFilesService: DocumentFilesService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post("presign-upload")
  async getPresignedUrl(
    @Body()
    body: {
      fileName: string;
      contentType: string;
      projectId: string;
      path?: string; // optional folder path, e.g. "Permissions"
    }
  ) {
    const { fileName, contentType, projectId, path = "" } = body;

    const key = `${projectId}/${path}/${fileName}`;
    const uploadUrl = await this.s3Service.getPresignedUploadUrl(
      key,
      contentType
    );

    return {
      uploadUrl,
      key,
    };
  }

  @Get("view-url")
  async getFileViewUrl(@Query("key") key: string) {
    return {
      url: await this.s3Service.getPresignedViewUrl(key),
    };
  }

  @Get("list-all-keys")
  async listAllKeys() {
    return {
      keys: await this.s3Service.listAllKeys(),
    };
  }

  @Post()
  async create(
    @Request() req,
    @Body() createDocumentFilesDto: CreateDocumentFilesDto
  ) {
    return {
      data: await this.documentFilesService.create(
        createDocumentFilesDto,
        req.user.id
      ),
      message:
        this.generateResponseService.generateCreateMessage("DocumentFiles"),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.documentFilesService.findAll(),
      message:
        this.generateResponseService.generateFindAllMessage("DocumentFiles"),
    };
  }

  @Get(":id")
  async findOne(@Param("id") id: string) {
    return {
      data: await this.documentFilesService.findOne(id),
      message:
        this.generateResponseService.generateFindOneMessage("DocumentFiles"),
    };
  }

  @Patch(":id")
  async update(
    @Param("id") id: string,
    @Body() updateDocumentFilesDto: UpdateDocumentFilesDto
  ) {
    return {
      data: await this.documentFilesService.update(id, updateDocumentFilesDto),
      message:
        this.generateResponseService.generateUpdateMessage("DocumentFiles"),
    };
  }

  @Delete(":id")
  async remove(@Param("id") id: string) {
    return {
      data: await this.documentFilesService.remove(id),
      message:
        this.generateResponseService.generateDeleteMessage("DocumentFiles"),
    };
  }
}
