import { Module } from "@nestjs/common";
import { TaskDependencyService } from "./task-dependency.service";
import { TaskDependencyController } from "./task-dependency.controller";
import { CommonModule } from "src/common/common.module";
import { PrismaService } from "src/prisma/prisma.service";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { TaskDependencyRepository } from "./task-dependency.repository";

@Module({
  imports: [CommonModule],
  controllers: [TaskDependencyController],
  providers: [
    TaskDependencyService,
    PrismaService,
    GenerateResponseMessage,
    TaskDependencyRepository,
  ],
})
export class TaskDependencyModule {}
