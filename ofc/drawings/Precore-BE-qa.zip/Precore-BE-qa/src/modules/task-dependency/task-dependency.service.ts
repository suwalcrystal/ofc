import { Injectable,Param } from "@nestjs/common";
import { CreateTaskDependencyDto } from "./dto/create-task-dependency.dto";
import { UpdateTaskDependencyDto } from "./dto/update-task-dependency.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { TaskDependencyRepository } from "./task-dependency.repository";
@Injectable()
export class TaskDependencyService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: TaskDependencyRepository) {}

  create(data: CreateTaskDependencyDto) {
    return this.crud.create("taskDependency", data);
  }

  findAll() {
    return this.crud.findAll("taskDependency");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("taskDependency", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateTaskDependencyDto) {
    return this.crud.update("taskDependency", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("taskDependency", id);
  }
}