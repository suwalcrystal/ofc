import { Type } from "class-transformer";
import { IsInt, IsNotEmpty } from "class-validator";
import { ApiProperty, getSchemaPath } from "@nestjs/swagger";

export class CreateTaskDependencyDto {
  @ApiProperty({
    type: `integer`,
    format: `int32`,
  })
  @IsNotEmpty()
  @IsInt()
  type: number;
}
