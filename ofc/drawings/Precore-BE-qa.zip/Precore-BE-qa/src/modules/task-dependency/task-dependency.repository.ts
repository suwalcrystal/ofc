import { Injectable } from "@nestjs/common";
import { TaskDependency, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class TaskDependencyRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<TaskDependency | null> {
    return this.prisma.taskDependency.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.TaskDependencyUncheckedCreateInput
  ): Promise<TaskDependency> {
    return this.prisma.taskDependency.create({ data });
  }

  async update(
    id: string,
    data: Partial<TaskDependency>
  ): Promise<TaskDependency> {
    return this.prisma.taskDependency.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<TaskDependency> {
    return this.prisma.taskDependency.delete({
      where: {
        id: id,
      },
    });
  }
}
