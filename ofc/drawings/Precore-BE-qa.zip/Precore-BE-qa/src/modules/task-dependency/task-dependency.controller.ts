import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { TaskDependencyService } from './task-dependency.service';
import { CreateTaskDependencyDto } from './dto/create-task-dependency.dto';
import { UpdateTaskDependencyDto } from './dto/update-task-dependency.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('task-dependency')
export class TaskDependencyController {
  constructor(
    private readonly taskDependencyService: TaskDependencyService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createTaskDependencyDto: CreateTaskDependencyDto) {
    return {
      data: await this.taskDependencyService.create(createTaskDependencyDto),
      message: this.generateResponseService.generateCreateMessage('TaskDependency'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.taskDependencyService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('TaskDependency'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.taskDependencyService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('TaskDependency'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateTaskDependencyDto: UpdateTaskDependencyDto
  ) {
    return {
      data: await this.taskDependencyService.update(id, updateTaskDependencyDto),
      message: this.generateResponseService.generateUpdateMessage('TaskDependency'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.taskDependencyService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('TaskDependency'),
    };
  }
}