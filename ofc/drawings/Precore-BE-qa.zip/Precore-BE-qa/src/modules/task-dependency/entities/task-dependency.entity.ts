export class TaskDependency {}
