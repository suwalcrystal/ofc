import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { BudgetSpendCategoryService } from './budget-spend-category.service';
import { CreateBudgetSpendCategoryDto } from './dto/create-budget-spend-category.dto';
import { UpdateBudgetSpendCategoryDto } from './dto/update-budget-spend-category.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('budget-spend-category')
export class BudgetSpendCategoryController {
  constructor(
    private readonly budgetSpendCategoryService: BudgetSpendCategoryService,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() createBudgetSpendCategoryDto: CreateBudgetSpendCategoryDto) {
    return {
      data: await this.budgetSpendCategoryService.create(createBudgetSpendCategoryDto),
      message: this.generateResponseService.generateCreateMessage('BudgetSpendCategory'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.budgetSpendCategoryService.findAll(),
      message: this.generateResponseService.generateFindAllMessage('BudgetSpendCategory'),
    };
  }

  @Get(':id')
  async findOne(@Param("id") id: string) {
    return {
      data: await this.budgetSpendCategoryService.findOne(id),
      message: this.generateResponseService.generateFindOneMessage('BudgetSpendCategory'),
    };
  }

  @Patch(':id')
  async update(
    @Param("id") id: string,
    @Body() updateBudgetSpendCategoryDto: UpdateBudgetSpendCategoryDto
  ) {
    return {
      data: await this.budgetSpendCategoryService.update(id, updateBudgetSpendCategoryDto),
      message: this.generateResponseService.generateUpdateMessage('BudgetSpendCategory'),
    };
  }

  @Delete(':id')
  async remove(@Param("id") id: string) {
    return {
      data: await this.budgetSpendCategoryService.remove(id),
      message: this.generateResponseService.generateDeleteMessage('BudgetSpendCategory'),
    };
  }
}