import { Injectable,Param } from "@nestjs/common";
import { CreateBudgetSpendCategoryDto } from "./dto/create-budget-spend-category.dto";
import { UpdateBudgetSpendCategoryDto } from "./dto/update-budget-spend-category.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { BudgetSpendCategoryRepository } from "./budget-spend-category.repository";
@Injectable()
export class BudgetSpendCategoryService {
  constructor(private readonly crud: GenericCrudService,private readonly repository: BudgetSpendCategoryRepository) {}

  create(data: CreateBudgetSpendCategoryDto) {
    return this.crud.create("budgetSpendCategory", data);
  }

  findAll() {
    return this.crud.findAll("budgetSpendCategory");
  }

   findOne(@Param("id") id: string) {
    return this.crud.findOne("budgetSpendCategory", id);
  }
    
  

 update(@Param("id") id: string,  data: UpdateBudgetSpendCategoryDto) {
    return this.crud.update("budgetSpendCategory", id, data);
  }

  remove(@Param("id") id: string) {
    return this.crud.remove("budgetSpendCategory", id);
  }
}