import { Injectable } from "@nestjs/common";
import { BudgetSpendCategory, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class BudgetSpendCategoryRepository {
  constructor(private prisma: PrismaService) {}

  async getById(id: string): Promise<BudgetSpendCategory | null> {
    return this.prisma.budgetSpendCategory.findUnique({
      where: {
        id: id,
      },
    });
  }

  async create(
    data: Prisma.BudgetSpendCategoryUncheckedCreateInput
  ): Promise<BudgetSpendCategory> {
    return this.prisma.budgetSpendCategory.create({ data });
  }

  async update(
    id: string,
    data: Partial<BudgetSpendCategory>
  ): Promise<BudgetSpendCategory> {
    return this.prisma.budgetSpendCategory.update({
      where: {
        id: id,
      },
      data,
    });
  }

  async delete(id: string): Promise<BudgetSpendCategory> {
    return this.prisma.budgetSpendCategory.delete({
      where: {
        id: id,
      },
    });
  }
}
