export class BudgetSpendCategory {}
