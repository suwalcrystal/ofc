import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";
import { IsUnique } from "src/validators/validators.service";

export class CreateBudgetSpendCategoryDto {
  @ApiProperty({
    example: "materials",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  @IsUnique(["budgetSpendCategory", "name"], {
    message: "Budget Spend Category is already in use",
  })
  name: string;

  @ApiProperty({
    example: "materials budget spend category description",
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  description: string;
}
