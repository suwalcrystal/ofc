import { PartialType } from '@nestjs/swagger';
import { CreateBudgetSpendCategoryDto } from './create-budget-spend-category.dto';

export class UpdateBudgetSpendCategoryDto extends PartialType(CreateBudgetSpendCategoryDto) {}
