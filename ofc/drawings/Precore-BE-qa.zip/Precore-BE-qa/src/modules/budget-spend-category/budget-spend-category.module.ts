import { Module } from "@nestjs/common";
import { BudgetSpendCategoryService } from "./budget-spend-category.service";
import { BudgetSpendCategoryController } from "./budget-spend-category.controller";
import { BudgetSpendCategoryRepository } from "./budget-spend-category.repository";
import { GenerateResponseMessage } from "src/helperServices/generateResponseMessage";
import { Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";
import { CommonModule } from "src/common/common.module";

@Module({
  imports: [CommonModule],
  controllers: [BudgetSpendCategoryController],
  providers: [
    BudgetSpendCategoryService,
    BudgetSpendCategoryRepository,
    GenerateResponseMessage,
    PrismaService,
  ],
})
export class BudgetSpendCategoryModule {}
