import { Catch, ExceptionFilter, ArgumentsHost } from "@nestjs/common";
import { GqlExecutionContext } from "@nestjs/graphql";
import { BadRequestException } from "@nestjs/common";
import { ValidationError } from "class-validator";
import { GraphQLError } from "graphql";

@Catch(BadRequestException)
export class GraphqlExceptionFilter implements ExceptionFilter {
  catch(exception: BadRequestException, host: ArgumentsHost) {
    const errors = exception.getResponse() as any;

    const formattedErrors = errors.errors.map((err: ValidationError) => ({
      field: err.property,
      errors: Object.values(err.constraints || {}),
    }));

    // Return formatted GraphQL error
    const graphQLError = new GraphQLError("Validation failed", {
      extensions: {
        code: "BAD_REQUEST",
        message: "Validation failed",
        errors: formattedErrors,
      },
    });

    return graphQLError;
  }
}
