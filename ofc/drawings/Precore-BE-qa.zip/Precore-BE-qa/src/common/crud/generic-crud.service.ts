import { Injectable } from "@nestjs/common";
import { Prisma, PrismaClient } from "@prisma/client";
import { diff } from "deep-object-diff";
import { PrismaService } from "src/prisma/prisma.service";
import { ModelNamesWithFindMany, ModelNamesWithFindUnique } from "src/types";

type OrderableModels =
  | "bOQItem"
  | "boqItem"
  | "workSchedule"
  | "approvalWorkflowStep"
  | "comment"; // extend as needed

@Injectable()
export class GenericCrudService {
  constructor(private readonly prisma: PrismaService) {}

  async create(
    model: keyof Omit<
      PrismaService,
      "$connect" | "$disconnect" | "$on" | "$transaction" | "$use"
    >,
    data: any
  ) {
    const prismaModel = this.prisma[model];
    if (!prismaModel || !("create" in prismaModel)) {
      throw new Error(`Model "${String(model)}" does not support .create().`);
    }

    return (prismaModel as any).create({ data });
  }

  async createMany<T>(
    model: keyof Omit<
      PrismaService,
      "$connect" | "$disconnect" | "$on" | "$transaction" | "$use"
    >,
    data: T[]
  ): Promise<any> {
    const prismaModel = this.prisma[model];

    if (
      !prismaModel ||
      typeof prismaModel !== "object" ||
      !("createMany" in prismaModel)
    ) {
      throw new Error(
        `Model "${String(model)}" does not support .createMany().`
      );
    }

    return (prismaModel as any).createMany({
      data,
      skipDuplicates: true, // optional: skip records with unique conflicts
    });
  }
  async createManyWithTransaction(
    tx: Prisma.TransactionClient,
    model: keyof Omit<
      Prisma.TransactionClient,
      "$connect" | "$disconnect" | "$on" | "$transaction" | "$use"
    >,
    data: any[]
  ) {
    const prismaModel = tx[model];

    if (
      !prismaModel ||
      typeof prismaModel !== "object" ||
      !("createMany" in prismaModel)
    ) {
      throw new Error(
        `Model "${String(model)}" does not support .createMany().`
      );
    }

    return (prismaModel as any).createMany({ data });
  }

  async createWithTransaction(
    tx: Prisma.TransactionClient,
    model: keyof Omit<
      Prisma.TransactionClient,
      "$connect" | "$disconnect" | "$on" | "$transaction" | "$use"
    >,
    data: any
  ) {
    const prismaModel = tx[model];

    if (
      !prismaModel ||
      typeof prismaModel !== "object" ||
      !("create" in prismaModel)
    ) {
      throw new Error(`Model "${String(model)}" does not support .create().`);
    }

    return (prismaModel as any).create({ data });
  }

  async upsertMany<ModelName extends keyof Prisma.TransactionClient>(
    tx: Prisma.TransactionClient,
    model: ModelName,
    data: Array<Record<string, any>>,
    options?: {
      idField?: string; // defaults to "id"
    }
  ) {
    const modelDelegate = tx[model] as any;
    const idField = options?.idField ?? "id";

    const operations = data.map((item) => {
      const hasId = item[idField] !== undefined && item[idField] !== null;

      if (hasId) {
        return modelDelegate.upsert({
          where: { [idField]: item[idField] },
          update: item,
          create: { ...item },
        });
      } else {
        return modelDelegate.create({
          data: { ...item },
        });
      }
    });

    return Promise.all(operations);
  }

  async upsertManyCompositeKey<
    ModelName extends keyof Prisma.TransactionClient,
  >(
    tx: Prisma.TransactionClient,
    model: ModelName,
    data: Array<Record<string, any>>,
    options?: {
      idFields?: string[]; // Composite keys only
    }
  ) {
    const modelDelegate = tx[model] as any;
    const idFields = options?.idFields ?? ["id"];

    let highestOrderNumber =
      await this.getHighestOrderNumberForDocumentRegistryId();

    const operations = data.map((item) => {
      const hasAllKeys = idFields.every(
        (field) => item[field] !== undefined && item[field] !== null
      );

      const where = Object.fromEntries(idFields.map((key) => [key, item[key]]));

      if (hasAllKeys) {
        return modelDelegate.upsert({
          where,
          update: item,
          create: { ...item, orderNumber: ++highestOrderNumber },
        });
      } else {
        return modelDelegate.create({
          data: { ...item, orderNumber: ++highestOrderNumber },
        });
      }
    });

    return Promise.all(operations);
  }

  async getHighestOrderNumber(
    model: OrderableModels,
    where: Record<string, any> = {}
  ): Promise<number> {
    const modelDelegate = this.prisma[model] as any;

    const result = await modelDelegate.aggregate({
      _max: {
        orderNumber: true,
      },
      where,
    });

    return result._max.orderNumber || 0;
  }

  async getHighestOrderNumberForDocumentRegistryId() {
    const result = await this.prisma.bOQItem.aggregate({
      _max: {
        orderNumber: true,
      },
      where: {
        documentRegistryId: {
          not: null,
        },
      },
    });

    return result._max.orderNumber || 0; // Return 0 if no order numbers found
  }

  async trackTenderChanges(oldParentObject, newParentObject) {
    return {
      parentChanges: diff(oldParentObject, newParentObject),
      childChanges: await this.trackBOQChanges(
        oldParentObject.boqItems,
        newParentObject.boqItems
      ),
    };
  }

  async trackBOQChanges(oldItems = [], newItems = []) {
    const oldMap = new Map(oldItems.map((item) => [item.id, item]));
    const newMap = new Map(newItems.map((item) => [item.id, item]));

    const added = [];
    const updated = [];
    const deleted = [];

    // Check for added/updated items
    newItems.forEach((newItem) => {
      if (!oldMap.has(newItem.id)) {
        added.push(newItem); // New BOQ item
      } else {
        const itemDiff = diff(oldMap.get(newItem.id), newItem);
        if (Object.keys(itemDiff).length > 0) {
          updated.push({
            id: newItem.id,
            changes: itemDiff,
            previous: oldMap.get(newItem.id),
          });
        }
      }
    });

    // Check for deleted items
    oldItems.forEach((oldItem) => {
      if (!newMap.has(oldItem.id)) {
        deleted.push(oldItem);
      }
    });

    return { added, updated, deleted };
  }
  async findAll<T extends ModelNamesWithFindMany>(
    model: T,
    fields?: string[],
    args?: Parameters<PrismaClient[T]["findMany"]>[0]
  ): Promise<ReturnType<PrismaClient[T]["findMany"]>> {
    const prismaModel = this.prisma[model];

    if (!prismaModel || typeof (prismaModel as any).findMany !== "function") {
      throw new Error(`Model "${String(model)}" does not support .findMany().`);
    }
    const include = fields?.reduce(
      (acc, field) => {
        acc[field] = true;
        return acc;
      },
      {} as Record<string, boolean>
    );

    return (prismaModel as any).findMany({
      ...args,
      ...(include && Object.keys(include).length > 0 ? { include } : {}),
    });
  }

  async findOne<T extends ModelNamesWithFindUnique>(
    model: T,
    id,
    fields?: string[],
    args?: Parameters<PrismaClient[T]["findUnique"]>[0]
  ): Promise<ReturnType<PrismaClient[T]["findUnique"]>> {
    const prismaModel = this.prisma[model];

    if (!prismaModel || typeof (prismaModel as any).findUnique !== "function") {
      throw new Error(
        `Model "${String(model)}" does not support .findUnique().`
      );
    }

    const include = fields?.reduce(
      (acc, field) => {
        acc[field] = true;
        return acc;
      },
      {} as Record<string, boolean>
    );

    return (prismaModel as any).findUnique({
      where: { id },
      ...args,
      ...(include ? { include } : {}),
    });
  }

  async update(
    model: keyof Omit<
      PrismaService,
      "$connect" | "$disconnect" | "$on" | "$transaction" | "$use"
    >,
    id: number | string,
    data: any
  ) {
    const prismaModel = this.prisma[model];
    if (!prismaModel || !("update" in prismaModel)) {
      throw new Error(`Model "${String(model)}" does not support .update().`);
    }

    return (prismaModel as any).update({ where: { id }, data });
  }

  async updateWithTransaction(
    tx: Prisma.TransactionClient,
    model: keyof Omit<
      Prisma.TransactionClient,
      "$connect" | "$disconnect" | "$on" | "$transaction" | "$use"
    >,
    id: number | string,
    data: any
  ) {
    const prismaModel = tx[model];
    if (!prismaModel || !("update" in prismaModel)) {
      throw new Error(`Model "${String(model)}" does not support .update().`);
    }

    return (prismaModel as any).update({ where: { id }, data });
  }

  async remove(
    model: keyof Omit<
      PrismaService,
      "$connect" | "$disconnect" | "$on" | "$transaction" | "$use"
    >,
    id: number | string
  ) {
    const prismaModel = this.prisma[model];
    if (!prismaModel || !("delete" in prismaModel)) {
      throw new Error(`Model "${String(model)}" does not support .delete().`);
    }

    return (prismaModel as any).delete({ where: { id } });
  }

  async removeByCompositeKey(
    model: keyof Omit<
      PrismaService,
      "$connect" | "$disconnect" | "$on" | "$transaction" | "$use"
    >,
    where: Record<string, any>
  ) {
    const prismaModel = this.prisma[model];
    if (!prismaModel || !("delete" in prismaModel)) {
      throw new Error(`Model "${String(model)}" does not support .delete().`);
    }

    return (prismaModel as any).delete({ where });
  }

  async getFirstApprover(documentRegistryId: string) {
    const firstApprover = await this.prisma.documentRegistry.findFirst({
      where: {
        id: documentRegistryId,
      },

      include: {
        approvalWorkflow: {
          include: {
            approvalWorkflowSteps: {
              where: {
                orderNumber: 1,
              },

              // Get only the first active approver
            },
          },
        },
      },
    });

    if (!firstApprover) {
      throw new Error("No active approver found for the given document.");
    }

    return firstApprover;
  }
}
