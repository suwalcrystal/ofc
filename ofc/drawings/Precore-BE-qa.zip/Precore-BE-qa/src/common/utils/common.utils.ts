// src/common/utils/date.utils.ts

import { isISO8601 } from "class-validator";
import { Request } from "express";
import moment from "moment";
import * as _ from "lodash";
export function isValidIsoDate(date: string): boolean {
  return isISO8601(date);
}

export function isTodayOrFuture(date: string | Date): boolean {
  const d = new Date(date);
  const today = new Date();

  d.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);
  return d >= today;
}

export function getMatchAndSortData(req: Request) {
  let matchData: Record<string, any> = {};
  let sortData: Record<string, any> = { createdAt: -1 };

  if (req.query.sortBy || req.query.orderBy) {
    const orderBy = req.query.orderBy ? req.query.orderBy : "desc";
    sortData[req.query.sortBy as string] = orderBy === "desc" ? -1 : 1;
  }
  if (req.query.startDate && req.query.endDate) {
    matchData["createdAt"] = _.pickBy({
      $gte: new Date(req.query.startDate as string),
      $lt: moment(req.query.endDate as string)
        .add(1, "days")
        .toDate(),
    });
  } else if (req.query.startDate) {
    matchData["createdAt"] = _.pickBy({
      $gte: new Date(req.query.startDate as string),
    });
  } else if (req.query.endDate) {
    matchData["createdAt"] = _.pickBy({
      $lt: moment(req.query.endDate as string)
        .add(1, "days")
        .toDate(),
    });
  }
  if (req.query.createdDate) {
    matchData["createdAt"] = {
      $gte: new Date(req.query.createdDate as string),
      $lt: moment(req.query.createdDate as string).add(1, "days"),
    };
  }
  if (req.query.updatedDate) {
    matchData["updatedAt"] = {
      $gte: new Date(req.query.updatedDate as string),
      $lt: moment(req.query.updatedDate as string).add(1, "days"),
    };
  }

  return {
    matchData,
    sortData,
  };
}

export interface PaginationResult<T> {
  totalRecords: number;
  records: T[];
  perPage: number;
  currentPage: number;
  next: number | null;
  prev: number | null;
  totalPages: number;
  pagingCounter: number;
  hasPrevious: boolean;
  hasNext: boolean;
  recordShown: number;
}

// export async function paginatedData<T>(
//   model: {
//     count: (args: any) => Promise<number>;
//     findMany: (args: any) => Promise<T[]>;
//   },
//   match: Prisma.ModelWhereInput,
//   sort: Record<string, "asc" | "desc">,
//   page = 1,
//   perPage = 10,
//   include?: Prisma.ModelFindManyArgs["include"],
//   select?: Prisma.ModelFindManyArgs["select"]
// ): Promise<PaginationResult<T>> {
//   const skip = (page - 1) * perPage;

//   // Optional: Convert sort fields like 'createdDate' to 'createdAt'
//   const mappedSort: Record<string, "asc" | "desc"> = {};
//   for (const key in sort) {
//     const field =
//       key === "createdDate"
//         ? "createdAt"
//         : key === "updatedDate"
//           ? "updatedAt"
//           : key === "id"
//             ? "id"
//             : key;
//     mappedSort[field] = sort[key];
//   }

//   const totalRecords = await model.count({ where: match });
//   const records = await model.findMany({
//     where: match,
//     orderBy: mappedSort,
//     skip,
//     take: perPage,
//     include,
//     select,
//   });

//   const totalPages = Math.ceil(totalRecords / perPage);
//   const pagingCounter = skip + 1;

//   return {
//     totalRecords,
//     records,
//     perPage,
//     currentPage: page,
//     totalPages,
//     next: page < totalPages ? page + 1 : null,
//     prev: page > 1 ? page - 1 : null,
//     pagingCounter,
//     hasPrevious: page > 1,
//     hasNext: page < totalPages,
//     recordShown: records.length + skip,
//   };
// }

// export async function paginatedData<
//   T,
//   WhereInput,
//   FindManyArgs extends {
//     where?: WhereInput;
//     orderBy?: any;
//     include?: any;
//     select?: any;
//   },
// >(
//   model: {
//     count: (args: { where?: WhereInput }) => Promise<number>;
//     findMany: (args: FindManyArgs) => Promise<T[]>;
//   },
//   match: WhereInput,
//   sort: Record<string, "asc" | "desc">,
//   page = 1,
//   perPage = 10,
//   include?: FindManyArgs["include"],
//   select?: FindManyArgs["select"]
// ): Promise<PaginationResult<T>> {
//   const skip = (page - 1) * perPage;
//   const totalRecords = await model.count({ where: match });
//   const records = await model.findMany({
//     where: match,
//     orderBy: sort,
//     skip,
//     take: perPage,
//     include,
//     select,
//   } as unknown as FindManyArgs);

//   const totalPages = Math.ceil(totalRecords / perPage);
//   const pagingCounter = skip + 1;

//   return {
//     totalRecords,
//     records,
//     perPage,
//     currentPage: page,
//     totalPages,
//     next: page < totalPages ? page + 1 : null,
//     prev: page > 1 ? page - 1 : null,
//     pagingCounter,
//     hasPrevious: page > 1,
//     hasNext: page < totalPages,
//     recordShown: records.length + skip,
//   };
// }
