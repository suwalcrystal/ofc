import * as _ from "lodash";

export interface ItemFilterData {
  search?: string;
  itemName?: string;
  supplier?: string;
  category?: string;
  currency?: string | null;
  itemType?: string | null;
  xeroChartOfAccounts?: string;
}
export function buildItemFilter(filter: ItemFilterData) {
  const searchValue = filter.search || filter.itemName;
  const raw = {
    name: searchValue
      ? { contains: searchValue, mode: "insensitive" }
      : undefined,
    supplierId: filter.supplier,
    itemCategoryId: filter.category,
    currency: filter.currency,
    itemTypeId: filter.itemType,
    xeroChartOfAccounts: filter.xeroChartOfAccounts,
  };

  // Remove null, undefined, or empty string values
  const where = _.omitBy(raw, (v) => {
    return v === null || v === undefined || v === "";
  });

  return where;
}
