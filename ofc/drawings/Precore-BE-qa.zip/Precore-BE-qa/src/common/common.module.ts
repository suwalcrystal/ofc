import { Module } from "@nestjs/common";
import { GenericCrudService } from "./crud/generic-crud.service";
import { PrismaService } from "src/prisma/prisma.service";
import { S3Service } from "./s3/s3.service";

@Module({
  providers: [GenericCrudService, PrismaService],
  exports: [GenericCrudService, S3Service],
})
export class CommonModule {}
