// s3.service.ts
import { Injectable } from "@nestjs/common";
import { S3Client } from "@aws-sdk/client-s3";
import multer from "multer";
import multerS3 from "multer-s3";
import { randomUUID } from "crypto";

@Injectable()
export class S3Service {
  private readonly s3: S3Client;
  public readonly upload;

  constructor() {
    this.s3 = new S3Client({
      region: process.env.AWS_REGION,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY!,
        secretAccessKey: process.env.AWS_SECRET_KEY!,
      },
    });

    this.upload = multer({
      storage: multerS3({
        s3: this.s3,
        bucket: process.env.AWS_BUCKET_NAME!,
        contentType: multerS3.AUTO_CONTENT_TYPE,
        key: (req, file, cb) => {
          const uniqueKey = `${randomUUID()}-${file.originalname}`;
          cb(null, uniqueKey);
        },
        acl: "public-read", // Optional: make uploaded files publicly readable
      }),
      limits: { fileSize: 10 * 1024 * 1024 }, // Optional: max file size 10MB
    });
  }
}
