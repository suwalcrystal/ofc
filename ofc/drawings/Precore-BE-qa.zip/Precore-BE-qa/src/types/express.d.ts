import { User } from "@prisma/client";

declare module "express" {
  interface Request {
    user?: User; // Adjust the type to your actual user object
  }
}
