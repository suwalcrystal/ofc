import { PrismaClient } from "@prisma/client";

export type ModelNamesWithFindMany = {
  [K in keyof PrismaClient]: PrismaClient[K] extends {
    findMany: (...args: any[]) => any;
  }
    ? K
    : never;
}[keyof PrismaClient];

export type ModelNamesWithFindUnique = {
  [K in keyof PrismaClient]: PrismaClient[K] extends {
    findUnique: (...args: any[]) => any;
  }
    ? K
    : never;
}[keyof PrismaClient];
