import { Module, forwardRef } from "@nestjs/common";
import { AuthModule } from "./modules/auth/auth.module";
import { PassportModule } from "@nestjs/passport";
import { JwtModule } from "@nestjs/jwt";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { appConfigs } from "./config/app.config";
import { RoleModule } from "./modules/document-registry/partials/role/role.module";
import { CommonModule } from "./common/common.module";
import { PermissionModule } from "./modules/document-registry/partials/permission/permission.module";
import { ValidatorsModule } from "./validators/validators.module";
import { GraphQLModule } from "@nestjs/graphql";
import { ApolloDriver, ApolloDriverConfig } from "@nestjs/apollo";
import { ApolloServerPlugin } from "@apollo/server";
// import { GraphqlModule } from "./graphql/graphql.module";
import { PrismaService } from "./prisma/prisma.service";
import { ItemCategoryModule } from "./modules/item/partials/item-category/item-category.module";
import { ItemModule } from "./modules/item/item.module";
import { RepositoryGenerator } from "./scripts/generate-repo";
import { SupplierModule } from "./modules/supplier/supplier.module";
import { join } from "path";
// import { RepositoryGenerator } from "./scripts/generate-repo";
import { UnitModule } from "./modules/item/partials/unit/unit.module";
import { GenerateResponseMessage } from "./helperServices/generateResponseMessage";
import { CurrencyModule } from "./modules/currency/currency.module";

import { FormatArrayObjectsWithFieldsOnly } from "./helperServices/formatArrayObjectsWithFieldsOnly";

import { PaymentDetailsModule } from "./modules/payment-details/payment-details.module";
import { PurchaseRequestsModule } from "./modules/purchase-requests/purchase-requests.module";
import { BudgetSpendCategoryModule } from "./modules/budget-spend-category/budget-spend-category.module";
import { TenderModule } from "./modules/tender/tender.module";
import { DocumentRegistryModule } from "./modules/document-registry/document-registry.module";
import { RolePermissionModule } from "./modules/role-permission/role-permission.module";
import { ApprovalWorkflowModule } from "./modules/approval-workflow/approval-workflow.module";
import { ApprovalWorkflowStepModule } from "./modules/approval-workflow-step/approval-workflow-step.module";
import { DocumentApprovalsModule } from "./modules/document-approvals/document-approvals.module";
import { NotificationModule } from "./modules/notification/notification.module";
import { DeviceModule } from "./modules/device/device.module";
import { ProjectRoleModule } from "./modules/project-role/project-role.module";
import { ProjectModule } from "./modules/project/project.module";
import { DocumentFilesModule } from "./modules/document-files/document-files.module";
import { TaskModule } from "./modules/task/task.module";
import { TaskDependencyModule } from "./modules/task-dependency/task-dependency.module";
import { ExecutionUnitModule } from "./modules/execution-unit/execution-unit.module";
import { SiteDiaryEntryModule } from "./modules/site-diary-entry/site-diary-entry.module";
import { BoqitemModule } from "./modules/boqitem/boqitem.module";
import { BudgetModule } from "./modules/budget/budget.module";
import { RequestForQuoteModule } from "./modules/request-for-quote/request-for-quote.module";
import { PurchaseOrderModule } from "./modules/purchase-order/purchase-order.module";
import { ServeStaticModule } from "@nestjs/serve-static";
import { ItemTypeModule } from './modules/item-type/item-type.module';

@Module({
  imports: [
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, "..", "uploads"), // folder where your files are stored
      serveRoot: "/", // maps to http://<host>:<port>/<filename>
    }),
    ConfigModule.forRoot({
      isGlobal: true, // Make ConfigModule available everywhere
    }),
    AuthModule,
    ValidatorsModule,
    CommonModule,
    ConfigModule.forRoot(appConfigs),
    PassportModule.register({ session: true }),
    JwtModule.register({
      global: true,
      secret: process.env.JWT_SECRET as string,
      signOptions: { expiresIn: "1hr" },
    }),
    RoleModule,
    PermissionModule,
    ItemCategoryModule,
    ItemModule,
    SupplierModule,
    UnitModule,
    CurrencyModule,
    PaymentDetailsModule,
    PurchaseRequestsModule,
    BudgetSpendCategoryModule,
    TenderModule,
    DocumentRegistryModule,
    RolePermissionModule,
    ApprovalWorkflowModule,
    ApprovalWorkflowStepModule,
    DocumentApprovalsModule,
    NotificationModule,
    DeviceModule,
    ProjectRoleModule,
    ProjectModule,
    DocumentFilesModule,
    TaskModule,
    TaskDependencyModule,
    ExecutionUnitModule,
    SiteDiaryEntryModule,
    BoqitemModule,
    BudgetModule,
    RequestForQuoteModule,
    PurchaseOrderModule,
    ItemTypeModule,
  ],
  providers: [
    PrismaService,
    GenerateResponseMessage,
    FormatArrayObjectsWithFieldsOnly,
    // RepositoryGenerator
  ],
})
export class AppModule {}
