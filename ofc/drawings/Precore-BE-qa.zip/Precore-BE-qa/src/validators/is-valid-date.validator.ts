import {
  registerDecorator,
  ValidationOptions,
  ValidationArguments,
} from "class-validator";

export function IsValidDate(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: "isValidDate",
      target: object.constructor,
      propertyName,
      options: validationOptions,
      validator: {
        validate(value: any) {
          return value instanceof Date && !isNaN(value.getTime());
        },
        defaultMessage(args: ValidationArguments) {
          return `${args.property} must be a valid Date`;
        },
      },
    });
  };
}
