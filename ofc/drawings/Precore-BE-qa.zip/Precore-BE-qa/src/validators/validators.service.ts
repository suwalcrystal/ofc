import {
  registerDecorator,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from "class-validator";
import { PrismaService } from "src/prisma/prisma.service";
import { BadRequestException, Injectable } from "@nestjs/common";

@ValidatorConstraint({ name: "IsUnique", async: true })
@Injectable()
export class IsUniqueConstraint implements ValidatorConstraintInterface {
  constructor(private readonly prisma: PrismaService) {}

  async validate(value: any, args: any): Promise<boolean> {
    if (!args.constraints || args.constraints.length < 2) {
      throw new Error(
        "Invalid constraints provided to IsUnique decorator. Expected [model, field]."
      );
    }

    const [model, field] = args.constraints;
    const idField = args.object["id"];

    // Check if the model exists in PrismaService
    if (!(model in this.prisma)) {
      throw new BadRequestException(
        `Model '${model}' not found in Prisma schema.`
      );
    }

    // Dynamically query the model
    const result = await (this.prisma as any)[model].findFirst({
      where: {
        [field]: value,
        ...(idField ? { NOT: { id: idField } } : {}),
      },
    });

    return !result;
  }

  defaultMessage(args: any) {
    return `${args.property} must be unique`;
  }
}

export function IsUnique(
  constraints: [model: string, field: string, id?: string],
  validationOptions?: ValidationOptions
) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName,
      options: validationOptions,
      constraints,
      validator: IsUniqueConstraint,
    });
  };
}
