import { Module } from "@nestjs/common";
import { IsUniqueConstraint } from "./validators.service";
import { PrismaService } from "src/prisma/prisma.service";
import { IsCompositeUniqueConstraint } from "./is-composite-unique.validator";

@Module({
  providers: [PrismaService, IsUniqueConstraint, IsCompositeUniqueConstraint],
  exports: [IsUniqueConstraint, IsCompositeUniqueConstraint],
})
export class ValidatorsModule {}
