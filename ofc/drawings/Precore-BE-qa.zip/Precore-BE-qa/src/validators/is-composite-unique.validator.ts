import {
  registerDecorator,
  ValidationArguments,
  ValidationOptions,
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from "class-validator";
import { Injectable, BadRequestException } from "@nestjs/common";
import { PrismaService } from "src/prisma/prisma.service";

@ValidatorConstraint({ name: "IsCompositeUnique", async: true })
@Injectable()
export class IsCompositeUniqueConstraint
  implements ValidatorConstraintInterface
{
  constructor(private readonly prisma: PrismaService) {}

  async validate(_: any, args: ValidationArguments): Promise<boolean> {
    const [model, fields] = args.constraints as [string, string[]];

    if (!model || !Array.isArray(fields) || fields.length === 0) {
      throw new Error(
        "Invalid constraints. Usage: @IsCompositeUnique('modelName', ['field1', 'field2'])"
      );
    }

    if (!(model in this.prisma)) {
      throw new BadRequestException(
        `Model '${model}' not found in PrismaService.`
      );
    }

    // Build 'where' condition using values from the object
    const where: Record<string, any> = {};
    for (const field of fields) {
      where[field] = (args.object as any)[field];
    }

    const result = await (this.prisma as any)[model].findFirst({ where });

    return !result; // valid if result is null (i.e., unique)
  }

  defaultMessage(args: ValidationArguments) {
    const [_, fields] = args.constraints;
    return `Combination of ${fields.join(", ")} must be unique`;
  }
}

export function IsCompositeUnique(
  model: string,
  fields: string[],
  validationOptions?: ValidationOptions
) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName,
      constraints: [model, fields],
      options: validationOptions,
      validator: IsCompositeUniqueConstraint,
    });
  };
}
