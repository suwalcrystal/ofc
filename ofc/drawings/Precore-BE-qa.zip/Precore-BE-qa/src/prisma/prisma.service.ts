import { Injectable, OnModuleInit } from "@nestjs/common";
import { PrismaClient } from "@prisma/client";

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  async onModuleInit() {
    await this.$connect();

    // this.$use(async (params, next) => {
    //   // Check if this is a find operation
    //   if (params.action === "findUnique" || params.action === "findFirst") {
    //     // Add deleted filter
    //     params.action = "findFirst";
    //     params.args.where = {
    //       ...params.args.where,
    //       deleted: false,
    //     };
    //   }

    //   // Check if this is a findMany operation
    //   if (params.action === "findMany") {
    //     // Add deleted filter
    //     if (!params.args) params.args = {};
    //     if (!params.args.where) params.args.where = {};

    //     // Add filter
    //     params.args.where = {
    //       ...params.args.where,
    //       deleted: false,
    //     };
    //   }

    //   // Implement soft delete for delete operations
    //   if (params.action === "delete") {
    //     // Change action to update
    //     params.action = "update";
    //     params.args.data = {
    //       deleted: true,
    //       deletedAt: new Date(),
    //     };
    //   }

    //   // Same for deleteMany
    //   if (params.action === "deleteMany") {
    //     // Change action to updateMany
    //     params.action = "updateMany";
    //     if (!params.args) params.args = {};
    //     if (!params.args.data) params.args.data = {};

    //     params.args.data = {
    //       ...params.args.data,
    //       deleted: true,
    //       deletedAt: new Date(),
    //     };
    //   }

    //   return next(params);
    // });
  }
}
