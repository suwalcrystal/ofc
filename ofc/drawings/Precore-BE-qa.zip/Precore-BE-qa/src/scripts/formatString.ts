export const modelNameToKebabCase = (inputString: string) => {
  return inputString
    .replace(/([a-z0-9])([A-Z])/g, "$1-$2") // insert hyphen before capital letters
    .replace(/([A-Z])([A-Z][a-z])/g, "$1-$2") // handle consecutive capitals
    .toLowerCase();
};

export const modelNameToCamelCase = (inputString: string) => {
  return inputString.charAt(0).toLowerCase() + inputString.slice(1);
};
