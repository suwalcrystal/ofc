import { writeFileSync, mkdirSync, existsSync } from "fs";
import { join } from "path";
import { PrismaService } from "../prisma/prisma.service"; // (this import can be removed if you don't really instantiate PrismaService here)
import { ServiceGenerator } from "./generate-service";
import { ControllerGenerator } from "./generate-controller";
import { modelNameToKebabCase } from "./formatString";
export class RepositoryGenerator {
  generateRepository(modelName: string, compositeKeys: string[] = []): string {
    const modelNameLower =
      modelName.charAt(0).toLowerCase() + modelName.slice(1);
    const isComposite = compositeKeys.length >= 2;

    const compositeKeyName = isComposite ? compositeKeys.join("_") : "id";

    const compositeKeyParams = isComposite
      ? compositeKeys.map((key) => `${key}: string`).join(", ")
      : "id: string";

    const compositeKeyObject = isComposite
      ? `{ ${compositeKeys.join(", ")} }`
      : "{ id }";

    return `
import { Injectable } from "@nestjs/common";
import { ${modelName}, Prisma } from "@prisma/client";
import { PrismaService } from "src/prisma/prisma.service";

@Injectable()
export class ${modelName}Repository {
  constructor(private prisma: PrismaService) {}

  async getById(${compositeKeyParams}): Promise<${modelName} | null> {
    return this.prisma.${modelNameLower}.findUnique({
      where: {
        ${compositeKeyName}: ${compositeKeyObject}
      }
    });
  }

  async create(data: Prisma.${modelName}UncheckedCreateInput): Promise<${modelName}> {
    return this.prisma.${modelNameLower}.create({ data });
  }

  async update(${compositeKeyParams}, data: Partial<${modelName}>): Promise<${modelName}> {
    return this.prisma.${modelNameLower}.update({
      where: {
        ${compositeKeyName}: ${compositeKeyObject}
      },
      data
    });
  }

  async delete(${compositeKeyParams}): Promise<${modelName}> {
    return this.prisma.${modelNameLower}.delete({
      where: {
        ${compositeKeyName}: ${compositeKeyObject}
      }
    });
  }
}
`.trim();
  }
}

const args = process.argv.slice(2);
const modelName = args[0]; // "ProjectMember"
const isComposite = args[1] === "composite";
const compositeKeys = isComposite ? args.slice(2) : [];

if (!modelName) {
  console.error("❌ Please provide a model name, e.g., Supplier");
  process.exit(1);
}

const generator = new RepositoryGenerator();
const content = generator.generateRepository(modelName, compositeKeys);

// Determine folder and file
const folderPath = join(
  __dirname,
  `../modules/${modelNameToKebabCase(modelName)}`
); // e.g., ../supplier
const filePath = join(
  folderPath,
  `${modelNameToKebabCase(modelName)}.repository.ts`
);

// Ensure folder exists
if (!existsSync(folderPath)) {
  mkdirSync(folderPath, { recursive: true });
}

// Write the file
writeFileSync(filePath, content.trim());

console.log(`✅ Repository generated: ${filePath}`);

const serviceGenerator = new ServiceGenerator();
const serviceContent = serviceGenerator.generateService(
  modelName,
  compositeKeys
);

const controllerGenerator = new ControllerGenerator();
const controllerContent = controllerGenerator.generateController(
  modelName,
  compositeKeys
);

// Write Service File
const serviceFilePath = join(
  folderPath,
  `${modelNameToKebabCase(modelName)}.service.ts`
);
writeFileSync(serviceFilePath, serviceContent);
console.log(`✅ Service generated: ${serviceFilePath}`);

const controllerFilePath = join(
  folderPath,
  `${modelNameToKebabCase(modelName)}.controller.ts`
);
writeFileSync(controllerFilePath, controllerContent);
console.log(`✅ Controller generated: ${controllerFilePath}`);
