import { modelNameToCamelCase, modelNameToKebabCase } from "./formatString";

export class ServiceGenerator {
  generateService(modelName: string, compositeKeys: string[] = []): string {
    const isComposite = compositeKeys.length >= 2;
    const modelNameCamel =
      modelName.charAt(0).toLowerCase() + modelName.slice(1);
    const createDto = `Create${modelName}Dto`;
    const updateDto = `Update${modelName}Dto`;

    const compositeParams = compositeKeys
      .map((key) => `@Param('${key}') ${key}: string`)
      .join(", ");

    const compositeKeyName = compositeKeys.join("_");
    const compositeKeyObject = `{
      ${compositeKeyName}: { ${compositeKeys.map((k) => `${k}`).join(", ")} }
    }`;

    return `
import { Injectable,Param } from "@nestjs/common";
import { ${createDto} } from "./dto/create-${modelNameToKebabCase(modelName)}.dto";
import { ${updateDto} } from "./dto/update-${modelNameToKebabCase(modelName)}.dto";
import { GenericCrudService } from "src/common/crud/generic-crud.service";
import { ${modelName}Repository } from "./${modelNameToKebabCase(modelName)}.repository";
@Injectable()
export class ${modelName}Service {
  constructor(private readonly crud: GenericCrudService,private readonly repository: ${modelName}Repository) {}

  create(data: ${createDto}) {
    ${
      isComposite
        ? `return this.repository.create(data as Prisma.${modelName}UncheckedCreateInput);`
        : `return this.crud.create("${modelNameCamel}", data);`
    }
  }

  findAll() {
    ${
      isComposite
        ? `throw new Error("findAll not implemented for composite-key models.");`
        : `return this.crud.findAll("${modelNameCamel}");`
    }
  }

   findOne(${isComposite ? compositeParams : '@Param("id") id: string'}) {
    ${
      isComposite
        ? `return this.repository.getByCompositeKeys(${compositeKeys.join(", ")});`
        : `return this.crud.findOne("${modelNameCamel}", id);`
    }
  }
    
  

 update(${isComposite ? compositeParams + ", " : '@Param("id") id: string, '} data: ${updateDto}) {
    ${
      isComposite
        ? `return this.repository.update(${compositeKeys.join(", ")}, data);`
        : `return this.crud.update("${modelNameCamel}", id, data);`
    }
  }

  remove(${isComposite ? compositeParams : '@Param("id") id: string'}) {
    ${
      isComposite
        ? `return this.repository.delete(${compositeKeys.join(", ")});`
        : `return this.crud.remove("${modelNameCamel}", id);`
    }
  }
}
`.trim();
  }
}
