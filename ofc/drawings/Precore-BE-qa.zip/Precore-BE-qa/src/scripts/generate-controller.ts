import { writeFileSync, mkdirSync, existsSync } from "fs";
import { join } from "path";
import { ServiceGenerator } from "./generate-service";
import { modelNameToCamelCase, modelNameToKebabCase } from "./formatString";

export class ControllerGenerator {
  generateController(modelName: string, compositeKeys: string[] = []): string {
    const isComposite = compositeKeys.length >= 2;
    const modelKebab = modelNameToKebabCase(modelName);
    const modelCamel = modelNameToCamelCase(modelName);
    const compositeParams = compositeKeys.map((key) => `:${key}`).join("/");
    const compositeHandlerParams = compositeKeys
      .map((key) => `@Param('${key}') ${key}: string`)
      .join(", ");

    const compositeKeyName = compositeKeys.join("_");
    const compositeWhereObject = `{ ${compositeKeyName}: { ${compositeKeys.join(", ")} } }`;

    return `
import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { ${modelName}Service } from './${modelKebab}.service';
import { Create${modelName}Dto } from './dto/create-${modelKebab}.dto';
import { Update${modelName}Dto } from './dto/update-${modelKebab}.dto';
import { GenerateResponseMessage } from 'src/helperServices/generateResponseMessage';

@Controller('${modelKebab}')
export class ${modelName}Controller {
  constructor(
    private readonly ${modelCamel}Service: ${modelName}Service,
    private readonly generateResponseService: GenerateResponseMessage
  ) {}

  @Post()
  async create(@Body() create${modelName}Dto: Create${modelName}Dto) {
    return {
      data: await this.${modelCamel}Service.create(create${modelName}Dto),
      message: this.generateResponseService.generateCreateMessage('${modelName}'),
    };
  }

  @Get()
  async findAll() {
    return {
      data: await this.${modelCamel}Service.findAll(),
      message: this.generateResponseService.generateFindAllMessage('${modelName}'),
    };
  }

  @Get('${isComposite ? compositeParams : ":id"}')
  async findOne(${isComposite ? compositeHandlerParams : '@Param("id") id: string'}) {
    return {
      data: await this.${modelCamel}Service.findOne(${isComposite ? (compositeKeys[0], compositeKeys[1]) : "id"}),
      message: this.generateResponseService.generateFindOneMessage('${modelName}'),
    };
  }

  @Patch('${isComposite ? compositeParams : ":id"}')
  async update(
    ${isComposite ? compositeHandlerParams : '@Param("id") id: string'},
    @Body() update${modelName}Dto: Update${modelName}Dto
  ) {
    return {
      data: await this.${modelCamel}Service.update(${isComposite ? (compositeKeys[0], compositeKeys[1]) : "id"}, update${modelName}Dto),
      message: this.generateResponseService.generateUpdateMessage('${modelName}'),
    };
  }

  @Delete('${isComposite ? compositeParams : ":id"}')
  async remove(${isComposite ? compositeHandlerParams : '@Param("id") id: string'}) {
    return {
      data: await this.${modelCamel}Service.remove(${isComposite ? (compositeKeys[0], compositeKeys[1]) : "id"}),
      message: this.generateResponseService.generateDeleteMessage('${modelName}'),
    };
  }
}
`.trim();
  }

  // Function to generate the controller file
  generateControllerFile(modelName: string, compositeKeys: string[] = []) {
    const content = this.generateController(modelName, compositeKeys);
    const folderPath = join(
      __dirname,
      `../modules/${modelNameToKebabCase(modelName)}`
    );
    const filePath = join(
      folderPath,
      `${modelNameToKebabCase(modelName)}.controller.ts`
    );

    if (!existsSync(folderPath)) {
      mkdirSync(folderPath, { recursive: true });
    }

    writeFileSync(filePath, content.trim());
  }
}
