export default () => ({
  APP_PORT_LOCAL: process.env.APP_PORT_LOCAL
    ? parseInt(process.env.APP_PORT_LOCAL)
    : 8000,
});
