import { ConfigModuleOptions } from "@nestjs/config/dist/interfaces";
import databaseConfig from "./database.config";
import paginationConfig from "./pagination.config";
import googleOauthConfig from "./google-oauth.config";
import jwtConfig from "./jwt.config";
import configurationConfig from "./configuration.config";
import * as Joi from "@hapi/joi";

export const appConfigs: ConfigModuleOptions = {
  isGlobal: true,
  envFilePath: ".env",
  load: [
    configurationConfig,
    databaseConfig,
    googleOauthConfig,
    jwtConfig,
    paginationConfig,
  ],
  validationSchema: Joi.object({
    APP_ENV: Joi.string()
      .valid("development", "production", "test")
      .default("development"),
    APP_PORT_LOCAL: Joi.number().required(),
    APP_PORT_LAN: Joi.number().required(),
    APP_PER_PAGE: Joi.number().default(15),

    DATABASE_URL: Joi.string().required(),
    TEST_DATABASE_URL: Joi.string().required(),
    CLIENT_ID: Joi.string().required(),
    CLIENT_SECRET: Joi.string().required(),
    CALL_BACK_URL: Joi.string().required(),
    JWT_SECRET: Joi.string().required(),
    // JWT_EXPIRATION_TIME: Joi.string().required(),
    SESSION_SECRET: Joi.string().required(),
  }),
};
