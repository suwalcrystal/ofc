export default (): any => ({
  pagination: {
    pageSize: process.env.APP_PER_PAGE ? parseInt(process.env.APP_PER_PAGE) : 15,
  },
});