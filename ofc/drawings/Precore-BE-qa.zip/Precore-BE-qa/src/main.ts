import { NestFactory } from "@nestjs/core";
import {
  SwaggerModule,
  DocumentBuilder,
  SwaggerDocumentOptions,
} from "@nestjs/swagger";
import { AppModule } from "./app.module";
import helmet from "helmet";
import * as session from "express-session";
import * as passport from "passport";
import { BadRequestException, ValidationPipe } from "@nestjs/common";
import { CustomInterceptor } from "./interceptors/logger.interceptor";
import { TransformInterceptor } from "./interceptors/transform.interceptor";
import { useContainer } from "class-validator";
import { GraphqlExceptionFilter } from "./exceptionFilters/graphql-exception.filter";
import { NestExpressApplication } from "@nestjs/platform-express";
import {
  HTTPExceptionFilter,
  ValidationExceptionFilter,
} from "./exceptionFilters/http-exception.filter";
import { GlobalValidationWithSourcePipe } from "./validators/global-validation-with-source";

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  const config = new DocumentBuilder()
    .setTitle("My API")
    .setDescription("API documentation")
    .setVersion("1.0")
    .addBearerAuth(
      {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT",
        name: "Authorization",
        in: "header",
      },
      "access-token" // This is a key you'll reference later
    )
    .addServer("/api")
    .build();

  const document = SwaggerModule.createDocument(app, config);
  app.use("/api-json", (req, res) => res.json(document));
  app.use(
    session({
      secret: process.env.SESSION_SECRET as string,
      saveUninitialized: false,
      resave: false,
      cookie: {
        maxAge: 60000,
      },
    })
  );
  useContainer(app.select(AppModule), { fallbackOnErrors: true });
  app.useGlobalFilters(new GraphqlExceptionFilter());
  // app.useGlobalPipes(
  //   new ValidationPipe({
  //     transform: true, // Enables automatic transformation of plain objects to DTO instances
  //     whitelist: true, // Removes properties not defined in the DTO
  //     forbidNonWhitelisted: true, // Throws an error if non-whitelisted properties are present
  //   })
  // );
  app.useGlobalPipes(new GlobalValidationWithSourcePipe());

  app.useGlobalInterceptors(new CustomInterceptor());

  app.useGlobalInterceptors(new TransformInterceptor());

  app.use(passport.initialize());
  app.use(passport.session());
  app.use(
    helmet({
      crossOriginEmbedderPolicy: false,
      contentSecurityPolicy: {
        directives: {
          defaultSrc: [`'self'`],
          imgSrc: [`'self'`, "data:", "validator.swagger.io"],
          scriptSrc: [`'self'`, `https: 'unsafe-inline'`],
          manifestSrc: [
            `'self'`,
            "apollo-server-landing-page.cdn.apollographql.com",
          ],
          frameSrc: [`'self'`, "sandbox.embed.apollographql.com"],
        },
      },
    })
  );

  SwaggerModule.setup("api", app, document, {
    swaggerOptions: {
      docExpansion: "none", // 'none' = collapsed by default, 'list' = expanded tags, 'full' = everything expanded
    },
  });

  app.useGlobalFilters(new HTTPExceptionFilter());
  app.useGlobalFilters(new ValidationExceptionFilter());

  const APP_PORT = process.env.APP_PORT ? parseInt(process.env.APP_PORT) : 8000;

  app.setGlobalPrefix("api");
  app.enableCors({
    origin: "*", // or restrict to frontend IP later
  });
  await app.listen(APP_PORT, "0.0.0.0"); // listen on port 8000
  console.log(`Listening on http://0.0.0.0:${APP_PORT}`);
}
bootstrap();
