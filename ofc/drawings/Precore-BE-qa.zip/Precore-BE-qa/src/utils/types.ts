export type UserDetails = {
  email: string
  name: string
}