import { Prisma } from "@prisma/client";
import { Request } from "express";
import * as moment from "moment";

export interface PaginationResult<T> {
  records: T[];
  pagination: {
    totalRecords: number;
    perPage: number;
    currentPage: number;
    next: number | null;
    prev: number | null;
    totalPages: number;
    pagingCounter: number;
    hasPrevious: boolean;
    hasNext: boolean;
    recordShown: number;
  };
}

export const getMatchAndSortData = async (req: Request) => {
  let matchData: Record<string, any> = {};
  let sortData: Record<string, any> = { createdAt: "desc" };

  if (req.query.sortBy || req.query.orderBy) {
    const orderBy = req.query.orderBy ? req.query.orderBy : "desc";
    sortData = {
      [req.query.sortBy as string]: orderBy as "asc" | "desc",
    };
  }

  if (req.query.startDate && req.query.endDate) {
    matchData["createdAt"] = {
      gte: new Date(req.query.startDate as string),
      lt: moment(req.query.endDate as string)
        .add(1, "days")
        .toDate(),
    };
  } else if (req.query.startDate) {
    matchData["createdAt"] = {
      gte: new Date(req.query.startDate as string),
    };
  } else if (req.query.endDate) {
    matchData["createdAt"] = {
      lt: moment(req.query.endDate as string)
        .add(1, "days")
        .toDate(),
    };
  }

  if (req.query.createdDate) {
    matchData["createdAt"] = {
      gte: new Date(req.query.createdDate as string),
      lt: moment(req.query.createdDate as string)
        .add(1, "days")
        .toDate(),
    };
  }

  if (req.query.updatedDate) {
    matchData["updatedAt"] = {
      gte: new Date(req.query.updatedDate as string),
      lt: moment(req.query.updatedDate as string)
        .add(1, "days")
        .toDate(),
    };
  }

  return {
    matchData,
    sortData,
  };
};

export async function paginatedData<
  T,
  WhereInput,
  FindManyArgs extends {
    where?: WhereInput;
    orderBy?: any;
    include?: any;
    select?: any;
  },
>(
  model: {
    count: (args: { where?: WhereInput }) => Promise<number>;
    findMany: (args: FindManyArgs) => Promise<T[]>;
  },
  match: WhereInput,
  sort: Record<string, "asc" | "desc">,
  page = 1,
  perPage = 10,
  includeObj?: FindManyArgs["include"],
  select?: FindManyArgs["select"]
): Promise<PaginationResult<T>> {
  const skip = (page - 1) * perPage;
  const totalRecords = await model.count({ where: match });

  const records = await model.findMany({
    where: match,
    orderBy: sort,
    skip,
    take: typeof perPage === "string" ? parseInt(perPage) : perPage,
    include: includeObj,
    select,
  } as unknown as FindManyArgs);

  const totalPages = Math.ceil(totalRecords / perPage);
  const pagingCounter = skip + 1;

  return {
    records,
    pagination: {
      totalRecords: totalRecords,
      perPage,
      currentPage: page,
      totalPages,
      next: page < totalPages ? page + 1 : null,
      prev: page > 1 ? page - 1 : null,
      pagingCounter,
      hasPrevious: page > 1,
      hasNext: page < totalPages,
      recordShown: records.length + skip,
    },
  };
}
