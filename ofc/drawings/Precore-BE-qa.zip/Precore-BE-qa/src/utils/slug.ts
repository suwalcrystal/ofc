import { PrismaClient } from "@prisma/client";
import slugify from "slugify";

const prisma = new PrismaClient();

export async function generateUniqueSlug<T extends keyof PrismaClient>(
  name: string,
  modelName: T,
  idToExclude: string | null = null
): Promise<string> {
  let slug = slugify(name, { lower: true });
  let counter = 1;
  const model = prisma[modelName] as any;
  while (
    await model.findFirst({
      where: {
        slug,
        ...(idToExclude && { id: { not: idToExclude } }),
      },
    })
  ) {
    slug = slugify(`${name}-${counter}`, { lower: true });
    counter++;
  }

  return slug;
}
