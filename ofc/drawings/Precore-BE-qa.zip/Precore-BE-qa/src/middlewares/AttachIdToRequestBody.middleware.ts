// src/common/middleware/attach-id-to-body.middleware.ts
import { Injectable, NestMiddleware } from "@nestjs/common";
import { Request, Response, NextFunction } from "express";

@Injectable()
export class AttachIdToBodyMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    if (req.params?.id) {
      req.body.id = req.params.id;
    }
    next();
  }
}
