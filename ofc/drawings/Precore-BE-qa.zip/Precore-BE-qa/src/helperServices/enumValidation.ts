import {
  registerDecorator,
  ValidationOptions,
  ValidationArguments,
} from "class-validator";

/**
 * Custom validator decorator for enum values with improved error messages
 * @param enumType The enum to validate against
 * @param validationOptions Additional validation options
 */
export function IsValidEnum(
  enumType: object,
  validationOptions?: ValidationOptions
) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: "isValidEnum",
      target: object.constructor,
      propertyName: propertyName,
      options: {
        message: (args: ValidationArguments) => {
          const enumValues = Object.values(enumType).join(" or ");
          return `${args.property} must be ${enumValues}`;
        },
        ...validationOptions,
      },
      validator: {
        validate(value: any, args: ValidationArguments) {
          if (value === null || value === undefined) {
            return true;
          }

          const enumValues = Object.values(enumType);
          return enumValues.includes(value);
        },
      },
    });
  };
}
