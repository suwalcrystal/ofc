import { Injectable } from "@nestjs/common";

type FlattenInstruction = Record<string, string>;

@Injectable()
export class FormatArrayObjectsWithFieldsOnly {
  flattenNestedFields<T extends Record<string, any>>(
    obj: T,
    instructions: FlattenInstruction,
    pathsToDelete: string[] = []
  ): T {
    const newItem = { ...obj }; // Clone the original object

    Object.entries(instructions).forEach(([sourcePath, destinationPath]) => {
      // Extract the value from the source path
      const fieldValue = sourcePath.split(".").reduce(
        (nestedObj, key) => {
          return nestedObj?.[key];
        },
        obj as Record<string, any>
      );

      if (fieldValue !== undefined) {
        // Use reduce again to set the value to the destination path in the newItem
        const destinationKeys = destinationPath.split(".");
        let target: Record<string, any> = newItem; // Explicitly define target as Record<string, any>

        destinationKeys.forEach((key, index) => {
          if (index === destinationKeys.length - 1) {
            target[key] = fieldValue; // Set the value at the final key
          } else {
            target[key] = target[key] || {}; // Create intermediate objects if needed
            target = target[key];
          }
        });
      }
    });

    pathsToDelete.forEach((path) => {
      const keys = path.split(".");
      const lastKey = keys.pop();
      const parent = keys.reduce((acc, key) => acc?.[key], newItem);

      if (parent && lastKey && lastKey in parent) {
        delete parent[lastKey];
      }
    });

    return newItem;
  }
}
