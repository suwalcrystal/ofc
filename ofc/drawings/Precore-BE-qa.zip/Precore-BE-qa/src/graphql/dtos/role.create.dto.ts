import { Field, InputType } from "@nestjs/graphql";

@InputType()
export class CreateRoleInput {
  @Field()
  title: string;

  @Field()
  roleCode: string;
}
