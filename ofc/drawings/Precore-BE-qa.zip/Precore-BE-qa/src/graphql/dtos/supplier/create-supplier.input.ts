// // src/supplier/dto/create-supplier.input.ts
// import { Field, InputType } from "@nestjs/graphql";
// import { BaseSupplierInput } from "src/sharedDtos/baseCreateSupplier.input";
// import { GraphQLUpload, FileUpload } from "graphql-upload-minimal";
// @InputType()
// export class CreateSupplierInput extends BaseSupplierInput {
//   @Field()
//   name: string;

//   @Field({ nullable: true })
//   description?: string;

//   @Field(() => GraphQLUpload, { nullable: true }) // Make it nullable
//   image?: FileUpload;

//   @Field({ nullable: true })
//   link?: string;
// }
