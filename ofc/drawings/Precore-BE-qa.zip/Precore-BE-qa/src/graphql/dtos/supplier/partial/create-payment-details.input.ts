// // src/supplier/dto/create-supplier.input.ts
// import { Field, InputType } from "@nestjs/graphql";
// import { BaseSupplierInput } from "src/sharedDtos/baseCreateSupplier.input";

// @InputType()
// export class CreatePaymentDetailsInput {
//   @Field()
//   name: string;

//   @Field({ nullable: true })
//   description?: string;

//   @Field({ nullable: true })
//   link?: string;

//   @Field({ nullable: true })
//   supplierId?: string;
// }
