// import { Module } from "@nestjs/common";
// import { PrismaService } from "src/prisma/prisma.service";
// import { RoleResolver } from "./resolvers/role.resolver";
// import { RoleRepository } from "src/role/role.repository";
// import { RoleModule } from "src/role/role.module";
// import { Item } from "./models/item.model";
// import { ItemModule } from "src/item/item.module";
// import { ItemCategory } from "./models/itemCategory.model";
// import { ItemCategoryModule } from "src/item-category/item-category.module";
// import { ItemCategoryResolver } from "./resolvers/itemCategory.resolver";
// import { Book } from "./models/author.model";
// import { BookResolver } from "./resolvers/book.resolver";
// import { AuthorResolver } from "./resolvers/author.resolver";
// import { PaymentDetailsResolver } from "./resolvers/paymentDetails.resolver";
// import { SupplierResolver } from "./resolvers/supplier.resolver";
// import { AuthRepository } from "src/modules/auth/auth.repository";
// import { SupplierModule } from "src/modules/supplier/supplier.module";

// @Module({
//   imports: [RoleModule, ItemModule, ItemCategoryModule, SupplierModule],
//   providers: [
//     PrismaService,
//     RoleResolver,
//     ItemCategoryResolver,
//     BookResolver,
//     AuthorResolver,
//     PaymentDetailsResolver,
//     SupplierResolver,
//     AuthRepository,
//   ],
//   exports: [
//     RoleResolver,
//     ItemCategoryResolver,
//     BookResolver,
//     AuthorResolver,
//     PaymentDetailsResolver,
//     SupplierResolver,
//   ],
// })
// export class GraphqlModule {}
