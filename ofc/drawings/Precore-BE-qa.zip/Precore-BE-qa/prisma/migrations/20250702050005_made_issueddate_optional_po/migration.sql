-- AlterTable
ALTER TABLE "PurchaseOrder" ALTER COLUMN "issuedDate" DROP NOT NULL,
ALTER COLUMN "issuedDate" DROP DEFAULT;
