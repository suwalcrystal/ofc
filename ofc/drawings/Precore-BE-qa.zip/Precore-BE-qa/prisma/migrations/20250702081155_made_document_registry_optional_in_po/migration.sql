-- DropForeignKey
ALTER TABLE "PurchaseOrder" DROP CONSTRAINT "PurchaseOrder_documentRegistryId_fkey";

-- AlterTable
ALTER TABLE "PurchaseOrder" ALTER COLUMN "documentRegistryId" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "PurchaseOrder" ADD CONSTRAINT "PurchaseOrder_documentRegistryId_fkey" FOREIGN KEY ("documentRegistryId") REFERENCES "DocumentRegistry"("id") ON DELETE SET NULL ON UPDATE CASCADE;
