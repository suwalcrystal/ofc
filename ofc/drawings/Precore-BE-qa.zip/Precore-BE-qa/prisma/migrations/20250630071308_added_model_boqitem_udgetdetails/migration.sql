-- CreateTable
CREATE TABLE "BOQItemBudgetDetails" (
    "id" TEXT NOT NULL,
    "boqItemId" TEXT NOT NULL,
    "packageName" "PACKAGE_TYPE" NOT NULL DEFAULT 'enabling',
    "budgetId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BOQItemBudgetDetails_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "BOQItemBudgetDetails" ADD CONSTRAINT "BOQItemBudgetDetails_boqItemId_fkey" FOREIGN KEY ("boqItemId") REFERENCES "BOQItem"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BOQItemBudgetDetails" ADD CONSTRAINT "BOQItemBudgetDetails_budgetId_fkey" FOREIGN KEY ("budgetId") REFERENCES "Budget"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
