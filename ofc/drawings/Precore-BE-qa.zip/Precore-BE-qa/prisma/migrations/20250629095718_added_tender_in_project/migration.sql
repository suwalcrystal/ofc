-- AddForeignKey
ALTER TABLE "Project" ADD CONSTRAINT "Project_tenderId_fkey" FOREIGN KEY ("tenderId") REFERENCES "Tender"("id") ON DELETE SET NULL ON UPDATE CASCADE;
