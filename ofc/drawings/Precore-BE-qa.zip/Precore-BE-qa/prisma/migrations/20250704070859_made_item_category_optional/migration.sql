-- AlterTable
ALTER TABLE "Item" ALTER COLUMN "itemCategoryId" DROP NOT NULL;
