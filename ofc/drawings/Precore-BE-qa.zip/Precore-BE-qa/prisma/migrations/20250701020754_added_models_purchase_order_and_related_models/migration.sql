-- AlterTable
ALTER TABLE "RFQLineItem" ADD COLUMN     "sourcePRLineItemId" TEXT;

-- AlterTable
ALTER TABLE "RequestForQuote" ADD COLUMN     "sourcePurchaseRequestId" TEXT;

-- CreateTable
CREATE TABLE "PRLineItemFulfillment" (
    "id" TEXT NOT NULL,
    "prLineItemId" TEXT NOT NULL,
    "poLineItemId" TEXT NOT NULL,
    "quantityFulfilled" DOUBLE PRECISION NOT NULL,
    "fulfilledAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PRLineItemFulfillment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PurchaseOrder" (
    "id" TEXT NOT NULL,
    "documentRegistryId" TEXT NOT NULL,
    "createdFromPrId" TEXT,
    "supplierId" TEXT NOT NULL,
    "createdById" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "issuedDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expectedDelivery" TIMESTAMP(3),
    "notes" TEXT,

    CONSTRAINT "PurchaseOrder_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PurchaseOrderLineItem" (
    "id" TEXT NOT NULL,
    "purchaseOrderId" TEXT NOT NULL,
    "itemId" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "quantity" DOUBLE PRECISION NOT NULL,
    "unit" TEXT NOT NULL,
    "unitPrice" DOUBLE PRECISION NOT NULL,
    "deliveryDate" TIMESTAMP(3),
    "sourcePrLineItemId" TEXT,
    "rfqLineItemId" TEXT,

    CONSTRAINT "PurchaseOrderLineItem_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "RequestForQuote" ADD CONSTRAINT "RequestForQuote_sourcePurchaseRequestId_fkey" FOREIGN KEY ("sourcePurchaseRequestId") REFERENCES "PurchaseRequests"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RFQLineItem" ADD CONSTRAINT "RFQLineItem_sourcePRLineItemId_fkey" FOREIGN KEY ("sourcePRLineItemId") REFERENCES "PurchaseRequestLineItems"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PRLineItemFulfillment" ADD CONSTRAINT "PRLineItemFulfillment_prLineItemId_fkey" FOREIGN KEY ("prLineItemId") REFERENCES "PurchaseRequestLineItems"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseOrder" ADD CONSTRAINT "PurchaseOrder_documentRegistryId_fkey" FOREIGN KEY ("documentRegistryId") REFERENCES "DocumentRegistry"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseOrder" ADD CONSTRAINT "PurchaseOrder_createdFromPrId_fkey" FOREIGN KEY ("createdFromPrId") REFERENCES "PurchaseRequests"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseOrder" ADD CONSTRAINT "PurchaseOrder_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES "Supplier"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseOrder" ADD CONSTRAINT "PurchaseOrder_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseOrderLineItem" ADD CONSTRAINT "PurchaseOrderLineItem_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES "PurchaseOrder"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseOrderLineItem" ADD CONSTRAINT "PurchaseOrderLineItem_sourcePrLineItemId_fkey" FOREIGN KEY ("sourcePrLineItemId") REFERENCES "PurchaseRequestLineItems"("id") ON DELETE SET NULL ON UPDATE CASCADE;
