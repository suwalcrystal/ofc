/*
  Warnings:

  - You are about to drop the column `description` on the `ItemType` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "ItemType" DROP COLUMN "description",
ADD COLUMN     "status" "ACTIVE_INACTIVE" NOT NULL DEFAULT 'active';
