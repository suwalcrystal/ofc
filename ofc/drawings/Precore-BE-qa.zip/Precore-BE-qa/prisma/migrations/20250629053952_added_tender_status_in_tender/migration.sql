-- CreateEnum
CREATE TYPE "TENDER_STATUS" AS ENUM ('sourced', 'won', 'lost');

-- AlterTable
ALTER TABLE "Tender" ADD COLUMN     "tenderStatus" "TENDER_STATUS" NOT NULL DEFAULT 'sourced';
