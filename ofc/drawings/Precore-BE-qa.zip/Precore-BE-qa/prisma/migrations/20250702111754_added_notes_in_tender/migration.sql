-- AlterTable
ALTER TABLE "Tender" ADD COLUMN     "notes" TEXT;
