/*
  Warnings:

  - You are about to drop the column `description` on the `ItemCategory` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "ItemCategory" DROP COLUMN "description",
ADD COLUMN     "status" "ACTIVE_INACTIVE" NOT NULL DEFAULT 'active';
