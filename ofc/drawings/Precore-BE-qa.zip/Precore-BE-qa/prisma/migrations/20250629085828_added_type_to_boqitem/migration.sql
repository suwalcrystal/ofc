-- CreateEnum
CREATE TYPE "DOCUMENT_BOQITEM" AS ENUM ('tender', 'project');

-- AlterTable
ALTER TABLE "BOQItem" ADD COLUMN     "type" "DOCUMENT_BOQITEM" NOT NULL DEFAULT 'tender';
