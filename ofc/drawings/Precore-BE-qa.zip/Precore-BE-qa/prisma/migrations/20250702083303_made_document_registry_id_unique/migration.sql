/*
  Warnings:

  - A unique constraint covering the columns `[documentRegistryId]` on the table `PurchaseOrder` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "PurchaseOrder_documentRegistryId_key" ON "PurchaseOrder"("documentRegistryId");
