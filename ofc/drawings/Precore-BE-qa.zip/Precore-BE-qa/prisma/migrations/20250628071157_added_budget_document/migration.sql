-- CreateTable
CREATE TABLE "Budgeting" (
    "id" TEXT NOT NULL,
    "documentRegistryId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Budgeting_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "Budgeting" ADD CONSTRAINT "Budgeting_documentRegistryId_fkey" FOREIGN KEY ("documentRegistryId") REFERENCES "DocumentRegistry"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
