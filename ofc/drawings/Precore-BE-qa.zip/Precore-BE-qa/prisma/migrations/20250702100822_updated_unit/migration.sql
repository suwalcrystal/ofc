/*
  Warnings:

  - You are about to drop the column `description` on the `Unit` table. All the data in the column will be lost.

*/
-- CreateEnum
CREATE TYPE "ACTIVE_INACTIVE" AS ENUM ('active', 'inactive');

-- AlterTable
ALTER TABLE "Unit" DROP COLUMN "description",
ADD COLUMN     "status" "ACTIVE_INACTIVE" NOT NULL DEFAULT 'active',
ADD COLUMN     "symbol" TEXT;
