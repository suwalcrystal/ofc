/*
  Warnings:

  - Made the column `documentRegistryId` on table `PurchaseOrder` required. This step will fail if there are existing NULL values in that column.

*/
-- DropForeignKey
ALTER TABLE "PurchaseOrder" DROP CONSTRAINT "PurchaseOrder_documentRegistryId_fkey";

-- AlterTable
ALTER TABLE "PurchaseOrder" ALTER COLUMN "documentRegistryId" SET NOT NULL;

-- AddForeignKey
ALTER TABLE "PurchaseOrder" ADD CONSTRAINT "PurchaseOrder_documentRegistryId_fkey" FOREIGN KEY ("documentRegistryId") REFERENCES "DocumentRegistry"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
