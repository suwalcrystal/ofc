/*
  Warnings:

  - You are about to drop the column `status` on the `PurchaseOrder` table. All the data in the column will be lost.

*/
-- CreateEnum
CREATE TYPE "VENDOR_SUPPLY_STATUS" AS ENUM ('sent_to_vendor', 'received_from_vendor');

-- AlterTable
ALTER TABLE "PurchaseOrder" DROP COLUMN "status",
ADD COLUMN     "vendorSupplyStatus" "VENDOR_SUPPLY_STATUS" NOT NULL DEFAULT 'sent_to_vendor';
