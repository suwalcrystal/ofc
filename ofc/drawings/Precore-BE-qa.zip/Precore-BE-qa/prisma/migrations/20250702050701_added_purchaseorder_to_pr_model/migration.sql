-- CreateTable
CREATE TABLE "PurchaseOrderToPR" (
    "id" TEXT NOT NULL,
    "purchaseOrderId" TEXT NOT NULL,
    "purchaseRequestId" TEXT NOT NULL,

    CONSTRAINT "PurchaseOrderToPR_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "PurchaseOrderToPR_purchaseOrderId_purchaseRequestId_key" ON "PurchaseOrderToPR"("purchaseOrderId", "purchaseRequestId");

-- AddForeignKey
ALTER TABLE "PurchaseOrderToPR" ADD CONSTRAINT "PurchaseOrderToPR_purchaseOrderId_fkey" FOREIGN KEY ("purchaseOrderId") REFERENCES "PurchaseOrder"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PurchaseOrderToPR" ADD CONSTRAINT "PurchaseOrderToPR_purchaseRequestId_fkey" FOREIGN KEY ("purchaseRequestId") REFERENCES "PurchaseRequests"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
