/*
  Warnings:

  - You are about to drop the column `createdFromPrId` on the `PurchaseOrder` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "PurchaseOrder" DROP CONSTRAINT "PurchaseOrder_createdFromPrId_fkey";

-- AlterTable
ALTER TABLE "PurchaseOrder" DROP COLUMN "createdFromPrId";
