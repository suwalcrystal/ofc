/*
  Warnings:

  - You are about to drop the `PurchaseOrderToPR` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "PurchaseOrderToPR" DROP CONSTRAINT "PurchaseOrderToPR_purchaseOrderId_fkey";

-- DropForeignKey
ALTER TABLE "PurchaseOrderToPR" DROP CONSTRAINT "PurchaseOrderToPR_purchaseRequestId_fkey";

-- DropTable
DROP TABLE "PurchaseOrderToPR";
