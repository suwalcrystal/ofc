-- AlterTable
ALTER TABLE "Item" ADD COLUMN     "status" "ACTIVE_INACTIVE" NOT NULL DEFAULT 'active';
